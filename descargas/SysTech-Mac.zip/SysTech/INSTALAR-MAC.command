#!/bin/bash
# Instala SysTech en este Mac (una sola vez).
exec /bin/bash "$(cd "$(dirname "$0")" && pwd)/mac/instalar.sh"
