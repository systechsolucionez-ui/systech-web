#!/bin/bash
# Abre SysTech (lo mismo que el icono del escritorio).
/bin/bash "$(cd "$(dirname "$0")" && pwd)/mac/abrir.sh"
echo "Ya podés cerrar esta ventana."
