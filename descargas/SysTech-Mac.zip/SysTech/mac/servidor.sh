#!/bin/bash
# SysTech para Mac — servidor. Lo arranca abrir.sh en segundo plano.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/comun.sh"
export PORT="$PUERTO" SYSTECH_REINICIO_AUTO=1
echo "[$(date)] Iniciando SysTech" > server-log.txt
while true; do
  node server.js >> server-log.txt 2>&1
  COD=$?
  # Código 75 = el sistema pidió reiniciarse (por ejemplo, tras instalar una actualización)
  if [ "$COD" = 75 ]; then echo "[$(date)] Reiniciando con la nueva versión" >> server-log.txt; sleep 2; continue; fi
  echo "[$(date)] SysTech se detuvo (código $COD)" >> server-log.txt
  break
done
