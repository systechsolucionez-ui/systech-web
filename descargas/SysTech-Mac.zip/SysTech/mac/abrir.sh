#!/bin/bash
# SysTech para Mac — abre el sistema: arranca el servidor en segundo plano (si no está) y después el navegador.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/comun.sh"
if ! arriba; then
  if ! nodeOk || [ ! -d "$DIR/node_modules" ]; then
    open -a Terminal "$DIR/INSTALAR-MAC.command"   # falta instalar: la única vez que se ve una ventana
    exit 0
  fi
  nohup /bin/bash "$DIR/mac/servidor.sh" >/dev/null 2>&1 &
  for _ in $(seq 1 80); do sleep 0.5; arriba && break; done
  if ! arriba; then aviso "SysTech no pudo arrancar. Mirá el archivo server-log.txt de la carpeta SysTech para ver el motivo."; exit 1; fi
fi
open "$URL"
