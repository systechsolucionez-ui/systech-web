#!/bin/bash
# SysTech para Mac — instalación. Se abre con INSTALAR-MAC.command (una sola vez).
#  0) Copia SysTech a la carpeta fija ~/SysTech (si ya estaba instalado, usa esa y no toca los datos)
#  1) Si el Mac no tiene Node.js, baja una copia solo para SysTech (sin contraseña de administrador)
#  2) Instala lo que necesita el sistema
#  3) Crea el icono SysTech en el escritorio y lo abre
ORIGEN="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DESTINO="$HOME/SysTech"
fallo() {
  echo; echo "================================================"; echo "$1"; echo "================================================"
  echo "Revisá la conexión a internet y volvé a abrir INSTALAR-MAC."
  read -r -p "Presioná Enter para cerrar " _; exit 1
}
echo "SysTech para Mac — preparando todo (solo la primera vez)..."
echo

# 0) Carpeta fija
if [ "$ORIGEN" != "$DESTINO" ]; then
  if [ -f "$DESTINO/server.js" ]; then
    echo "0/3  SysTech ya estaba instalado en $DESTINO: uso esa carpeta (tus datos no se tocan)."
    echo "     Para pasar a una versión nueva usá Configuración → Sistema dentro de SysTech."
  else
    echo "0/3  Copiando SysTech a $DESTINO ..."
    mkdir -p "$DESTINO" && cp -R "$ORIGEN"/. "$DESTINO"/ || fallo "No pude copiar los archivos a $DESTINO."
  fi
fi
xattr -dr com.apple.quarantine "$DESTINO" 2>/dev/null
chmod +x "$DESTINO"/*.command "$DESTINO"/mac/*.sh 2>/dev/null
. "$DESTINO/mac/comun.sh" || fallo "Falta la carpeta mac dentro de $DESTINO."

# 1) Node.js
if nodeOk; then
  echo "1/3  Node.js ya está disponible ($(node -v))."
else
  echo "1/3  Descargando Node.js (una sola vez, unos 50 MB)..."
  case "$(uname -m)" in arm64) ARQ=arm64 ;; x86_64) ARQ=x64 ;; *) fallo "Este Mac no es compatible ($(uname -m))." ;; esac
  BASE="https://nodejs.org/dist/latest-v24.x/"
  TMP="$(mktemp -d)" || fallo "No pude crear una carpeta temporal."
  curl -fsSL "${BASE}SHASUMS256.txt" -o "$TMP/sumas" || fallo "No pude bajar la lista de Node.js."
  LINEA="$(grep -E "node-v[0-9.]+-darwin-$ARQ\.tar\.gz$" "$TMP/sumas" | head -1)"
  [ -n "$LINEA" ] || fallo "No encontré la descarga de Node.js para este Mac."
  HASH="${LINEA%% *}"; ARCHIVO="${LINEA##* }"
  curl -fSL --progress-bar "${BASE}${ARCHIVO}" -o "$TMP/$ARCHIVO" || fallo "No pude bajar Node.js."
  [ "$(shasum -a 256 "$TMP/$ARCHIVO" | cut -d' ' -f1)" = "$HASH" ] || fallo "La descarga de Node.js llegó dañada. Probá de nuevo."
  tar -xzf "$TMP/$ARCHIVO" -C "$TMP" || fallo "No pude descomprimir Node.js."
  rm -rf "$DIR/runtime/node"; mkdir -p "$DIR/runtime"
  mv "$TMP/${ARCHIVO%.tar.gz}" "$DIR/runtime/node" || fallo "No pude guardar Node.js."
  rm -rf "$TMP"
  export PATH="$DIR/runtime/node/bin:$PATH"
  nodeOk || fallo "Node.js no quedó funcionando."
  echo "     Node.js listo ($(node -v))."
fi

# 2) Dependencias
if [ ! -d "$DIR/node_modules" ]; then
  echo "2/3  Instalando lo necesario (1-2 minutos, no cierres esta ventana)..."
  npm install --omit=dev --no-audit --no-fund || { rm -rf "$DIR/node_modules"; fallo "No se pudo instalar lo necesario."; }
  node -e "require('better-sqlite3')" 2>/dev/null || { rm -rf "$DIR/node_modules"; fallo "No se pudo preparar la base de datos. Si el Mac pidió instalar las Herramientas de línea de comandos, aceptá, esperá a que terminen y volvé a abrir INSTALAR-MAC."; }
  echo "     Listo."
else
  echo "2/3  Ya estaba instalado."
fi

# 3) Icono en el escritorio (una app chiquita que abre SysTech sin ventanas)
echo "3/3  Creando el icono SysTech en el escritorio..."
APP="$HOME/Desktop/SysTech.app"
if [ ! -d "$APP" ]; then
  RUTA="$(printf '%s' "$DIR/mac/abrir.sh" | sed 's/\\/\\\\/g; s/"/\\"/g')"
  if osacompile -o "$APP" -e "do shell script \"/bin/bash \" & quoted form of \"$RUTA\" & \" >/dev/null 2>&1 &\"" 2>/dev/null; then
    [ -f "$DIR/mac/SysTech.icns" ] && cp "$DIR/mac/SysTech.icns" "$APP/Contents/Resources/applet.icns" && touch "$APP"
  else
    echo "     (No pude crear el icono: abrí SysTech con ABRIR-SYSTECH dentro de $DIR)"
  fi
fi
echo
echo "Todo listo. Desde ahora entrás con el icono SysTech del escritorio."
echo "La carpeta del sistema es $DIR: no la borres ni la muevas."
echo "Ya podés cerrar esta ventana."
/bin/bash "$DIR/mac/abrir.sh"
exit 0
