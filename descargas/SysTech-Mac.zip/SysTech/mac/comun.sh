# SysTech para Mac — lo comparten los demás scripts de esta carpeta (no se abre solo).
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$DIR" || exit 1
PUERTO=3000
if [ -f puerto.txt ]; then p="$(tr -dc '0-9' < puerto.txt)"; [ -n "$p" ] && PUERTO="$p"; fi
URL="http://localhost:$PUERTO"
# Node.js: primero el que se bajó para SysTech (runtime/node); si no, el instalado en el Mac
export PATH="/usr/local/bin:/opt/homebrew/bin:$PATH"
[ -x "$DIR/runtime/node/bin/node" ] && export PATH="$DIR/runtime/node/bin:$PATH"
arriba() { curl -fsS -m 2 "$URL/api/build" >/dev/null 2>&1; }
nodeOk() { command -v node >/dev/null 2>&1 && [ "$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)" -ge 18 ]; }
aviso() { osascript -e "display dialog \"$1\" with title \"SysTech\" buttons {\"OK\"} default button 1 with icon caution" >/dev/null 2>&1 || echo "$1"; }
