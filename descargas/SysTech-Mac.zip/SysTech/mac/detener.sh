#!/bin/bash
# SysTech para Mac — cierra el sistema.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/comun.sh"
PIDS="$(lsof -ti tcp:"$PUERTO" -sTCP:LISTEN 2>/dev/null)"
if [ -n "$PIDS" ]; then kill $PIDS 2>/dev/null; sleep 1; echo "SysTech cerrado."; else echo "SysTech no estaba abierto."; fi
