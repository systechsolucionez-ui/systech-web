#!/bin/bash
# Cierra SysTech y lo vuelve a abrir.
D="$(cd "$(dirname "$0")" && pwd)"
/bin/bash "$D/mac/detener.sh"
sleep 2
/bin/bash "$D/mac/abrir.sh"
echo "Ya podés cerrar esta ventana."
