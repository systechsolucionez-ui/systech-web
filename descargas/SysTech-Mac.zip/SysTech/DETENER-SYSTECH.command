#!/bin/bash
# Cierra SysTech. Para volver a abrirlo usá el icono.
/bin/bash "$(cd "$(dirname "$0")" && pwd)/mac/detener.sh"
echo "Ya podés cerrar esta ventana."
