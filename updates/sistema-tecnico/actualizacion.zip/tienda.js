// ─── TIENDA: comisiones por vendedor, fondo de garantía y garantías generales ───
// Módulo aparte: no toca nada del servicio técnico. Se engancha desde server.js con
//   require('./tienda').registrar(app, deps)  y  tienda.registrarFondoVenta(db, ...)
//
// Reglas acordadas:
//  · Comisión por vendedor: solo la ve/configura el admin (modo transparencia opcional).
//  · Las garantías NO afectan la comisión salvo que el admin lo active.
//  · Fondo de garantía: SIEMPRE activo. Un % del COSTO REAL de lo vendido se reserva;
//    las pérdidas por garantía salen de ahí.
//  · Cambio por garantía: el stock del producto devuelto lo decide el admin.

const DEFAULTS = {
  comision_activa: '0',
  comision_tipo: 'pct_venta',        // pct_venta | pct_margen | fijo_unidad | escalones
  comision_valor: '0',
  comision_categorias: '{}',         // { "<categoria_id>": { tipo, valor } }
  comision_escalones: '[]',          // [ { desde: <ventas $>, pct: <%> } ]
  comision_transparencia: '0',       // 1 = cada vendedor ve la suya
  comision_descuenta_garantia: '0',  // 1 = una devolución por garantía descuenta su comisión
  comision_incluye_tecnicos: '0',    // 1 = las ventas de mostrador hechas por técnicos también pagan comisión de vendedor
  fondo_pct: '2',                    // % del costo real que se reserva
  garantia_dias: '30',               // plazo de garantía de Tienda
};
const TIPOS_COMISION = ['pct_venta', 'pct_margen', 'fijo_unidad', 'escalones'];
const redondear = n => Math.round((Number(n) || 0) * 100) / 100;

function leerConfig(db) {
  const c = { ...DEFAULTS };
  try { db.prepare('SELECT clave,valor FROM tienda_config').all().forEach(r => { if (r.clave in DEFAULTS) c[r.clave] = r.valor; }); } catch (e) {}
  let categorias = {}, escalones = [];
  try { categorias = JSON.parse(c.comision_categorias) || {}; } catch (e) {}
  try { escalones = (JSON.parse(c.comision_escalones) || []).map(e => ({ desde: Number(e.desde) || 0, pct: Number(e.pct) || 0 })).sort((a, b) => a.desde - b.desde); } catch (e) {}
  return {
    activa: c.comision_activa === '1',
    tipo: TIPOS_COMISION.includes(c.comision_tipo) ? c.comision_tipo : 'pct_venta',
    valor: Number(c.comision_valor) || 0,
    categorias, escalones,
    transparencia: c.comision_transparencia === '1',
    descuentaGarantia: c.comision_descuenta_garantia === '1',
    incluyeTecnicos: c.comision_incluye_tecnicos === '1',
    fondoPct: Math.max(0, Number(c.fondo_pct) || 0),
    garantiaDias: Math.max(0, Math.floor(Number(c.garantia_dias)) || 0),
  };
}
function guardarConfig(db, cuerpo) {
  const up = db.prepare('INSERT OR REPLACE INTO tienda_config (clave,valor) VALUES (?,?)');
  const b = cuerpo || {};
  const num = (v, min, max) => { const n = Number(v); if (!isFinite(n) || n < min || n > max) throw new Error('Valor fuera de rango.'); return String(n); };
  if ('activa' in b) up.run('comision_activa', b.activa ? '1' : '0');
  if ('tipo' in b) { if (!TIPOS_COMISION.includes(b.tipo)) throw new Error('Tipo de comisión inválido.'); up.run('comision_tipo', b.tipo); }
  if ('valor' in b) up.run('comision_valor', num(b.valor, 0, 1e9));
  if ('transparencia' in b) up.run('comision_transparencia', b.transparencia ? '1' : '0');
  if ('descuentaGarantia' in b) up.run('comision_descuenta_garantia', b.descuentaGarantia ? '1' : '0');
  if ('incluyeTecnicos' in b) up.run('comision_incluye_tecnicos', b.incluyeTecnicos ? '1' : '0');
  if ('fondoPct' in b) up.run('fondo_pct', num(b.fondoPct, 0, 100));
  if ('garantiaDias' in b) up.run('garantia_dias', num(b.garantiaDias, 0, 3650));
  if ('categorias' in b) {
    const out = {};
    for (const [k, r] of Object.entries(b.categorias || {})) {
      if (!r || !['pct_venta', 'pct_margen', 'fijo_unidad'].includes(r.tipo)) continue;
      const v = Number(r.valor); if (!isFinite(v) || v < 0) continue;
      out[String(Number(k))] = { tipo: r.tipo, valor: v };
    }
    up.run('comision_categorias', JSON.stringify(out));
  }
  if ('escalones' in b) {
    const out = (Array.isArray(b.escalones) ? b.escalones : []).map(e => ({ desde: Number(e.desde), pct: Number(e.pct) }))
      .filter(e => isFinite(e.desde) && e.desde >= 0 && isFinite(e.pct) && e.pct >= 0 && e.pct <= 100);
    up.run('comision_escalones', JSON.stringify(out));
  }
}

function parseItems(txt) { try { const a = JSON.parse(txt || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
const pidDe = i => Number(i._producto_id || i.producto_id || 0);

/** Al emitir un comprobante: guarda el costo real y lo que se reserva para el fondo de garantía. */
function registrarFondoVenta(db, comprobanteId, tipo, items) {
  try {
    if (tipo !== 'factura' && tipo !== 'nota_entrega' && tipo !== 'nota_credito') return;
    const signo = tipo === 'nota_credito' ? -1 : 1;
    const q = db.prepare('SELECT precio_costo FROM productos WHERE id=?');
    let costo = 0;
    for (const i of items || []) {
      const pid = pidDe(i), cant = Number(i.cantidad) || 0;
      if (!pid || cant <= 0) continue;
      costo += (q.get(pid)?.precio_costo || 0) * cant;
    }
    const pct = leerConfig(db).fondoPct;
    db.prepare('UPDATE comprobantes SET costo_total=?, fondo_garantia=? WHERE id=?')
      .run(redondear(signo * costo), redondear(signo * costo * pct / 100), comprobanteId);
  } catch (e) { console.error('[Tienda] fondo de garantía:', e.message); }
}

// ─── Cálculo de comisiones (al vuelo, a partir de las ventas reales) ───
function reglaDeLinea(cfg, categoriaId) {
  const o = categoriaId != null ? cfg.categorias[String(categoriaId)] : null;
  if (o) return o;
  return cfg.tipo === 'escalones' ? null : { tipo: cfg.tipo, valor: cfg.valor };
}
function comisionLinea(regla, venta, costo, cant) {
  if (!regla) return 0;
  if (regla.tipo === 'pct_venta') return venta * regla.valor / 100;
  if (regla.tipo === 'pct_margen') return Math.max(0, venta - costo) * regla.valor / 100;
  if (regla.tipo === 'fijo_unidad') return regla.valor * cant;
  return 0;
}
function pctEscalon(cfg, ventasNetas) {
  let pct = 0;
  for (const e of cfg.escalones) if (ventasNetas >= e.desde) pct = e.pct;
  return pct;
}

function calcularComisiones(db, { desde, hasta, sucursal_id } = {}) {
  const cfg = leerConfig(db);
  // Lo facturado desde una orden de taller (orden_id) NO es venta de mostrador: su comisión es del técnico (Liquidación).
  const where = ["c.estado != 'anulado'", "c.tipo IN ('factura','nota_entrega','nota_credito')", 'c.orden_id IS NULL'];
  const params = [];
  if (desde) { where.push("date(c.fecha,'localtime') >= ?"); params.push(desde); }
  if (hasta) { where.push("date(c.fecha,'localtime') <= ?"); params.push(hasta); }
  if (sucursal_id) { where.push('c.sucursal_id = ?'); params.push(Number(sucursal_id)); }
  const comps0 = db.prepare(`SELECT c.id,c.numero,c.tipo,c.items,c.subtotal,c.descuento,c.fecha,
      COALESCE(NULLIF(c.vendedor_codigo,''), NULLIF(c.generado_por_usuario,''), 'Sin vendedor') AS vendedor
      FROM comprobantes c WHERE ${where.join(' AND ')}`).all(...params);
  // Ventas de mostrador de técnicos: solo cuentan si el administrador lo decidió
  const tecnicos = new Set();
  if (!cfg.incluyeTecnicos) {
    try { db.prepare("SELECT usuario,nombre FROM usuarios WHERE rol='taller'").all().forEach(u => {
      [u.usuario, u.nombre, 'SYS-' + String(u.nombre || '').toUpperCase()].filter(Boolean).forEach(x => tecnicos.add(String(x).toLowerCase()));
    }); } catch (e) {}
  }
  const comps = comps0.filter(c => !tecnicos.has(String(c.vendedor).toLowerCase()));
  const prods = {};
  const prod = id => prods[id] || (prods[id] = db.prepare('SELECT precio_costo, categoria_id FROM productos WHERE id=?').get(id) || { precio_costo: 0, categoria_id: null });
  const V = {};
  const nuevo = nombre => V[nombre] || (V[nombre] = { vendedor: nombre, comprobantes: 0, unidades: 0, ventas: 0, devoluciones: 0, margen: 0, comision_directa: 0, base_escalones: 0, descuento_garantia: 0 });
  for (const c of comps) {
    const v = nuevo(c.vendedor), signo = c.tipo === 'nota_credito' ? -1 : 1;
    const factor = c.subtotal > 0 ? Math.max(0, (c.subtotal - (c.descuento || 0)) / c.subtotal) : 1;
    v.comprobantes += signo;
    for (const i of parseItems(c.items)) {
      const cant = Number(i.cantidad) || 0, pu = Number(i.precio_unitario) || 0;
      if (cant <= 0) continue;
      const pid = pidDe(i), p = pid ? prod(pid) : { precio_costo: 0, categoria_id: null };
      const venta = pu * cant * factor, costo = (p.precio_costo || 0) * cant;
      v.unidades += signo * cant; v.ventas += signo * venta; v.margen += signo * (venta - costo);
      if (signo < 0) v.devoluciones += venta;
      const regla = reglaDeLinea(cfg, p.categoria_id);
      if (regla) v.comision_directa += signo * comisionLinea(regla, venta, costo, cant);
      else v.base_escalones += signo * venta;
    }
  }
  // Garantías: solo descuentan si el admin lo decidió (una devolución quita la comisión de esa venta)
  if (cfg.descuentaGarantia) {
    const gw = ["resultado = 'devolucion'"], gp = [];
    if (desde) { gw.push("date(fecha,'localtime') >= ?"); gp.push(desde); }
    if (hasta) { gw.push("date(fecha,'localtime') <= ?"); gp.push(hasta); }
    if (sucursal_id) { gw.push('sucursal_id = ?'); gp.push(Number(sucursal_id)); }
    for (const g of db.prepare(`SELECT * FROM garantias_tienda WHERE ${gw.join(' AND ')}`).all(...gp)) {
      const v = nuevo(g.vendedor_codigo || 'Sin vendedor');
      const p = g.producto_id ? prod(g.producto_id) : { categoria_id: null };
      const regla = reglaDeLinea(cfg, p.categoria_id);
      const venta = g.precio_unitario * g.cantidad, costo = g.costo_unitario * g.cantidad;
      v.descuento_garantia += regla ? comisionLinea(regla, venta, costo, g.cantidad) : (venta * pctEscalon(cfg, Math.max(0, v.ventas)) / 100);
    }
  }
  const filas = Object.values(V).map(v => {
    const pctEsc = cfg.tipo === 'escalones' ? pctEscalon(cfg, Math.max(0, v.ventas)) : 0;
    const comEsc = v.base_escalones * pctEsc / 100;
    const bruta = v.comision_directa + comEsc;
    return {
      vendedor: v.vendedor, comprobantes: v.comprobantes, unidades: redondear(v.unidades),
      ventas: redondear(v.ventas), devoluciones: redondear(v.devoluciones), margen: redondear(v.margen),
      pct_escalon: pctEsc, comision_bruta: redondear(bruta),
      descuento_garantia: redondear(v.descuento_garantia),
      comision: redondear(Math.max(0, bruta - v.descuento_garantia)),
    };
  }).sort((a, b) => b.ventas - a.ventas);
  return { config: cfg, filas, totales: {
    ventas: redondear(filas.reduce((s, f) => s + f.ventas, 0)),
    margen: redondear(filas.reduce((s, f) => s + f.margen, 0)),
    comision: redondear(filas.reduce((s, f) => s + f.comision, 0)),
  } };
}

/** Fondo de garantía ÚNICO. Reserva: % del costo real de lo vendido en mostrador (+ de los repuestos de reparaciones
 *  entregadas si hay taller). Gasto: productos dados por perdidos + pérdida de las reparaciones en garantía. */
function resumenFondo(db, { desde, hasta, conTaller } = {}) {
  const cfg = leerConfig(db);
  const rango = (col, ws, ps) => {
    if (desde) { ws.push(`date(${col},'localtime')>=?`); ps.push(desde); }
    if (hasta) { ws.push(`date(${col},'localtime')<=?`); ps.push(hasta); }
  };
  const calc = conRango => {
    const wc = ["estado!='anulado'"], wg = ["resultado!='rechazada'"], wr = ["tipo='reparacion'"], wp = ["tipo='garantia'"];
    const pc = [], pg = [], pr = [], pp = [];
    if (conRango) { rango('fecha', wc, pc); rango('fecha', wg, pg); rango('fecha', wr, pr); rango('fecha', wp, pp); }
    const o = {
      ventas: db.prepare(`SELECT COALESCE(SUM(fondo_garantia),0) s FROM comprobantes WHERE ${wc.join(' AND ')}`).get(...pc).s,
      garantias_tienda: db.prepare(`SELECT COALESCE(SUM(costo_perdida),0) s FROM garantias_tienda WHERE ${wg.join(' AND ')}`).get(...pg).s,
      reparaciones: 0, garantias_reparaciones: 0,
    };
    if (conTaller) {
      try {
        o.reparaciones = db.prepare(`SELECT COALESCE(SUM(repuestos_costo),0) s FROM comisiones WHERE ${wr.join(' AND ')}`).get(...pr).s * cfg.fondoPct / 100;
        o.garantias_reparaciones = db.prepare(`SELECT COALESCE(SUM(perdida_local),0) s FROM comisiones WHERE ${wp.join(' AND ')}`).get(...pp).s;
      } catch (e) {}
    }
    const acumulado = o.ventas + o.reparaciones, gastado = o.garantias_tienda + o.garantias_reparaciones;
    return { acumulado: redondear(acumulado), gastado: redondear(gastado), saldo: redondear(acumulado - gastado),
      detalle: { reservado_ventas: redondear(o.ventas), reservado_reparaciones: redondear(o.reparaciones),
        gastado_tienda: redondear(o.garantias_tienda), gastado_reparaciones: redondear(o.garantias_reparaciones) } };
  };
  const pend = db.prepare("SELECT COUNT(*) c FROM garantias_tienda WHERE destino_stock='pendiente' AND resultado!='rechazada'").get().c;
  const t = calc(false);
  return { pct: cfg.fondoPct, acumulado: t.acumulado, gastado: t.gastado, saldo: t.saldo, detalle: t.detalle,
    pendientes_de_stock: pend, con_taller: !!conTaller, periodo: (desde || hasta) ? calc(true) : null };
}

function registrar(app, d) {
  const { authMiddleware, adminOnly, audit, moverStock, regMovStock, stockDisponible, lugarDeStock, planes, MODO_DISTRIBUIDOR } = d;
  const conTienda = (req, res, next) => {
    const p = planes.queIncluye(req, MODO_DISTRIBUIDOR);
    if (p.activado && !p.modulos.tienda) return res.status(402).json({ error: `Tu plan (${p.etiqueta}) no incluye la tienda.`, modulo_no_incluido: 'tienda' });
    next();
  };
  const adminOCaja = (req, res, next) => ['admin', 'caja'].includes(req.user.rol) ? next() : res.status(403).json({ error: 'Sin acceso.' });
  const base = '/api/tienda';
  const tallerIncluido = req => { try { const p = planes.queIncluye(req, MODO_DISTRIBUIDOR); return !p.activado || !!p.modulos.taller; } catch (e) { return false; } };
  const soloConTaller = (req, res, next) => tallerIncluido(req) ? next() : res.status(404).json({ error: 'Este plan no incluye servicio técnico.' });

  // Estado liviano para el menú (cualquier usuario logueado)
  app.get(base + '/estado', authMiddleware, conTienda, (req, res) => {
    const cfg = leerConfig(req.db);
    res.json({ comision_activa: cfg.activa, transparencia: cfg.transparencia, con_taller: tallerIncluido(req) });
  });

  // ── Configuración (solo admin) ──
  app.get(base + '/config', authMiddleware, adminOnly, conTienda, (req, res) => {
    const categorias = req.db.prepare("SELECT id,nombre FROM categorias WHERE tipo='producto' ORDER BY nombre").all();
    res.json({ ...leerConfig(req.db), categorias_disponibles: categorias });
  });
  app.put(base + '/config', authMiddleware, adminOnly, conTienda, (req, res) => {
    try { guardarConfig(req.db, req.body); } catch (e) { return res.status(400).json({ error: e.message }); }
    audit(req, 'tienda.config', 'tienda', null, JSON.stringify(req.body || {}).slice(0, 400));
    res.json({ ok: true, ...leerConfig(req.db) });
  });

  // ── Comisiones por vendedor ──
  app.get(base + '/comisiones', authMiddleware, adminOnly, conTienda, (req, res) => {
    const { desde, hasta, sucursal_id } = req.query;
    res.json(calcularComisiones(req.db, { desde, hasta, sucursal_id }));
  });
  app.get(base + '/comisiones.csv', authMiddleware, adminOnly, conTienda, (req, res) => {
    const { desde, hasta, sucursal_id } = req.query;
    const r = calcularComisiones(req.db, { desde, hasta, sucursal_id });
    const f = n => String(n).replace('.', ',');
    const lineas = ['Vendedor;Comprobantes;Unidades;Ventas;Devoluciones;Margen;Comision bruta;Descuento garantia;Comision a pagar']
      .concat(r.filas.map(x => [x.vendedor, x.comprobantes, f(x.unidades), f(x.ventas), f(x.devoluciones), f(x.margen), f(x.comision_bruta), f(x.descuento_garantia), f(x.comision)].join(';')));
    audit(req, 'tienda.comisiones_descarga', 'tienda', null, `${desde || ''} → ${hasta || ''}`);
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="comisiones.csv"');
    res.send('﻿' + lineas.join('\r\n'));
  });
  // Modo transparencia: cada vendedor ve SOLO la suya (si el admin lo activó)
  app.get(base + '/mi-comision', authMiddleware, conTienda, (req, res) => {
    const cfg = leerConfig(req.db);
    if (!cfg.activa || !cfg.transparencia) return res.status(403).json({ error: 'El administrador no habilitó ver las comisiones.' });
    const { desde, hasta } = req.query;
    const r = calcularComisiones(req.db, { desde, hasta, sucursal_id: req.user.rol === 'admin' ? null : req.user.sucursal_id });
    const mios = new Set([req.user.usuario, req.user.nombre, 'SYS-' + String(req.user.nombre || '').toUpperCase()].filter(Boolean).map(s => String(s).toLowerCase()));
    res.json({ filas: r.filas.filter(f => mios.has(String(f.vendedor).toLowerCase())) });
  });

  // ── Fondo de garantía ──
  app.get(base + '/fondo', authMiddleware, adminOnly, conTienda, (req, res) => res.json(resumenFondo(req.db, { ...req.query, conTaller: tallerIncluido(req) })));

  // ── Taller + Tienda juntos (solo admin): técnicos, vendedores, garantías y fondo en una vista ──
  app.get(base + '/resumen-conjunto', authMiddleware, adminOnly, conTienda, soloConTaller, (req, res) => {
    const { desde, hasta } = req.query;
    const w = [], p = [];
    if (desde) { w.push("date(c.fecha,'localtime')>=date(?)"); p.push(desde); }
    if (hasta) { w.push("date(c.fecha,'localtime')<=date(?)"); p.push(hasta); }
    const tecnicos = req.db.prepare(`SELECT COALESCE(c.tecnico_nombre,'(sin técnico)') AS tecnico,
        SUM(CASE WHEN c.tipo='reparacion' THEN 1 ELSE 0 END) AS reparaciones,
        SUM(CASE WHEN c.tipo='garantia' THEN 1 ELSE 0 END) AS garantias,
        SUM(CASE WHEN c.estado='pendiente' THEN c.total ELSE 0 END) AS por_pagar,
        SUM(CASE WHEN c.estado='pagada' THEN c.total ELSE 0 END) AS pagadas,
        SUM(c.perdida_local) AS perdida_local
      FROM comisiones c ${w.length ? 'WHERE ' + w.join(' AND ') : ''} GROUP BY c.tecnico_id, c.tecnico_nombre ORDER BY tecnico`).all(...p)
      .map(r => { Object.keys(r).forEach(k => { if (typeof r[k] === 'number') r[k] = redondear(r[k]); }); return r; });
    const gw = ["resultado!='rechazada'"], gp = [];
    if (desde) { gw.push("date(fecha,'localtime')>=?"); gp.push(desde); }
    if (hasta) { gw.push("date(fecha,'localtime')<=?"); gp.push(hasta); }
    const gt = req.db.prepare(`SELECT COUNT(*) n, COALESCE(SUM(costo_perdida),0) perdida FROM garantias_tienda WHERE ${gw.join(' AND ')}`).get(...gp);
    const gr = req.db.prepare(`SELECT COUNT(*) n, COALESCE(SUM(c.perdida_local),0) perdida FROM comisiones c WHERE c.tipo='garantia' ${w.length ? 'AND ' + w.join(' AND ') : ''}`).get(...p);
    const vend = calcularComisiones(req.db, { desde, hasta });
    res.json({
      tecnicos,
      vendedores: { activa: vend.config.activa, incluye_tecnicos: vend.config.incluyeTecnicos, ventas: vend.totales.ventas, comision: vend.config.activa ? vend.totales.comision : 0 },
      garantias: { tienda: { cantidad: gt.n, perdida: redondear(gt.perdida) }, reparaciones: { cantidad: gr.n, perdida: redondear(gr.perdida) } },
      fondo: resumenFondo(req.db, { desde, hasta, conTaller: true }),
    });
  });
  // Garantías de reparaciones (órdenes de garantía del taller) en la misma pantalla de Garantías
  app.get(base + '/garantias-taller', authMiddleware, adminOnly, conTienda, soloConTaller, (req, res) => {
    const w = ["c.tipo='garantia'"], p = [];
    if (req.query.desde) { w.push("date(c.fecha,'localtime')>=date(?)"); p.push(req.query.desde); }
    if (req.query.hasta) { w.push("date(c.fecha,'localtime')<=date(?)"); p.push(req.query.hasta); }
    const rows = req.db.prepare(`SELECT c.id, c.fecha, c.tecnico_nombre, c.pago_garantia, c.total AS pago_tecnico, c.perdida_local, c.repuestos_costo, c.detalle,
        o.numero, o.equipo, o.marca, o.modelo, o.garantia_ref, cl.nombre AS cliente
      FROM comisiones c LEFT JOIN ordenes o ON o.id=c.orden_id LEFT JOIN clientes cl ON cl.id=o.cliente_id
      WHERE ${w.join(' AND ')} ORDER BY c.id DESC LIMIT 300`).all(...p);
    res.json(rows.map(r => { let d = {}; try { d = JSON.parse(r.detalle || '{}'); } catch (e) {} delete r.detalle; return { ...r, cobrado_cliente: d.cobrado_cliente || 0 }; }));
  });

  // ── Garantías generales ──
  const lugar = (req, suc) => lugarDeStock(req, suc);
  app.get(base + '/garantias', authMiddleware, adminOCaja, conTienda, (req, res) => {
    const w = [], p = [];
    if (req.user.rol !== 'admin') { w.push('sucursal_id = ?'); p.push(req.user.sucursal_id || -1); }
    if (req.query.estado === 'pendiente_stock') w.push("destino_stock='pendiente' AND resultado!='rechazada'");
    const filas = req.db.prepare(`SELECT * FROM garantias_tienda ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY id DESC LIMIT 300`).all(...p);
    res.json(filas);
  });

  // Buscar la venta original (por número, cliente o documento)
  app.get(base + '/garantias/buscar-venta', authMiddleware, adminOCaja, conTienda, (req, res) => {
    const q = String(req.query.q || '').trim();
    if (q.length < 2) return res.json([]);
    const like = '%' + q + '%';
    const w = ["estado!='anulado'", "tipo IN ('factura','nota_entrega')", '(numero LIKE ? OR cliente_nombre LIKE ? OR cliente_apellido LIKE ? OR cliente_doc_numero LIKE ?)'];
    const p = [like, like, like, like];
    if (req.user.rol !== 'admin') { w.push('sucursal_id = ?'); p.push(req.user.sucursal_id || -1); }
    const dias = leerConfig(req.db).garantiaDias;
    const filas = req.db.prepare(`SELECT id,numero,tipo,fecha,cliente_id,cliente_nombre,cliente_apellido,vendedor_codigo,items,sucursal_id,total FROM comprobantes WHERE ${w.join(' AND ')} ORDER BY fecha DESC LIMIT 15`).all(...p);
    const reclamado = req.db.prepare("SELECT item_index, COALESCE(SUM(cantidad),0) c FROM garantias_tienda WHERE comprobante_id=? AND resultado!='rechazada' GROUP BY item_index");
    for (const f of filas) {
      f.items = parseItems(f.items);
      const ya = {}; reclamado.all(f.id).forEach(r => { ya[r.item_index] = r.c; });
      f.items = f.items.map((i, idx) => ({ index: idx, descripcion: i.descripcion, cantidad: Number(i.cantidad) || 0, precio_unitario: Number(i.precio_unitario) || 0,
        producto_id: pidDe(i) || null, reclamado: ya[idx] || 0, disponible: Math.max(0, (Number(i.cantidad) || 0) - (ya[idx] || 0)) }));
      const edad = (Date.now() - new Date(String(f.fecha).replace(' ', 'T') + 'Z').getTime()) / 86400000;
      f.dias_transcurridos = Math.floor(edad); f.plazo_dias = dias; f.vencida = dias > 0 && edad > dias;
    }
    res.json(filas);
  });

  app.post(base + '/garantias', authMiddleware, adminOCaja, conTienda, (req, res) => {
    const b = req.body || {}, db = req.db, esAdmin = req.user.rol === 'admin';
    if (!['cambio', 'devolucion', 'rechazada'].includes(b.resultado)) return res.status(400).json({ error: 'Elegí qué se resuelve: cambio, devolución o rechazar.' });
    const motivo = String(b.motivo || '').trim().slice(0, 300);
    if (!motivo) return res.status(400).json({ error: 'Contá brevemente el motivo del reclamo.' });
    const comp = db.prepare("SELECT * FROM comprobantes WHERE id=? AND estado!='anulado' AND tipo IN ('factura','nota_entrega')").get(Number(b.comprobante_id));
    if (!comp) return res.status(404).json({ error: 'No encontré esa venta.' });
    if (!esAdmin && comp.sucursal_id !== req.user.sucursal_id) return res.status(403).json({ error: 'Esa venta es de otro local.' });
    const items = parseItems(comp.items), idx = Number(b.item_index), it = items[idx];
    if (!it) return res.status(400).json({ error: 'Elegí el producto del comprobante.' });
    const cant = Number(b.cantidad) || 1;
    if (!(cant > 0)) return res.status(400).json({ error: 'Cantidad inválida.' });
    const ya = db.prepare("SELECT COALESCE(SUM(cantidad),0) c FROM garantias_tienda WHERE comprobante_id=? AND item_index=? AND resultado!='rechazada'").get(comp.id, idx).c;
    if (b.resultado !== 'rechazada' && cant > (Number(it.cantidad) || 0) - ya + 1e-9) return res.status(409).json({ error: `Ese producto ya tiene ${ya} reclamado(s) de ${it.cantidad}.` });
    // Plazo de garantía: el admin puede autorizar fuera de plazo; el resto no
    const cfg = leerConfig(db);
    const edad = (Date.now() - new Date(String(comp.fecha).replace(' ', 'T') + 'Z').getTime()) / 86400000;
    const vencida = cfg.garantiaDias > 0 && edad > cfg.garantiaDias;
    if (vencida && b.resultado !== 'rechazada' && !esAdmin) return res.status(409).json({ error: `Pasó el plazo de garantía (${cfg.garantiaDias} días). Lo tiene que autorizar el administrador.`, vencida: true });

    const pid = pidDe(it) || null;
    const prod = pid ? db.prepare('SELECT nombre,precio_costo,precio_venta FROM productos WHERE id=?').get(pid) : null;
    const precioUnit = Number(it.precio_unitario) || 0, costoUnit = prod?.precio_costo || 0;
    const sucId = lugar(req, comp.sucursal_id);
    let nuevo = null, precioNuevo = 0, diferencia = 0, medio = null, destino = 'no_aplica', perdida = 0;

    if (b.resultado !== 'rechazada') {
      // 1) Plata: cambio por otro producto (diferencia) o devolución (sale todo el precio)
      medio = String(b.medio_pago || 'Efectivo');
      if (!['Efectivo', 'Débito', 'Crédito', 'Transferencia', 'Mercado Pago'].includes(medio)) return res.status(400).json({ error: 'Medio de pago inválido.' });
      if (b.resultado === 'cambio') {
        const nid = Number(b.producto_nuevo_id) || pid;
        nuevo = db.prepare('SELECT id,nombre,precio_venta,precio_costo FROM productos WHERE id=?').get(nid);
        if (!nuevo) return res.status(400).json({ error: 'Elegí el producto nuevo.' });
        precioNuevo = b.precio_nuevo_unitario != null && b.precio_nuevo_unitario !== '' ? Number(b.precio_nuevo_unitario) : (nid === pid ? precioUnit : (nuevo.precio_venta || 0));
        if (!(precioNuevo >= 0)) return res.status(400).json({ error: 'Precio inválido.' });
        diferencia = redondear((precioNuevo - precioUnit) * cant);
        const disp = stockDisponible(db, nuevo.id, sucId);
        if (disp < cant) return res.status(409).json({ error: `No hay stock del producto nuevo (${nuevo.nombre}): hay ${disp}.` });
      } else {
        diferencia = -redondear(precioUnit * cant);
      }
      let caja = null;
      if (diferencia !== 0) {
        caja = db.prepare(`SELECT id FROM caja_sesiones WHERE estado='abierta' AND (sucursal_id=? OR sucursal_id IS NULL) ORDER BY id DESC LIMIT 1`).get(comp.sucursal_id || 0);
        if (!caja) return res.status(409).json({ error: 'La caja está cerrada: abrila para registrar el movimiento de plata de esta garantía.' });
      }
      // 2) Stock del producto devuelto: lo decide el admin. Caja lo deja pendiente.
      if (esAdmin && ['stock', 'perdida'].includes(b.destino_stock)) destino = b.destino_stock; else destino = 'pendiente';
      if (destino === 'perdida') perdida = redondear(costoUnit * cant);

      const tx = db.transaction(() => {
        const r = db.prepare(`INSERT INTO garantias_tienda
          (comprobante_id,comprobante_numero,fecha_venta,cliente_id,cliente_nombre,vendedor_codigo,producto_id,producto_nombre,item_index,cantidad,
           precio_unitario,costo_unitario,motivo,nota,resultado,producto_nuevo_id,producto_nuevo_nombre,precio_nuevo_unitario,diferencia,medio_pago,
           destino_stock,costo_perdida,vencida,sucursal_id,usuario,usuario_rol) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
          .run(comp.id, comp.numero, comp.fecha, comp.cliente_id, [comp.cliente_nombre, comp.cliente_apellido].filter(Boolean).join(' '), comp.vendedor_codigo || comp.generado_por_usuario || null,
            pid, it.descripcion || prod?.nombre || '', idx, cant, precioUnit, costoUnit, motivo, String(b.nota || '').slice(0, 300), b.resultado,
            nuevo?.id || null, nuevo?.nombre || null, precioNuevo, diferencia, medio, destino, perdida, vencida ? 1 : 0, comp.sucursal_id || null, req.user.nombre || req.user.usuario, req.user.rol);
        const gid = r.lastInsertRowid, numero = 'GAR-' + String(gid).padStart(5, '0');
        db.prepare('UPDATE garantias_tienda SET numero=? WHERE id=?').run(numero, gid);
        if (nuevo) { moverStock(db, nuevo.id, sucId, -cant); regMovStock(db, nuevo.id, 'salida', cant, `Garantía ${numero} (cambio)`, sucId, req.user.nombre); }
        if (destino === 'stock' && pid) { moverStock(db, pid, sucId, cant); regMovStock(db, pid, 'entrada', cant, `Garantía ${numero} (producto devuelto)`, sucId, req.user.nombre); }
        if (caja && diferencia !== 0) {
          db.prepare(`INSERT INTO caja_movimientos (caja_sesion_id,tipo,origen,medio_pago,monto,motivo,comprobante_id,usuario,vendedor_codigo,desde_admin) VALUES (?,?,?,?,?,?,?,?,?,?)`)
            .run(caja.id, diferencia > 0 ? 'ingreso' : 'egreso', 'garantia', medio, Math.abs(diferencia),
              `Garantía ${numero} (${b.resultado === 'cambio' ? 'diferencia de cambio' : 'devolución'}) · venta ${comp.numero}`, comp.id, req.user.nombre || req.user.usuario || '', comp.vendedor_codigo || null, esAdmin ? 1 : 0);
        }
        return { gid, numero };
      });
      let out;
      try { out = tx(); } catch (e) { console.error('[Tienda] garantía:', e.message); return res.status(500).json({ error: 'No se pudo registrar la garantía: ' + e.message }); }
      audit(req, 'garantia_tienda.crear', 'garantia_tienda', out.gid, `${out.numero} ${b.resultado} · ${it.descripcion || ''} ×${cant} · venta ${comp.numero} · dif $${diferencia} · stock: ${destino}${vencida ? ' · FUERA DE PLAZO (autorizó admin)' : ''}`);
      return res.json({ ok: true, id: out.gid, numero: out.numero, diferencia, destino_stock: destino, costo_perdida: perdida });
    }

    // Reclamo rechazado: queda registrado, no mueve nada
    const r = db.prepare(`INSERT INTO garantias_tienda
      (comprobante_id,comprobante_numero,fecha_venta,cliente_id,cliente_nombre,vendedor_codigo,producto_id,producto_nombre,item_index,cantidad,precio_unitario,costo_unitario,motivo,nota,resultado,destino_stock,vencida,sucursal_id,usuario,usuario_rol)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'rechazada','no_aplica',?,?,?,?)`)
      .run(comp.id, comp.numero, comp.fecha, comp.cliente_id, [comp.cliente_nombre, comp.cliente_apellido].filter(Boolean).join(' '), comp.vendedor_codigo || comp.generado_por_usuario || null,
        pid, it.descripcion || '', idx, cant, precioUnit, costoUnit, motivo, String(b.nota || '').slice(0, 300), vencida ? 1 : 0, comp.sucursal_id || null, req.user.nombre || req.user.usuario, req.user.rol);
    const numero = 'GAR-' + String(r.lastInsertRowid).padStart(5, '0');
    db.prepare('UPDATE garantias_tienda SET numero=? WHERE id=?').run(numero, r.lastInsertRowid);
    audit(req, 'garantia_tienda.rechazar', 'garantia_tienda', r.lastInsertRowid, `${numero} rechazada · ${it.descripcion || ''} · venta ${comp.numero} · ${motivo}`);
    res.json({ ok: true, id: r.lastInsertRowid, numero });
  });

  // El admin decide qué pasa con el producto devuelto (vuelve al stock o se da por perdido)
  app.put(base + '/garantias/:id/destino-stock', authMiddleware, adminOnly, conTienda, (req, res) => {
    const db = req.db, g = db.prepare('SELECT * FROM garantias_tienda WHERE id=?').get(req.params.id);
    if (!g) return res.status(404).json({ error: 'No encontrada.' });
    if (g.destino_stock !== 'pendiente') return res.status(409).json({ error: 'Esa garantía ya tiene decidido el destino del producto.' });
    const destino = req.body?.destino;
    if (!['stock', 'perdida'].includes(destino)) return res.status(400).json({ error: 'Elegí: vuelve al stock o se pierde.' });
    const sucId = lugar(req, g.sucursal_id);
    const tx = db.transaction(() => {
      if (destino === 'stock' && g.producto_id) { moverStock(db, g.producto_id, sucId, g.cantidad); regMovStock(db, g.producto_id, 'entrada', g.cantidad, `Garantía ${g.numero} (producto devuelto)`, sucId, req.user.nombre); }
      db.prepare('UPDATE garantias_tienda SET destino_stock=?, costo_perdida=? WHERE id=?').run(destino, destino === 'perdida' ? redondear(g.costo_unitario * g.cantidad) : 0, g.id);
    });
    tx();
    audit(req, 'garantia_tienda.destino', 'garantia_tienda', g.id, `${g.numero} → ${destino === 'stock' ? 'vuelve al stock' : 'se da por perdido (sale del fondo)'}`);
    res.json({ ok: true });
  });
}

module.exports = { registrar, registrarFondoVenta, calcularComisiones, resumenFondo, leerConfig };
