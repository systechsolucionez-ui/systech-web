// ============================================================
// Sistema de licencia local — 100% offline para el código inicial.
// El código de activación NO necesita internet para validarse: es un
// token firmado (HMAC) que el propio .exe puede verificar solo, con
// una clave secreta que solo vos (Systech) conocés al generarlo.
//
// Lo que SÍ necesita internet es la compra de una sucursal extra
// (paga con Mercado Pago, y el servidor central le suma el permiso)
// — pero activar el sistema por primera vez, no.
// ============================================================
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// Firma ASIMÉTRICA (Ed25519): la clave PRIVADA solo la tenés vos (archivo
// licencia-privada.pem, junto a generar-licencia.js — nunca va en lo que se le
// entrega al cliente). Acá adentro va solo la clave PÚBLICA, que sirve para
// VERIFICAR códigos pero no para fabricarlos. Así, aunque alguien abra el código
// del sistema, no puede inventarse una licencia.
const CLAVE_PUBLICA = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEALZQK5lW42jSEKs1gEk290K4EFtNpxVwIUGtVBQzzL38=
-----END PUBLIC KEY-----
`;

const ARCHIVO_LICENCIA = path.join(__dirname, 'licencia.local.json');
const ARCHIVO_CLAVE_PRIVADA = process.env.LICENCIA_PRIVADA_ARCHIVO || path.join(__dirname, 'licencia-privada.pem');

/**
 * Arma un código de activación. Se usa DEL LADO DE SYSTECH (vos), no
 * corre en la PC del cliente — necesita licencia-privada.pem, que solo tenés vos.
 */
function fechaValida(f) { return f === undefined || f === null || f === '' || (/^\d{4}-\d{2}-\d{2}$/.test(String(f)) && !isNaN(new Date(f + 'T00:00:00Z'))); }

/**
 * Fechas opcionales (todas 'AAAA-MM-DD'; sin fecha = no vence nunca):
 *   vence               → la base (módulos y sucursales). Pasada la gracia, el sistema queda en solo lectura.
 *   tecnibotHasta       → solo apaga Tecnibot.
 *   iaHasta             → solo apaga la IA.
 *   actualizacionesHasta→ el sistema sigue funcionando siempre; deja de ofrecer versiones NUEVAS publicadas después de esa fecha
 *                         (las correcciones marcadas como críticas se ofrecen igual).
 * Un código sin ninguna fecha (los de antes) funciona exactamente igual que siempre: permanente.
 */
function generarCodigo({ tienda, taller, tecnibot, limiteSucursales, negocioId, vence, tecnibotHasta, iaHasta, actualizacionesHasta, ia }) {
  if (!fs.existsSync(ARCHIVO_CLAVE_PRIVADA)) {
    throw new Error('Falta licencia-privada.pem (la clave privada de Systech). Sin ella no se pueden generar códigos.');
  }
  for (const [n, f] of [['vence', vence], ['tecnibotHasta', tecnibotHasta], ['iaHasta', iaHasta], ['actualizacionesHasta', actualizacionesHasta]]) {
    if (!fechaValida(f)) throw new Error(`La fecha "${n}" no es válida: usá el formato AAAA-MM-DD (ej. 2027-10-08).`);
  }
  const payload = {
    tienda: !!tienda, taller: !!taller, tecnibot: !!tecnibot,
    limiteSucursales: limiteSucursales || 1,
    // Mismo negocioId en todas las sucursales de UN mismo cliente —
    // es lo que las conecta entre sí para el chat interno.
    negocioId: negocioId || crypto.randomUUID(),
    emitido: new Date().toISOString(),
  };
  if (ia !== undefined) payload.ia = !!ia;
  if (vence) payload.vence = vence;
  if (tecnibotHasta) payload.tecnibotHasta = tecnibotHasta;
  if (iaHasta) payload.iaHasta = iaHasta;
  if (actualizacionesHasta) payload.actualizacionesHasta = actualizacionesHasta;
  const payloadStr = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const firma = crypto.sign(null, Buffer.from(payloadStr), crypto.createPrivateKey(fs.readFileSync(ARCHIVO_CLAVE_PRIVADA))).toString('base64url');
  return `${payloadStr}.${firma}`;
}

/** Verifica un código SIN internet — solo con la clave pública. */
function verificarCodigo(codigo) {
  const partes = String(codigo || '').trim().split('.');
  if (partes.length !== 2) return null;
  const [payloadStr, firma] = partes;
  try {
    const ok = crypto.verify(null, Buffer.from(payloadStr), crypto.createPublicKey(CLAVE_PUBLICA), Buffer.from(firma, 'base64url'));
    if (!ok) return null; // código inventado o mal copiado
    return JSON.parse(Buffer.from(payloadStr, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
}

function leerLicenciaActual() {
  if (!fs.existsSync(ARCHIVO_LICENCIA)) return null;
  let lic;
  try { lic = JSON.parse(fs.readFileSync(ARCHIVO_LICENCIA, 'utf8')); } catch { return null; }
  // Si el archivo trae el código firmado, los permisos salen SIEMPRE del código (no del archivo):
  // editar licencia.local.json a mano no sirve para agregarse módulos ni sucursales.
  if (lic && lic.codigo) {
    const firmado = verificarCodigo(lic.codigo);
    if (!firmado) return null;
    return { ...lic, ...firmado };
  }
  return lic; // instalaciones anteriores (sin código guardado)
}

function activar(codigo) {
  const datos = verificarCodigo(codigo);
  if (!datos) throw new Error('Código inválido — revisá que lo hayas copiado completo, sin espacios de más.');
  const existente = leerLicenciaActual();
  // Renovar o cambiar de plan = pegar un código NUEVO del mismo negocio. Dos protecciones:
  //   · tiene que ser del mismo negocio (mismo negocioId) — no se mezcla con el de otro cliente;
  //   · no puede ser más viejo que el que ya está (un código vencido viejo no pisa a la renovación).
  if (existente && existente.codigo && existente.negocioId && datos.negocioId !== existente.negocioId) {
    throw new Error('Este código es de otro negocio. Si es una renovación o un cambio de plan, pedile a SysTech un código del mismo negocio.');
  }
  if (existente && existente.codigo && existente.emitido && (!datos.emitido || datos.emitido < existente.emitido)) {
    throw new Error('Este código es más viejo que el que ya está cargado. Usá el último que te mandó SysTech.');
  }
  // instalacionId: identidad única de ESTA PC — se genera una sola vez,
  // y es lo que conecta esta instalación con el servidor central para
  // lo de sucursales extra / chat (lo único que sí necesita internet).
  const instalacionId = existente?.instalacionId || crypto.randomUUID();
  const licencia = { ...datos, codigo: String(codigo).trim(), instalacionId, sucursalesExtra: existente?.sucursalesExtra || 0, activadoEn: existente?.activadoEn || new Date().toISOString(), renovadoEn: existente ? new Date().toISOString() : undefined };
  fs.writeFileSync(ARCHIVO_LICENCIA, JSON.stringify(licencia, null, 2));
  return licencia;
}

/** Límite total de sucursales: la base del código + lo que se haya comprado online. */
function limiteSucursalesActual() {
  const lic = leerLicenciaActual();
  if (!lic) return 0;
  return (lic.limiteSucursales || 1) + (lic.sucursalesExtra || 0);
}

/** Se llama cuando el servidor central confirma un pago de sucursal extra. */
function sumarSucursalExtra() {
  const lic = leerLicenciaActual();
  if (!lic) throw new Error('El sistema todavía no está activado.');
  lic.sucursalesExtra = (lic.sucursalesExtra || 0) + 1;
  fs.writeFileSync(ARCHIVO_LICENCIA, JSON.stringify(lic, null, 2));
  return lic;
}

/** Firma un texto con la clave privada de Systech (se usa al publicar una actualización). */
function firmarTexto(texto) {
  if (!fs.existsSync(ARCHIVO_CLAVE_PRIVADA)) throw new Error('Falta licencia-privada.pem (la clave privada de Systech).');
  return crypto.sign(null, Buffer.from(String(texto)), crypto.createPrivateKey(fs.readFileSync(ARCHIVO_CLAVE_PRIVADA))).toString('base64url');
}
/** Verifica con la clave pública que un texto fue firmado por Systech. */
function verificarFirmaTexto(texto, firma) {
  try { return crypto.verify(null, Buffer.from(String(texto)), crypto.createPublicKey(CLAVE_PUBLICA), Buffer.from(String(firma || ''), 'base64url')); }
  catch { return false; }
}

module.exports = { firmarTexto, verificarFirmaTexto, generarCodigo, verificarCodigo, leerLicenciaActual, activar, limiteSucursalesActual, sumarSucursalExtra };
