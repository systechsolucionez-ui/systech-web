' SysTech - arranque SIN ventana negra
' Abre el servidor en segundo plano y despues el navegador.
Option Explicit
Dim sh, fso, dir, puerto, url, i, f, t, lnk, desk, env

Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = dir

puerto = "3000"
If fso.FileExists(dir & "\puerto.txt") Then
  Set f = fso.OpenTextFile(dir & "\puerto.txt", 1)
  If Not f.AtEndOfStream Then t = Trim(f.ReadLine())
  f.Close
  If Len(t) > 0 Then
    If IsNumeric(t) Then puerto = t
  End If
End If
url = "http://localhost:" & puerto

Function Arriba()
  On Error Resume Next
  Dim h
  Set h = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  h.setTimeouts 1000, 1000, 1500, 1500
  h.open "GET", url & "/api/build", False
  h.send
  Arriba = (Err.Number = 0 And h.status = 200)
  Err.Clear
End Function

' Acceso directo en el escritorio (solo si no existe todavia)
desk = sh.SpecialFolders("Desktop")
If Not fso.FileExists(desk & "\SysTech.lnk") Then
  On Error Resume Next
  Set lnk = sh.CreateShortcut(desk & "\SysTech.lnk")
  lnk.TargetPath = "wscript.exe"
  lnk.Arguments = """" & dir & "\SysTech.vbs"""
  lnk.WorkingDirectory = dir
  lnk.IconLocation = dir & "\SysTech.ico"
  lnk.Description = "SysTech"
  lnk.Save
  On Error GoTo 0
End If

If Not Arriba() Then
  ' Node.js portable de esta carpeta (si existe) tiene prioridad
  Set env = sh.Environment("Process")
  If fso.FileExists(dir & "\runtime\node\node.exe") Then env("PATH") = dir & "\runtime\node;" & env("PATH")
  ' Falta Node.js o lo que necesita el sistema: instalacion automatica (la unica vez que se ve una ventana)
  If sh.Run("cmd /c node -v >nul 2>&1", 0, True) <> 0 Or Not fso.FolderExists(dir & "\node_modules") Then
    sh.Run """" & dir & "\INSTALAR.bat"" nolanzar", 1, True
    If fso.FileExists(dir & "\runtime\node\node.exe") Then env("PATH") = dir & "\runtime\node;" & env("PATH")
    If sh.Run("cmd /c node -v >nul 2>&1", 0, True) <> 0 Or Not fso.FolderExists(dir & "\node_modules") Then
      MsgBox "No se pudo terminar la instalacion. Revisa la conexion a internet y volve a abrir SysTech.", 48, "SysTech"
      WScript.Quit 1
    End If
  End If
  ' Servidor en segundo plano (ventana oculta)
  sh.Run """" & dir & "\servidor-oculto.bat""", 0, False
  For i = 1 To 80
    WScript.Sleep 500
    If Arriba() Then Exit For
  Next
  If Not Arriba() Then
    MsgBox "SysTech no pudo arrancar. Mira el archivo server-log.txt de esta carpeta para ver el motivo.", 48, "SysTech"
    WScript.Quit 1
  End If
End If

sh.Run url, 1, False
