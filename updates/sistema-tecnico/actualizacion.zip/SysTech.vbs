Set objShell = CreateObject("WScript.Shell")
carpeta = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
objShell.CurrentDirectory = carpeta
' El "7" hace que la consola arranque minimizada en la barra de tareas,
' en vez de aparecer en pantalla. Si algo falla, el cliente puede abrirla
' desde la barra de tareas para ver el mensaje de error.
objShell.Run """" & carpeta & "INICIAR.bat""", 7, False
