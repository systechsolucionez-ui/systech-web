// AYUDA-1.7.3 — Fila de botones debajo del logo (🌙 tema · 💬 mensajes internos · 🤖 ayuda) y el chat de ayuda.
// La ayuda responde con la guía del sistema (ayuda-guia.js): funciona sin internet y no consume IA.
// Cada usuario ve la ayuda de lo que puede usar: el admin todo; Caja y Taller lo suyo y lo que el admin les habilitó.
(function () {
  'use strict';
  var GUIA = window.AYUDA_GUIA || [];
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var norm = function (s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9ñ ]+/g, ' ').replace(/\s+/g, ' ').trim(); };
  var VACIAS = 'el la los las un una unos unas de del al a en y o que como se me mi mis tu te lo le les por para con sin es son hay hago hacer puedo quiero necesito donde cuando cual esta este esto eso ese hola buenas buen dia tengo tiene'.split(' ');
  var SIN = { wsp: 'whatsapp', wpp: 'whatsapp', whats: 'whatsapp', guasap: 'whatsapp', mail: 'correo', email: 'correo', emails: 'correo', mails: 'correo', clave: 'contrasena', password: 'contrasena',
    pass: 'contrasena', compu: 'computadora', pc: 'computadora', notebook: 'computadora', laptop: 'computadora', macbook: 'mac', ordenes: 'orden', ot: 'orden', reparaciones: 'reparacion',
    arreglo: 'reparacion', arreglar: 'reparacion', productos: 'producto', articulo: 'producto', articulos: 'producto', repuestos: 'repuesto', clientes: 'cliente', usuarios: 'usuario',
    empleado: 'usuario', empleada: 'usuario', cajero: 'cajera', facturar: 'factura', facturas: 'factura', afip: 'arca', remoto: 'afuera', lejos: 'afuera', casa: 'afuera',
    imprimo: 'imprimir', impresion: 'imprimir', vendo: 'vender', venta: 'vender', ventas: 'vender', cobro: 'cobrar', cobra: 'cobrar', pago: 'cobrar', pagar: 'cobrar',
    garantias: 'garantia', sucursales: 'sucursal', locales: 'sucursal', local: 'sucursal', actualizo: 'actualizar', actualizacion: 'actualizar', oscuro: 'tema', claro: 'tema',
    cierro: 'cerrar', cierra: 'cerrar', cierre: 'cerrar', abro: 'abrir', abre: 'abrir', creo: 'crear', armo: 'crear', armar: 'crear', cargo: 'cargar', cargo2: 'cargar', subo: 'cargar', subir: 'cargar',
    mando: 'enviar', mandar: 'enviar', manda: 'enviar', envio: 'enviar', envia: 'enviar', facturo: 'factura', facturar: 'factura', vendi: 'vender', vendo: 'vender', vendimos: 'vender',
    agrego: 'agregar', sumo: 'agregar', sumar: 'agregar', borro: 'borrar', elimino: 'borrar', eliminar: 'borrar', busco: 'buscar', cambio: 'cambiar', configuro: 'configurar', conecto: 'conectar',
    entrego: 'entregar', imprimir2: 'imprimir', aviso: 'avisar', avisarle: 'avisar', registro: 'registrar', paso: 'pasos', recupero: 'recuperar', olvide: 'olvide', anulo: 'anular' };
  function palabras(s) {
    return norm(s).split(' ').filter(function (w) { return w.length > 1 && VACIAS.indexOf(w) < 0; }).map(function (w) { return SIN[w] || w; });
  }
  // índice de cada tema
  GUIA.forEach(function (g) { g._t = palabras(g.t); g._k = palabras(g.k + ' ' + g.t); });

  // ── Quién soy y qué puedo usar ──
  function rol() { try { return (typeof ROL !== 'undefined' && ROL) || localStorage.getItem('rol') || 'admin'; } catch (e) { return 'admin'; } }
  function permisos() { try { return (typeof PERMISOS !== 'undefined' && PERMISOS && PERMISOS.permisos) || {}; } catch (e) { return {}; } }
  function conTaller() { try { return typeof CON_TALLER === 'function' ? CON_TALLER() : true; } catch (e) { return true; } }
  function conTienda() { try { return !(typeof PLAN !== 'undefined' && PLAN && PLAN.modulos) || !!PLAN.modulos.tienda; } catch (e) { return true; } }
  function estado(g) {   // 'si' = lo puede usar · 'admin' = lo hace el administrador · 'plan' = no está en el plan
    if (g.plan === 'taller' && !conTaller()) return 'plan';
    if (g.plan === 'tienda' && !conTienda()) return 'plan';
    var r = rol();
    if (r !== 'admin' && g.r && g.r.indexOf(r) < 0) return 'admin';
    if (r !== 'admin' && g.p && permisos()[g.p] === false) return 'admin';
    return 'si';
  }
  function buscar(q) {
    var ws = palabras(q); if (!ws.length) return [];
    return GUIA.map(function (g) {
      var s = 0;
      ws.forEach(function (w) {
        if (g._t.indexOf(w) >= 0) s += 3;
        else if (g._k.indexOf(w) >= 0) s += 2;
        else if (w.length >= 4 && g._k.some(function (k) { return k.length >= 4 && (k.indexOf(w) === 0 || w.indexOf(k) === 0); })) s += 1;
      });
      var e = estado(g); if (e === 'plan') s -= 2; if (e === 'admin') s -= 0.5;
      return { g: g, s: s, e: e };
    }).filter(function (x) { return x.s >= 2; }).sort(function (a, b) { return b.s - a.s; });
  }

  // ── Llevarme ahí ──
  function ir(g) {
    var d = g.ir; if (!d) return;
    if (d.cfg) {
      var n = document.querySelector('.nav-item[data-page="config"]'); if (n) n.click(); else if (typeof goTo === 'function') goTo('config');
      setTimeout(function () { if (typeof showCfgTab === 'function') showCfgTab(d.cfg); if (d.cfg === 'sistema' && window.cargarConexion) cargarConexion(); }, 150);
    } else if (d.page) {
      var it = document.querySelector('.nav-item[data-page="' + d.page + '"]');
      if (it) it.click(); else if (typeof goTo === 'function') goTo(d.page);
    }
    cerrar();
  }
  function puedeIr(g) {
    if (!g.ir) return false;
    if (g.ir.cfg) return rol() === 'admin';
    return !!document.querySelector('.nav-item[data-page="' + g.ir.page + '"]');
  }

  // ── Pantalla del chat ──
  var CSS = '.ay-panel{position:fixed;left:232px;bottom:18px;width:380px;max-width:calc(100vw - 24px);height:560px;max-height:calc(100vh - 36px);background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:16px;box-shadow:0 20px 50px rgba(0,0,0,.35);display:none;flex-direction:column;z-index:10050;overflow:hidden;font-size:14px}' +
    '.ay-panel.abierto{display:flex}' +
    '.ay-cab{display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid var(--border);background:var(--surface2)}' +
    '.ay-cab b{font-size:15px}.ay-cab small{display:block;color:var(--text2);font-size:11.5px}.ay-cab button{margin-left:auto;background:none;border:0;color:var(--text2);font-size:18px;cursor:pointer}' +
    '.ay-robot{width:34px;height:34px;border-radius:50%;display:grid;place-items:center;background:var(--accent);color:#fff;font-size:19px;flex:0 0 auto}' +
    '.ay-msgs{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:10px}' +
    '.ay-m{max-width:92%;padding:10px 12px;border-radius:14px;line-height:1.45}' +
    '.ay-m.bot{background:var(--surface2);border:1px solid var(--border);align-self:flex-start;border-top-left-radius:4px}' +
    '.ay-m.yo{background:var(--accent);color:#fff;align-self:flex-end;border-top-right-radius:4px}' +
    '.ay-m h4{margin:0 0 6px;font-size:14px}.ay-m ol{margin:4px 0 0;padding-left:20px}.ay-m li{margin:3px 0}' +
    '.ay-ojo{margin-top:8px;padding:8px 10px;border-radius:10px;background:rgba(212,168,87,.13);border:1px solid rgba(212,168,87,.35);font-size:12.5px}' +
    '.ay-lim{margin-top:8px;padding:8px 10px;border-radius:10px;background:rgba(178,34,34,.1);border:1px solid rgba(178,34,34,.35);font-size:12.5px}' +
    '.ay-ir{margin-top:9px;display:inline-flex;align-items:center;gap:6px;padding:7px 12px;border-radius:9px;border:0;background:var(--accent);color:#fff;font:inherit;font-size:13px;font-weight:600;cursor:pointer}' +
    '.ay-chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}' +
    '.ay-chip{padding:6px 10px;border-radius:999px;border:1px solid var(--border);background:var(--surface);color:var(--text);font:inherit;font-size:12.5px;cursor:pointer;text-align:left}' +
    '.ay-chip:hover{border-color:var(--accent)}' +
    '.ay-pie{display:flex;gap:8px;padding:10px;border-top:1px solid var(--border)}' +
    '.ay-pie input{flex:1;padding:10px 12px;border-radius:10px;border:1px solid var(--border);background:var(--bg);color:var(--text);font:inherit}' +
    '.ay-pie button{padding:0 14px;border-radius:10px;border:0;background:var(--accent);color:#fff;font:inherit;font-weight:600;cursor:pointer}' +
    '.st-herr button{position:relative}' +
    '.st-num{position:absolute;top:-5px;right:-6px;min-width:18px;height:18px;padding:0 5px;border-radius:9px;background:var(--danger,#e03131);color:#fff;font-size:11px;font-weight:700;line-height:18px;text-align:center;display:none}' +
    '@media (max-width:760px){.ay-panel{left:12px;right:12px;bottom:12px;width:auto;height:calc(100vh - 24px)}}';

  function montar() {
    var herr = $('st-herr'); if (!herr || $('ay-btn')) return;
    var st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
    var tema = $('st-theme-toggle'); if (tema) tema.title = 'Modo claro / oscuro';
    var chat = document.createElement('button'); chat.id = 'st-chat-btn'; chat.title = 'Mensajes internos'; chat.innerHTML = '💬<span class="st-num" id="st-chat-num"></span>';
    chat.onclick = function () { var n = document.querySelector('.nav-item[data-page="chat"]'); if (n) n.click(); else if (typeof goTo === 'function') goTo('chat'); };
    var ay = document.createElement('button'); ay.id = 'ay-btn'; ay.title = 'Ayuda: preguntame cómo hacer algo'; ay.textContent = '🤖'; ay.onclick = function () { panel.classList.contains('abierto') ? cerrar() : abrir(); };
    herr.appendChild(chat); herr.appendChild(ay);
    var panel = document.createElement('div'); panel.className = 'ay-panel'; panel.id = 'ay-panel';
    panel.innerHTML = '<div class="ay-cab"><span class="ay-robot">🤖</span><div><b>Ayuda de SysTech</b><small>Preguntame cómo hacer algo en el sistema</small></div><button type="button" id="ay-x" title="Cerrar">✕</button></div>' +
      '<div class="ay-msgs" id="ay-msgs"></div>' +
      '<form class="ay-pie" id="ay-form"><input id="ay-q" autocomplete="off" placeholder="Ej.: ¿cómo creo una orden?" maxlength="200"><button type="submit">Preguntar</button></form>';
    document.body.appendChild(panel);
    $('ay-x').onclick = cerrar;
    $('ay-form').onsubmit = function (e) { e.preventDefault(); var q = $('ay-q').value.trim(); if (!q) return; $('ay-q').value = ''; preguntar(q); };
    $('ay-msgs').addEventListener('click', function (e) {
      var b = e.target.closest('[data-ay]'); if (!b) return;
      var g = GUIA.find(function (x) { return x.id === b.getAttribute('data-ay'); }); if (!g) return;
      if (b.hasAttribute('data-ir')) ir(g); else { burbuja('yo', esc(g.t)); responder(g); }
    });
    iniciarContador();
  }
  function abrir() {
    var p = $('ay-panel'); p.classList.add('abierto');
    if (!$('ay-msgs').children.length) saludo();
    setTimeout(function () { $('ay-q').focus(); }, 50);
  }
  function cerrar() { var p = $('ay-panel'); if (p) p.classList.remove('abierto'); }
  function burbuja(quien, html) { var m = document.createElement('div'); m.className = 'ay-m ' + quien; m.innerHTML = html; var box = $('ay-msgs'); box.appendChild(m); box.scrollTop = box.scrollHeight; }
  function chips(lista) { return '<div class="ay-chips">' + lista.map(function (g) { return '<button type="button" class="ay-chip" data-ay="' + g.id + '">' + esc(g.t) + '</button>'; }).join('') + '</div>'; }
  function sugeridos() {
    var r = rol();
    var ids = r === 'caja' ? ['abrir-caja', 'nueva-orden', 'cobrar-orden', 'vender', 'cerrar-caja', 'garantia']
      : r === 'taller' ? ['estado-orden', 'repuesto-orden', 'avisar-whatsapp', 'garantia', 'mis-reparaciones', 'imprimir']
      : ['primeros', 'nueva-orden', 'correo', 'usuario', 'otra-compu', 'desde-afuera'];
    return ids.map(function (id) { return GUIA.find(function (g) { return g.id === id; }); }).filter(function (g) { return g && estado(g) === 'si'; });
  }
  function saludo() {
    var nombre = ''; try { nombre = (typeof USER_NOMBRE !== 'undefined' && USER_NOMBRE) ? ' ' + String(USER_NOMBRE).split(' ')[0] : ''; } catch (e) {}
    burbuja('bot', '¡Hola' + esc(nombre) + '! 👋 Contame qué querés hacer y te explico paso a paso. Por ejemplo:' + chips(sugeridos()));
  }
  function responder(g) {
    var e = estado(g), h = '<h4>' + esc(g.t) + '</h4>';
    if (e === 'plan') h += '<div class="ay-lim">Esto no está incluido en tu plan. El administrador lo puede sumar desde Configuración → 🔄 Sistema.</div>';
    else if (e === 'admin') h += '<div class="ay-lim">🔒 Esto lo hace el <b>administrador</b> (o te tiene que dar el permiso). Pedíselo a él.</div>';
    if (e !== 'plan') {
      h += '<ol>' + g.pasos.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('') + '</ol>';
      if (g.ojo) h += '<div class="ay-ojo">💡 ' + esc(g.ojo) + '</div>';
      if (e === 'si' && puedeIr(g)) h += '<button type="button" class="ay-ir" data-ay="' + g.id + '" data-ir>➜ Llevarme ahí</button>';
    }
    burbuja('bot', h);
  }
  function preguntar(q) {
    burbuja('yo', esc(q));
    var r = buscar(q);
    if (!r.length) {
      burbuja('bot', 'No encontré eso en la guía 🤔. Probá con otras palabras (por ejemplo «orden», «caja», «correo», «usuario») o elegí uno de estos:' + chips(sugeridos()));
      return;
    }
    responder(r[0].g);
    var otros = r.slice(1, 4).filter(function (x) { return x.s >= Math.max(2, r[0].s - 3) && x.e !== 'plan'; }).map(function (x) { return x.g; });
    if (otros.length) burbuja('bot', 'También te puede servir:' + chips(otros));
  }

  // ── Número de mensajes internos sin leer ──
  function iniciarContador() {
    var clave = function () { var u = ''; try { u = (typeof USER_NOMBRE !== 'undefined' && USER_NOMBRE) || ''; } catch (e) {} return 'st_chat_visto_' + u; };
    var primera = true;
    function mirar() {
      if (typeof h !== 'function' || !(typeof TOKEN !== 'undefined' && TOKEN)) return;
      h('/api/chat').then(function (msgs) {
        if (!Array.isArray(msgs)) return;
        var yo = (typeof USER_NOMBRE !== 'undefined' && USER_NOMBRE) || '';
        var guardado = null; try { guardado = localStorage.getItem(clave()); } catch (e) {}
        var visto = Number(guardado || 0);
        var max = msgs.reduce(function (a, m) { return Math.max(a, Number(m.id) || 0); }, 0);
        var pg = $('page-chat');
        if (pg && pg.classList.contains('active')) { visto = max; try { localStorage.setItem(clave(), String(max)); } catch (e) {} }
        if (primera && guardado === null) { visto = max; try { localStorage.setItem(clave(), String(max)); } catch (e) {} }   // en un navegador nuevo no cuenta lo viejo
        primera = false;
        var n = msgs.filter(function (m) { return (Number(m.id) || 0) > visto && m.usuario_nombre !== yo; }).length;
        var b = $('st-chat-num'); if (b) { b.textContent = n > 9 ? '9+' : String(n); b.style.display = n ? 'block' : 'none'; }
        var nb = $('chat-badge'); if (nb) { nb.textContent = n ? String(n) : '!'; nb.style.display = n ? 'inline' : 'none'; }
      }).catch(function () {});
    }
    setInterval(mirar, 8000); setTimeout(mirar, 1500);
    document.addEventListener('click', function (e) { var n = e.target.closest && e.target.closest('.nav-item[data-page="chat"], #st-chat-btn'); if (n) setTimeout(mirar, 600); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', montar); else montar();
  window.AyudaSysTech = { abrir: abrir, cerrar: cerrar, buscar: buscar, preguntar: preguntar };
})();
