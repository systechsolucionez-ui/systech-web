import sys, json, os
from openpyxl import Workbook
from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side)
from openpyxl.chart import BarChart, PieChart, Reference
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule
from datetime import datetime

# Carga de datos y archivo de salida
data = json.loads(sys.argv[1])
output = sys.argv[2]

wb = Workbook()

# ─── ESTILOS GLOBALES ────────────────────────────────────────────────────────
AZUL        = "1E3A5F"
AZUL_CLARO  = "D6E4F0"
VERDE       = "1A7A4A"
VERDE_CLARO = "D4EDDA"
GRIS        = "F5F6FA"
GRIS_OSC    = "6C757D"
NARANJA     = "E67E22"
ROJO        = "C0392B"
BLANCO      = "FFFFFF"

def fill(hex_color): 
    return PatternFill("solid", fgColor=hex_color)

def font(bold=False, color="000000", size=11, italic=False):
    return Font(bold=bold, color=color, size=size, italic=italic, name="Arial")

def border_thin():
    s = Side(style="thin", color="CCCCCC")
    return Border(left=s, right=s, top=s, bottom=s)

def center(): 
    return Alignment(horizontal="center", vertical="center", wrap_text=True)

def left():   
    return Alignment(horizontal="left", vertical="center", wrap_text=True)

def header_row(ws, row, cols):
    """Genera una fila de encabezado estandarizada"""
    ws.row_dimensions[row].height = 24
    for c, label in enumerate(cols, 1):
        cell = ws.cell(row=row, column=c, value=label)
        cell.font      = font(bold=True, color=BLANCO, size=10)
        cell.fill      = fill(AZUL)
        cell.alignment = center()
        cell.border    = border_thin()

def title_section(ws, row, text, col_start=1, col_end=6):
    """Sección de título visualmente destacada"""
    ws.row_dimensions[row].height = 30
    cell = ws.cell(row=row, column=col_start, value=text)
    cell.font      = font(bold=True, color=BLANCO, size=12)
    cell.fill      = fill(AZUL)
    cell.alignment = center()
    ws.merge_cells(start_row=row, start_column=col_start,
                   end_row=row,   end_column=col_end)
    return row + 1

def pesos(val):
    try:
        return float(val) if val else 0.0
    except ValueError:
        return 0.0

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 1: RESUMEN EJECUTIVO
# ═══════════════════════════════════════════════════════════════════════════════
ws1 = wb.active
ws1.title = "📊 Resumen"
ws1.sheet_view.showGridLines = False

# Título principal
ws1.row_dimensions[1].height = 40
ws1.merge_cells("A1:H1")
c = ws1["A1"]
c.value     = "REPORTE EJECUTIVO — SISTEMA DE GESTIÓN TÉCNICA"
c.font      = font(bold=True, color=BLANCO, size=14)
c.fill      = fill(AZUL)
c.alignment = center()

ws1.merge_cells("A2:H2")
c = ws1["A2"]
c.value     = f"Generado el {datetime.now().strftime('%d/%m/%Y %H:%M')}"
c.font      = font(italic=True, color=GRIS_OSC, size=10)
c.fill      = fill(AZUL_CLARO)
c.alignment = center()
ws1.row_dimensions[2].height = 20

# KPIs
kpis = [
    ("Total Órdenes",      pesos(data["resumen"]["total_ordenes"]),       AZUL,    "🔧"),
    ("Total Facturado",    pesos(data["resumen"]["total_facturado"]),     VERDE,   "💰"),
    ("Ticket Promedio",    pesos(data["resumen"]["ticket_promedio"]),    NARANJA, "📈"),
    ("Órdenes Cobradas",   pesos(data["resumen"]["cobradas"]),            VERDE,   "✅"),
    ("Equipos Entregados", pesos(data["resumen"]["entregadas"]),          AZUL,    "📦"),
]

ws1.row_dimensions[4].height = 24
ws1["A4"].value = "INDICADORES CLAVE"
ws1["A4"].font  = font(bold=True, color=AZUL, size=11)
ws1.merge_cells("A4:H4")

row_kpi = 5
for col, (label, valor, color, icon) in enumerate(kpis, 1):
    ws1.column_dimensions[get_column_letter(col)].width = 20
    # Ícono + label
    c1 = ws1.cell(row=row_kpi, column=col, value=f"{icon} {label}")
    c1.font      = font(bold=True, color=BLANCO, size=9)
    c1.fill      = fill(color)
    c1.alignment = center()
    c1.border    = border_thin()
    ws1.row_dimensions[row_kpi].height = 24
    # Valor
    c2 = ws1.cell(row=row_kpi+1, column=col, value=valor)
    c2.font      = font(bold=True, color=color, size=14)
    c2.fill      = fill(GRIS)
    c2.alignment = center()
    c2.border    = border_thin()
    if col in (2, 3):  # Formato de moneda para Facturación y Ticket Promedio
        c2.number_format = '$#,##0'
    else:
        c2.number_format = '#,##0'
    ws1.row_dimensions[row_kpi+1].height = 34

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 2: ÓRDENES POR MES
# ═══════════════════════════════════════════════════════════════════════════════
ws2 = wb.create_sheet("📅 Órdenes por Mes")
ws2.sheet_view.showGridLines = False
ws2.column_dimensions["A"].width = 16
ws2.column_dimensions["B"].width = 16
ws2.column_dimensions["C"].width = 22

title_section(ws2, 1, "ÓRDENES Y FACTURACIÓN POR MES", 1, 3)
header_row(ws2, 2, ["Mes", "Cantidad de Órdenes", "Total Facturado ($)"])

for i, m in enumerate(data["ordenesPorMes"]):
    alt = i % 2 == 0
    row_n = i + 3
    
    c_mes = ws2.cell(row=row_n, column=1, value=m["mes"])
    c_mes.fill = fill(GRIS if alt else BLANCO)
    c_mes.font = font(bold=True, size=10)
    c_mes.border = border_thin()
    
    c_cant = ws2.cell(row=row_n, column=2, value=int(m["cantidad"]))
    c_cant.fill = fill(GRIS if alt else BLANCO)
    c_cant.alignment = center()
    c_cant.border = border_thin()
    c_cant.number_format = '#,##0'
    
    c_tot = ws2.cell(row=row_n, column=3, value=pesos(m["total"]))
    c_tot.number_format = '$#,##0.00'
    c_tot.fill = fill(GRIS if alt else BLANCO)
    c_tot.border = border_thin()

# Fila TOTAL
last = len(data["ordenesPorMes"]) + 3
ws2.cell(row=last, column=1, value="TOTAL").font = font(bold=True, color=BLANCO, size=10)
ws2.cell(row=last, column=1).fill = fill(AZUL)
ws2.cell(row=last, column=1).border = border_thin()

c_sum_cant = ws2.cell(row=last, column=2, value=f'=SUM(B3:B{last-1})')
c_sum_cant.font = font(bold=True, color=BLANCO)
c_sum_cant.fill = fill(AZUL)
c_sum_cant.alignment = center()
c_sum_cant.border = border_thin()
c_sum_cant.number_format = '#,##0'

c_sum_tot = ws2.cell(row=last, column=3, value=f'=SUM(C3:C{last-1})')
c_sum_tot.number_format = '$#,##0.00'
c_sum_tot.font = font(bold=True, color=BLANCO)
c_sum_tot.fill = fill(AZUL)
c_sum_tot.border = border_thin()

# Gráfico de barras
if data["ordenesPorMes"]:
    chart = BarChart()
    chart.type = "col"
    chart.title = "Órdenes por Mes"
    chart.y_axis.title = "Cantidad"
    chart.x_axis.title = "Mes"
    chart.style = 10
    chart.width = 18; chart.height = 10
    cats = Reference(ws2, min_col=1, min_row=3, max_row=last-1)
    vals = Reference(ws2, min_col=2, min_row=2, max_row=last-1)
    chart.add_data(vals, titles_from_data=True)
    chart.set_categories(cats)
    chart.series[0].graphicalProperties.solidFill = "2E86C1"
    ws2.add_chart(chart, "E2")

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 3: ÓRDENES POR ESTADO
# ═══════════════════════════════════════════════════════════════════════════════
ws3 = wb.create_sheet("🔄 Estado de Órdenes")
ws3.sheet_view.showGridLines = False
ws3.column_dimensions["A"].width = 22
ws3.column_dimensions["B"].width = 20
ws3.column_dimensions["C"].width = 16

title_section(ws3, 1, "DISTRIBUCIÓN DE ÓRDENES POR ESTADO", 1, 3)
header_row(ws3, 2, ["Estado", "Cantidad", "% del Total"])

total_ord = sum(e["cantidad"] for e in data["ordenesPorEstado"]) or 1
ESTADO_COLORES = {"recibido":"2E86C1","diagnostico":"F39C12","reparando":"8E44AD","listo":"27AE60","entregado":"7F8C8D","cancelado":"E74C3C"}

for i, e in enumerate(data["ordenesPorEstado"]):
    row_n = i + 3
    color = ESTADO_COLORES.get(e["estado"].lower(), "555555")
    
    c1 = ws3.cell(row=row_n, column=1, value=e["estado"].upper())
    c1.font = font(bold=True, color=BLANCO, size=10)
    c1.fill = fill(color); c1.alignment = left(); c1.border = border_thin()
    
    c2 = ws3.cell(row=row_n, column=2, value=int(e["cantidad"]))
    c2.alignment = center(); c2.border = border_thin(); c2.font = font(size=10)
    c2.number_format = '#,##0'
    
    c3 = ws3.cell(row=row_n, column=3, value=pesos(e["cantidad"]/total_ord))
    c3.number_format = '0.0%'
    c3.alignment = center(); c3.border = border_thin(); c3.font = font(size=10)

# Gráfico de Torta
if data["ordenesPorEstado"]:
    pie = PieChart()
    pie.title = "Estados de Órdenes"
    pie.style = 10; pie.width = 15; pie.height = 10
    labels = Reference(ws3, min_col=1, min_row=3, max_row=2+len(data["ordenesPorEstado"]))
    data_ref = Reference(ws3, min_col=2, min_row=2, max_row=2+len(data["ordenesPorEstado"]))
    pie.add_data(data_ref, titles_from_data=True)
    pie.set_categories(labels)
    ws3.add_chart(pie, "E2")

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 4: REPUESTOS MÁS USADOS
# ═══════════════════════════════════════════════════════════════════════════════
ws4 = wb.create_sheet("🔩 Repuestos")
ws4.sheet_view.showGridLines = False
ws4.column_dimensions["A"].width = 14
ws4.column_dimensions["B"].width = 35
ws4.column_dimensions["C"].width = 18
ws4.column_dimensions["D"].width = 20

title_section(ws4, 1, "REPUESTOS MÁS UTILIZADOS", 1, 4)
header_row(ws4, 2, ["Código", "Nombre del Repuesto", "Unidades Usadas", "Total Facturado ($)"])

for i, rep in enumerate(data["repuestosMasUsados"]):
    alt = i % 2 == 0
    bg = GRIS if alt else BLANCO
    row_n = i + 3
    
    for col, val in enumerate([rep["codigo"], rep["nombre"], int(rep["total_usado"]), pesos(rep["total_facturado"])], 1):
        c = ws4.cell(row=row_n, column=col, value=val)
        c.fill = fill(bg); c.border = border_thin(); c.font = font(size=10)
        if col == 4: 
            c.number_format = '$#,##0.00'
        elif col == 3: 
            c.alignment = center()
            c.number_format = '#,##0'

# Formato condicional columna C (barras de calor)
if data["repuestosMasUsados"]:
    last_r = 2 + len(data["repuestosMasUsados"])
    ws4.conditional_formatting.add(f"C3:C{last_r}", ColorScaleRule(
        start_type="min", start_color="FFFFFF",
        end_type="max",   end_color="1A7A4A"))

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 5: TÉCNICOS
# ═══════════════════════════════════════════════════════════════════════════════
ws5 = wb.create_sheet("👨‍🔧 Técnicos")
ws5.sheet_view.showGridLines = False
ws5.column_dimensions["A"].width = 28
ws5.column_dimensions["B"].width = 18
ws5.column_dimensions["C"].width = 22

title_section(ws5, 1, "RENDIMIENTO POR TÉCNICO", 1, 3)
header_row(ws5, 2, ["Técnico", "Órdenes Realizadas", "Total Generado ($)"])

for i, tec in enumerate(data["ingresosPorTecnico"]):
    alt = i % 2 == 0
    bg = VERDE_CLARO if alt else BLANCO
    row_n = i + 3
    
    c1 = ws5.cell(row=row_n, column=1, value=tec["tecnico"] or "Sin asignar")
    c1.font = font(bold=True, size=10); c1.fill = fill(bg); c1.border = border_thin()
    
    c2 = ws5.cell(row=row_n, column=2, value=int(tec["ordenes"]))
    c2.alignment = center(); c2.fill = fill(bg); c2.border = border_thin(); c2.font = font(size=10)
    c2.number_format = '#,##0'
    
    c3 = ws5.cell(row=row_n, column=3, value=pesos(tec["total"]))
    c3.number_format = '$#,##0.00'; c3.fill = fill(bg); c3.border = border_thin(); c3.font = font(size=10)

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 6: STOCK CRÍTICO
# ═══════════════════════════════════════════════════════════════════════════════
ws6 = wb.create_sheet("⚠️ Stock Crítico")
ws6.sheet_view.showGridLines = False
ws6.column_dimensions["A"].width = 16
ws6.column_dimensions["B"].width = 36
ws6.column_dimensions["C"].width = 16
ws6.column_dimensions["D"].width = 16

title_section(ws6, 1, "PRODUCTOS CON STOCK CRÍTICO O AGOTADO", 1, 4)
header_row(ws6, 2, ["Código", "Nombre del Producto", "Stock Actual", "Stock Mínimo"])

for i, p in enumerate(data["stockCritico"]):
    row_n = i + 3
    agotado = p["stock"] == 0
    bg = "FADBD8" if agotado else "FDEBD0"
    color = ROJO if agotado else NARANJA
    
    for col, val in enumerate([p["codigo"], p["nombre"], int(p["stock"]), int(p["stock_minimo"])], 1):
        c = ws6.cell(row=row_n, column=col, value=val)
        c.fill = fill(bg); c.border = border_thin()
        c.font = font(bold=(col <= 2), color=color if col >= 3 else "000000", size=10)
        if col >= 3: 
            c.alignment = center()
            c.number_format = '#,##0'

if not data["stockCritico"]:
    ws6.cell(row=3, column=1, value="✅ No hay productos en stock crítico").font = font(bold=True, color=VERDE, size=11)

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 7: TIPOS DE EQUIPO
# ═══════════════════════════════════════════════════════════════════════════════
ws7 = wb.create_sheet("💻 Tipos de Equipo")
ws7.sheet_view.showGridLines = False
ws7.column_dimensions["A"].width = 26
ws7.column_dimensions["B"].width = 20

title_section(ws7, 1, "ÓRDENES POR TIPO DE EQUIPO", 1, 2)
header_row(ws7, 2, ["Tipo de Equipo", "Cantidad de Órdenes"])

for i, eq in enumerate(data["ordenesPorEquipo"]):
    row_n = i + 3
    alt = i % 2 == 0
    
    c1 = ws7.cell(row=row_n, column=1, value=eq["equipo"] or "Sin especificar")
    c1.fill = fill(GRIS if alt else BLANCO); c1.border = border_thin(); c1.font = font(size=10)
    
    c2 = ws7.cell(row=row_n, column=2, value=int(eq["cantidad"]))
    c2.fill = fill(GRIS if alt else BLANCO); c2.border = border_thin()
    c2.alignment = center(); c2.font = font(size=10)
    c2.number_format = '#,##0'

# ─── AJUSTE DINÁMICO DE COLUMNAS (Aplica a todas las hojas) ──────────────────
for ws in wb.worksheets:
    for col in ws.columns:
        max_len = 0
        for cell in col:
            val = str(cell.value or '')
            # Omitimos celdas fusionadas (generalmente títulos muy largos)
            if cell.coordinate in ws.merged_cells:
                continue
            if len(val) > max_len:
                max_len = len(val)
        col_letter = get_column_letter(col[0].column)
        actual_width = ws.column_dimensions[col_letter].width
        # Determinamos si usar el ancho calculado o mantener el predeterminado
        calculated_width = max(max_len + 3, 10)
        ws.column_dimensions[col_letter].width = max(calculated_width, actual_width or 10)

# ─── AGREGAR MARCA DE AGUA (Unificada sin guardado doble) ────────────────────
try:
    from openpyxl.drawing.image import Image as XLImage
    wm_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'public', 'watermark_excel.png')
    if os.path.exists(wm_path):
        for ws in wb.worksheets:
            try:
                img = XLImage(wm_path)
                img.width = 280
                img.height = 266
                img.anchor = 'D8'
                ws.add_image(img)
            except Exception:
                pass
except Exception:
    pass

# ─── GUARDADO FINAL (ÚNICO) ──────────────────────────────────────────────────
wb.save(output)
print("OK")