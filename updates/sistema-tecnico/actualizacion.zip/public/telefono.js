// MEJORAS-1.7.2 — Arma el número para WhatsApp como sea que lo hayan cargado.
// Acepta: +54 9 11 1234-5678 · 54 11 1234 5678 · 011 15 1234-5678 · 11 1234 5678 · 0424 123 4567 (Venezuela) …
// Devuelve solo dígitos con código de país (lo que pide wa.me) o '' si el número no sirve.
(function (raiz, fabrica) {
  if (typeof module === 'object' && module.exports) module.exports = fabrica();
  else raiz.SysTel = fabrica();
})(typeof self !== 'undefined' ? self : this, function () {
  function digitos(t) { return String(t == null ? '' : t).replace(/\D/g, ''); }

  function argentina(d) {
    var n = d;
    if (n.indexOf('54') === 0 && n.length >= 12) n = n.slice(2);       // ya venía con el código de país
    if (n.length === 11 && n.charAt(0) === '9') n = n.slice(1);          // el 9 de celular
    if (n.charAt(0) === '0') n = n.slice(1);                             // el 0 de larga distancia
    if (n.length === 12) {                                               // el 15 después del código de área
      for (var a = 2; a <= 4; a++) if (n.substr(a, 2) === '15') { n = n.slice(0, a) + n.slice(a + 2); break; }
    }
    if (n.length !== 10 || n.indexOf('15') === 0) return '';             // sin código de área no se puede adivinar
    return '549' + n;
  }

  function venezuela(d) {
    var n = d;
    if (n.indexOf('58') === 0 && n.length === 12) n = n.slice(2);
    if (n.charAt(0) === '0') n = n.slice(1);
    return n.length === 10 ? '58' + n : '';
  }

  function generico(d, pais) {
    var n = d.indexOf(pais) === 0 ? d : pais + (d.charAt(0) === '0' ? d.slice(1) : d);
    return n.length >= 9 && n.length <= 15 ? n : '';
  }

  function numeroWhatsApp(tel, pais) {
    var d = digitos(tel);
    if (!d) return '';
    if (d.indexOf('00') === 0) d = d.slice(2);
    pais = digitos(pais) || '54';
    if (pais === '54') {
      // Un número de otro país cargado completo (con +) se respeta tal cual
      if (/^\s*\+/.test(String(tel)) && d.indexOf('54') !== 0) return d.length >= 9 && d.length <= 15 ? d : '';
      return argentina(d);
    }
    if (pais === '58') {
      if (/^\s*\+/.test(String(tel)) && d.indexOf('58') !== 0) return d.length >= 9 && d.length <= 15 ? d : '';
      return venezuela(d);
    }
    return generico(d, pais);
  }

  function enlaceWhatsApp(tel, texto, pais) {
    var n = numeroWhatsApp(tel, pais);
    return n ? 'https://wa.me/' + n + '?text=' + encodeURIComponent(texto || '') : '';
  }

  return { numeroWhatsApp: numeroWhatsApp, enlaceWhatsApp: enlaceWhatsApp, digitos: digitos };
});
