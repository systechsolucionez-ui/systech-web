/**
 * scanner.js — Soporte universal para lectores de código de barras / QR (pistola USB o Bluetooth)
 *
 * Los lectores funcionan como un teclado: tipean cada carácter del código muy rápido
 * (normalmente <30-50ms entre teclas, contra >100-150ms de una persona escribiendo)
 * y terminan enviando "Enter". No importa el tipo de código (EAN13, Code128, QR, etc.):
 * el lector ya lo decodificó, así que acá solo hay que "escuchar" ese tecleo rápido.
 *
 * Uso:
 *   ScannerListener.on(codigo => { ... hacer algo con el código ... });
 *
 * Por defecto escucha en toda la ventana (funciona aunque el usuario no tenga el foco
 * en ningún campo). Si el foco está sobre un <input>/<textarea> normal donde el usuario
 * está escribiendo a mano, el listener lo detecta por la velocidad y NO interfiere:
 * deja que seas vos quien controle qué campos "escuchan" con data-scan-target.
 */
(function (global) {
  const MAX_INTERVALO_MS = 40;      // tiempo máx. entre teclas para considerarlo "pistola"
  const MIN_LARGO_CODIGO = 3;       // largo mínimo para considerar que es un código válido
  const TIMEOUT_RESET_MS = 300;     // si pasa este tiempo sin teclas, se reinicia el buffer

  let buffer = '';
  let ultimoTiempo = 0;
  let esProbablementeEscaner = true;
  const callbacks = [];

  function resetBuffer() {
    buffer = '';
    esProbablementeEscaner = true;
  }

  function disparar(codigo) {
    callbacks.forEach(cb => { try { cb(codigo); } catch (e) { console.error('Error en callback de scanner:', e); } });
  }

  document.addEventListener('keydown', (e) => {
    // Ignorar teclas de control/modificadoras que no aportan al código
    if (e.key === 'Shift' || e.key === 'Control' || e.key === 'Alt' || e.key === 'Meta' || e.key === 'CapsLock') return;

    const ahora = Date.now();
    const delta = ahora - ultimoTiempo;

    if (delta > TIMEOUT_RESET_MS) resetBuffer();

    if (e.key === 'Enter' || e.key === 'Tab') {
      if (buffer.length >= MIN_LARGO_CODIGO && esProbablementeEscaner) {
        const codigo = buffer;
        resetBuffer();
        ultimoTiempo = ahora;
        // No bloqueamos el Enter/Tab si el foco está en un campo normal de texto libre
        // (así no rompemos formularios que usan Enter para otra cosa), salvo que el
        // campo esté marcado explícitamente como "target" de escaneo.
        const activo = document.activeElement;
        if (activo && activo.hasAttribute && activo.hasAttribute('data-scan-target')) {
          e.preventDefault();
        }
        disparar(codigo);
        return;
      }
      resetBuffer();
      ultimoTiempo = ahora;
      return;
    }

    // Si la tecla llega muy espaciada de la anterior (y ya hay algo en el buffer),
    // probablemente sea tipeo humano, no la pistola.
    if (buffer.length > 0 && delta > MAX_INTERVALO_MS) {
      esProbablementeEscaner = false;
    }

    if (e.key.length === 1) buffer += e.key;
    ultimoTiempo = ahora;
  }, true);

  global.ScannerListener = {
    /** Suscribirse a códigos escaneados. Devuelve función para desuscribirse. */
    on(callback) {
      callbacks.push(callback);
      return () => {
        const i = callbacks.indexOf(callback);
        if (i >= 0) callbacks.splice(i, 1);
      };
    }
  };
})(window);
