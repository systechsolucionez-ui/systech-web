// ============================================================
// Capa de licencia + conexión + chat entre sucursales — se agrega
// como script aparte para no tocar el resto de la app existente.
// ============================================================
(function () {
  function iniciar() {
  const API = window.location.origin + '/api';
  // Configurable por instalación — si no está seteado, las funciones
  // que necesitan el servidor central simplemente avisan que no está
  // disponible, en vez de romper nada del resto del sistema.
  const SERVIDOR_CENTRAL = window.SYSTECH_SERVIDOR_CENTRAL || null;

  const estilos = document.createElement('style');
  estilos.textContent = `
    #systech-lic-overlay { position:fixed; inset:0; background:#0E1220; z-index:99999; display:flex; align-items:center; justify-content:center; font-family:-apple-system,sans-serif; }
    #systech-lic-card { background:#171C2E; border:1px solid #2A3149; border-radius:16px; padding:32px; max-width:420px; width:90%; color:#EDEEF7; }
    #systech-lic-card h2 { margin-top:0 }
    #systech-lic-card input { width:100%; padding:11px 12px; border-radius:8px; border:1px solid #2A3149; background:#0E1220; color:#EDEEF7; font-size:13px; box-sizing:border-box; margin-top:8px }
    #systech-lic-card button { width:100%; margin-top:14px; padding:11px; border:none; border-radius:8px; background:#C6A34E; color:#1a1608; font-weight:600; cursor:pointer }
    #systech-lic-error { color:#E08080; font-size:13px; margin-top:8px }
    #systech-conexion-pill { position:fixed; top:10px; right:10px; z-index:9998; font-size:12px; padding:4px 10px; border-radius:999px; font-family:-apple-system,sans-serif; }
    #systech-conexion-pill.online { background:#1e3a2b; color:#7ee0a0; }
    #systech-conexion-pill.offline { background:#3a1e1e; color:#e07e7e; }
    #systech-chat-btn { position:fixed; bottom:20px; right:20px; z-index:9997; background:#C6A34E; color:#1a1608; border:none; border-radius:50%; width:54px; height:54px; font-size:22px; cursor:pointer; box-shadow:0 4px 12px rgba(0,0,0,.3); }
    #systech-chat-panel { position:fixed; bottom:84px; right:20px; z-index:9997; width:320px; max-height:420px; background:#171C2E; border:1px solid #2A3149; border-radius:14px; display:none; flex-direction:column; overflow:hidden; font-family:-apple-system,sans-serif; }
    #systech-chat-panel.abierto { display:flex; }
    #systech-chat-header { padding:12px 14px; background:#12172B; color:#EDEEF7; font-size:13px; font-weight:600; }
    #systech-chat-mensajes { flex:1; overflow-y:auto; padding:10px; display:flex; flex-direction:column; gap:8px; max-height:280px }
    #systech-chat-mensajes .msg { background:#0E1220; border-radius:8px; padding:8px 10px; font-size:12px; color:#EDEEF7 }
    #systech-chat-mensajes .msg b { color:#C6A34E }
    #systech-chat-form { display:flex; gap:6px; padding:10px; border-top:1px solid #2A3149 }
    #systech-chat-form input { flex:1; padding:8px; border-radius:6px; border:1px solid #2A3149; background:#0E1220; color:#EDEEF7; font-size:12px }
    #systech-chat-form button { padding:8px 12px; border:none; border-radius:6px; background:#C6A34E; color:#1a1608; font-weight:600; cursor:pointer; font-size:12px }
    #systech-chat-aviso { padding:14px; color:#9BA0B8; font-size:12px; text-align:center }
  `;
  document.head.appendChild(estilos);

  // ---------- Indicador de conexión ----------
  const pill = document.createElement('div');
  pill.id = 'systech-conexion-pill';
  document.body.appendChild(pill);
  function actualizarPill() {
    const online = navigator.onLine;
    pill.textContent = online ? '● Conectado' : '● Sin conexión';
    pill.className = online ? 'online' : 'offline';
  }
  window.addEventListener('online', actualizarPill);
  window.addEventListener('offline', actualizarPill);
  actualizarPill();

  // ---------- Activación ----------
  async function verificarActivacion() {
    try {
      const r = await fetch(API + '/licencia/estado');
      const estado = await r.json();
      if (!estado.activado) mostrarPantallaActivacion();
      else window.SYSTECH_LICENCIA = estado;
    } catch (e) {
      // Si ni siquiera el propio backend local responde, no es tema de
      // licencia — dejamos que el resto de la app maneje ese error.
    }
  }

  function mostrarPantallaActivacion() {
    const overlay = document.createElement('div');
    overlay.id = 'systech-lic-overlay';
    overlay.innerHTML = `
      <div id="systech-lic-card">
        <h2>Activar Systech</h2>
        <p style="color:#9BA0B8;font-size:13px">Pegá el código de activación que te dio Systech. No necesitás internet para este paso.</p>
        <input type="text" id="systech-lic-input" placeholder="Código de activación">
        <button id="systech-lic-btn">Activar</button>
        <div id="systech-lic-error" style="display:none"></div>
      </div>`;
    document.body.appendChild(overlay);
    document.getElementById('systech-lic-btn').addEventListener('click', async () => {
      const codigo = document.getElementById('systech-lic-input').value.trim();
      const errEl = document.getElementById('systech-lic-error');
      errEl.style.display = 'none';
      try {
        const r = await fetch(API + '/licencia/activar', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ codigo }),
        });
        const d = await r.json();
        if (!r.ok) throw new Error(d.error || 'Código inválido.');
        overlay.remove();
        window.location.reload();
      } catch (e) {
        errEl.textContent = '⚠️ ' + e.message;
        errEl.style.display = 'block';
      }
    });
  }

  // ---------- Chat entre sucursales ----------
  const chatBtn = document.createElement('button');
  chatBtn.id = 'systech-chat-btn';
  chatBtn.textContent = '💬';
  chatBtn.title = 'Chat entre sucursales';
  document.body.appendChild(chatBtn);

  const chatPanel = document.createElement('div');
  chatPanel.id = 'systech-chat-panel';
  chatPanel.innerHTML = `
    <div id="systech-chat-header">Chat entre sucursales</div>
    <div id="systech-chat-mensajes"></div>
    <div id="systech-chat-aviso" style="display:none"></div>
    <form id="systech-chat-form">
      <input type="text" id="systech-chat-input" placeholder="Escribí acá…" maxlength="500">
      <button type="submit">Enviar</button>
    </form>`;
  document.body.appendChild(chatPanel);

  let chatTimer = null;
  chatBtn.addEventListener('click', async () => {
    chatPanel.classList.toggle('abierto');
    if (chatPanel.classList.contains('abierto')) iniciarChat();
    else if (chatTimer) clearInterval(chatTimer);
  });

  async function iniciarChat() {
    const aviso = document.getElementById('systech-chat-aviso');
    const mensajesDiv = document.getElementById('systech-chat-mensajes');
    if (!SERVIDOR_CENTRAL) {
      aviso.style.display = 'block';
      aviso.textContent = 'El chat entre sucursales todavía no está configurado en esta instalación. Contactá a Systech.';
      return;
    }
    if (!navigator.onLine) {
      aviso.style.display = 'block';
      aviso.textContent = 'El chat entre sucursales necesita conexión a internet, porque conecta tu local con los otros a través de nuestro servidor. El resto del sistema sigue funcionando normal sin internet.';
      return;
    }
    aviso.style.display = 'none';
    const negocioId = window.SYSTECH_LICENCIA?.negocioId || (await (await fetch(API + '/licencia/estado')).json()).negocioId;
    if (!negocioId) return;

    async function cargar() {
      try {
        const r = await fetch(`${SERVIDOR_CENTRAL}/api/chat/${negocioId}/mensajes`, { signal: AbortSignal.timeout(6000) });
        const rows = await r.json();
        mensajesDiv.innerHTML = rows.map((m) => `<div class="msg"><b>${escapeHtml(m.sucursal_nombre)}:</b> ${escapeHtml(m.texto)}</div>`).join('');
        mensajesDiv.scrollTop = mensajesDiv.scrollHeight;
      } catch {
        aviso.style.display = 'block';
        aviso.textContent = 'No se pudo conectar al chat en este momento.';
      }
    }
    cargar();
    if (chatTimer) clearInterval(chatTimer);
    chatTimer = setInterval(cargar, 5000);

    document.getElementById('systech-chat-form').onsubmit = async (e) => {
      e.preventDefault();
      const input = document.getElementById('systech-chat-input');
      const texto = input.value.trim();
      if (!texto) return;
      const sucursal = window.SYSTECH_NOMBRE_SUCURSAL || 'Sucursal';
      try {
        await fetch(`${SERVIDOR_CENTRAL}/api/chat/${negocioId}/mensaje`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sucursal, texto }),
        });
        input.value = '';
        cargar();
      } catch {}
    };
  }

  function escapeHtml(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

  verificarActivacion();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciar);
  } else {
    iniciar();
  }
})();
