/* SysTech — Configuración → ARCA / Facturación electrónica (1.6.1)
   Asistente para obtener el certificado sin comandos:
     1. El programa genera el pedido (.csr) y guarda la clave privada adentro (nunca se muestra).
     2. La persona sube ese pedido a ARCA, autoriza Facturación Electrónica y crea el punto de venta.
     3. Sube acá el certificado (.crt) que le dio ARCA → el programa controla que haga pareja.
     4. Completa los datos y prueba la conexión.
   Usa las funciones de index.html: h() (fetch con token), TOKEN, toast(), showCfgTab(), goTo(). */
(function () {
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const fecha = iso => iso ? iso.slice(0, 10).split('-').reverse().join('/') : '';
  const cuitFmt = c => /^\d{11}$/.test(c || '') ? `${c.slice(0, 2)}-${c.slice(2, 10)}-${c.slice(10)}` : (c || '');

  const CSS = `
  .arca-wrap{display:grid;gap:16px;max-width:900px}
  .arca-estado{display:flex;gap:14px;align-items:center;padding:14px 16px;border-radius:10px;border:1px solid var(--border);background:var(--surface2)}
  .arca-estado b{font-size:15px}
  .arca-dot{width:14px;height:14px;border-radius:50%;flex:none}
  .arca-paso{display:grid;grid-template-columns:34px 1fr;gap:12px;padding:14px 0;border-top:1px solid var(--border)}
  .arca-paso:first-of-type{border-top:0}
  .arca-num{width:30px;height:30px;border-radius:50%;display:grid;place-items:center;font-weight:700;background:var(--surface2);border:1px solid var(--border)}
  .arca-paso.ok .arca-num{background:#1FBF75;color:#fff;border-color:#1FBF75}
  .arca-paso h4{margin:2px 0 6px;font-size:14px}
  .arca-paso ol{margin:6px 0 0 18px;padding:0;font-size:13px;line-height:1.7}
  .arca-row{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end}
  .arca-row label:not(.btn){display:grid;gap:4px;font-size:12px;color:var(--text2)}
  .arca-row input,.arca-row select{min-width:180px}
  .arca-ok{color:#1FBF75;font-weight:600}.arca-mal{color:#e5484d;font-weight:600}
  .arca-nota{font-size:12px;color:var(--text2);line-height:1.6}
  .arca-res{margin-top:10px;font-size:13px}`;

  function html() {
    return `<style>${CSS}</style>
    <div class="arca-wrap">
      <!-- FISCAL-1.7.0: datos fiscales del emisor (antes en Facturación → Datos Fiscales) -->
      <div class="config-section" id="fis-sec">
        <h3>📄 Datos fiscales del emisor</h3>
        <div class="arca-nota" style="margin-bottom:12px">Salen impresos en facturas, presupuestos y notas. El CUIT tiene que ser el mismo del certificado de ARCA.</div>
        <div id="fis-aviso"></div>
        <div class="form-grid">
          <div class="form-group full"><label>Razón social / Nombre</label><input type="text" id="fis-razon_social" placeholder="Tu nombre o empresa"></div>
          <div class="form-group"><label>CUIT</label><input type="text" id="fis-cuit" placeholder="20-12345678-9"></div>
          <div class="form-group"><label>Condición IVA</label>
            <select id="fis-condicion_iva"><option value="Monotributo">Monotributista</option><option value="Responsable Inscripto">Responsable Inscripto</option><option value="Exento">Exento</option></select></div>
          <div class="form-group"><label>Punto de venta</label><input type="number" id="fis-punto_venta" placeholder="1" min="1"></div>
          <div class="form-group"><label>Ingresos Brutos</label><input type="text" id="fis-ingresos_brutos" placeholder="N° IIBB o CM"></div>
          <div class="form-group full"><label>Dirección fiscal</label><input type="text" id="fis-direccion_fiscal" placeholder="Calle, número, ciudad, provincia"></div>
          <div class="form-group"><label>Inicio de actividades</label><input type="text" id="fis-inicio_actividades" placeholder="dd/mm/aaaa"></div>
          <div class="form-group"><label>Texto al pie del comprobante</label><input type="text" id="fis-pie_factura" placeholder="Gracias por su preferencia"></div>
        </div>
        <div class="arca-nota" style="margin:8px 0 14px">El logo se carga en Configuración → 🏢 Empresa.</div>
        <h4 style="font-size:13px;margin:6px 0 10px">Redes sociales (pie de los comprobantes impresos)</h4>
        <div class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr))">
          <div class="form-group"><label>Instagram</label><input type="text" id="fis-redes_instagram" placeholder="@tu_negocio"></div>
          <div class="form-group"><label>Facebook</label><input type="text" id="fis-redes_facebook" placeholder="/tu_negocio"></div>
          <div class="form-group"><label>WhatsApp</label><input type="text" id="fis-redes_whatsapp" placeholder="11 2345-6789"></div>
        </div>
        <h4 style="font-size:13px;margin:16px 0 10px">Numeración correlativa</h4>
        <div class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr))">
          <div class="form-group"><label>Próximo N° presupuesto</label><input type="number" id="fis-proximo_numero_presupuesto" min="1"></div>
          <div class="form-group"><label>Próximo N° factura A</label><input type="number" id="fis-proximo_numero_factura_a" min="1"></div>
          <div class="form-group"><label>Próximo N° factura B</label><input type="number" id="fis-proximo_numero_factura_b" min="1"></div>
          <div class="form-group"><label>Próximo N° nota de crédito</label><input type="number" id="fis-proximo_numero_nota_credito" min="1"></div>
        </div>
        <div class="arca-nota" style="margin-top:6px">Con ARCA habilitado, el número de cada factura lo da ARCA.</div>
        <div style="display:flex;justify-content:flex-end;margin-top:14px"><button class="btn btn-primary" id="fis-save">💾 Guardar datos fiscales</button></div>
      </div>
      <div class="config-section">
        <h3>🏛️ Facturación electrónica ARCA</h3>
        <div class="hint" style="margin-bottom:12px">Para emitir facturas con CAE desde SysTech. Se configura una sola vez. Lo de ARCA se hace con la clave fiscal (nivel 3) del titular del CUIT o de su contador.</div>
        <div class="arca-estado" id="arca-estado"><span class="arca-dot" style="background:#999"></span><div><b>Consultando…</b></div></div>
      </div>

      <div class="config-section">
        <h3>🔐 Certificado de ARCA — paso a paso</h3>
        <div class="arca-paso" id="arca-p1"><div class="arca-num">1</div><div>
          <h4>Generá el pedido para ARCA</h4>
          <div class="arca-row">
            <label>CUIT del titular<input type="text" id="arca-g-cuit" inputmode="numeric" maxlength="13" placeholder="20-12345678-9"></label>
            <label style="flex:1">Nombre o razón social (como figura en ARCA)<input type="text" id="arca-g-nombre" maxlength="60" placeholder="Ej.: Juan Pérez o Taller Pérez SRL"></label>
            <button class="btn btn-primary" id="arca-g-btn">📄 Generar pedido</button>
          </div>
          <div class="arca-nota" id="arca-g-estado" style="margin-top:8px">Se descarga un archivo <b>.csr</b>. La clave privada queda guardada en SysTech: no la tenés que manejar.</div>
        </div></div>

        <div class="arca-paso" id="arca-p2"><div class="arca-num">2</div><div>
          <h4>Subí el pedido a ARCA y bajá el certificado</h4>
          <ol>
            <li>Entrá a <b>arca.gob.ar</b> con la clave fiscal del titular.</li>
            <li>Abrí <b>Administración de Certificados Digitales</b>. Si no aparece: <i>Administrador de Relaciones de Clave Fiscal → Adherir servicio → ARCA → Servicios interactivos → Administración de Certificados Digitales</i>.</li>
            <li>Elegí el CUIT → <b>Agregar alias</b> → alias <b>systech</b> → elegí el archivo <b>.csr</b> del paso 1 → <b>Agregar alias</b>.</li>
            <li>Entrá al alias <b>systech</b> y <b>descargá el certificado</b> (.crt).</li>
          </ol>
        </div></div>

        <div class="arca-paso" id="arca-p3"><div class="arca-num">3</div><div>
          <h4>Autorizá la facturación electrónica</h4>
          <ol>
            <li>En ARCA: <b>Administrador de Relaciones de Clave Fiscal → Nueva relación</b>.</li>
            <li><b>Buscar → ARCA → Web Services → Facturación Electrónica</b>.</li>
            <li>En <b>Representante</b> elegí el computador fiscal <b>systech</b> y confirmá.</li>
          </ol>
          <div class="arca-nota">Sin este paso, ARCA rechaza la conexión aunque el certificado esté bien.</div>
        </div></div>

        <div class="arca-paso" id="arca-p4"><div class="arca-num">4</div><div>
          <h4>Creá un punto de venta para SysTech</h4>
          <ol>
            <li>En ARCA: <b>Administración de puntos de venta y domicilios → A/B/M de puntos de venta → Agregar</b>.</li>
            <li>Un número nuevo (por ejemplo <b>2</b>) con sistema <b>"Factura Electrónica – Monotributo – Web Services"</b> (monotributo) o <b>"RECE para aplicativo y web services"</b> (responsable inscripto).</li>
          </ol>
          <div class="arca-nota">No uses el punto de venta de "Comprobantes en línea": SysTech necesita uno propio.</div>
        </div></div>

        <div class="arca-paso" id="arca-p5"><div class="arca-num">5</div><div>
          <h4>Subí acá el certificado (.crt) que te dio ARCA</h4>
          <div class="arca-row">
            <label class="btn btn-primary" style="cursor:pointer">⬆️ Subir certificado .crt<input type="file" id="arca-up-crt" accept=".crt,.pem,.cer" style="display:none"></label>
          </div>
          <div class="arca-nota" id="arca-cert-estado" style="margin-top:8px"></div>
          <details style="margin-top:10px"><summary class="arca-nota" style="cursor:pointer">¿Ya tenés tu propio .crt y .key? (generados con OpenSSL o por tu contador)</summary>
            <div class="arca-row" style="margin-top:8px">
              <label>Certificado (.crt)<input type="file" id="arca-own-crt" accept=".crt,.pem,.cer"></label>
              <label>Clave privada (.key)<input type="file" id="arca-own-key" accept=".key,.pem"></label>
              <button class="btn btn-ghost" id="arca-own-btn">Subir los dos</button>
            </div>
            <div class="arca-nota">La clave privada nunca se sube a ARCA ni se manda por mail o WhatsApp: solo va acá.</div>
          </details>
        </div></div>

        <div class="arca-paso" id="arca-p6"><div class="arca-num">6</div><div>
          <h4>Completá los datos y probá</h4>
          <div class="arca-row">
            <label>CUIT (sin guiones)<input type="text" id="arca-cuit" maxlength="11" inputmode="numeric"></label>
            <label>Punto de venta<input type="number" id="arca-pv" min="1" max="99999" style="min-width:110px"></label>
            <label>Condición fiscal<select id="arca-cond"><option value="monotributo">Monotributo — Factura C</option><option value="responsable">Responsable Inscripto — Factura A/B</option></select></label>
          </div>
          <div class="arca-row" style="margin-top:10px">
            <label>Ambiente<select id="arca-prod"><option value="1">🚀 Producción (facturas reales)</option><option value="0">🧪 Homologación (solo pruebas, con certificado de homologación)</option></select></label>
            <label>Facturación electrónica<select id="arca-hab"><option value="1">✅ Habilitada</option><option value="0">❌ Deshabilitada</option></select></label>
            <button class="btn btn-primary" id="arca-save">💾 Guardar</button>
            <button class="btn btn-ghost" id="arca-test">🔌 Probar conexión</button>
          </div>
          <div class="arca-res" id="arca-test-res"></div>
          <div class="arca-nota" style="margin-top:8px">Después hacé una factura chica de prueba y verificala en ARCA → "Mis Comprobantes".</div>
        </div></div>
      </div>

      <div class="config-section">
        <h3>🧾 Facturas y ARCA</h3>
        <div class="arca-nota">Todas las facturas en un solo lugar: cuáles ya pasaron por ARCA (tienen CAE) y cuáles no. Desde acá las imprimís y pedís el CAE de las que falten. Con ARCA habilitado, las facturas nuevas piden el CAE solas al emitirse.</div>
        <div class="arca-row" style="margin:10px 0"><button class="btn btn-sm" data-arcaf="sin">Sin CAE</button><button class="btn btn-sm" data-arcaf="con">Con CAE</button><button class="btn btn-sm" data-arcaf="">Todas</button></div>
        <div id="arca-comps"></div>
      </div>

      <div class="config-section">
        <h3>📋 Últimas operaciones con ARCA</h3>
        <button class="btn btn-ghost btn-sm" id="arca-log-btn">Ver</button>
        <div id="arca-log" style="margin-top:10px"></div>
      </div>
    </div>`;
  }

  const api = (url, opts) => h(url, opts);
  function bajar(nombre, texto) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([texto], { type: 'application/pkcs10' })); a.download = nombre;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
  async function subir(campos) {
    const fd = new FormData(); for (const [k, f] of Object.entries(campos)) if (f) fd.append(k, f);
    const r = await fetch('/api/arca/upload-cert', { method: 'POST', headers: { 'x-token': TOKEN }, body: fd });
    let d = {}; try { d = await r.json(); } catch (e) {}
    if (!r.ok || !d.ok) throw new Error(d.error || 'No se pudo subir el archivo.');
    return d;
  }

  let CFG = {}, EST = {};
  // FISCAL-1.7.0: datos fiscales del emisor (misma tabla y mismos datos que antes en Facturación)
  const FIS_CAMPOS = ['razon_social', 'cuit', 'condicion_iva', 'punto_venta', 'ingresos_brutos', 'direccion_fiscal', 'inicio_actividades', 'pie_factura',
    'redes_instagram', 'redes_facebook', 'redes_whatsapp', 'proximo_numero_presupuesto', 'proximo_numero_factura_a', 'proximo_numero_factura_b', 'proximo_numero_nota_credito'];
  let FIS = {};
  function avisoFiscal() {
    const box = $('fis-aviso'); if (!box) return;
    const cf = String((FIS.cuit || '')).replace(/\D/g, ''), ca = String(CFG.cuit || '').replace(/\D/g, '');
    box.innerHTML = cf && ca && cf !== ca
      ? `<div class="arca-res arca-mal" style="margin:0 0 12px">⚠ El CUIT de los datos fiscales (${esc(cuitFmt(cf))}) no es el del certificado de ARCA (${esc(cuitFmt(ca))}). Corregí uno de los dos: si no, ARCA no da el CAE.</div>`
      : (!cf ? '<div class="arca-res" style="margin:0 0 12px;color:#f59f00;font-weight:600">Completá la razón social y el CUIT: salen impresos en los comprobantes.</div>' : '');
  }
  async function cargarFiscal() {
    try { FIS = await api('/api/fiscal/config'); } catch (e) { FIS = {}; }
    if (!FIS || FIS.error) { FIS = {}; const s = $('fis-sec'); if (s) s.style.display = 'none'; return; }
    for (const k of FIS_CAMPOS) { const el = $('fis-' + k); if (el) el.value = FIS[k] == null ? '' : FIS[k]; }
    if (!$('fis-condicion_iva').value) $('fis-condicion_iva').value = 'Monotributo';
    avisoFiscal();
  }
  async function cargar() {
    const box = $('cfgtab-arca'); if (!box) return;
    if (!box.dataset.listo) { box.innerHTML = html(); box.dataset.listo = '1'; enlazar(); }
    try { [CFG, EST] = await Promise.all([api('/api/arca/config'), api('/api/arca/estado-cert')]); } catch (e) { CFG = {}; EST = {}; }
    if (CFG.error || EST.error) { $('arca-estado').innerHTML = `<span class="arca-dot" style="background:#e5484d"></span><div><b>Solo un administrador puede ver esta sección.</b></div>`; return; }
    $('arca-cuit').value = CFG.cuit || ''; $('arca-pv').value = CFG.punto_venta || '';
    $('arca-cond').value = CFG.condicion || 'monotributo'; $('arca-prod').value = CFG.habilitado && !CFG.produccion ? '0' : '1';
    $('arca-hab').value = CFG.habilitado ? '1' : '0';
    await cargarFiscal(); // FISCAL-1.7.0
    if (!$('arca-g-cuit').value && CFG.cuit) $('arca-g-cuit').value = cuitFmt(CFG.cuit);
    pintar();
  }
  function pintar() {
    const listoCert = EST.tiene_cert && EST.tiene_key && EST.pareja && !EST.vencido;
    const datos = CFG.cuit && CFG.punto_venta;
    let color = '#e5484d', titulo = 'Falta el certificado de ARCA', sub = 'Seguí los pasos de abajo.';
    if (listoCert && datos && CFG.habilitado) { color = '#1FBF75'; titulo = 'Lista para facturar'; sub = `CUIT ${cuitFmt(CFG.cuit)} · Punto de venta ${CFG.punto_venta} · ${CFG.produccion ? 'Producción' : 'Homologación'} · certificado válido hasta el ${fecha(EST.vence)}`; }
    else if (listoCert && datos) { color = '#F2B84B'; titulo = 'Certificado listo — falta habilitar'; sub = 'Elegí "Habilitada" en el paso 6, guardá y probá la conexión.'; }
    else if (listoCert) { color = '#F2B84B'; titulo = 'Certificado listo — faltan datos'; sub = 'Completá CUIT y punto de venta en el paso 6.'; }
    else if (EST.vencido) { titulo = 'El certificado está vencido'; sub = 'Generá un pedido nuevo (paso 1) y repetí los pasos 2 y 5.'; }
    else if (EST.tiene_cert && EST.tiene_key && EST.pareja === false) { titulo = 'El certificado y la clave no son pareja'; sub = 'Subí el certificado del último pedido que generaste (paso 5).'; }
    else if (EST.pendiente) { color = '#F2B84B'; titulo = 'Pedido generado — falta el certificado'; sub = 'Hacé los pasos 2 a 4 en ARCA y subí el .crt en el paso 5.'; }
    $('arca-estado').innerHTML = `<span class="arca-dot" style="background:${color}"></span><div><b>${titulo}</b><div class="arca-nota">${esc(sub)}</div></div>`;
    const marca = (id, ok) => $(id).classList.toggle('ok', !!ok);
    marca('arca-p1', EST.pendiente || listoCert); marca('arca-p2', listoCert); marca('arca-p5', listoCert); marca('arca-p6', listoCert && datos && CFG.habilitado);
    $('arca-g-estado').innerHTML = EST.pendiente
      ? `Pedido generado el ${fecha(EST.pendiente.fecha)} para el CUIT ${cuitFmt(EST.pendiente.cuit)}. <a href="#" id="arca-g-again">Descargarlo de nuevo</a>. Si generás otro, el anterior deja de servir.`
      : `Se descarga un archivo <b>.csr</b>. La clave privada queda guardada en SysTech: no la tenés que manejar.${listoCert ? ' Ya tenés un certificado funcionando: generá uno nuevo solo si vence o lo cambiás.' : ''}`;
    const again = $('arca-g-again'); if (again) again.onclick = async ev => { ev.preventDefault(); const r = await api('/api/arca/pedido-csr'); if (r.csr) bajar(r.archivo, r.csr); };
    $('arca-cert-estado').innerHTML = EST.tiene_cert
      ? (listoCert ? `<span class="arca-ok">✔ Certificado cargado</span> · CUIT ${cuitFmt(EST.cuit_cert || CFG.cuit)} · válido hasta el ${fecha(EST.vence)}` : `<span class="arca-mal">⚠ Hay un certificado cargado pero ${EST.vencido ? 'está vencido' : !EST.tiene_key ? 'falta la clave' : 'no hace pareja con la clave'}.</span>`)
      : 'Todavía no hay certificado cargado.';
  }
  function enlazar() {
    // FISCAL-1.7.0: guardar datos fiscales
    $('fis-save').onclick = async () => {
      const cfg = {}; for (const k of FIS_CAMPOS) { const el = $('fis-' + k); if (el) cfg[k] = el.value.trim(); }
      const d = cfg.cuit.replace(/\D/g, '');
      if (cfg.cuit && d.length !== 11) return toast('El CUIT tiene que tener 11 números', 'error');
      if (!cfg.razon_social) return toast('Escribí la razón social o nombre', 'error');
      $('fis-save').disabled = true;
      try { const r = await api('/api/fiscal/config', { method: 'PUT', body: JSON.stringify(cfg) });
        if (!r || r.error) throw new Error((r && r.error) || 'No se pudo guardar');
        FIS = { ...FIS, ...cfg }; avisoFiscal(); toast('Datos fiscales guardados ✓');
      } catch (e) { toast(e.message, 'error'); } finally { $('fis-save').disabled = false; }
    };
    $('arca-g-btn').onclick = async () => {
      const cuit = $('arca-g-cuit').value.replace(/\D/g, ''), nombre = $('arca-g-nombre').value.trim();
      if (cuit.length !== 11) return toast('El CUIT tiene que tener 11 números', 'error');
      if (nombre.length < 3) return toast('Escribí el nombre o razón social', 'error');
      if (EST.pendiente && !confirm('Ya generaste un pedido el ' + fecha(EST.pendiente.fecha) + '. Si generás otro, el anterior deja de servir: si ya lo subiste a ARCA, vas a tener que borrar ese alias y subir el nuevo. ¿Generar uno nuevo igual?')) return;
      if (EST.tiene_cert && EST.pareja && !EST.vencido && !confirm('Ya tenés un certificado funcionando. ¿Generar un pedido nuevo? El actual sigue andando hasta que subas el nuevo certificado.')) return;
      $('arca-g-btn').disabled = true;
      try { const r = await api('/api/arca/generar-pedido', { method: 'POST', body: JSON.stringify({ cuit, nombre }) });
        if (!r.ok) throw new Error(r.error || 'No se pudo generar');
        bajar(r.archivo, r.csr); toast('Pedido descargado: subilo a ARCA (paso 2)'); await cargar();
      } catch (e) { toast(e.message, 'error'); } finally { $('arca-g-btn').disabled = false; }
    };
    $('arca-up-crt').onchange = async e => { const f = e.target.files[0]; e.target.value = ''; if (!f) return;
      try { const d = await subir({ cert: f }); toast(d.aviso || `Certificado cargado ✓ (válido hasta el ${fecha(d.vence)})`, d.aviso ? 'error' : undefined); await cargar(); }
      catch (x) { toast(x.message, 'error'); $('arca-cert-estado').innerHTML = `<span class="arca-mal">✖ ${esc(x.message)}</span>`; } };
    $('arca-own-btn').onclick = async () => { const c = $('arca-own-crt').files[0], k = $('arca-own-key').files[0];
      if (!c && !k) return toast('Elegí el .crt y el .key', 'error');
      try { const d = await subir({ cert: c, key: k }); toast(d.aviso || 'Archivos cargados ✓', d.aviso ? 'error' : undefined); $('arca-own-crt').value = ''; $('arca-own-key').value = ''; await cargar(); }
      catch (x) { toast(x.message, 'error'); } };
    $('arca-save').onclick = async () => {
      const body = { cuit: $('arca-cuit').value.replace(/\D/g, ''), punto_venta: parseInt($('arca-pv').value, 10) || '', condicion: $('arca-cond').value, produccion: $('arca-prod').value === '1', habilitado: $('arca-hab').value === '1' };
      if (body.cuit.length !== 11) return toast('El CUIT tiene que tener 11 números', 'error');
      if (!body.punto_venta) return toast('Poné el número de punto de venta', 'error');
      const r = await api('/api/arca/config', { method: 'PUT', body: JSON.stringify(body) });
      if (r.ok) { toast('Configuración ARCA guardada ✓'); await cargar(); avisoFiscal(); } else toast(r.error || 'No se pudo guardar', 'error');
    };
    $('arca-test').onclick = async () => {
      const box = $('arca-test-res'); box.innerHTML = 'Conectando con ARCA…';
      try { const r = await api('/api/arca/test');
        if (r.ok) box.innerHTML = `<span class="arca-ok">✔ Conexión correcta</span> · ${esc(r.ambiente)} · servidores: aplicación ${esc(r.AppServer || r.appserver || '?')}, base ${esc(r.DbServer || r.dbserver || '?')}, autenticación ${esc(r.AuthServer || r.authserver || '?')}`;
        else box.innerHTML = `<span class="arca-mal">✖ ${esc(r.error || 'No se pudo conectar')}</span>`;
      } catch (e) { box.innerHTML = `<span class="arca-mal">✖ ${esc(e.message)}</span>`; }
    };
    // ARCA-1.6.5: todas las facturas con su estado en ARCA, en esta misma pestaña
    const pintarComps = async (filtro) => {
      const box = $('arca-comps'); if (!box) return;
      document.querySelectorAll('[data-arcaf]').forEach(b => b.classList.toggle('btn-primary', b.dataset.arcaf === filtro));
      box.innerHTML = '<div class="arca-nota">Cargando…</div>';
      const rows = await api('/api/arca/comprobantes?estado=' + filtro).catch(() => []);
      const nro = c => `${String(c.arca_pv).padStart(4, '0')}-${String(c.arca_nro).padStart(8, '0')}`;
      const tipo = c => c.tipo === 'nota_credito' ? 'Nota de Crédito' : c.tipo === 'nota_debito' ? 'Nota de Débito' : 'Factura';
      box.innerHTML = Array.isArray(rows) && rows.length ? `<table style="width:100%;border-collapse:collapse;font-size:12px">
        <tr><th style="text-align:left">Fecha</th><th style="text-align:left">Comprobante</th><th style="text-align:left">Cliente</th><th style="text-align:right">Total</th><th style="text-align:left">ARCA</th><th></th></tr>
        ${rows.map(c => `<tr style="border-top:1px solid var(--border)">
          <td>${esc(fecha(String(c.fecha || '').replace(' ', 'T')))}</td>
          <td style="font-family:monospace">${esc(c.numero)}</td>
          <td>${esc(((c.cliente_nombre || '') + ' ' + (c.cliente_apellido || '')).trim() || '—')}</td>
          <td style="text-align:right">${Number(c.total || 0).toLocaleString('es-AR')}</td>
          <td>${c.cae ? `<span class="arca-ok">✅ ${tipo(c)} ${esc(c.arca_letra || '')} ${c.arca_nro ? nro(c) : ''}</span><br><span class="arca-nota">CAE ${esc(c.cae)} · vence ${esc(c.cae_vencimiento || '')}</span>` : '<span style="color:#f59f00;font-weight:600">Sin CAE</span>'}</td>
          <td style="white-space:nowrap"><button class="btn btn-ghost btn-sm" data-arcaprint="${c.id}">🖨️</button>
            ${c.cae ? '' : `<button class="btn btn-sm" style="background:#f59f00;color:#111" data-arcacae="${c.id}">Pedir CAE</button>`}</td></tr>`).join('')}</table>`
        : `<div class="arca-nota">${filtro === 'sin' ? 'No hay facturas sin CAE. ✓' : 'Sin comprobantes.'}</div>`;
      box.querySelectorAll('[data-arcaprint]').forEach(b => b.onclick = () => window.open('/factura-print.html?id=' + b.dataset.arcaprint, '_blank', 'width=900,height=700'));
      box.querySelectorAll('[data-arcacae]').forEach(b => b.onclick = async () => {
        const c = rows.find(x => String(x.id) === b.dataset.arcacae); if (!c) return;
        if (!confirm(`¿Pedir el CAE a ARCA para este comprobante?\n\n${c.numero}\nCliente: ${((c.cliente_nombre || '') + ' ' + (c.cliente_apellido || '')).trim() || '—'}\nTotal: ${Number(c.total || 0).toLocaleString('es-AR')}\n\nQueda registrado en ARCA como factura real.`)) return;
        b.disabled = true; b.textContent = '⏳';
        const r = await api('/api/arca/emitir/' + c.id, { method: 'POST', body: '{}' }).catch(e => ({ error: e.message }));
        if (r && r.ok) toast(`✅ ARCA: ${r.recuperado ? 'se recuperó el CAE ' : 'CAE '}${r.cae} · ${r.letra || ''} ${String(r.pv || '').padStart(4, '0')}-${String(r.numero || '').padStart(8, '0')}`);
        else toast('ARCA: ' + ((r && r.error) || 'no respondió'), 'error');
        pintarComps(filtro);
      });
    };
    document.querySelectorAll('[data-arcaf]').forEach(b => b.onclick = () => pintarComps(b.dataset.arcaf));
    pintarComps('sin');
    $('arca-log-btn').onclick = async () => {
      const rows = await api('/api/arca/log').catch(() => []);
      $('arca-log').innerHTML = Array.isArray(rows) && rows.length
        ? `<table style="width:100%;border-collapse:collapse;font-size:12px"><tr><th style="text-align:left">Fecha</th><th style="text-align:left">Acción</th><th style="text-align:left">Comprobante</th><th style="text-align:left">Resultado</th></tr>${rows.slice(0, 30).map(r => `<tr><td>${esc(r.fecha)}</td><td>${esc(r.accion)}</td><td>${esc(r.comp_numero || '')}</td><td>${esc(r.resultado)}</td></tr>`).join('')}</table>`
        : '<div class="arca-nota">Sin operaciones todavía.</div>';
    };
  }

  // Se carga al abrir la pestaña
  if (typeof window.showCfgTab === 'function') {
    const orig = window.showCfgTab;
    window.showCfgTab = function (tab) { orig.apply(this, arguments); if (tab === 'arca') cargar(); };
  }
  // Para abrirla desde Facturación u otras pantallas
  window.abrirArcaConfig = function () {
    try { if (typeof goTo === 'function') goTo('config'); } catch (e) {}
    try { window.showCfgTab('arca'); } catch (e) {}
  };
  if (location.hash === '#arca') setTimeout(window.abrirArcaConfig, 800);
})();
