@echo off
title SysTech - Primera vez
cd /d "%~dp0"
echo Primera vez arrancando el sistema, instalando lo necesario...
echo Esto puede tardar 1-2 minutos. No cierres esta ventana.
echo.
call npm install
if errorlevel 1 (
  echo.
  echo ================================================
  echo Hubo un error instalando. Verifica la conexion a
  echo internet y que Node.js este bien instalado
  echo ^(node -v en la terminal^).
  echo ================================================
  pause
  exit /b 1
)
echo.
echo Instalacion lista. Ya se abre SysTech.
ping -n 3 127.0.0.1 >nul
