import sys, json
from openpyxl import Workbook
from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side,
                              GradientFill)
from openpyxl.chart import BarChart, PieChart, LineChart, Reference
from openpyxl.chart.series import DataPoint
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule
from datetime import datetime

data = json.loads(sys.argv[1])
output = sys.argv[2]

wb = Workbook()

# ─── ESTILOS ─────────────────────────────────────────────────────────────────
AZUL       = "1E3A5F"
AZUL_CLARO = "D6E4F0"
VERDE      = "1A7A4A"
VERDE_CLARO= "D4EDDA"
GRIS       = "F5F6FA"
GRIS_OSC   = "6C757D"
NARANJA    = "E67E22"
ROJO       = "C0392B"
BLANCO     = "FFFFFF"

def fill(hex): return PatternFill("solid", fgColor=hex)
def font(bold=False, color="000000", size=11, italic=False):
    return Font(bold=bold, color=color, size=size, italic=italic, name="Arial")
def border_thin():
    s = Side(style="thin", color="CCCCCC")
    return Border(left=s, right=s, top=s, bottom=s)
def center(): return Alignment(horizontal="center", vertical="center", wrap_text=True)
def left():   return Alignment(horizontal="left",   vertical="center", wrap_text=True)

def header_row(ws, row, cols, titulo):
    """Fila de encabezado de tabla"""
    for c, label in enumerate(cols, 1):
        cell = ws.cell(row=row, column=c, value=label)
        cell.font      = font(bold=True, color=BLANCO, size=10)
        cell.fill      = fill(AZUL)
        cell.alignment = center()
        cell.border    = border_thin()

def data_row(ws, row, values, alt=False):
    bg = GRIS if alt else BLANCO
    for c, val in enumerate(values, 1):
        cell = ws.cell(row=row, column=c, value=val)
        cell.fill      = fill(bg)
        cell.alignment = left()
        cell.border    = border_thin()
        cell.font      = font(size=10)
    return row + 1

def title_section(ws, row, text, col_start=1, col_end=6):
    """Título de sección"""
    ws.row_dimensions[row].height = 28
    cell = ws.cell(row=row, column=col_start, value=text)
    cell.font      = font(bold=True, color=BLANCO, size=12)
    cell.fill      = fill(AZUL)
    cell.alignment = center()
    ws.merge_cells(start_row=row, start_column=col_start,
                   end_row=row,   end_column=col_end)
    return row + 1

def pesos(val):
    return val if val else 0

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 1: RESUMEN EJECUTIVO
# ═══════════════════════════════════════════════════════════════════════════════
ws1 = wb.active
ws1.title = "📊 Resumen"
ws1.sheet_view.showGridLines = False

# Título principal
ws1.row_dimensions[1].height = 40
ws1.merge_cells("A1:H1")
c = ws1["A1"]
c.value     = "REPORTE EJECUTIVO — SISTEMA DE GESTIÓN TÉCNICA"
c.font      = font(bold=True, color=BLANCO, size=16)
c.fill      = fill(AZUL)
c.alignment = center()

ws1.merge_cells("A2:H2")
c = ws1["A2"]
c.value     = f"Generado el {datetime.now().strftime('%d/%m/%Y %H:%M')}"
c.font      = font(italic=True, color=GRIS_OSC, size=10)
c.fill      = fill(AZUL_CLARO)
c.alignment = center()
ws1.row_dimensions[2].height = 18

# ── KPIs ──
r = ws1
kpis = [
    ("Total Órdenes",      data["resumen"]["total_ordenes"],       AZUL,    "🔧"),
    ("Total Facturado",    f"${pesos(data['resumen']['total_facturado']):,.0f}", VERDE, "💰"),
    ("Ticket Promedio",    f"${pesos(data['resumen']['ticket_promedio']):,.0f}", NARANJA,"📈"),
    ("Órdenes Cobradas",   data["resumen"]["cobradas"],            VERDE,   "✅"),
    ("Equipos Entregados", data["resumen"]["entregadas"],           AZUL,   "📦"),
]

ws1.row_dimensions[4].height = 22
ws1["A4"].value = "INDICADORES CLAVE"
ws1["A4"].font  = font(bold=True, color=AZUL, size=11)
ws1.merge_cells("A4:H4")

row_kpi = 5
for col, (label, valor, color, icon) in enumerate(kpis, 1):
    ws1.column_dimensions[get_column_letter(col)].width = 18
    # Ícono + label
    c1 = ws1.cell(row=row_kpi, column=col, value=f"{icon} {label}")
    c1.font      = font(bold=True, color=BLANCO, size=10)
    c1.fill      = fill(color)
    c1.alignment = center()
    c1.border    = border_thin()
    ws1.row_dimensions[row_kpi].height = 22
    # Valor
    c2 = ws1.cell(row=row_kpi+1, column=col, value=valor)
    c2.font      = font(bold=True, color=color, size=16)
    c2.fill      = fill(GRIS)
    c2.alignment = center()
    c2.border    = border_thin()
    ws1.row_dimensions[row_kpi+1].height = 32

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 2: ÓRDENES POR MES
# ═══════════════════════════════════════════════════════════════════════════════
ws2 = wb.create_sheet("📅 Órdenes por Mes")
ws2.sheet_view.showGridLines = False
ws2.column_dimensions["A"].width = 16
ws2.column_dimensions["B"].width = 16
ws2.column_dimensions["C"].width = 22

title_section(ws2, 1, "ÓRDENES Y FACTURACIÓN POR MES", 1, 3)

header_row(ws2, 2, ["Mes", "Cantidad de Órdenes", "Total Facturado ($)"], None)

for i, m in enumerate(data["ordenesPorMes"]):
    alt = i % 2 == 0
    row_n = i + 3
    ws2.cell(row=row_n, column=1, value=m["mes"]).fill = fill(GRIS if alt else BLANCO)
    ws2.cell(row=row_n, column=1).font = font(bold=True, size=10)
    ws2.cell(row=row_n, column=1).border = border_thin()
    ws2.cell(row=row_n, column=2, value=m["cantidad"]).fill = fill(GRIS if alt else BLANCO)
    ws2.cell(row=row_n, column=2).alignment = center()
    ws2.cell(row=row_n, column=2).border = border_thin()
    t = ws2.cell(row=row_n, column=3, value=round(pesos(m["total"]), 2))
    t.number_format = '$#,##0.00'
    t.fill = fill(GRIS if alt else BLANCO)
    t.border = border_thin()

# Fila TOTAL
last = len(data["ordenesPorMes"]) + 3
ws2.cell(row=last, column=1, value="TOTAL").font = font(bold=True, color=BLANCO, size=10)
ws2.cell(row=last, column=1).fill = fill(AZUL)
ws2.cell(row=last, column=1).border = border_thin()
ws2.cell(row=last, column=2, value=f'=SUM(B3:B{last-1})').font = font(bold=True, color=BLANCO)
ws2.cell(row=last, column=2).fill = fill(AZUL)
ws2.cell(row=last, column=2).alignment = center()
ws2.cell(row=last, column=2).border = border_thin()
ws2.cell(row=last, column=3, value=f'=SUM(C3:C{last-1})').number_format = '$#,##0.00'
ws2.cell(row=last, column=3).font = font(bold=True, color=BLANCO)
ws2.cell(row=last, column=3).fill = fill(AZUL)
ws2.cell(row=last, column=3).border = border_thin()

# Gráfico de barras
if data["ordenesPorMes"]:
    chart = BarChart()
    chart.type = "col"
    chart.title = "Órdenes por Mes"
    chart.y_axis.title = "Cantidad"
    chart.x_axis.title = "Mes"
    chart.style = 10
    chart.width = 20; chart.height = 12
    cats = Reference(ws2, min_col=1, min_row=3, max_row=last-1)
    vals = Reference(ws2, min_col=2, min_row=2, max_row=last-1)
    chart.add_data(vals, titles_from_data=True)
    chart.set_categories(cats)
    chart.series[0].graphicalProperties.solidFill = "2E86C1"
    ws2.add_chart(chart, "E2")

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 3: ÓRDENES POR ESTADO
# ═══════════════════════════════════════════════════════════════════════════════
ws3 = wb.create_sheet("🔄 Estado de Órdenes")
ws3.sheet_view.showGridLines = False
ws3.column_dimensions["A"].width = 22
ws3.column_dimensions["B"].width = 20
ws3.column_dimensions["C"].width = 16

title_section(ws3, 1, "DISTRIBUCIÓN DE ÓRDENES POR ESTADO", 1, 3)
header_row(ws3, 2, ["Estado", "Cantidad", "% del Total"])

total_ord = sum(e["cantidad"] for e in data["ordenesPorEstado"]) or 1
ESTADO_COLORES = {"recibido":"2E86C1","diagnostico":"F39C12","reparando":"8E44AD","listo":"27AE60","entregado":"7F8C8D","cancelado":"E74C3C"}
for i, e in enumerate(data["ordenesPorEstado"]):
    row_n = i + 3
    color = ESTADO_COLORES.get(e["estado"], "555555")
    c1 = ws3.cell(row=row_n, column=1, value=e["estado"].upper())
    c1.font = font(bold=True, color=BLANCO, size=10)
    c1.fill = fill(color); c1.alignment = left(); c1.border = border_thin()
    c2 = ws3.cell(row=row_n, column=2, value=e["cantidad"])
    c2.alignment = center(); c2.border = border_thin(); c2.font = font(size=10)
    c3 = ws3.cell(row=row_n, column=3, value=round(e["cantidad"]/total_ord*100,1))
    c3.number_format = '0.0"%"'; c3.alignment = center(); c3.border = border_thin(); c3.font = font(size=10)

# Gráfico torta
if data["ordenesPorEstado"]:
    pie = PieChart()
    pie.title = "Estados de Órdenes"
    pie.style = 10; pie.width = 16; pie.height = 12
    labels = Reference(ws3, min_col=1, min_row=3, max_row=2+len(data["ordenesPorEstado"]))
    data_ref = Reference(ws3, min_col=2, min_row=2, max_row=2+len(data["ordenesPorEstado"]))
    pie.add_data(data_ref, titles_from_data=True)
    pie.set_categories(labels)
    ws3.add_chart(pie, "E2")

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 4: REPUESTOS MÁS USADOS
# ═══════════════════════════════════════════════════════════════════════════════
ws4 = wb.create_sheet("🔩 Repuestos")
ws4.sheet_view.showGridLines = False
ws4.column_dimensions["A"].width = 14
ws4.column_dimensions["B"].width = 35
ws4.column_dimensions["C"].width = 18
ws4.column_dimensions["D"].width = 20

title_section(ws4, 1, "REPUESTOS MÁS UTILIZADOS", 1, 4)
header_row(ws4, 2, ["Código", "Nombre del Repuesto", "Unidades Usadas", "Total Facturado ($)"])

for i, rep in enumerate(data["repuestosMasUsados"]):
    alt = i % 2 == 0
    bg = GRIS if alt else BLANCO
    row_n = i + 3
    for col, val in enumerate([rep["codigo"], rep["nombre"], rep["total_usado"], round(pesos(rep["total_facturado"]),2)], 1):
        c = ws4.cell(row=row_n, column=col, value=val)
        c.fill = fill(bg); c.border = border_thin(); c.font = font(size=10)
        if col == 4: c.number_format = '$#,##0.00'
        if col == 3: c.alignment = center()

# Formato condicional columna C (barras de calor)
if data["repuestosMasUsados"]:
    last_r = 2 + len(data["repuestosMasUsados"])
    ws4.conditional_formatting.add(f"C3:C{last_r}", ColorScaleRule(
        start_type="min", start_color="FFFFFF",
        end_type="max",   end_color="1A7A4A"))

    # Gráfico barras horizontal
    bar = BarChart()
    bar.type = "bar"
    bar.title = "Top Repuestos Utilizados"
    bar.y_axis.title = "Repuesto"; bar.x_axis.title = "Unidades"
    bar.style = 10; bar.width = 20; bar.height = 14
    cats = Reference(ws4, min_col=2, min_row=3, max_row=last_r)
    vals = Reference(ws4, min_col=3, min_row=2, max_row=last_r)
    bar.add_data(vals, titles_from_data=True)
    bar.set_categories(cats)
    bar.series[0].graphicalProperties.solidFill = "1A7A4A"
    ws4.add_chart(bar, "F2")

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 5: TÉCNICOS
# ═══════════════════════════════════════════════════════════════════════════════
ws5 = wb.create_sheet("👨‍🔧 Técnicos")
ws5.sheet_view.showGridLines = False
ws5.column_dimensions["A"].width = 28
ws5.column_dimensions["B"].width = 18
ws5.column_dimensions["C"].width = 22

title_section(ws5, 1, "RENDIMIENTO POR TÉCNICO", 1, 3)
header_row(ws5, 2, ["Técnico", "Órdenes Realizadas", "Total Generado ($)"])

for i, tec in enumerate(data["ingresosPorTecnico"]):
    alt = i % 2 == 0
    bg = VERDE_CLARO if alt else BLANCO
    row_n = i + 3
    c1 = ws5.cell(row=row_n, column=1, value=tec["tecnico"] or "Sin asignar")
    c1.font = font(bold=True, size=10); c1.fill = fill(bg); c1.border = border_thin()
    c2 = ws5.cell(row=row_n, column=2, value=tec["ordenes"])
    c2.alignment = center(); c2.fill = fill(bg); c2.border = border_thin(); c2.font = font(size=10)
    c3 = ws5.cell(row=row_n, column=3, value=round(pesos(tec["total"]),2))
    c3.number_format = '$#,##0.00'; c3.fill = fill(bg); c3.border = border_thin(); c3.font = font(size=10)

if data["ingresosPorTecnico"]:
    last_r = 2 + len(data["ingresosPorTecnico"])
    bar2 = BarChart()
    bar2.type = "col"; bar2.title = "Ingresos por Técnico"
    bar2.style = 10; bar2.width = 18; bar2.height = 12
    cats = Reference(ws5, min_col=1, min_row=3, max_row=last_r)
    vals = Reference(ws5, min_col=3, min_row=2, max_row=last_r)
    bar2.add_data(vals, titles_from_data=True)
    bar2.set_categories(cats)
    bar2.series[0].graphicalProperties.solidFill = "1E3A5F"
    ws5.add_chart(bar2, "E2")

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 6: STOCK CRÍTICO
# ═══════════════════════════════════════════════════════════════════════════════
ws6 = wb.create_sheet("⚠️ Stock Crítico")
ws6.sheet_view.showGridLines = False
ws6.column_dimensions["A"].width = 16
ws6.column_dimensions["B"].width = 36
ws6.column_dimensions["C"].width = 16
ws6.column_dimensions["D"].width = 16

title_section(ws6, 1, "PRODUCTOS CON STOCK CRÍTICO O AGOTADO", 1, 4)
header_row(ws6, 2, ["Código", "Nombre del Producto", "Stock Actual", "Stock Mínimo"])

for i, p in enumerate(data["stockCritico"]):
    row_n = i + 3
    agotado = p["stock"] == 0
    bg = "FADBD8" if agotado else "FDEBD0"
    color = ROJO if agotado else NARANJA
    for col, val in enumerate([p["codigo"], p["nombre"], p["stock"], p["stock_minimo"]], 1):
        c = ws6.cell(row=row_n, column=col, value=val)
        c.fill = fill(bg); c.border = border_thin()
        c.font = font(bold=(col <= 2), color=color if col >= 3 else "000000", size=10)
        if col >= 3: c.alignment = center()

if not data["stockCritico"]:
    ws6.cell(row=3, column=1, value="✅ No hay productos en stock crítico").font = font(bold=True, color=VERDE, size=11)

# ═══════════════════════════════════════════════════════════════════════════════
# HOJA 7: TIPOS DE EQUIPO
# ═══════════════════════════════════════════════════════════════════════════════
ws7 = wb.create_sheet("💻 Tipos de Equipo")
ws7.sheet_view.showGridLines = False
ws7.column_dimensions["A"].width = 26
ws7.column_dimensions["B"].width = 20

title_section(ws7, 1, "ÓRDENES POR TIPO DE EQUIPO", 1, 2)
header_row(ws7, 2, ["Tipo de Equipo", "Cantidad de Órdenes"])

for i, eq in enumerate(data["ordenesPorEquipo"]):
    row_n = i + 3
    alt = i % 2 == 0
    c1 = ws7.cell(row=row_n, column=1, value=eq["equipo"] or "Sin especificar")
    c1.fill = fill(GRIS if alt else BLANCO); c1.border = border_thin(); c1.font = font(size=10)
    c2 = ws7.cell(row=row_n, column=2, value=eq["cantidad"])
    c2.fill = fill(GRIS if alt else BLANCO); c2.border = border_thin()
    c2.alignment = center(); c2.font = font(size=10)

if data["ordenesPorEquipo"]:
    last_r = 2 + len(data["ordenesPorEquipo"])
    pie2 = PieChart()
    pie2.title = "Distribución por Equipo"; pie2.style = 10
    pie2.width = 16; pie2.height = 12
    labels = Reference(ws7, min_col=1, min_row=3, max_row=last_r)
    vals   = Reference(ws7, min_col=2, min_row=2, max_row=last_r)
    pie2.add_data(vals, titles_from_data=True)
    pie2.set_categories(labels)
    ws7.add_chart(pie2, "D2")

# ─── GUARDAR ─────────────────────────────────────────────────────────────────
wb.save(output)
print("OK")
