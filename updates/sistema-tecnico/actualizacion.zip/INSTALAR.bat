@echo off
title SysTech - Instalacion
cd /d "%~dp0"
set EXTRA=
if /I "%1"=="nolanzar" set EXTRA=-NoLanzar
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALAR-SYSTECH.ps1" %EXTRA%
