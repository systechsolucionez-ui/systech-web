// ============================================================
// tecnibot-celular.js — Tecnibot en el celular, conectado por QR (SysTech 1.7.1)
// En la PC, Tecnibot muestra un código QR. El celular lo escanea (misma wifi), queda conectado
// y le puede escribir al bot desde ahí, sin ocupar la computadora del sistema.
//  • UN solo celular por sistema: conectar otro desconecta el anterior.
//  • El QR sirve una sola vez y vence a los 5 minutos.
//  • El celular solo puede usar Tecnibot (no ve el resto del sistema) y habla como el usuario
//    que lo conectó desde la PC. Si ese usuario se desactiva, el celular deja de funcionar.
//  • En la base se guarda solo el resumen (hash) de la llave del celular, nunca la llave.
// ============================================================
const crypto = require('crypto');
const os = require('os');

const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const iguales = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
const VENCE_QR_MS = 5 * 60 * 1000;
const PENDIENTES = new Map();     // hash del código QR → { sub, usuario_id, vence }
const FALLOS = new Map();         // ip → { n, desde }   (freno a quien prueba códigos al azar)

function ipDeRed() {
  if (process.env.SYSTECH_IP) return process.env.SYSTECH_IP;   // por si la PC tiene varias redes y hay que fijar una
  const todas = [];
  for (const lista of Object.values(os.networkInterfaces())) for (const i of lista || []) {
    if (i.family !== 'IPv4' || i.internal || i.address.startsWith('169.254.')) continue;
    const p = i.address;
    // primero la red de la casa/local (192.168…), después otras redes privadas, al final cualquier otra
    const prioridad = p.startsWith('192.168.') ? 0 : p.startsWith('10.') ? 1 : /^172\.(1[6-9]|2\d|3[01])\./.test(p) ? 2 : 3;
    todas.push({ p, prioridad });
  }
  todas.sort((a, b) => a.prioridad - b.prioridad);
  return todas.length ? todas[0].p : null;
}

function tabla(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS tecnibot_celular (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    token_hash TEXT NOT NULL,
    usuario_id INTEGER NOT NULL,
    nombre TEXT,
    creado DATETIME DEFAULT (datetime('now','localtime')),
    ultimo_uso DATETIME
  )`);
}

function montar(app, { authMiddleware, tecnibotHabilitado, tecnibotChat, puerto }) {
  const sub = (req) => (req.tenant && req.tenant.subdominio) || 'default';
  const limpiar = () => { const ahora = Date.now(); for (const [k, v] of PENDIENTES) if (v.vence < ahora) PENDIENTES.delete(k); };

  // PC: genera el código QR (lo muestra Tecnibot)
  app.post('/api/tecnibot/celular/vincular', authMiddleware, tecnibotHabilitado, (req, res) => {
    if (req.user.rol === 'caja') return res.status(403).json({ error: 'Tecnibot no está disponible para este usuario.' });
    limpiar();
    const codigo = crypto.randomBytes(18).toString('base64url');
    PENDIENTES.set(sha(codigo), { sub: sub(req), usuario_id: req.user.usuario_id, vence: Date.now() + VENCE_QR_MS });
    // Dirección que va a abrir el celular: si la PC entró por localhost, se usa la IP de la red local.
    const host = String(req.headers.host || '');
    const nombreHost = host.replace(/:\d+$/, '');
    let base;
    if (nombreHost === 'localhost' || nombreHost === '127.0.0.1' || nombreHost === '::1' || nombreHost === '[::1]') {
      const ip = ipDeRed();
      if (!ip) return res.status(409).json({ error: 'Esta PC no está conectada a una red wifi o cableada. Conectala a la misma red que el celular.' });
      base = `http://${ip}:${puerto()}`;
    } else {
      base = `${req.protocol}://${host}`;
    }
    res.json({ url: `${base}/tecnibot-celular.html#c=${codigo}`, vence_seg: VENCE_QR_MS / 1000 });
  });

  // PC: qué celular está conectado
  app.get('/api/tecnibot/celular', authMiddleware, tecnibotHabilitado, (req, res) => {
    tabla(req.db);
    const r = req.db.prepare('SELECT c.nombre, c.creado, c.ultimo_uso, c.usuario_id, u.nombre AS usuario FROM tecnibot_celular c LEFT JOIN usuarios u ON u.id = c.usuario_id WHERE c.id = 1').get();
    res.json(r ? { vinculado: true, nombre: r.nombre, creado: r.creado, ultimo_uso: r.ultimo_uso, usuario: r.usuario } : { vinculado: false });
  });

  // PC: desconectar el celular (admin, o el mismo usuario que lo conectó)
  app.delete('/api/tecnibot/celular', authMiddleware, tecnibotHabilitado, (req, res) => {
    tabla(req.db);
    const r = req.db.prepare('SELECT usuario_id FROM tecnibot_celular WHERE id = 1').get();
    if (r && req.user.rol !== 'admin' && r.usuario_id !== req.user.usuario_id) return res.status(403).json({ error: 'Solo el administrador o quien lo conectó puede desconectarlo.' });
    req.db.prepare('DELETE FROM tecnibot_celular WHERE id = 1').run();
    res.json({ ok: true });
  });

  // Celular: canjea el código del QR por su llave (una sola vez)
  app.post('/api/tecnibot/celular/canjear', (req, res) => {
    const ip = req.ip || '';
    const f = FALLOS.get(ip);
    if (f && f.n >= 20 && Date.now() - f.desde < 10 * 60 * 1000) return res.status(429).json({ error: 'Demasiados intentos. Esperá unos minutos y escaneá un código nuevo.' });
    limpiar();
    const codigo = String((req.body && req.body.codigo) || '');
    const p = codigo ? PENDIENTES.get(sha(codigo)) : null;
    if (!p || p.sub !== sub(req) || p.vence < Date.now()) {
      const g = f && Date.now() - f.desde < 10 * 60 * 1000 ? f : { n: 0, desde: Date.now() };
      g.n++; FALLOS.set(ip, g);
      return res.status(400).json({ error: 'El código QR venció o ya se usó. Generá uno nuevo desde Tecnibot en la PC.' });
    }
    PENDIENTES.delete(sha(codigo));
    const u = req.db.prepare('SELECT id, activo FROM usuarios WHERE id = ?').get(p.usuario_id);
    if (!u || u.activo === 0) return res.status(403).json({ error: 'El usuario que generó el código ya no está activo.' });
    tabla(req.db);
    const token = crypto.randomBytes(32).toString('hex');
    const nombre = String((req.body && req.body.nombre) || 'Celular').slice(0, 40);
    req.db.prepare(`INSERT OR REPLACE INTO tecnibot_celular (id, token_hash, usuario_id, nombre, creado, ultimo_uso)
      VALUES (1, ?, ?, ?, datetime('now','localtime'), datetime('now','localtime'))`).run(sha(token), p.usuario_id, nombre);
    res.json({ ok: true, token });
  });

  function celularAuth(req, res, next) {
    const token = String(req.headers['x-celular-token'] || '');
    tabla(req.db);
    const r = token ? req.db.prepare('SELECT token_hash, usuario_id FROM tecnibot_celular WHERE id = 1').get() : null;
    if (!r || !iguales(r.token_hash, sha(token))) return res.status(401).json({ error: 'Este celular ya no está conectado. Escaneá el código QR de nuevo desde Tecnibot en la PC.', desconectado: true });
    const u = req.db.prepare('SELECT id, nombre, rol, activo FROM usuarios WHERE id = ?').get(r.usuario_id);
    if (!u || u.activo === 0) return res.status(401).json({ error: 'El usuario de este celular ya no está activo. Pedile al administrador que lo conecte de nuevo.', desconectado: true });
    if (u.rol === 'caja') return res.status(403).json({ error: 'Tecnibot no está disponible para este usuario.' });
    req.user = { usuario_id: u.id, nombre: u.nombre, rol: u.rol };
    try { req.db.prepare("UPDATE tecnibot_celular SET ultimo_uso = datetime('now','localtime') WHERE id = 1").run(); } catch (e) {}
    next();
  }

  // Celular: quién soy
  app.get('/api/tecnibot/celular/yo', celularAuth, tecnibotHabilitado, (req, res) => {
    let negocio = '';
    try { const c = req.db.prepare("SELECT valor FROM config WHERE clave = 'empresa_nombre'").get(); negocio = (c && c.valor) || ''; } catch (e) {}
    res.json({ usuario: req.user.nombre, negocio });
  });
  // Celular: chat (el mismo Tecnibot de la PC)
  app.post('/api/tecnibot/celular/chat', celularAuth, tecnibotHabilitado, tecnibotChat);
}

module.exports = { montar, ipDeRed };
