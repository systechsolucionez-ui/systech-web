@echo off
taskkill /F /IM node.exe /T
pause
