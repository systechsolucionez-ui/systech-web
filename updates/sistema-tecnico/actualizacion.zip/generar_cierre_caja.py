import sys, json
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

with open(sys.argv[1], encoding='utf-8') as f:
    data = json.load(f)
output = sys.argv[2]

wb = Workbook()
ws = wb.active
ws.title = "Cierre de Caja"

AZUL = "1E3A5F"
GRIS = "F5F6FA"
VERDE = "1A7A4A"
ROJO = "C0392B"
BLANCO = "FFFFFF"

def fill(hex): return PatternFill("solid", fgColor=hex)
def font(bold=False, color="000000", size=11, italic=False):
    return Font(bold=bold, color=color, size=size, italic=italic, name="Arial")
def border_thin():
    s = Side(style="thin", color="CCCCCC")
    return Border(left=s, right=s, top=s, bottom=s)
def center(): return Alignment(horizontal="center", vertical="center", wrap_text=True)
def left():   return Alignment(horizontal="left", vertical="center", wrap_text=True)
def money(v):
    try: return float(v or 0)
    except: return 0

for col, w in zip("ABCD", [28, 22, 22, 22]):
    ws.column_dimensions[col].width = w

row = 1
ws.merge_cells(f"A{row}:D{row}")
c = ws.cell(row=row, column=1, value=f"PLANILLA DE CIERRE DE CAJA — {data.get('empresaNombre','SysTech')}")
c.font = font(bold=True, color=BLANCO, size=14); c.fill = fill(AZUL); c.alignment = center()
ws.row_dimensions[row].height = 26
row += 2

info = [
    ("Apertura", data.get('fechaApertura','')),
    ("Cierre", data.get('fechaCierre','') or '— (turno todavía abierto) —'),
    ("Cajero que abrió", data.get('usuarioApertura','')),
    ("Cajero que cierra", data.get('usuarioCierre','') or data.get('usuarioApertura','')),
]
for label, val in info:
    ws.cell(row=row, column=1, value=label).font = font(bold=True)
    ws.merge_cells(f"B{row}:D{row}")
    ws.cell(row=row, column=2, value=val).font = font()
    row += 1
row += 1

# ── Ventas del turno por tipo de comprobante ──
ws.merge_cells(f"A{row}:D{row}")
c = ws.cell(row=row, column=1, value="VENTAS DEL TURNO")
c.font = font(bold=True, color=BLANCO); c.fill = fill(AZUL); c.alignment = center()
row += 1
headers = ["Tipo de comprobante", "Cantidad", "Total", ""]
for i, h in enumerate(headers, 1):
    cell = ws.cell(row=row, column=i, value=h)
    cell.font = font(bold=True, color=BLANCO, size=10); cell.fill = fill("4A6D8C"); cell.alignment = center(); cell.border = border_thin()
row += 1
totalVentas = 0
for v in data.get('ventasPorTipo', []):
    ws.cell(row=row, column=1, value=v.get('label', v.get('tipo',''))).border = border_thin()
    ws.cell(row=row, column=2, value=v.get('cantidad',0)).alignment = center(); ws.cell(row=row, column=2).border = border_thin()
    cell = ws.cell(row=row, column=3, value=money(v.get('total')))
    cell.number_format = '$ #,##0'; cell.border = border_thin()
    ws.cell(row=row, column=4).border = border_thin()
    totalVentas += money(v.get('total'))
    row += 1
ws.cell(row=row, column=1, value="TOTAL VENTAS").font = font(bold=True)
cell = ws.cell(row=row, column=3, value=totalVentas)
cell.number_format = '$ #,##0'; cell.font = font(bold=True, color=VERDE)
for col in range(1,5): ws.cell(row=row, column=col).border = border_thin()
row += 2

# ── Desglose por medio de pago — lo que el cajero cuenta/concilia ──
ws.merge_cells(f"A{row}:D{row}")
c = ws.cell(row=row, column=1, value="ARQUEO POR MEDIO DE PAGO")
c.font = font(bold=True, color=BLANCO); c.fill = fill(AZUL); c.alignment = center()
row += 1
headers = ["Medio de pago", "Esperado (sistema)", "Contado por el cajero", "Diferencia"]
for i, h in enumerate(headers, 1):
    cell = ws.cell(row=row, column=i, value=h)
    cell.font = font(bold=True, color=BLANCO, size=10); cell.fill = fill("4A6D8C"); cell.alignment = center(); cell.border = border_thin()
row += 1
totalEsperado = 0
totalContado = 0
for m in data.get('detalleCierre', data.get('porMedio', [])):
    medio = m.get('medio','')
    esperado = money(m.get('esperado'))
    esEfectivo = medio.strip().lower() == 'efectivo'
    contado_raw = m.get('contado')
    ws.cell(row=row, column=1, value=medio + (" 💵" if esEfectivo else "")).border = border_thin()
    cell = ws.cell(row=row, column=2, value=esperado); cell.number_format = '$ #,##0'; cell.border = border_thin()
    totalEsperado += esperado
    if contado_raw is not None:
        contado = money(contado_raw)
        cell = ws.cell(row=row, column=3, value=contado); cell.number_format = '$ #,##0'; cell.border = border_thin()
        dif = money(m.get('diferencia', contado - esperado))
        cell = ws.cell(row=row, column=4, value=dif); cell.number_format = '$ #,##0'; cell.border = border_thin()
        if abs(dif) > 0.5: cell.font = font(bold=True, color=ROJO)
        totalContado += contado
    else:
        ws.cell(row=row, column=3, value="(turno todavía abierto)").font = font(italic=True, size=9)
        ws.cell(row=row, column=3).border = border_thin()
        ws.cell(row=row, column=4).border = border_thin()
    row += 1
ws.cell(row=row, column=1, value="TOTAL").font = font(bold=True)
cell = ws.cell(row=row, column=2, value=totalEsperado); cell.number_format = '$ #,##0'; cell.font = font(bold=True)
cell = ws.cell(row=row, column=3, value=totalContado); cell.number_format = '$ #,##0'; cell.font = font(bold=True)
totalDif = totalContado - totalEsperado
cell = ws.cell(row=row, column=4, value=totalDif); cell.number_format = '$ #,##0'
cell.font = font(bold=True, color=(ROJO if abs(totalDif) > 0.5 else VERDE))
for col in range(1,5): ws.cell(row=row, column=col).border = border_thin()
row += 2

# ── Firma ──
ws.merge_cells(f"A{row}:D{row}")
ws.cell(row=row, column=1, value="Certifico que los valores arriba detallados son los que conté físicamente al cerrar este turno de caja.").font = font(italic=True, size=9)
row += 3
ws.cell(row=row, column=1, value="_______________________________")
ws.cell(row=row+1, column=1, value=f"Firma y aclaración — {data.get('usuarioCierre','') or data.get('usuarioApertura','')}").font = font(size=9)
ws.merge_cells(f"C{row}:D{row}")
ws.cell(row=row, column=3, value="_______________________________")
ws.merge_cells(f"C{row+1}:D{row+1}")
ws.cell(row=row+1, column=3, value="Fecha y hora").font = font(size=9)

wb.save(output)
