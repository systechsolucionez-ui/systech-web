const express = require('express');
const cors = require('cors');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');
const multer = require('multer');
const ExcelJS = require('exceljs');
const uploadExcel = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
const { MODO_DISTRIBUIDOR, tenantMiddleware, masterDb, getDbForTenant, findTaller, crearTaller, listarTalleres, actualizarTaller, eliminarTaller, loginDistribuidor, validarSesionDistribuidor, cambiarPasswordDistribuidor } = require('./tenancy');
const licencia = require('./licencia');
const telefono = require('./public/telefono'); // MEJORAS-1.7.2: números de WhatsApp
const planes = require('./planes');
const tienda = require('./tienda');
const asistente = require('./asistente');
const seguridad = require('./seguridad');
const central = require('./central');
const { spawnSync } = require('child_process');

// ─── Ejecutar un script Python pasándole los datos por archivo temporal ───────
// Antes se armaba un comando de shell con execSync y el JSON entre comillas
// simples ('${jsonData}'). Eso funciona en bash pero rompe en Windows: cmd.exe
// no interpreta las comillas simples como agrupador, así que el JSON se cortaba
// en pedazos y el script de Python nunca se ejecutaba bien. Además "python3" no
// existe por defecto en Windows (ahí el comando es "python"). spawnSync evita
// el shell por completo (nada de escapes) y probamos ambos nombres de binario.
function ejecutarScriptPython(scriptPath, datos, outputPath) {
  const tmpJsonPath = path.join(require('os').tmpdir(), `py_in_${Date.now()}_${Math.random().toString(36).slice(2)}.json`);
  fs.writeFileSync(tmpJsonPath, JSON.stringify(datos), 'utf8');
  const candidatos = process.platform === 'win32' ? ['python', 'py', 'python3'] : ['python3', 'python'];
  let ultimoError = null;
  try {
    for (const bin of candidatos) {
      const r = spawnSync(bin, [scriptPath, tmpJsonPath, outputPath], { timeout: 30000, encoding: 'utf8' });
      if (!r.error && r.status === 0) return; // éxito
      ultimoError = r.error || new Error(r.stderr || `"${bin}" terminó con código ${r.status}`);
    }
    throw ultimoError || new Error('No se encontró un intérprete de Python (python/python3)');
  } finally {
    try { fs.unlinkSync(tmpJsonPath); } catch (e) {}
  }
}

// ─── Config fiscal con override por sucursal ──────────────────────────────
// Lee una clave de config_fiscal_sucursal si esa sucursal tiene un valor
// propio cargado por el admin; si no, cae al valor global de config_fiscal.
// `scoped` dice en cuál de las dos tablas hay que escribir el próximo valor
// (clave para la numeración: una sucursal con punto de venta propio tiene que
// incrementar SU contador, no el global, y viceversa).
function fiscalGet(db, sucursalId, clave) {
  if (sucursalId) {
    const o = db.prepare('SELECT valor FROM config_fiscal_sucursal WHERE sucursal_id=? AND clave=?').get(sucursalId, clave);
    if (o) return { valor: o.valor, scoped: true };
  }
  const g = db.prepare('SELECT valor FROM config_fiscal WHERE clave=?').get(clave);
  return { valor: g?.valor, scoped: false };
}
function fiscalSet(db, sucursalId, clave, valor, scoped) {
  if (scoped && sucursalId) {
    db.prepare('INSERT OR REPLACE INTO config_fiscal_sucursal (sucursal_id,clave,valor) VALUES (?,?,?)').run(sucursalId, clave, String(valor));
  } else {
    db.prepare('INSERT OR REPLACE INTO config_fiscal (clave,valor) VALUES (?,?)').run(clave, String(valor));
  }
}

const app = express();

// Solo el propio sitio puede llamar a la API desde un navegador. Si algún día hace
// falta otro origen, se agrega por variable de entorno CORS_ORIGINS (separados por coma).
const ORIGENES_PERMITIDOS = (process.env.CORS_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
app.use(cors({ origin: ORIGENES_PERMITIDOS.length ? ORIGENES_PERMITIDOS : false }));
app.use(seguridad.encabezadosSeguridad);
app.use(express.json({ limit: '10mb' }));

// ARCA-1.6.5: con la facturación electrónica habilitada, cada Factura que se emite (Caja, Facturación, cobro de
// órdenes) pide el CAE en el momento y la respuesta trae el resultado en «arca». Si ARCA falla, la venta queda hecha.
const RUTAS_AUTO_CAE = [/^\/api\/comprobantes\/(\d+)$/, /^\/api\/ordenes\/\d+\/cobrar-entregar$/];
app.use((req, res, next) => {
  const m = ['POST', 'PUT'].includes(req.method) ? RUTAS_AUTO_CAE.map(r => req.path.match(r)).find(Boolean) : null;
  if (!m || (req.method === 'PUT' && !(req.body && req.body.estado === 'emitido'))) return next();
  const enviar = res.json.bind(res);
  res.json = body => {
    const id = (body && (body.comprobante_id || (req.method === 'POST' && body.id))) || (m[1] ? Number(m[1]) : null);
    if (res.statusCode >= 400 || !id || !req.db || (body && body.error)) return enviar(body);
    autoCAE(req.db, id).then(a => enviar(a ? { ...body, arca: a } : body), () => enviar(body));
    return res;
  };
  next();
});
// El middleware de tenant NO aplica a rutas del distribuidor ni a archivos estáticos
app.use((req, res, next) => {
  if (req.path === '/api/imei/verificar' || req.path.startsWith('/api/asistente/relevo') || req.path === '/api/tecnibot/relevo' || req.path.startsWith('/api/ventas/')) return next(); // servidor central: no depende de ningún taller en particular
  const esDistribuidor = req.path === '/distribuidor.html' ||
    req.path.startsWith('/api/distribuidor/');
  if (esDistribuidor) {
    if (!MODO_DISTRIBUIDOR) return res.status(404).send('No encontrado');
    return next();
  }
  return tenantMiddleware(req, res, next);
});
app.use('/api', planes.gateModulos(MODO_DISTRIBUIDOR));
app.use('/api', planes.soloLecturaVencido(MODO_DISTRIBUIDOR));   // suscripción vencida (pasada la gracia): solo lectura   // planes sin servicio técnico: el servidor corta esas rutas
app.use(express.static('public'));

// ─── UPLOAD DE LOGO EMPRESA ───────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = UPLOADS_DIR;
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `logo_empresa${ext}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (req, file, cb) => {
  if (file.mimetype.startsWith('image/')) cb(null, true);
  else cb(new Error('Solo imágenes'));
}});

// Endpoint para subir logo empresa (NO el logo de SysTech)
// Subir foto de producto
const storageFoto = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = require('path').join(UPLOADS_DIR, 'productos');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `prod_${req.params.id}_${Date.now()}${ext}`);
  }
});
const uploadFoto = multer({ storage: storageFoto, limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (req, file, cb) => {
  if (file.mimetype.startsWith('image/')) cb(null, true);
  else cb(new Error('Solo imágenes'));
}});

app.post('/api/productos/:id/foto', authMiddleware, (req, res, next) => {
  uploadFoto.single('foto')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No se recibió imagen' });
    const url = `/uploads/productos/${req.file.filename}`;
    // Borrar foto anterior si existe
    const prod = req.db.prepare('SELECT foto_url FROM productos WHERE id=?').get(req.params.id);
    if (prod && prod.foto_url) {
      const oldPath = path.join(__dirname, 'public', prod.foto_url);
      try { if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath); } catch(e) {}
    }
    req.db.prepare('UPDATE productos SET foto_url=? WHERE id=?').run(url, req.params.id);
    res.json({ ok: true, url });
  });
});

app.delete('/api/productos/:id/foto', authMiddleware, (req, res) => {
  const prod = req.db.prepare('SELECT foto_url FROM productos WHERE id=?').get(req.params.id);
  if (prod && prod.foto_url) {
    const oldPath = path.join(__dirname, 'public', prod.foto_url);
    try { if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath); } catch(e) {}
    req.db.prepare('UPDATE productos SET foto_url=NULL WHERE id=?').run(req.params.id);
  }
  res.json({ ok: true });
});

// Datos de orden para facturación (caja puede facturar desde orden)
app.get('/api/facturar-orden/:id', authMiddleware, (req, res) => {
  // clientes solo tiene "nombre" (no hay columna "apellido" separada en la
  // tabla) — pedir c.apellido acá tiraba "no such column" y rompía todo el
  // endpoint con 500, por eso nunca cargaba la vista previa para facturar.
  const o = req.db.prepare(`
    SELECT o.*, c.nombre as cliente_nombre,
           c.telefono as cliente_telefono, c.email as cliente_email,
           c.direccion as cliente_direccion
    FROM ordenes o LEFT JOIN clientes c ON o.cliente_id = c.id
    WHERE o.id = ?
  `).get(req.params.id);
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  const repuestos = req.db.prepare(`
    SELECT or2.cantidad, or2.precio_unitario, or2.subtotal, p.nombre as descripcion
    FROM orden_repuestos or2 JOIN productos p ON or2.producto_id = p.id
    WHERE or2.orden_id = ?
  `).all(req.params.id);
  // Armar items para factura
  const items = [];
  if (o.mano_obra > 0) items.push({ descripcion: `Mano de obra técnica - ${o.equipo} ${o.marca||''}`.trim(), cantidad: 1, precio_unitario: o.mano_obra });
  repuestos.forEach(r => items.push({ descripcion: r.descripcion, cantidad: r.cantidad, precio_unitario: r.precio_unitario }));
  res.json({
    orden: { numero: o.numero, equipo: o.equipo, marca: o.marca, modelo: o.modelo },
    cliente: {
      nombre: (o.cliente_nombre || '').split(' ')[0] || '',
      apellido: (o.cliente_nombre || '').split(' ').slice(1).join(' ') || '',
      telefono: o.cliente_telefono || '',
      email: o.cliente_email || '',
      direccion: o.cliente_direccion || ''
    },
    items
  });
});

app.post('/api/upload/logo-empresa', upload.single('logo'), authMiddlewareUpload, (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No se recibió archivo' });
  const url = `/uploads/${req.file.filename}`;
  // Guardar en config
  req.db.prepare("INSERT OR REPLACE INTO config (clave,valor) VALUES ('logo_empresa',?)").run(url);
  req.db.prepare("INSERT OR REPLACE INTO config_fiscal (clave,valor) VALUES ('logo_factura',?)").run(url);
  res.json({ ok: true, url });
});

// Eliminar logo empresa
app.delete('/api/upload/logo-empresa', authMiddlewareUpload, (req, res) => {
  req.db.prepare("INSERT OR REPLACE INTO config (clave,valor) VALUES ('logo_empresa','')").run();
  req.db.prepare("INSERT OR REPLACE INTO config_fiscal (clave,valor) VALUES ('logo_factura','')").run();
  const filePath = require('path').join(UPLOADS_DIR, 'logo_empresa.png');
  ['png','jpg','jpeg','webp'].forEach(ext => {
    const f = require('path').join(UPLOADS_DIR,`logo_empresa.${ext}`);
    if(fs.existsSync(f)) try { fs.unlinkSync(f); } catch(e) {}
  });
  res.json({ ok: true });
});

function authMiddlewareUpload(req, res, next) {
  const token = req.headers['x-token'];
  if (!token) return res.status(401).json({ error: 'No autorizado' });
  const sesion = req.db.prepare("SELECT * FROM sesiones WHERE token=? AND expires > datetime('now')").get(token);
  if (!sesion) return res.status(401).json({ error: 'Sesión expirada' });
  if (sesion.rol !== 'admin') return res.status(403).json({ error: 'Solo administradores' });
  req.user = sesion;
  next();
}

// ─── AUTH ─────────────────────────────────────────────────────────────────────
function leerCookieSesion(req) {
  const m = (req.headers.cookie || '').match(/(?:^|;\s*)st_token=([a-f0-9]{64})/);
  return m ? m[1] : null;
}
function ponerCookieSesion(req, res, token) {
  res.setHeader('Set-Cookie', `st_token=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${req.secure ? '; Secure' : ''}`);
}
function authMiddleware(req, res, next) {
  // Normalmente el token viaja en el header x-token (lo manda el helper h()
  // del frontend). Pero una descarga de archivo disparada con window.open()
  // no puede mandar headers custom — solo una URL — así que para esos casos
  // puntuales (plantillas, exports) también se acepta por query string.
  // El token YA NO viaja en la URL (quedaba en historial, logs y capturas). Las descargas que
  // no pueden mandar headers usan una cookie HttpOnly, aceptada solo para lecturas (GET).
  let token = req.headers['x-token'];
  if (!token && (req.method === 'GET' || req.method === 'HEAD')) token = leerCookieSesion(req);
  if (!token) return res.status(401).json({ error: 'No autorizado' });
  const sesion = req.db.prepare("SELECT * FROM sesiones WHERE token=? AND expires > datetime('now')").get(token);
  if (!sesion) return res.status(401).json({ error: 'Sesión expirada' });
  // La tabla de sesiones no guarda la sucursal asignada al usuario (eso vive
  // en usuarios y puede cambiar sin cerrar sesión) — la traemos siempre de ahí
  // para que /api/me y el resto del backend tengan el dato fresco.
  const usuario = req.db.prepare('SELECT sucursal_id, ver_otras_sucursales, rol, debe_cambiar_password FROM usuarios WHERE id=?').get(sesion.usuario_id);
  sesion.sucursal_id = usuario?.sucursal_id || null;
  sesion.debe_cambiar_password = !!usuario?.debe_cambiar_password;
  // Con la clave por defecto (o reseteada) no se puede usar nada hasta cambiarla —
  // se exige acá, en el servidor, no solo con una pantalla.
  if (sesion.debe_cambiar_password && !['/api/cambiar-password', '/api/me', '/api/logout'].includes(req.path)) {
    return res.status(403).json({ error: 'Tenés que cambiar tu contraseña antes de continuar.', debe_cambiar_password: true });
  }
  // Admin siempre puede ver todo; para el resto depende del permiso que le haya dado el admin.
  sesion.ver_otras_sucursales = sesion.rol === 'admin' || !!usuario?.ver_otras_sucursales;
  req.user = sesion;
  next();
}

function adminOnly(req, res, next) {
  if (req.user.rol !== 'admin') return res.status(403).json({ error: 'Solo administradores' });
  next();
}

// ─── AUDITORÍA: quién hizo qué, cuándo y desde dónde ─────────────────────────
function audit(req, accion, entidad, entidadId, detalle) {
  try {
    req.db.prepare('INSERT INTO auditoria (usuario,rol,sucursal_id,accion,entidad,entidad_id,detalle,ip) VALUES (?,?,?,?,?,?,?,?)').run(
      req.user?.nombre || req.user?.usuario || '', req.user?.rol || '', req.user?.sucursal_id || null,
      accion, entidad || null, entidadId != null ? String(entidadId) : null,
      (typeof detalle === 'string' ? detalle : JSON.stringify(detalle || {})).slice(0, 500), req.ip || '');
  } catch (e) { /* la auditoría nunca debe romper la operación */ }
}
function auditAnonimo(req, usuario, rol, accion, detalle) {
  try {
    req.db.prepare('INSERT INTO auditoria (usuario,rol,accion,entidad,detalle,ip) VALUES (?,?,?,?,?,?)')
      .run(usuario || '', rol || '', accion, 'sesion', String(detalle || '').slice(0, 500), req.ip || '');
  } catch (e) {}
}

// ─── PERMISOS FINOS POR USUARIO ──────────────────────────────────────────────
// El admin tiene todo siempre. Para el resto, cada permiso arranca con el valor
// de su rol (para no cambiar lo que ya funcionaba) y el admin lo puede
// prender/apagar por usuario. Siempre se verifica en el servidor.
const PERMISOS = {
  ver_costos:          { label: 'Ver precios de costo',              def: { caja: 1, taller: 0 } },
  editar_productos:    { label: 'Crear y editar productos',          def: { caja: 1, taller: 0 } },
  ajustar_stock:       { label: 'Ajustar stock a mano',              def: { caja: 1, taller: 1 } },
  ingreso_mercaderia:  { label: 'Ingreso de mercadería (compras)',   def: { caja: 1, taller: 0 } },
  enviar_mercaderia:   { label: 'Crear remitos / enviar mercadería', def: { caja: 1, taller: 1 } },
  anular_comprobantes: { label: 'Anular comprobantes',               def: { caja: 1, taller: 1 } },
  ver_reportes:        { label: 'Ver reportes y ventas',             def: { caja: 1, taller: 0 } },
};
function permisosDe(db, userId, rol) {
  const out = {};
  for (const [k, v] of Object.entries(PERMISOS)) out[k] = rol === 'admin' ? true : !!v.def[rol];
  if (rol === 'admin') return out;
  let custom = {};
  try { custom = JSON.parse(db.prepare('SELECT permisos FROM usuarios WHERE id=?').get(userId)?.permisos || '{}') || {}; } catch (e) {}
  for (const k of Object.keys(out)) if (k in custom) out[k] = !!custom[k];
  return out;
}
function requierePermiso(clave) {
  return (req, res, next) => {
    if (permisosDe(req.db, req.user.usuario_id, req.user.rol)[clave]) return next();
    res.status(403).json({ error: `Tu usuario no tiene permiso para: ${PERMISOS[clave].label}. Pedíselo al administrador.` });
  };
}
function sinCostos(req, data) {
  if (permisosDe(req.db, req.user.usuario_id, req.user.rol).ver_costos) return data;
  const limpiar = r => { if (r && typeof r === 'object') { delete r.precio_costo; delete r.costo; delete r.proveedor; } return r; };
  return Array.isArray(data) ? data.map(limpiar) : limpiar(data);
}

// ─── STOCK POR LUGAR (depósito central = productos.stock; el resto = stock_sucursal) ───
function stockDisponible(db, productoId, sucId) {
  if (!sucId) return db.prepare('SELECT stock FROM productos WHERE id=?').get(productoId)?.stock || 0;
  return stockEn(db, productoId, sucId);
}
function moverStock(db, productoId, sucId, delta) {
  if (!delta) return;
  if (!sucId) db.prepare('UPDATE productos SET stock = stock + ? WHERE id=?').run(delta, productoId);
  else ajustarStock(db, productoId, sucId, delta);
}
// De qué lugar sale/entra el stock de lo que hace este usuario: el usuario común, siempre el de su
// sucursal; el admin elige (si no elige, el depósito central).
function lugarDeStock(req, sucElegida) {
  const id = req.user.rol === 'admin' ? Number(sucElegida || 0) : Number(req.user.sucursal_id || 0);
  return id || null;
}
function nombreLugar(db, sucId) {
  return sucId ? (db.prepare('SELECT nombre FROM sucursales WHERE id=?').get(sucId)?.nombre || 'Sucursal') : 'Depósito Central';
}
function regMovStock(db, productoId, tipo, cantidad, motivo, sucId, usuario, ordenId) {
  db.prepare('INSERT INTO movimientos_stock (producto_id,tipo,cantidad,motivo,orden_id,sucursal_id,usuario) VALUES (?,?,?,?,?,?,?)')
    .run(productoId, tipo, cantidad, `[${nombreLugar(db, sucId)}] ${motivo}`, ordenId || null, sucId || null, usuario || '');
}

app.post('/api/login', (req, res) => {
  const { usuario, password } = req.body || {};
  if (typeof usuario !== 'string' || typeof password !== 'string' || !usuario || !password) {
    return res.status(400).json({ error: 'Completá usuario y contraseña' });
  }
  const clave = `${req.tenant?.subdominio || 'default'}|${req.ip}|${usuario.toLowerCase()}`;
  const espera = seguridad.loginBloqueado(clave);
  if (espera) return res.status(429).json({ error: `Demasiados intentos. Probá de nuevo en ${espera} minuto(s). Si es urgente, pedile al administrador que te desbloquee.` });

  const user = req.db.prepare("SELECT * FROM usuarios WHERE usuario=? AND activo=1").get(usuario);
  const v = user ? seguridad.verificarPassword(password, user.password) : { ok: false };
  if (!user || !v.ok) {
    seguridad.loginFallo(clave);
    auditAnonimo(req, usuario, '', 'login.fallido', `Intento fallido para "${String(usuario).slice(0,60)}"`);
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos' });
  }
  seguridad.loginOk(clave);
  // Hash viejo (SHA-256 sin sal): lo reemplazamos por uno seguro ahora que sabemos la clave
  if (v.legacy) req.db.prepare('UPDATE usuarios SET password=? WHERE id=?').run(seguridad.hashPassword(password), user.id);
  const token = crypto.randomBytes(32).toString('hex');
  req.db.prepare("DELETE FROM sesiones WHERE expires <= datetime('now')").run(); // limpieza de sesiones vencidas
  req.db.prepare("INSERT INTO sesiones (token,usuario_id,rol,nombre,expires) VALUES (?,?,?,?,datetime('now','+8 hours'))").run(token, user.id, user.rol, user.nombre);
  auditAnonimo(req, user.nombre, user.rol, 'login.ok', `Inició sesión (${user.usuario})`);
  ponerCookieSesion(req, res, token);
  res.json({ token, rol: user.rol, nombre: user.nombre, id: user.id, sucursal_id: user.sucursal_id || null, debe_cambiar_password: !!user.debe_cambiar_password });
});

// Cambio de contraseña propio (obligatorio si todavía tiene la de fábrica)
app.post('/api/cambiar-password', authMiddleware, (req, res) => {
  const { password_actual, password_nueva } = req.body || {};
  const user = req.db.prepare('SELECT * FROM usuarios WHERE id=?').get(req.user.usuario_id);
  if (!user || !seguridad.verificarPassword(password_actual, user.password).ok) {
    return res.status(400).json({ error: 'La contraseña actual no es correcta.' });
  }
  const err = seguridad.validarPasswordNueva(password_nueva);
  if (err) return res.status(400).json({ error: err });
  if (password_nueva === password_actual) return res.status(400).json({ error: 'La nueva contraseña tiene que ser distinta de la actual.' });
  req.db.prepare('UPDATE usuarios SET password=?, debe_cambiar_password=0 WHERE id=?').run(seguridad.hashPassword(password_nueva), user.id);
  audit(req, 'usuario.cambio_password', 'usuario', user.id, `${user.usuario} cambió su contraseña`);
  res.json({ ok: true });
});

// Bloqueos por intentos fallidos: el admin los ve y los levanta sin reiniciar nada
app.get('/api/seguridad/bloqueos', authMiddleware, adminOnly, (req, res) => {
  res.json(seguridad.bloqueosActivos(req.tenant?.subdominio || 'default'));
});
app.post('/api/seguridad/desbloquear', authMiddleware, adminOnly, (req, res) => {
  const n = seguridad.desbloquear(req.tenant?.subdominio || 'default', req.body?.usuario || '');
  audit(req, 'seguridad.desbloqueo', 'usuario', null, `Desbloqueó a "${req.body?.usuario || ''}"`);
  res.json({ ok: true, desbloqueados: n });
});

app.post('/api/logout', authMiddleware, (req, res) => {
  req.db.prepare("DELETE FROM sesiones WHERE token=?").run(req.headers['x-token'] || leerCookieSesion(req));
  audit(req, 'logout', 'sesion', null, 'Cerró sesión');
  res.setHeader('Set-Cookie', 'st_token=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
  res.json({ ok: true });
});

app.get('/api/me', authMiddleware, (req, res) => {
  if (!leerCookieSesion(req) && req.headers['x-token']) ponerCookieSesion(req, res, req.headers['x-token']);
  const { token, ...resto } = req.user;
  res.json({ ...resto, token });
});

// ─── CONFIG ───────────────────────────────────────────────────────────────────
app.get('/api/config', authMiddleware, (req, res) => {
  const rows = req.db.prepare("SELECT * FROM config").all();
  const cfg = {};
  rows.forEach(r => cfg[r.clave] = r.valor);
  if (req.user.rol !== 'admin') delete cfg.smtp_pass;   // MEJORAS-1.7.2
  res.json(cfg);
});

app.put('/api/config', authMiddleware, adminOnly, (req, res) => {
  const entries = Object.entries(req.body);
  const stmt = req.db.prepare("INSERT OR REPLACE INTO config (clave,valor) VALUES (?,?)");
  entries.forEach(([k,v]) => stmt.run(k, v));
  audit(req, 'config.cambio', 'config', null, `Claves: ${entries.map(([k]) => k).join(', ').slice(0,300)}`);
  res.json({ ok: true });
});

// ─── USUARIOS (solo admin) ────────────────────────────────────────────────────
app.get('/api/usuarios', authMiddleware, adminOnly, (req, res) => {
  const rows = req.db.prepare("SELECT id,nombre,usuario,rol,activo,sucursal_id,ver_otras_sucursales,created_at,permisos FROM usuarios").all();
  rows.forEach(u => { u.permisos_efectivos = permisosDe(req.db, u.id, u.rol); delete u.permisos; });
  res.json(rows);
});
// Catálogo de permisos (para armar la pantalla de permisos)
app.get('/api/permisos/catalogo', authMiddleware, adminOnly, (req, res) => {
  res.json(Object.entries(PERMISOS).map(([clave, v]) => ({ clave, label: v.label, def: v.def })));
});
function permisosParaGuardar(rol, permisos) {
  // Solo se guardan los que difieren del valor por defecto de su rol
  if (!permisos || typeof permisos !== 'object' || rol === 'admin') return null;
  const out = {};
  for (const [k, v] of Object.entries(PERMISOS)) if (k in permisos && !!permisos[k] !== !!v.def[rol]) out[k] = !!permisos[k];
  return Object.keys(out).length ? JSON.stringify(out) : null;
}

app.post('/api/usuarios', authMiddleware, adminOnly, (req, res) => {
  const { nombre, usuario, password, rol, sucursal_id, ver_otras_sucursales, permisos } = req.body;
  if (!['admin','taller','caja'].includes(rol)) return res.status(400).json({ error: 'Rol inválido' });
  if (rol === 'taller' && planes.queIncluye(req, MODO_DISTRIBUIDOR).activado && !planes.queIncluye(req, MODO_DISTRIBUIDOR).modulos.taller) return res.status(402).json({ error: 'Tu plan no incluye el servicio técnico: no se pueden crear técnicos.' });
  const errPass = seguridad.validarPasswordNueva(password);
  if (errPass) return res.status(400).json({ error: errPass });
  const hash = seguridad.hashPassword(password);
  try {
    const r = req.db.prepare("INSERT INTO usuarios (nombre,usuario,password,rol,sucursal_id,ver_otras_sucursales,permisos) VALUES (?,?,?,?,?,?,?)").run(nombre,usuario,hash,rol,sucursal_id||null,ver_otras_sucursales?1:0,permisosParaGuardar(rol, permisos));
    audit(req, 'usuario.crear', 'usuario', r.lastInsertRowid, `${usuario} (${rol}) sucursal ${sucursal_id||'-'}`);
    res.json({ id: r.lastInsertRowid });
  } catch(e) { res.status(400).json({ error: 'Usuario ya existe' }); }
});

app.put('/api/usuarios/:id', authMiddleware, adminOnly, (req, res) => {
  const { nombre, usuario, password, rol, activo, sucursal_id, ver_otras_sucursales, permisos } = req.body;
  if (!['admin','taller','caja'].includes(rol)) return res.status(400).json({ error: 'Rol inválido' });
  const antes = req.db.prepare('SELECT * FROM usuarios WHERE id=?').get(req.params.id);
  if (!antes) return res.status(404).json({ error: 'Usuario no encontrado' });
  if (rol === 'taller' && antes.rol !== 'taller' && planes.queIncluye(req, MODO_DISTRIBUIDOR).activado && !planes.queIncluye(req, MODO_DISTRIBUIDOR).modulos.taller) return res.status(402).json({ error: 'Tu plan no incluye el servicio técnico: no se pueden crear técnicos.' });
  const permisosJson = permisos === undefined ? antes.permisos : permisosParaGuardar(rol, permisos);
  if (password) {
    const errPass = seguridad.validarPasswordNueva(password);
    if (errPass) return res.status(400).json({ error: errPass });
    const hash = seguridad.hashPassword(password);
    req.db.prepare("UPDATE usuarios SET nombre=?,usuario=?,password=?,rol=?,activo=?,sucursal_id=?,ver_otras_sucursales=?,permisos=? WHERE id=?").run(nombre,usuario,hash,rol,activo,sucursal_id||null,ver_otras_sucursales?1:0,permisosJson,req.params.id);
  } else {
    req.db.prepare("UPDATE usuarios SET nombre=?,usuario=?,rol=?,activo=?,sucursal_id=?,ver_otras_sucursales=?,permisos=? WHERE id=?").run(nombre,usuario,rol,activo,sucursal_id||null,ver_otras_sucursales?1:0,permisosJson,req.params.id);
  }
  const cambios = [];
  if (antes.rol !== rol) cambios.push(`rol ${antes.rol}→${rol}`);
  if (String(antes.sucursal_id||'') !== String(sucursal_id||'')) cambios.push(`sucursal ${antes.sucursal_id||'-'}→${sucursal_id||'-'}`);
  if (antes.activo !== activo) cambios.push(`activo ${antes.activo}→${activo}`);
  if (password) cambios.push('nueva contraseña');
  if ((antes.permisos||null) !== (permisosJson||null)) cambios.push(`permisos ${permisosJson||'(por defecto)'}`);
  audit(req, 'usuario.editar', 'usuario', req.params.id, `${usuario}: ${cambios.join(', ') || 'sin cambios relevantes'}`);
  res.json({ ok: true });
});


// ─── AUDITORÍA (solo admin) ───────────────────────────────────────────────────
app.get('/api/auditoria', authMiddleware, adminOnly, (req, res) => {
  const where = [], args = [];
  const { desde, hasta, usuario, accion, q } = req.query;
  if (desde) { where.push('fecha >= ?'); args.push(String(desde).slice(0,10) + ' 00:00:00'); }
  if (hasta) { where.push('fecha <= ?'); args.push(String(hasta).slice(0,10) + ' 23:59:59'); }
  if (usuario) { where.push('usuario LIKE ?'); args.push(`%${usuario}%`); }
  if (accion) { where.push('accion LIKE ?'); args.push(`${accion}%`); }
  if (q) { where.push('(detalle LIKE ? OR entidad_id LIKE ? OR accion LIKE ?)'); args.push(`%${q}%`, `%${q}%`, `%${q}%`); }
  const limite = Math.min(Number(req.query.limite) || 300, 2000);
  const rows = req.db.prepare(`SELECT a.*, s.nombre AS sucursal_nombre FROM auditoria a LEFT JOIN sucursales s ON s.id = a.sucursal_id
    ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY a.id DESC LIMIT ?`).all(...args, limite);
  res.json(rows);
});

// Stock de TODOS los lugares lado a lado (base para auditar y controlar)
app.get('/api/stock/matriz', authMiddleware, adminOnly, (req, res) => {
  const lugares = req.db.prepare('SELECT id,nombre,es_deposito_central FROM sucursales WHERE activa=1 ORDER BY es_deposito_central DESC, nombre').all();
  const prods = req.db.prepare('SELECT id,codigo,nombre,stock FROM productos ORDER BY nombre').all();
  const ss = req.db.prepare('SELECT producto_id,sucursal_id,cantidad FROM stock_sucursal').all();
  const mapa = {}; ss.forEach(r => { (mapa[r.producto_id] = mapa[r.producto_id] || {})[r.sucursal_id] = r.cantidad; });
  res.json({
    lugares,
    productos: prods.map(p => {
      const porLugar = {};
      lugares.forEach(l => { porLugar[l.id] = l.es_deposito_central ? p.stock : (mapa[p.id]?.[l.id] || 0); });
      return { id: p.id, codigo: p.codigo, nombre: p.nombre, por_lugar: porLugar, total: Object.values(porLugar).reduce((a, b) => a + b, 0) };
    }),
  });
});

// ─── PRODUCTOS ────────────────────────────────────────────────────────────────
// Cada usuario trabaja con el stock de SU sucursal (stock_sucursal); el admin puede elegir cuál mirar.
// El depósito central y los usuarios sin sucursal siguen con productos.stock.
function sucursalOperativa(req, sucAdmin) {
  const id = req.user?.rol === 'admin' ? Number(sucAdmin || 0) : Number(req.user?.sucursal_id || 0);
  if (!id) return null;
  const s = req.db.prepare('SELECT id, nombre, es_deposito_central FROM sucursales WHERE id=?').get(id);
  return s && !s.es_deposito_central ? s : null;
}
app.get('/api/productos', authMiddleware, (req, res) => {
  const _suc = sucursalOperativa(req, req.query.sucursal_id);
  if (_suc) {
    const rows = req.db.prepare(`
      SELECT p.*, COALESCE(ss.cantidad,0) AS stock, c.nombre as categoria_nombre, c.icono as categoria_icono, s.nombre as subcategoria_nombre
      FROM productos p
      LEFT JOIN stock_sucursal ss ON ss.producto_id = p.id AND ss.sucursal_id = ?
      LEFT JOIN categorias c ON c.id = p.categoria_id
      LEFT JOIN subcategorias s ON s.id = p.subcategoria_id
      ${req.user.rol === 'taller' ? 'WHERE (p.es_repuesto = 1 OR COALESCE(ss.cantidad,0) > 0)' : ''}
      ORDER BY p.nombre`).all(_suc.id);
    rows.forEach(r => { r.stock_sucursal_nombre = _suc.nombre; r.stock_sucursal_id = _suc.id; });
    return res.json(sinCostos(req, rows));
  }
  // El rol taller solo trabaja con repuestos/insumos de reparación — nunca
  // ve ni puede tocar el stock de venta de mostrador (celulares, accesorios).
  // Se filtra acá, en el origen, para que ninguna pantalla que use este
  // mismo endpoint (Stock, Enviar Mercadería, etc.) se lo pueda saltear.
  const soloRepuestos = req.user.rol === 'taller';
  res.json(sinCostos(req, req.db.prepare(`
    SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono, s.nombre as subcategoria_nombre
    FROM productos p
    LEFT JOIN categorias c ON c.id = p.categoria_id
    LEFT JOIN subcategorias s ON s.id = p.subcategoria_id
    ${soloRepuestos ? 'WHERE p.es_repuesto = 1' : ''}
    ORDER BY p.nombre
  `).all()));
});

// ─── CATEGORÍAS Y SUBCATEGORÍAS — catálogo propio de cada taller ───────────────
// tipo='producto' para Stock/Mercadería, tipo='herramienta' para Herramientas.
// Cada negocio arma el suyo (no viene todo precargado salvo para Herramientas,
// que trae un set típico de taller, y para la instalación local de Systech).
app.get('/api/categorias', authMiddleware, (req, res) => {
  const { tipo } = req.query;
  if (!['producto','herramienta'].includes(tipo)) return res.status(400).json({ error: 'tipo inválido' });
  const categorias = req.db.prepare('SELECT * FROM categorias WHERE tipo=? ORDER BY nombre').all(tipo);
  const subcategorias = req.db.prepare(`SELECT s.* FROM subcategorias s JOIN categorias c ON c.id=s.categoria_id WHERE c.tipo=? ORDER BY s.nombre`).all(tipo);
  categorias.forEach(c => c.subcategorias = subcategorias.filter(s => s.categoria_id === c.id));
  res.json(categorias);
});

app.post('/api/categorias', authMiddleware, (req, res) => {
  const { tipo, nombre, icono } = req.body;
  if (!['producto','herramienta'].includes(tipo)) return res.status(400).json({ error: 'tipo inválido' });
  if (!nombre?.trim()) return res.status(400).json({ error: 'Falta el nombre de la categoría' });
  try {
    const r = req.db.prepare('INSERT INTO categorias (tipo,nombre,icono) VALUES (?,?,?)').run(tipo, nombre.trim(), icono || '📦');
    res.json({ id: r.lastInsertRowid });
  } catch(e) { res.status(400).json({ error: e.message.includes('UNIQUE') ? 'Esa categoría ya existe' : e.message }); }
});

app.delete('/api/categorias/:id', authMiddleware, adminOnly, (req, res) => {
  const enUsoProd = req.db.prepare('SELECT COUNT(*) as c FROM productos WHERE categoria_id=?').get(req.params.id).c;
  const enUsoHerr = req.db.prepare(`SELECT COUNT(*) as c FROM herramientas WHERE categoria=(SELECT nombre FROM categorias WHERE id=?)`).get(req.params.id).c;
  if (enUsoProd || enUsoHerr) return res.status(400).json({ error: 'No se puede borrar: hay productos o herramientas usando esta categoría' });
  req.db.prepare('DELETE FROM subcategorias WHERE categoria_id=?').run(req.params.id);
  req.db.prepare('DELETE FROM categorias WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

app.post('/api/subcategorias', authMiddleware, (req, res) => {
  const { categoria_id, nombre } = req.body;
  if (!categoria_id || !nombre?.trim()) return res.status(400).json({ error: 'Faltan datos' });
  try {
    const r = req.db.prepare('INSERT INTO subcategorias (categoria_id,nombre) VALUES (?,?)').run(categoria_id, nombre.trim());
    res.json({ id: r.lastInsertRowid });
  } catch(e) { res.status(400).json({ error: e.message.includes('UNIQUE') ? 'Esa subcategoría ya existe en esta categoría' : e.message }); }
});

app.delete('/api/subcategorias/:id', authMiddleware, adminOnly, (req, res) => {
  const enUso = req.db.prepare('SELECT COUNT(*) as c FROM productos WHERE subcategoria_id=?').get(req.params.id).c;
  if (enUso) return res.status(400).json({ error: 'No se puede borrar: hay productos usando esta subcategoría' });
  req.db.prepare('DELETE FROM subcategorias WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});
// Búsqueda por código exacto (usada por el lector de código de barras/QR)
app.get('/api/productos/buscar-codigo/:codigo', authMiddleware, (req, res) => {
  const codigo = req.params.codigo.trim();
  let p = req.db.prepare('SELECT * FROM productos WHERE codigo=?').get(codigo);
  if (!p) p = req.db.prepare('SELECT * FROM productos WHERE codigo LIKE ? ORDER BY nombre LIMIT 1').get(`%${codigo}%`);
  if (!p) return res.status(404).json({ error: 'No se encontró ningún producto con ese código' });
  res.json(sinCostos(req, p));
});
app.get('/api/productos/:id', authMiddleware, (req, res) => {
  const p = req.db.prepare('SELECT * FROM productos WHERE id=?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'No encontrado' });
  res.json(sinCostos(req, p));
});
app.post('/api/productos', authMiddleware, requierePermiso('editar_productos'), (req, res) => {
  const _sucP = sucursalOperativa(req);
  const { codigo, nombre, categoria, categoria_id, subcategoria_id, stock, stock_minimo, precio_costo, precio_venta, es_repuesto } = req.body;
  try {
    const r = req.db.prepare(`INSERT INTO productos (codigo,nombre,categoria,categoria_id,subcategoria_id,stock,stock_minimo,precio_costo,precio_venta,es_repuesto) VALUES (?,?,?,?,?,?,?,?,?,?)`)
      .run(codigo,nombre,categoria||'',categoria_id||null,subcategoria_id||null,_sucP?0:(stock||0),stock_minimo||1,precio_costo||0,precio_venta||0,es_repuesto?1:0);
    if (_sucP && stock>0) { ajustarStock(req.db, r.lastInsertRowid, _sucP.id, Number(stock)); regMovStock(req.db, r.lastInsertRowid, 'entrada', stock, 'Stock inicial', _sucP.id, req.user.nombre); }
    else if (stock>0) regMovStock(req.db, r.lastInsertRowid, 'entrada', stock, 'Stock inicial', null, req.user.nombre);
    audit(req, 'producto.crear', 'producto', r.lastInsertRowid, `${codigo} — ${nombre} (stock inicial ${stock||0}, venta $${precio_venta||0})`);
    res.json({ id: r.lastInsertRowid });
  } catch(e) { res.status(400).json({ error: e.message.includes('UNIQUE') ? 'El código ya existe' : 'Error al crear el producto: '+e.message }); }
});
app.put('/api/productos/:id', authMiddleware, requierePermiso('editar_productos'), (req, res) => {
  const { codigo, nombre, categoria, categoria_id, subcategoria_id, stock_minimo, precio_costo, precio_venta, es_repuesto } = req.body;
  req.db.prepare(`UPDATE productos SET codigo=?,nombre=?,categoria=?,categoria_id=?,subcategoria_id=?,stock_minimo=?,precio_costo=?,precio_venta=?,es_repuesto=? WHERE id=?`)
    .run(codigo,nombre,categoria||'',categoria_id||null,subcategoria_id||null,stock_minimo||1,precio_costo||0,precio_venta||0,es_repuesto?1:0,req.params.id);
  audit(req, 'producto.editar', 'producto', req.params.id, `${codigo} — ${nombre} (costo $${precio_costo||0}, venta $${precio_venta||0})`);
  res.json({ ok: true });
});
app.post('/api/productos/:id/ajustar-stock', authMiddleware, requierePermiso('ajustar_stock'), (req, res) => {
  const { cantidad, tipo, motivo } = req.body;
  if (!Number.isInteger(cantidad) || cantidad <= 0) return res.status(400).json({ error: 'La cantidad tiene que ser un número entero mayor a 0' });
  if (tipo !== 'entrada' && tipo !== 'salida') return res.status(400).json({ error: 'Tipo de ajuste inválido' });
  const p = req.db.prepare('SELECT * FROM productos WHERE id=?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'No encontrado' });
  const _suc = sucursalOperativa(req, req.body.sucursal_id);
  if (_suc) {
    const actual = stockEn(req.db, p.id, _suc.id);
    const nuevoS = tipo==='entrada' ? actual+cantidad : actual-cantidad;
    if (nuevoS<0) return res.status(400).json({ error: 'Stock insuficiente en tu sucursal' });
    ajustarStock(req.db, p.id, _suc.id, nuevoS-actual);
    regMovStock(req.db, p.id, tipo, cantidad, motivo||'Ajuste manual', _suc.id, req.user.nombre);
    audit(req, 'stock.ajuste', 'producto', p.id, `${p.codigo} ${tipo} ${cantidad} en ${_suc.nombre}: ${actual} → ${nuevoS}. ${motivo||''}`);
    return res.json({ nuevo_stock: nuevoS });
  }
  const nuevo = tipo==='entrada' ? p.stock+cantidad : p.stock-cantidad;
  if (nuevo<0) return res.status(400).json({ error: 'Stock insuficiente' });
  req.db.prepare('UPDATE productos SET stock=? WHERE id=?').run(nuevo,req.params.id);
  regMovStock(req.db, p.id, tipo, cantidad, motivo||'Ajuste manual', null, req.user.nombre);
  audit(req, 'stock.ajuste', 'producto', p.id, `${p.codigo} ${tipo} ${cantidad} en Depósito Central: ${p.stock} → ${nuevo}. ${motivo||''}`);
  res.json({ nuevo_stock: nuevo });
});
app.delete('/api/productos/:id', authMiddleware, adminOnly, (req, res) => {
  const _pd = req.db.prepare('SELECT codigo,nombre FROM productos WHERE id=?').get(req.params.id);
  audit(req, 'producto.eliminar', 'producto', req.params.id, _pd ? `${_pd.codigo} — ${_pd.nombre}` : '');
  req.db.prepare('DELETE FROM productos WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ─── CLIENTES ─────────────────────────────────────────────────────────────────
// Teléfono normalizado (solo dígitos) para detectar duplicados aunque cambie el formato
const _telNorm = t => String(t || '').replace(/\D/g, '');
function _clienteDuplicadoPorTel(db, tel, exceptoId) {
  const n = _telNorm(tel);
  if (n.length < 6) return null;
  const todos = db.prepare("SELECT * FROM clientes WHERE COALESCE(telefono,'')<>'' ORDER BY id ASC").all();
  // el primero registrado (id menor) gana
  return todos.find(c => c.id !== Number(exceptoId || 0) && (() => {
    const m = _telNorm(c.telefono);
    return m === n || (m.length >= 8 && n.length >= 8 && (m.endsWith(n) || n.endsWith(m)));
  })()) || null;
}
app.get('/api/clientes', authMiddleware, (req, res) => res.json(req.db.prepare('SELECT * FROM clientes ORDER BY nombre').all()));
// Búsqueda rápida (nombre, teléfono, documento, email) — la usan Taller y Tienda
app.get('/api/clientes/buscar', authMiddleware, (req, res) => {
  const q = String(req.query.q || '').trim();
  if (!q) return res.json([]);
  const like = `%${q}%`, dig = _telNorm(q);
  const filas = req.db.prepare(`SELECT * FROM clientes WHERE nombre LIKE ? OR email LIKE ? OR documento LIKE ? OR telefono LIKE ? ORDER BY nombre LIMIT 15`).all(like, like, like, like);
  if (dig.length >= 4) {
    const ya = new Set(filas.map(f => f.id));
    req.db.prepare("SELECT * FROM clientes WHERE COALESCE(telefono,'')<>''").all().forEach(c => {
      if (!ya.has(c.id) && _telNorm(c.telefono).includes(dig) && filas.length < 15) filas.push(c);
    });
  }
  res.json(filas);
});
app.post('/api/clientes', authMiddleware, (req, res) => {
  const { nombre, telefono, email, direccion, documento, forzar } = req.body;
  if (!String(nombre || '').trim()) return res.status(400).json({ error: 'El nombre del cliente es obligatorio' });
  if (_telNorm(telefono).length < 6) return res.status(400).json({ error: 'El teléfono es obligatorio (mínimo 6 números)' });
  const dup = _clienteDuplicadoPorTel(req.db, telefono);
  if (dup && !forzar) return res.json({ duplicado: true, existente: dup, error: `Ya existe un cliente con ese teléfono: ${dup.nombre}` });
  const r = req.db.prepare(`INSERT INTO clientes (nombre,telefono,email,direccion,documento) VALUES (?,?,?,?,?)`).run(String(nombre).trim(), String(telefono).trim(), email||'', direccion||'', documento||'');
  res.json({ id: r.lastInsertRowid });
});
app.put('/api/clientes/:id', authMiddleware, (req, res) => {
  const { nombre, telefono, email, direccion, documento } = req.body;
  const ant = req.db.prepare('SELECT * FROM clientes WHERE id=?').get(req.params.id);
  if (!ant) return res.status(404).json({ error: 'Cliente no encontrado' });
  if (!String(nombre || '').trim()) return res.status(400).json({ error: 'El nombre del cliente es obligatorio' });
  if (_telNorm(telefono).length < 6) return res.status(400).json({ error: 'El teléfono es obligatorio (mínimo 6 números)' });
  req.db.prepare(`UPDATE clientes SET nombre=?,telefono=?,email=?,direccion=?,documento=? WHERE id=?`).run(String(nombre).trim(),String(telefono).trim(),email||'',direccion||'',documento===undefined?(ant.documento||''):documento,req.params.id);
  res.json({ ok: true });
});

// ─── ESTADOS ESPECIALES DE ORDEN (los define el admin; se suman a los estados base) ───
const ESTADOS_BASE = [
  { clave: 'recibido', nombre: 'Recibido' }, { clave: 'diagnostico', nombre: 'En diagnóstico' },
  { clave: 'reparando', nombre: 'En reparación' }, { clave: 'listo', nombre: 'Listo para entregar' },
  { clave: 'entregado', nombre: 'Entregado' }, { clave: 'cancelado', nombre: 'Cancelado' },
];
const TIPOS_ORDEN = ['cliente', 'garantia', 'gremio'];
app.get('/api/estados-orden', authMiddleware, (req, res) => {
  const custom = req.db.prepare('SELECT id,clave,nombre,color,cuenta_como,activo,orden FROM estados_orden ORDER BY orden,id').all();
  const uso = {};
  req.db.prepare('SELECT estado,COUNT(*) c FROM ordenes GROUP BY estado').all().forEach(r => uso[r.estado] = r.c);
  custom.forEach(c => c.ordenes = uso[c.clave] || 0);
  res.json({ base: ESTADOS_BASE, especiales: custom });
});
function _estadoDatos(b) {
  const nombre = String(b?.nombre || '').trim().slice(0, 40);
  const color = /^#[0-9a-fA-F]{6}$/.test(String(b?.color || '')) ? b.color : '#8b90a7';
  const cuenta = ['reparacion', 'espera'].includes(b?.cuenta_como) ? b.cuenta_como : 'reparacion';
  return { nombre, color, cuenta };
}
app.post('/api/estados-orden', authMiddleware, adminOnly, (req, res) => {
  const d = _estadoDatos(req.body);
  if (!d.nombre) return res.status(400).json({ error: 'Escribí el nombre del estado.' });
  const slug = d.nombre.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 30) || 'estado';
  let clave = 'x_' + slug, n = 2;
  while (req.db.prepare('SELECT 1 FROM estados_orden WHERE clave=?').get(clave)) clave = `x_${slug}_${n++}`;
  if (req.db.prepare('SELECT 1 FROM estados_orden WHERE lower(nombre)=lower(?)').get(d.nombre) || ESTADOS_BASE.some(e => e.nombre.toLowerCase() === d.nombre.toLowerCase()))
    return res.status(409).json({ error: 'Ya existe un estado con ese nombre.' });
  const ord = (req.db.prepare('SELECT COALESCE(MAX(orden),0)+1 m FROM estados_orden').get().m);
  const r = req.db.prepare('INSERT INTO estados_orden (clave,nombre,color,cuenta_como,orden) VALUES (?,?,?,?,?)').run(clave, d.nombre, d.color, d.cuenta, ord);
  audit(req, 'estado_orden.crear', 'estado_orden', r.lastInsertRowid, `Creó el estado especial «${d.nombre}» (${d.cuenta === 'espera' ? 'en espera' : 'cuenta como en reparación'})`);
  res.json({ ok: true, id: r.lastInsertRowid, clave });
});
app.put('/api/estados-orden/:id', authMiddleware, adminOnly, (req, res) => {
  const e = req.db.prepare('SELECT * FROM estados_orden WHERE id=?').get(req.params.id);
  if (!e) return res.status(404).json({ error: 'Estado no encontrado' });
  const d = _estadoDatos({ nombre: req.body?.nombre ?? e.nombre, color: req.body?.color ?? e.color, cuenta_como: req.body?.cuenta_como ?? e.cuenta_como });
  if (!d.nombre) return res.status(400).json({ error: 'Escribí el nombre del estado.' });
  const activo = req.body?.activo === undefined ? e.activo : (req.body.activo ? 1 : 0);
  req.db.prepare('UPDATE estados_orden SET nombre=?,color=?,cuenta_como=?,activo=? WHERE id=?').run(d.nombre, d.color, d.cuenta, activo, e.id);
  audit(req, 'estado_orden.editar', 'estado_orden', e.id, `Estado especial «${e.nombre}» → «${d.nombre}»${activo !== e.activo ? (activo ? ' (activado)' : ' (desactivado)') : ''}`);
  res.json({ ok: true });
});
app.delete('/api/estados-orden/:id', authMiddleware, adminOnly, (req, res) => {
  const e = req.db.prepare('SELECT * FROM estados_orden WHERE id=?').get(req.params.id);
  if (!e) return res.status(404).json({ error: 'Estado no encontrado' });
  const n = req.db.prepare('SELECT COUNT(*) c FROM ordenes WHERE estado=?').get(e.clave).c;
  if (n) return res.status(409).json({ error: `Hay ${n} orden(es) en «${e.nombre}»: cambialas de estado o desactivá este estado en vez de borrarlo.` });
  req.db.prepare('DELETE FROM estados_orden WHERE id=?').run(e.id);
  audit(req, 'estado_orden.borrar', 'estado_orden', e.id, `Borró el estado especial «${e.nombre}»`);
  res.json({ ok: true });
});

// ─── COMISIONES DE TÉCNICOS, CAUSAS DE GARANTÍA Y GREMIOS (Entrega B) ───────────
const _r2 = n => Math.round((Number(n) || 0) * 100) / 100;
const _num = (v, min, max, def = 0) => { const n = parseFloat(v); if (!isFinite(n)) return def; return Math.max(min, Math.min(max, n)); };
function recargoRepuestoPct(db) { return _num(db.prepare("SELECT valor FROM config WHERE clave='recargo_repuesto_pct'").get()?.valor, 0, 1000, 0); }

// Técnicos disponibles para asignar a una orden (lista desplegable)
app.get('/api/tecnicos', authMiddleware, (req, res) => {
  const rows = req.db.prepare("SELECT id,nombre FROM usuarios WHERE rol='taller' AND COALESCE(activo,1)=1 ORDER BY nombre").all();
  rows.forEach(r => { r.yo = r.id === req.user.usuario_id; });
  res.json(rows);
});

// Reglas (solo admin): recargo sobre el costo del repuesto + % y monto de garantía por técnico
app.get('/api/comisiones/config', authMiddleware, adminOnly, (req, res) => {
  const tecs = req.db.prepare("SELECT id,nombre FROM usuarios WHERE rol='taller' AND COALESCE(activo,1)=1 ORDER BY nombre").all();
  const reglas = tecs.map(t => {
    const r = req.db.prepare('SELECT pct_mano_obra,pct_repuesto,monto_garantia FROM comision_reglas WHERE tecnico_id=?').get(t.id) || {};
    return { tecnico_id: t.id, nombre: t.nombre, pct_mano_obra: r.pct_mano_obra || 0, pct_repuesto: r.pct_repuesto || 0, monto_garantia: r.monto_garantia || 0 };
  });
  res.json({ recargo_repuesto_pct: recargoRepuestoPct(req.db), reglas });
});
app.put('/api/comisiones/config', authMiddleware, adminOnly, (req, res) => {
  const rec = _num(req.body?.recargo_repuesto_pct, 0, 1000, 0);
  req.db.prepare("INSERT INTO config (clave,valor) VALUES ('recargo_repuesto_pct',?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor").run(String(rec));
  const cambios = [`recargo repuestos ${rec}%`];
  for (const r of (Array.isArray(req.body?.reglas) ? req.body.reglas : [])) {
    const t = req.db.prepare("SELECT id,nombre FROM usuarios WHERE id=? AND rol='taller'").get(r.tecnico_id);
    if (!t) continue;
    const pmo = _num(r.pct_mano_obra, 0, 100), prep = _num(r.pct_repuesto, 0, 100), mg = _num(r.monto_garantia, 0, 1e9);
    req.db.prepare(`INSERT INTO comision_reglas (tecnico_id,pct_mano_obra,pct_repuesto,monto_garantia,updated_at) VALUES (?,?,?,?,CURRENT_TIMESTAMP)
      ON CONFLICT(tecnico_id) DO UPDATE SET pct_mano_obra=excluded.pct_mano_obra,pct_repuesto=excluded.pct_repuesto,monto_garantia=excluded.monto_garantia,updated_at=CURRENT_TIMESTAMP`).run(t.id, pmo, prep, mg);
    cambios.push(`${t.nombre}: ${pmo}% M.O. / ${prep}% repuesto / garantía $${mg}`);
  }
  audit(req, 'comisiones.reglas', 'comisiones', 0, 'Reglas de comisión guardadas · ' + cambios.join(' · ').slice(0, 600));
  res.json({ ok: true });
});

// Causas de garantía (las crea el admin)
app.get('/api/garantia-causas', authMiddleware, (req, res) => res.json(req.db.prepare('SELECT * FROM garantia_causas ORDER BY activo DESC,nombre').all()));
function _causaDatos(b) {
  const nombre = String(b?.nombre || '').trim().slice(0, 60);
  const absorbe = b?.absorbe === 'tecnico' ? 'tecnico' : 'local';
  const tipo = ['ninguno', 'monto', 'pct'].includes(b?.descuento_tipo) ? b.descuento_tipo : 'ninguno';
  const valor = tipo === 'ninguno' || absorbe === 'local' ? 0 : _num(b?.descuento_valor, 0, tipo === 'pct' ? 100 : 1e9);
  return { nombre, absorbe, tipo: absorbe === 'local' ? 'ninguno' : tipo, valor };
}
app.post('/api/garantia-causas', authMiddleware, adminOnly, (req, res) => {
  const d = _causaDatos(req.body);
  if (!d.nombre) return res.status(400).json({ error: 'Escribí el nombre de la causa.' });
  const r = req.db.prepare('INSERT INTO garantia_causas (nombre,absorbe,descuento_tipo,descuento_valor) VALUES (?,?,?,?)').run(d.nombre, d.absorbe, d.tipo, d.valor);
  audit(req, 'garantia_causa.crear', 'garantia_causa', r.lastInsertRowid, `Causa de garantía «${d.nombre}» (${d.absorbe === 'tecnico' ? 'lo absorbe el técnico: ' + d.tipo + ' ' + d.valor : 'lo absorbe el local'})`);
  res.json({ ok: true, id: r.lastInsertRowid });
});
app.put('/api/garantia-causas/:id', authMiddleware, adminOnly, (req, res) => {
  const e = req.db.prepare('SELECT * FROM garantia_causas WHERE id=?').get(req.params.id);
  if (!e) return res.status(404).json({ error: 'No existe esa causa' });
  const d = _causaDatos({ nombre: req.body?.nombre ?? e.nombre, absorbe: req.body?.absorbe ?? e.absorbe, descuento_tipo: req.body?.descuento_tipo ?? e.descuento_tipo, descuento_valor: req.body?.descuento_valor ?? e.descuento_valor });
  if (!d.nombre) return res.status(400).json({ error: 'Escribí el nombre de la causa.' });
  const activo = req.body?.activo === undefined ? e.activo : (req.body.activo ? 1 : 0);
  req.db.prepare('UPDATE garantia_causas SET nombre=?,absorbe=?,descuento_tipo=?,descuento_valor=?,activo=? WHERE id=?').run(d.nombre, d.absorbe, d.tipo, d.valor, activo, e.id);
  audit(req, 'garantia_causa.editar', 'garantia_causa', e.id, `Causa «${e.nombre}» → «${d.nombre}» (${d.absorbe}, ${d.tipo} ${d.valor})${activo !== e.activo ? (activo ? ' activada' : ' desactivada') : ''}`);
  res.json({ ok: true });
});
app.delete('/api/garantia-causas/:id', authMiddleware, adminOnly, (req, res) => {
  const e = req.db.prepare('SELECT * FROM garantia_causas WHERE id=?').get(req.params.id);
  if (!e) return res.status(404).json({ error: 'No existe esa causa' });
  const n = req.db.prepare('SELECT COUNT(*) c FROM ordenes WHERE garantia_causa_id=?').get(e.id).c;
  if (n) return res.status(409).json({ error: `Hay ${n} garantía(s) con esta causa: desactivala en vez de borrarla.` });
  req.db.prepare('DELETE FROM garantia_causas WHERE id=?').run(e.id);
  audit(req, 'garantia_causa.borrar', 'garantia_causa', e.id, `Borró la causa «${e.nombre}»`);
  res.json({ ok: true });
});

// Gremios: cada uno con su trato (monto fijo o % de descuento) y su % de comisión para el técnico
app.get('/api/gremios', authMiddleware, (req, res) => res.json(req.db.prepare('SELECT * FROM gremios ORDER BY activo DESC,nombre').all()));
function _gremioDatos(b) {
  const nombre = String(b?.nombre || '').trim().slice(0, 80);
  const tipo = ['ninguna', 'monto', 'pct_descuento'].includes(b?.tarifa_tipo) ? b.tarifa_tipo : 'ninguna';
  const valor = tipo === 'ninguna' ? 0 : _num(b?.tarifa_valor, 0, tipo === 'pct_descuento' ? 100 : 1e9);
  const pctTec = (b?.pct_mano_obra_tecnico === '' || b?.pct_mano_obra_tecnico === null || b?.pct_mano_obra_tecnico === undefined) ? null : _num(b.pct_mano_obra_tecnico, 0, 100);
  return { nombre, tipo, valor, pctTec };
}
app.post('/api/gremios', authMiddleware, adminOnly, (req, res) => {
  const d = _gremioDatos(req.body);
  if (!d.nombre) return res.status(400).json({ error: 'Escribí el nombre del gremio.' });
  const r = req.db.prepare('INSERT INTO gremios (nombre,tarifa_tipo,tarifa_valor,pct_mano_obra_tecnico) VALUES (?,?,?,?)').run(d.nombre, d.tipo, d.valor, d.pctTec);
  audit(req, 'gremio.crear', 'gremio', r.lastInsertRowid, `Gremio «${d.nombre}» · tarifa ${d.tipo} ${d.valor} · comisión técnico ${d.pctTec === null ? 'la normal' : d.pctTec + '%'}`);
  res.json({ ok: true, id: r.lastInsertRowid });
});
app.put('/api/gremios/:id', authMiddleware, adminOnly, (req, res) => {
  const e = req.db.prepare('SELECT * FROM gremios WHERE id=?').get(req.params.id);
  if (!e) return res.status(404).json({ error: 'No existe ese gremio' });
  const d = _gremioDatos({ nombre: req.body?.nombre ?? e.nombre, tarifa_tipo: req.body?.tarifa_tipo ?? e.tarifa_tipo, tarifa_valor: req.body?.tarifa_valor ?? e.tarifa_valor, pct_mano_obra_tecnico: req.body && 'pct_mano_obra_tecnico' in req.body ? req.body.pct_mano_obra_tecnico : e.pct_mano_obra_tecnico });
  if (!d.nombre) return res.status(400).json({ error: 'Escribí el nombre del gremio.' });
  const activo = req.body?.activo === undefined ? e.activo : (req.body.activo ? 1 : 0);
  req.db.prepare('UPDATE gremios SET nombre=?,tarifa_tipo=?,tarifa_valor=?,pct_mano_obra_tecnico=?,activo=? WHERE id=?').run(d.nombre, d.tipo, d.valor, d.pctTec, activo, e.id);
  audit(req, 'gremio.editar', 'gremio', e.id, `Gremio «${e.nombre}» actualizado: tarifa ${d.tipo} ${d.valor} · comisión técnico ${d.pctTec === null ? 'la normal' : d.pctTec + '%'}${activo !== e.activo ? (activo ? ' · activado' : ' · desactivado') : ''}`);
  res.json({ ok: true });
});
app.delete('/api/gremios/:id', authMiddleware, adminOnly, (req, res) => {
  const e = req.db.prepare('SELECT * FROM gremios WHERE id=?').get(req.params.id);
  if (!e) return res.status(404).json({ error: 'No existe ese gremio' });
  const n = req.db.prepare('SELECT COUNT(*) c FROM ordenes WHERE gremio_id=?').get(e.id).c;
  if (n) return res.status(409).json({ error: `Hay ${n} orden(es) de este gremio: desactivalo en vez de borrarlo.` });
  req.db.prepare('DELETE FROM gremios WHERE id=?').run(e.id);
  audit(req, 'gremio.borrar', 'gremio', e.id, `Borró el gremio «${e.nombre}»`);
  res.json({ ok: true });
});

// Calcula y GUARDA (como foto fija) la comisión de una orden ya entregada. Idempotente: una sola vez por orden.
function registrarComision(db, ordenId) {
  const o = db.prepare('SELECT * FROM ordenes WHERE id=?').get(ordenId);
  if (!o || o.estado !== 'entregado') return null;
  const tipoFila = o.tipo_orden === 'garantia' ? 'garantia' : 'reparacion';
  if (db.prepare('SELECT 1 FROM comisiones WHERE orden_id=? AND tipo=?').get(o.id, tipoFila)) return null;
  if (db.prepare('SELECT 1 FROM comprobantes WHERE orden_id=? AND sin_reparacion=1').get(o.id)) return null;   // equipos que salen sin reparar no generan comisión
  let tec = o.tecnico_id ? db.prepare('SELECT id,nombre FROM usuarios WHERE id=?').get(o.tecnico_id) : null;
  if (!tec && o.tecnico) tec = db.prepare("SELECT id,nombre FROM usuarios WHERE lower(nombre)=lower(?) AND rol='taller'").get(String(o.tecnico).trim()) || null;
  const regla = (tec && db.prepare('SELECT * FROM comision_reglas WHERE tecnico_id=?').get(tec.id)) || { pct_mano_obra: 0, pct_repuesto: 0, monto_garantia: 0 };
  const recargo = recargoRepuestoPct(db);
  const lineas = db.prepare(`SELECT or2.cantidad,or2.subtotal,or2.precio_unitario,p.nombre,p.precio_costo FROM orden_repuestos or2 JOIN productos p ON p.id=or2.producto_id WHERE or2.orden_id=?`).all(o.id);
  const venta = lineas.reduce((a, l) => a + Number(l.subtotal || 0), 0);
  const costo = lineas.reduce((a, l) => a + Number(l.cantidad || 0) * Number(l.precio_costo || 0), 0);
  const costoAj = costo * (1 + recargo / 100);
  const det = { repuestos: lineas.map(l => ({ nombre: l.nombre, cantidad: l.cantidad, venta: _r2(l.subtotal), costo: _r2(l.cantidad * l.precio_costo), costo_ajustado: _r2(l.cantidad * l.precio_costo * (1 + recargo / 100)) })) };
  let f;
  if (o.tipo_orden === 'garantia') {
    const pago = _r2(regla.monto_garantia);
    const cg = cobroGarantia(o);
    const pctG = Number(regla.pct_mano_obra) || 0;
    const cMoG = _r2(cg.mo * pctG / 100);
    const totalTec = _r2(pago + cMoG);
    f = { mano_obra_base: _r2(cg.mo), pct_mano_obra: pctG, comision_mano_obra: cMoG, repuestos_venta: _r2(cg.rep), repuestos_costo: _r2(costo), repuestos_costo_ajustado: _r2(costoAj), recargo_pct: recargo, margen_repuesto: 0, pct_repuesto: 0, comision_repuesto: 0, pago_garantia: pago, descuento: 0, total: totalTec, perdida_local: _r2(Math.max(0, costo + totalTec - cg.total)) };
    det.resultado = _r2(cg.total - costo - totalTec);   // con signo: negativo = pérdida real, positivo = el cliente cubrió todo
    det.costo_real_repuesto = _r2(costo); det.pago_tecnico = totalTec;
    if (lineas.some(l => !(Number(l.precio_costo) > 0))) det.aviso_costo = 'Hay un repuesto sin costo cargado en Inventario: la pérdida real puede ser mayor.';
    det.cobrado_cliente = cg.total; det.cobrado_mo = _r2(cg.mo); det.cobrado_repuesto = _r2(cg.rep); det.repuestos_precio_venta = _r2(venta);
    det.nota = (cg.total > 0 ? `Garantía con cobro parcial: el cliente pagó $${_r2(cg.total)} (mano de obra $${_r2(cg.mo)} + repuesto $${_r2(cg.rep)})` : 'Garantía del local: no se cobró al cliente') + (o.garantia_ref ? ` · reparación original ${o.garantia_ref}` : '');
  } else {
    let pctMo = Number(regla.pct_mano_obra) || 0;
    if (o.tipo_orden === 'gremio' && o.gremio_id) {
      const g = db.prepare('SELECT nombre,pct_mano_obra_tecnico FROM gremios WHERE id=?').get(o.gremio_id);
      if (g) { det.gremio = g.nombre; if (g.pct_mano_obra_tecnico !== null && g.pct_mano_obra_tecnico !== undefined) pctMo = Number(g.pct_mano_obra_tecnico); }
    }
    const mo = _r2(o.mano_obra);
    const margen = _r2(venta - costoAj);
    const cMo = _r2(mo * pctMo / 100), cRep = _r2(Math.max(0, margen) * (Number(regla.pct_repuesto) || 0) / 100);
    f = { mano_obra_base: mo, pct_mano_obra: pctMo, comision_mano_obra: cMo, repuestos_venta: _r2(venta), repuestos_costo: _r2(costo), repuestos_costo_ajustado: _r2(costoAj), recargo_pct: recargo, margen_repuesto: margen, pct_repuesto: Number(regla.pct_repuesto) || 0, comision_repuesto: cRep, pago_garantia: 0, descuento: 0, total: _r2(cMo + cRep), perdida_local: 0 };
  }
  if (!tec) det.aviso = 'La orden no tenía técnico asignado: no genera pago.';
  db.prepare(`INSERT INTO comisiones (orden_id,tipo,tecnico_id,tecnico_nombre,mano_obra_base,pct_mano_obra,comision_mano_obra,repuestos_venta,repuestos_costo,repuestos_costo_ajustado,recargo_pct,margen_repuesto,pct_repuesto,comision_repuesto,pago_garantia,descuento,total,perdida_local,detalle)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(o.id, tipoFila, tec?.id || null, tec?.nombre || (o.tecnico || null), f.mano_obra_base, f.pct_mano_obra, f.comision_mano_obra, f.repuestos_venta, f.repuestos_costo, f.repuestos_costo_ajustado, f.recargo_pct, f.margen_repuesto, f.pct_repuesto, f.comision_repuesto, f.pago_garantia, f.descuento, tec ? f.total : 0, f.perdida_local, JSON.stringify(det));
  return f;
}
function _registrarComisionSeguro(db, ordenId) { try { registrarComision(db, ordenId); } catch (e) { console.error('comisión:', e.message); } }

// Causa de una garantía (admin): si la absorbe el técnico, se le descuenta al técnico de la reparación ORIGINAL
app.put('/api/ordenes/:id/garantia-causa', authMiddleware, adminOnly, (req, res) => {
  const o = req.db.prepare('SELECT * FROM ordenes WHERE id=?').get(req.params.id);
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  if (o.tipo_orden !== 'garantia') return res.status(409).json({ error: 'Esta orden no es una garantía.' });
  const prev = req.db.prepare("SELECT * FROM comisiones WHERE orden_id=? AND tipo='descuento_garantia'").get(o.id);
  if (prev && prev.estado !== 'pendiente') return res.status(409).json({ error: 'El descuento de esta garantía ya fue liquidado: no se puede cambiar.' });
  const causaId = req.body?.causa_id ? Number(req.body.causa_id) : null;
  const causa = causaId ? req.db.prepare('SELECT * FROM garantia_causas WHERE id=?').get(causaId) : null;
  if (causaId && !causa) return res.status(404).json({ error: 'Esa causa no existe.' });
  req.db.prepare('UPDATE ordenes SET garantia_causa_id=? WHERE id=?').run(causa?.id || null, o.id);
  if (prev) req.db.prepare('DELETE FROM comisiones WHERE id=?').run(prev.id);
  let msg = causa ? `Causa: ${causa.nombre}.` : 'Causa quitada.';
  if (causa && causa.absorbe === 'tecnico' && causa.descuento_tipo !== 'ninguno' && causa.descuento_valor > 0) {
    const orig = o.garantia_ref ? req.db.prepare('SELECT id,numero,tecnico_id,tecnico FROM ordenes WHERE numero=?').get(String(o.garantia_ref).trim()) : null;
    let tecId = orig?.tecnico_id || null, tecNom = orig?.tecnico || null;
    if (!tecId && tecNom) tecId = req.db.prepare("SELECT id FROM usuarios WHERE lower(nombre)=lower(?) AND rol='taller'").get(tecNom)?.id || null;
    if (!tecId && req.body?.tecnico_id) { const t = req.db.prepare("SELECT id,nombre FROM usuarios WHERE id=? AND rol='taller'").get(req.body.tecnico_id); if (t) { tecId = t.id; tecNom = t.nombre; } }
    if (!tecId) return res.status(400).json({ error: 'No sé a qué técnico descontarle: cargá el N° de la reparación original en la garantía, o elegí el técnico.', pedir_tecnico: true });
    if (!tecNom) tecNom = req.db.prepare('SELECT nombre FROM usuarios WHERE id=?').get(tecId)?.nombre || '';
    let monto = causa.descuento_valor;
    let base = null;
    if (causa.descuento_tipo === 'pct') {
      base = orig ? req.db.prepare("SELECT total FROM comisiones WHERE orden_id=? AND tipo='reparacion'").get(orig.id)?.total : null;
      monto = _r2((base || 0) * causa.descuento_valor / 100);
    }
    monto = _r2(monto);
    req.db.prepare(`INSERT INTO comisiones (orden_id,tipo,tecnico_id,tecnico_nombre,descuento,total,detalle) VALUES (?,?,?,?,?,?,?)`)
      .run(o.id, 'descuento_garantia', tecId, tecNom, monto, -monto, JSON.stringify({ causa: causa.nombre, regla: causa.descuento_tipo === 'pct' ? `${causa.descuento_valor}% de la comisión original${base === null ? ' (no se encontró la reparación original: $0)' : ''}` : `monto fijo $${causa.descuento_valor}`, reparacion_original: orig?.numero || o.garantia_ref || null }));
    msg += ` Se le descuentan $${monto} a ${tecNom}.`;
  } else if (causa) msg += ' Lo absorbe el local: no se descuenta nada al técnico.';
  audit(req, 'orden.garantia_causa', 'orden', o.id, `${o.numero}: ${msg}`);
  res.json({ ok: true, mensaje: msg });
});

// Comisiones generadas (admin) — vista de control; la liquidación completa viene en la Entrega C
app.get('/api/comisiones', authMiddleware, adminOnly, (req, res) => {
  const w = [], a = [];
  if (req.query.tecnico_id) { w.push('c.tecnico_id=?'); a.push(req.query.tecnico_id); }
  if (req.query.estado) { w.push('c.estado=?'); a.push(req.query.estado); }
  if (req.query.desde) { w.push("date(c.fecha,'localtime')>=date(?)"); a.push(req.query.desde); }
  if (req.query.hasta) { w.push("date(c.fecha,'localtime')<=date(?)"); a.push(req.query.hasta); }
  const rows = req.db.prepare(`SELECT c.*,o.numero,o.equipo,o.marca,o.modelo,o.tipo_orden,o.garantia_ref,o.cobrado,o.fecha_entrega FROM comisiones c LEFT JOIN ordenes o ON o.id=c.orden_id ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY c.id DESC LIMIT 2000`).all(...a);
  rows.forEach(r => { try { r.detalle = JSON.parse(r.detalle || '{}'); } catch (e) { r.detalle = {}; } });
  res.json(rows);
});

// Recalcula con las reglas ACTUALES las comisiones todavía PENDIENTES (las pagadas no se tocan nunca)
app.post('/api/comisiones/recalcular', authMiddleware, adminOnly, (req, res) => {
  const { w, a } = _filtroLiq({ ...(req.body || {}), estado: 'pendiente' }, 'c');
  w.push("c.tipo IN ('reparacion','garantia')");
  const filas = req.db.prepare(`SELECT c.id,c.orden_id FROM comisiones c WHERE ${w.join(' AND ')}`).all(...a);
  let n = 0;
  req.db.transaction(() => {
    for (const f of filas) {
      req.db.prepare('DELETE FROM comisiones WHERE id=?').run(f.id);
      if (registrarComision(req.db, f.orden_id)) n++;
    }
  })();
  audit(req, 'comisiones.recalcular', 'comision', null, `Recalculó ${n} comisión(es) pendientes con las reglas actuales`);
  res.json({ ok: true, recalculadas: n });
});

// ── Liquidación de comisiones (admin) ──
function _filtroLiq(q, alias) {
  const w = [], a = [];
  if (q.tecnico_id) { w.push(`${alias}.tecnico_id=?`); a.push(q.tecnico_id); }
  if (q.desde) { w.push(`date(${alias}.fecha,'localtime')>=date(?)`); a.push(q.desde); }
  if (q.hasta) { w.push(`date(${alias}.fecha,'localtime')<=date(?)`); a.push(q.hasta); }
  if (q.estado === 'pagada' || q.estado === 'pendiente') { w.push(`${alias}.estado=?`); a.push(q.estado); }
  return { w, a };
}
// Resumen por técnico
app.get('/api/liquidacion/resumen', authMiddleware, adminOnly, (req, res) => {
  const { w, a } = _filtroLiq({ ...req.query, tecnico_id: '' }, 'c');
  const rows = req.db.prepare(`SELECT c.tecnico_id, COALESCE(MAX(c.tecnico_nombre),'(sin técnico)') AS tecnico,
      SUM(CASE WHEN c.tipo='reparacion' THEN 1 ELSE 0 END) AS reparaciones,
      SUM(CASE WHEN c.tipo='garantia' THEN 1 ELSE 0 END) AS garantias,
      SUM(CASE WHEN c.tipo='reparacion' THEN c.mano_obra_base + c.repuestos_venta ELSE 0 END) AS facturado,
      SUM(c.comision_mano_obra) AS comision_mo, SUM(c.comision_repuesto) AS comision_rep,
      SUM(c.pago_garantia) AS pago_garantias, SUM(c.descuento) AS descuentos,
      SUM(c.total) AS total, SUM(c.perdida_local) AS perdida_local
    FROM comisiones c ${w.length ? 'WHERE ' + w.join(' AND ') : ''} GROUP BY c.tecnico_id ORDER BY tecnico`).all(...a);
  res.json(rows.map(r => { Object.keys(r).forEach(k => { if (typeof r[k] === 'number') r[k] = _r2(r[k]); }); return r; }));
});
// Datos para el gráfico: por día (rango corto) o por mes. Ignora el filtro de estado: muestra pagadas vs por pagar.
app.get('/api/liquidacion/grafico', authMiddleware, adminOnly, (req, res) => {
  const { w, a } = _filtroLiq({ ...req.query, tecnico_id: req.query.tecnico_id || '', estado: '' }, 'c');
  let dias = 9999;
  if (req.query.desde && req.query.hasta) dias = Math.round((new Date(req.query.hasta) - new Date(req.query.desde)) / 86400000) + 1;
  const porDia = dias <= 62;
  const fmt = porDia ? '%Y-%m-%d' : '%Y-%m';
  const rows = req.db.prepare(`SELECT strftime('${fmt}', c.fecha, 'localtime') AS periodo,
      SUM(CASE WHEN c.tipo='reparacion' THEN 1 ELSE 0 END) AS reparaciones,
      SUM(CASE WHEN c.tipo='garantia' THEN 1 ELSE 0 END) AS garantias,
      SUM(CASE WHEN c.tipo='garantia' AND c.perdida_local>0 THEN 1 ELSE 0 END) AS garantias_con_perdida,
      SUM(c.perdida_local) AS perdida,
      SUM(CASE WHEN c.estado='pendiente' THEN c.total ELSE 0 END) AS por_pagar,
      SUM(CASE WHEN c.estado='pagada' THEN c.total ELSE 0 END) AS pagadas
    FROM comisiones c ${w.length ? 'WHERE ' + w.join(' AND ') : ''} GROUP BY periodo ORDER BY periodo`).all(...a);
  rows.forEach(r => { ['perdida', 'por_pagar', 'pagadas'].forEach(k => r[k] = _r2(r[k])); });
  res.json({ agrupado: porDia ? 'dia' : 'mes', filas: rows });
});
// Detalle orden por orden
app.get('/api/liquidacion/detalle', authMiddleware, adminOnly, (req, res) => {
  const { w, a } = _filtroLiq(req.query, 'c');
  if (req.query.liquidacion_id) { w.push('c.liquidacion_id=?'); a.push(req.query.liquidacion_id); }
  const rows = req.db.prepare(`SELECT c.*, o.numero, o.equipo, o.marca, o.modelo, o.tipo_orden, o.garantia_ref, o.cobrado, o.fecha_entrega, cl.nombre AS cliente
    FROM comisiones c LEFT JOIN ordenes o ON o.id=c.orden_id LEFT JOIN clientes cl ON cl.id=o.cliente_id
    ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY c.fecha, c.id`).all(...a);
  rows.forEach(r => { try { r.detalle = JSON.parse(r.detalle || '{}'); } catch (e) { r.detalle = {}; } });
  res.json(rows);
});
// Marcar como pagado un período de un técnico
app.post('/api/liquidaciones', authMiddleware, adminOnly, (req, res) => {
  const { tecnico_id, desde, hasta, nota, medio } = req.body || {};
  if (!tecnico_id) return res.status(400).json({ error: 'Elegí el técnico' });
  const { w, a } = _filtroLiq({ tecnico_id, desde, hasta, estado: 'pendiente' }, 'c');
  const db = req.db;
  const filas = db.prepare(`SELECT c.id,c.total,c.perdida_local,c.tipo,c.tecnico_nombre FROM comisiones c WHERE ${w.join(' AND ')}`).all(...a);
  if (!filas.length) return res.status(400).json({ error: 'No hay comisiones pendientes de ese técnico en ese período' });
  const total = _r2(filas.reduce((s, f) => s + f.total, 0)), perdida = _r2(filas.reduce((s, f) => s + (f.perdida_local || 0), 0));
  let id;
  db.transaction(() => {
    id = db.prepare(`INSERT INTO liquidaciones (tecnico_id,tecnico_nombre,desde,hasta,cantidad,total,perdida_local,medio,nota,usuario_id,usuario_nombre) VALUES (?,?,?,?,?,?,?,?,?,?,?)`)
      .run(tecnico_id, filas[0].tecnico_nombre || '', desde || '', hasta || '', filas.length, total, perdida, String(medio || '').slice(0, 40), String(nota || '').slice(0, 300), req.user.usuario_id, req.user.nombre || req.user.usuario || '').lastInsertRowid;
    db.prepare(`UPDATE comisiones SET estado='pagada', liquidacion_id=? WHERE id IN (${filas.map(() => '?').join(',')})`).run(id, ...filas.map(f => f.id));
  })();
  audit(req, 'comisiones.liquidar', 'liquidacion', id, `${filas[0].tecnico_nombre || 'técnico ' + tecnico_id}: ${filas.length} comisiones, total $${total} (${desde || '…'} a ${hasta || '…'})`);
  res.json({ ok: true, id, total, cantidad: filas.length });
});
app.get('/api/liquidaciones', authMiddleware, adminOnly, (req, res) => {
  res.json(req.db.prepare(`SELECT * FROM liquidaciones ORDER BY id DESC LIMIT 200`).all());
});
// Deshacer un pago (por si se marcó por error): las comisiones vuelven a pendientes
app.delete('/api/liquidaciones/:id', authMiddleware, adminOnly, (req, res) => {
  const l = req.db.prepare('SELECT * FROM liquidaciones WHERE id=?').get(req.params.id);
  if (!l) return res.status(404).json({ error: 'No encontrada' });
  req.db.transaction(() => {
    req.db.prepare(`UPDATE comisiones SET estado='pendiente', liquidacion_id=NULL WHERE liquidacion_id=?`).run(l.id);
    req.db.prepare('DELETE FROM liquidaciones WHERE id=?').run(l.id);
  })();
  audit(req, 'comisiones.liquidar_deshacer', 'liquidacion', l.id, `Se deshizo el pago de ${l.tecnico_nombre}: $${l.total} (${l.cantidad} comisiones vuelven a pendientes)`);
  res.json({ ok: true });
});

// El técnico ve SUS reparaciones y lo que lleva ganado (solo lectura)
app.get('/api/mis-reparaciones', authMiddleware, (req, res) => {
  if (!['taller', 'admin'].includes(req.user.rol)) return res.status(403).json({ error: 'Sin acceso.' });
  const yo = req.db.prepare('SELECT id,nombre FROM usuarios WHERE id=?').get(req.user.usuario_id);
  const tid = req.user.rol === 'admin' && req.query.tecnico_id ? Number(req.query.tecnico_id) : yo?.id;
  const tnom = req.db.prepare('SELECT nombre FROM usuarios WHERE id=?').get(tid)?.nombre || '';
  const w = ['(o.tecnico_id=? OR (o.tecnico_id IS NULL AND lower(o.tecnico)=lower(?)))'], a = [tid, tnom];
  if (req.query.estado) { w.push('o.estado=?'); a.push(req.query.estado); }
  if (req.query.tipo) { w.push("COALESCE(o.tipo_orden,'cliente')=?"); a.push(req.query.tipo); }
  if (req.query.desde) { w.push('date(o.fecha_ingreso)>=date(?)'); a.push(req.query.desde); }
  if (req.query.hasta) { w.push('date(o.fecha_ingreso)<=date(?)'); a.push(req.query.hasta); }
  const rows = req.db.prepare(`SELECT o.id,o.numero,o.equipo,o.marca,o.modelo,o.estado,o.tipo_orden,o.garantia_ref,o.fecha_ingreso,o.fecha_entrega,o.mano_obra,o.total_repuestos,c.nombre AS cliente_nombre
    FROM ordenes o LEFT JOIN clientes c ON c.id=o.cliente_id WHERE ${w.join(' AND ')} ORDER BY o.fecha_ingreso DESC LIMIT 500`).all(...a);
  let pend = 0, pag = 0;
  rows.forEach(o => {
    const cs = req.db.prepare("SELECT tipo,estado,total,mano_obra_base,pct_mano_obra,comision_mano_obra,repuestos_venta,repuestos_costo_ajustado,margen_repuesto,pct_repuesto,comision_repuesto,pago_garantia FROM comisiones WHERE orden_id=? AND tipo IN ('reparacion','garantia')").get(o.id);
    o.comision = cs || null;
    if (cs) { if (cs.estado === 'pagada') pag += cs.total; else pend += cs.total; }
  });
  // descuentos por garantías que le tocan a este técnico (de reparaciones suyas)
  const desc = req.db.prepare("SELECT c.total,c.estado,o.numero,c.detalle FROM comisiones c LEFT JOIN ordenes o ON o.id=c.orden_id WHERE c.tipo='descuento_garantia' AND c.tecnico_id=? ORDER BY c.id DESC LIMIT 100").all(tid);
  desc.forEach(d => { try { d.detalle = JSON.parse(d.detalle || '{}'); } catch (e) { d.detalle = {}; } if (d.estado === 'pagada') pag += d.total; else pend += d.total; });
  res.json({ tecnico: tnom, items: rows, descuentos: desc, resumen: { pendiente: _r2(pend), pagada: _r2(pag), reparaciones: rows.length } });
});

// ─── ÓRDENES ──────────────────────────────────────────────────────────────────
app.get('/api/ordenes', authMiddleware, (req, res) => {
  const { q } = req.query;
  if (q && q.trim()) {
    const busq = `%${q.trim()}%`;
    res.json(req.db.prepare(`
      SELECT o.*,c.nombre as cliente_nombre,c.telefono as cliente_telefono,(SELECT nombre FROM sucursales WHERE id=o.retiro_sucursal_id) AS retiro_sucursal_nombre,(SELECT nombre FROM sucursales WHERE id=o.sucursal_id) AS sucursal_nombre,(SELECT COUNT(*) FROM envios_equipos e WHERE e.orden_id=o.id AND e.estado='enviado') AS envio_en_camino
      FROM ordenes o LEFT JOIN clientes c ON o.cliente_id=c.id
      WHERE o.numero LIKE ? OR c.nombre LIKE ? OR o.equipo LIKE ? OR o.marca LIKE ?
      ORDER BY o.fecha_ingreso DESC
    `).all(busq,busq,busq,busq));
  } else {
    res.json(req.db.prepare(`SELECT o.*,c.nombre as cliente_nombre,c.telefono as cliente_telefono,(SELECT nombre FROM sucursales WHERE id=o.retiro_sucursal_id) AS retiro_sucursal_nombre,(SELECT nombre FROM sucursales WHERE id=o.sucursal_id) AS sucursal_nombre,(SELECT COUNT(*) FROM envios_equipos e WHERE e.orden_id=o.id AND e.estado='enviado') AS envio_en_camino FROM ordenes o LEFT JOIN clientes c ON o.cliente_id=c.id ORDER BY o.fecha_ingreso DESC`).all());
  }
});
// ─── FASE 3: indicación de cobro/retiro desde el taller + cobro y entrega en Caja ───
// El taller marca en la orden CÓMO pagará el cliente y en QUÉ local retira (y puede enviar el
// equipo ahí). La Caja de ese local ve la indicación, cobra y entrega: cada cobro genera un
// comprobante vinculado a la orden. El descuento por efectivo lo define el admin (config
// descuento_efectivo_pct) y SOLO vale si se cobra con el método indicado; si el cajero cambia
// el método, el descuento no se aplica (el admin puede forzarlo).
const METODOS_COBRO = ['Efectivo', 'Débito', 'Crédito', 'Transferencia', 'Mercado Pago'];

function totalOrdenReal(db, o) {
  const tr = db.prepare('SELECT COALESCE(SUM(subtotal),0) t FROM orden_repuestos WHERE orden_id=?').get(o.id).t || 0;
  return { repuestos: tr, mano_obra: Number(o.mano_obra || 0), total: tr + Number(o.mano_obra || 0) };
}

// Garantía con cobro parcial: el técnico define cuánto paga el cliente (mano de obra + la parte del repuesto que le toca).
// Si el total es 0 la garantía sale sin cargo; si es mayor, la Caja cobra exactamente ese importe.
function cobroGarantia(o) {
  const mo = Math.max(0, Number(o.mano_obra || 0)), rep = Math.max(0, Number(o.garantia_rep_cobrado || 0));
  return { mo, rep, total: Math.round((mo + rep) * 100) / 100 };
}

// Numeración genérica (misma lógica que POST /api/comprobantes)
function numerarComprobante(db, sucursal_id, tipo, letra) {
  const tipoKey = tipo === 'nota_entrega' ? 'proximo_numero_nota_entrega'
    : letra === 'A' ? 'proximo_numero_factura_a' : letra === 'B' ? 'proximo_numero_factura_b' : 'proximo_numero_factura_c';
  const prox = fiscalGet(db, sucursal_id, tipoKey);
  const numComp = parseInt(prox.valor || '1');
  const pv = fiscalGet(db, sucursal_id, 'punto_venta').valor || '1';
  const pvPad = String(pv).padStart(4, '0');
  fiscalSet(db, sucursal_id, tipoKey, numComp + 1, prox.scoped);
  const pre = tipo === 'nota_entrega' ? 'ENT' : 'FC';
  return { numero: `${pre}-${letra || 'X'}${pvPad}-${String(numComp).padStart(8, '0')}`, numComp, pv: parseInt(pv) };
}

app.put('/api/ordenes/:id/cobro-indicacion', authMiddleware, (req, res) => {
  if (!['taller', 'admin'].includes(req.user.rol)) return res.status(403).json({ error: 'Solo el taller o el administrador indican el cobro.' });
  const o = req.db.prepare('SELECT * FROM ordenes WHERE id=?').get(req.params.id);
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  if (o.estado === 'entregado' || o.estado === 'cancelado' || o.cobrado) return res.status(409).json({ error: 'Esta orden ya está entregada/cobrada: no se puede cambiar la indicación.' });
  if (req.user.rol !== 'admin' && o.sucursal_id && String(o.sucursal_id) !== String(req.user.sucursal_id)) {
    return res.status(403).json({ error: 'Este equipo no está en tu sucursal.' });
  }
  const metodo = String(req.body?.metodo || '').trim();
  const cfgPct = Math.max(0, Math.min(100, parseFloat(req.db.prepare("SELECT valor FROM config WHERE clave='descuento_efectivo_pct'").get()?.valor) || 0));
  if (!metodo) { // quitar la indicación
    req.db.prepare('UPDATE ordenes SET pago_metodo=NULL, retiro_sucursal_id=NULL, pago_descuento_pct=0, pago_marcado_por=?, pago_marcado_fecha=datetime(\'now\',\'localtime\') WHERE id=?').run(req.user.nombre || '', o.id);
    audit(req, 'orden.cobro_indicacion', 'orden', o.id, `${o.numero}: indicación de cobro/retiro QUITADA`);
    return res.json({ ok: true });
  }
  const esGarantia = o.tipo_orden === 'garantia';   // las garantías del local no se cobran: solo se indica dónde retira el cliente
  if (!esGarantia && !METODOS_COBRO.includes(metodo)) return res.status(400).json({ error: 'Método de pago inválido.' });
  const montoOrden = totalOrdenReal(req.db, o);
  if (!esGarantia && montoOrden.total <= 0) return res.status(400).json({ error: 'La orden no tiene importe para cobrar: cargá primero la mano de obra o los repuestos.' });
  const retiroId = Number(req.body?.retiro_sucursal_id);
  const suc = retiroId ? req.db.prepare('SELECT id,nombre,es_deposito_central,activa FROM sucursales WHERE id=?').get(retiroId) : null;
  if (!suc) return res.status(400).json({ error: 'Elegí el local donde retira el cliente.' });
  if (suc.es_deposito_central) return res.status(400).json({ error: 'El Depósito Central no entrega equipos: elegí un local.' });
  let pct = (!esGarantia && metodo === 'Efectivo') ? cfgPct : 0;
  if (!esGarantia && req.body?.descuento_pct !== undefined && req.body?.descuento_pct !== null && req.body?.descuento_pct !== '') {
    if (req.user.rol !== 'admin') return res.status(403).json({ error: 'Solo el administrador puede cambiar el descuento.' });
    pct = Math.max(0, Math.min(100, parseFloat(req.body.descuento_pct) || 0));
  }
  if (metodo !== 'Efectivo' && req.user.rol !== 'admin') pct = 0;
  const aqui = o.sucursal_id || req.user.sucursal_id || null;
  let envio = false;
  if (req.body?.enviar && Number(aqui || 0) !== suc.id) {
    const ya = req.db.prepare("SELECT id,destino_sucursal_id FROM envios_equipos WHERE orden_id=? AND estado='enviado'").get(o.id);
    if (ya && Number(ya.destino_sucursal_id) !== suc.id) return res.status(409).json({ error: 'Ya hay un envío de este equipo en camino a otro local: confirmalo primero.' });
    if (!ya) {
      req.db.prepare(`INSERT INTO envios_equipos (orden_id,origen_sucursal_id,destino_sucursal_id,notas,usuario_envio) VALUES (?,?,?,?,?)`)
        .run(o.id, aqui, suc.id, 'Retiro del cliente (indicado desde el taller)', req.user.nombre || req.user.usuario || '');
      envio = true;
    }
  }
  req.db.prepare(`UPDATE ordenes SET pago_metodo=?, retiro_sucursal_id=?, pago_descuento_pct=?, pago_marcado_por=?, pago_marcado_fecha=datetime('now','localtime') WHERE id=?`)
    .run(esGarantia ? 'Garantía' : metodo, suc.id, pct, req.user.nombre || '', o.id);
  audit(req, 'orden.cobro_indicacion', 'orden', o.id, `${o.numero}: ${esGarantia ? 'GARANTÍA sin cobro' : 'pagará con ' + metodo}${pct ? ` (descuento ${pct}%)` : ''} · retira en ${suc.nombre}${envio ? ' · equipo ENVIADO a ese local' : ''}`);
  res.json({ ok: true, descuento_pct: pct, envio_creado: envio, monto: esGarantia ? cobroGarantia(o).total : montoOrden.total, metodo: esGarantia ? 'Garantía' : metodo, retiro_nombre: suc.nombre, ya_en_local: !envio && Number(aqui || 0) === suc.id, estado: o.estado });
});

// Equipos que la Caja del local tiene que cobrar y entregar
app.get('/api/ordenes/para-cobrar', authMiddleware, (req, res) => {
  if (!['caja', 'admin'].includes(req.user.rol)) return res.status(403).json({ error: 'Sin acceso.' });
  const suc = req.user.rol === 'admin' ? (req.query.sucursal_id || null) : (req.user.sucursal_id || -1);
  const q = String(req.query.q || '').trim();
  const filtro = q
    // Búsqueda desde Caja: encuentra la orden SIEMPRE (en cualquier estado/lugar) y explica qué falta para cobrarla
    ? `(o.numero LIKE ? OR c.nombre LIKE ? OR o.equipo LIKE ? OR o.marca LIKE ?)`
    : `o.retiro_sucursal_id IS NOT NULL AND o.pago_metodo IS NOT NULL AND o.estado NOT IN ('entregado','cancelado') AND COALESCE(o.cobrado,0)=0 ${suc ? 'AND o.retiro_sucursal_id=?' : ''}`;
  const args = q ? [`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`] : (suc ? [suc] : []);
  const rows = req.db.prepare(`
    SELECT o.id,o.numero,o.equipo,o.marca,o.modelo,o.estado,o.mano_obra,o.sucursal_id,o.cobrado,o.pago_metodo,o.pago_descuento_pct,o.retiro_sucursal_id,
           o.tipo_orden,o.garantia_rep_cobrado,o.pago_marcado_por,o.pago_marcado_fecha,c.nombre AS cliente_nombre,c.telefono AS cliente_telefono,
           (SELECT nombre FROM sucursales WHERE id=o.retiro_sucursal_id) AS retiro_nombre,
           (SELECT nombre FROM sucursales WHERE id=o.sucursal_id) AS sucursal_nombre,
           (SELECT COUNT(*) FROM envios_equipos e WHERE e.orden_id=o.id AND e.estado='enviado') AS en_camino,
           (SELECT sd.nombre FROM envios_equipos e JOIN sucursales sd ON sd.id=e.destino_sucursal_id WHERE e.orden_id=o.id AND e.estado='enviado' ORDER BY e.id DESC LIMIT 1) AS camino_destino,
           (SELECT e.id FROM envios_equipos e WHERE e.orden_id=o.id AND e.estado='enviado' ORDER BY e.id DESC LIMIT 1) AS envio_id,
           (SELECT e.destino_sucursal_id FROM envios_equipos e WHERE e.orden_id=o.id AND e.estado='enviado' ORDER BY e.id DESC LIMIT 1) AS camino_destino_id
    FROM ordenes o LEFT JOIN clientes c ON c.id=o.cliente_id
    WHERE ${filtro} ORDER BY ${q ? 'o.fecha_ingreso DESC LIMIT 8' : 'o.pago_marcado_fecha ASC LIMIT 30'}`).all(...args);
  const localChk = suc && Number(suc) > 0 ? Number(suc) : null;
  const localNombre = localChk ? nombreLugar(req.db, localChk) : null;
  rows.forEach(o => {
    const t = totalOrdenReal(req.db, o);
    if (o.tipo_orden === 'garantia') { const cg = cobroGarantia(o); o.garantia_cobro = cg.total; o.garantia_cobro_mo = cg.mo; o.garantia_cobro_rep = cg.rep; t.total = cg.total; }
    o.total = t.total;
    const destino = o.retiro_sucursal_id || localChk;
    // ¿Este usuario puede marcar «recibido» ese envío? (admin, o el local de destino)
    o.puede_recibir = !!o.envio_id && (req.user.rol === 'admin' || String(o.camino_destino_id) === String(req.user.sucursal_id));
    // Viene en camino JUSTO a este local: se puede cobrar igual, al cobrar queda recibido solo
    o.recibe_al_cobrar = !!o.en_camino && !!destino && Number(o.camino_destino_id) === Number(destino);
    o.en_el_local = o.recibe_al_cobrar || (!o.en_camino && (!o.sucursal_id || !destino || Number(o.sucursal_id) === Number(destino)));
    o.descuento_monto = o.pago_metodo === 'Efectivo' ? Math.round(t.total * (o.pago_descuento_pct || 0)) / 100 : 0;
    // ¿Se puede cobrar acá y ahora? Si no, qué falta (en orden de lo que hay que hacer)
    const falta = [];
    if (o.estado === 'entregado') falta.push('Ya fue entregada');
    else if (o.estado === 'cancelado') falta.push('Está cancelada');
    else if (o.cobrado) falta.push('Ya está cobrada');
    else if (o.tipo_orden === 'garantia' && !(o.garantia_cobro > 0)) falta.push('Es una GARANTÍA del local: no se cobra al cliente. Se entrega con «Entregar garantía (sin cobro)».');
    else {
      if (t.total <= 0) falta.push('No tiene importe: el técnico tiene que cargar la mano de obra o los repuestos');
      if (o.estado !== 'listo') falta.push(`Está en «${o.estado}»: falta que el técnico la marque «Listo»`);
      if (o.en_camino && !o.recibe_al_cobrar) falta.push(`El equipo está en camino a ${o.camino_destino || 'otro local'}${o.puede_recibir ? ': tocá «📥 Recibí el equipo» para confirmarlo' : ''}`);
      else if (!o.recibe_al_cobrar && localChk && o.sucursal_id && Number(o.sucursal_id) !== localChk) falta.push(`El equipo está en ${o.sucursal_nombre || 'otro lugar'}: falta enviarlo a ${localNombre}`);
      if (localChk && o.retiro_sucursal_id && Number(o.retiro_sucursal_id) !== localChk) falta.push(`Esta orden se retira en ${o.retiro_nombre}`);
    }
    o.motivos = falta;
    o.puede_cobrar = falta.length === 0;
  });
  res.json(rows);
});

app.post('/api/ordenes/:id/cobrar-entregar', authMiddleware, (req, res) => {
  if (!['caja', 'admin'].includes(req.user.rol)) return res.status(403).json({ error: 'Solo Caja o el administrador cobran y entregan.' });
  const o = req.db.prepare('SELECT o.*, c.nombre AS cli_nombre FROM ordenes o LEFT JOIN clientes c ON c.id=o.cliente_id WHERE o.id=?').get(req.params.id);
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  if (o.estado === 'entregado' || o.estado === 'cancelado' || o.cobrado) return res.status(409).json({ error: 'Esta orden ya fue entregada/cobrada.' });
  const admin = req.user.rol === 'admin';
  const esGar = o.tipo_orden === 'garantia';
  if (esGar && !(cobroGarantia(o).total > 0)) return res.status(409).json({ error: 'Es una garantía del local sin cobro: usá «Entregar garantía (sin cobro)».' });
  const localId = admin ? Number(req.body?.sucursal_id || o.retiro_sucursal_id) : Number(req.user.sucursal_id);
  const local = localId ? req.db.prepare('SELECT id,nombre,es_deposito_central FROM sucursales WHERE id=?').get(localId) : null;
  if (!local || local.es_deposito_central) return res.status(400).json({ error: 'Elegí el local desde el que se cobra y entrega.' });
  if (!admin && o.retiro_sucursal_id && Number(o.retiro_sucursal_id) !== local.id) return res.status(403).json({ error: 'Este equipo se retira en otro local.' });
  // Si el taller lo mandó a este local y todavía figura «en camino», cobrarlo ya implica que lo recibieron: se confirma solo.
  const enCamino = req.db.prepare("SELECT * FROM envios_equipos WHERE orden_id=? AND estado='enviado' ORDER BY id DESC LIMIT 1").get(o.id);
  if (enCamino && Number(enCamino.destino_sucursal_id) !== local.id) return res.status(409).json({ error: 'El equipo está en camino a OTRO local (' + nombreLugar(req.db, enCamino.destino_sucursal_id) + '): no se puede cobrar acá.' });
  if (!enCamino && o.sucursal_id && Number(o.sucursal_id) !== local.id) return res.status(409).json({ error: 'El equipo no está en este local.' });
  if (o.estado !== 'listo') return res.status(409).json({ error: 'El equipo todavía no está marcado como «Listo para entregar» por el taller.' });
  const tipo = req.body?.tipo === 'factura' ? 'factura' : 'nota_entrega';
  const letra = tipo === 'factura' ? (['A', 'B', 'C'].includes(req.body?.letra) ? req.body.letra : 'B') : 'X';
  const medio = String(req.body?.medio_pago || '');
  if (!METODOS_COBRO.includes(medio)) return res.status(400).json({ error: 'Indicá el medio de pago.' });
  // PAGOS-1.6.8: pago dividido en varios medios (el descuento por medio de pago no se aplica)
  const pagosDiv = (Array.isArray(req.body?.pagos) ? req.body.pagos : []).filter(p => p && Number(p.monto) > 0)
    .map(p => ({ medio_pago: String(p.medio_pago || ''), monto: Math.round(Number(p.monto) * 100) / 100 }));
  const esDividido = pagosDiv.length > 1;
  if (esDividido && pagosDiv.some(p => !METODOS_COBRO.includes(p.medio_pago))) return res.status(400).json({ error: 'Un medio de pago no es válido para cobrar una orden.' });
  const tReal = totalOrdenReal(req.db, o);
  const cgar = esGar ? cobroGarantia(o) : null;
  const t = esGar ? { repuestos: cgar.rep, mano_obra: cgar.mo, total: cgar.total } : tReal;
  // Ítems extra que el cajero suma al cobro (accesorios, productos del stock del local, ítems libres)
  const extras = [];
  for (const e of (Array.isArray(req.body?.extras) ? req.body.extras : [])) {
    const cant = Number(e?.cantidad), precio = Number(e?.precio_unitario), desc = String(e?.descripcion || '').trim().slice(0, 200);
    if (!desc || !(cant > 0) || !(precio >= 0)) return res.status(400).json({ error: 'Hay un ítem extra incompleto (descripción, cantidad y precio).' });
    const pid = Number(e._producto_id || e.producto_id || 0);
    extras.push({ descripcion: desc, cantidad: cant, precio_unitario: precio, ...(pid ? { _producto_id: pid } : {}) });
  }
  const lineasExtra = {};
  extras.forEach(e => { if (e._producto_id) lineasExtra[e._producto_id] = (lineasExtra[e._producto_id] || 0) + e.cantidad; });
  for (const [pid, c] of Object.entries(lineasExtra)) {
    const disp = stockDisponible(req.db, Number(pid), local.id);
    if (disp < c) {
      const pn = req.db.prepare('SELECT nombre FROM productos WHERE id=?').get(pid)?.nombre || ('#' + pid);
      return res.status(400).json({ error: `Stock insuficiente de "${pn}" en ${local.nombre}. Disponible: ${disp}, pedido: ${c}.` });
    }
  }
  const subExtras = extras.reduce((a, e) => a + e.cantidad * e.precio_unitario, 0);
  if (t.total <= 0 && !extras.length) return res.status(400).json({ error: 'La orden no tiene importe para cobrar (revisá mano de obra/repuestos).' });
  const caja = req.db.prepare(`SELECT id FROM caja_sesiones WHERE estado='abierta' AND (sucursal_id=? OR sucursal_id IS NULL) ORDER BY id DESC LIMIT 1`).get(local.id);
  if (!caja) return res.status(409).json({ error: `La caja de "${local.nombre}" está cerrada: abrila para cobrar.` });

  // Descuento: solo si se cobra con el método que el taller indicó
  let pct = (!esDividido && medio === o.pago_metodo) ? Number(o.pago_descuento_pct || 0) : 0;
  const descuentoPerdido = ((esDividido || medio !== o.pago_metodo) && Number(o.pago_descuento_pct || 0) > 0) ? Number(o.pago_descuento_pct) : 0;
  if (admin && req.body?.forzar_descuento_pct !== undefined && req.body?.forzar_descuento_pct !== '' && req.body?.forzar_descuento_pct !== null) {
    pct = Math.max(0, Math.min(100, parseFloat(req.body.forzar_descuento_pct) || 0));
  }
  const items = [];
  if (esGar) {
    pct = 0;   // en garantía el técnico ya definió el monto final: no hay descuento automático
    if (cgar.mo > 0) items.push({ descripcion: `Mano de obra (garantía) — Orden ${o.numero}`, cantidad: 1, precio_unitario: cgar.mo });
    if (cgar.rep > 0) items.push({ descripcion: `Repuesto — parte a cargo del cliente (garantía) — Orden ${o.numero}`, cantidad: 1, precio_unitario: cgar.rep });
  } else {
    if (t.mano_obra > 0) items.push({ descripcion: `Mano de obra — Orden ${o.numero}`, cantidad: 1, precio_unitario: t.mano_obra });
    req.db.prepare(`SELECT or2.cantidad,or2.precio_unitario,p.nombre FROM orden_repuestos or2 JOIN productos p ON p.id=or2.producto_id WHERE or2.orden_id=?`).all(o.id)
      .forEach(r => items.push({ descripcion: `${r.nombre} (repuesto) — Orden ${o.numero}`, cantidad: r.cantidad, precio_unitario: r.precio_unitario }));
  }
  const subOrden = items.reduce((s, i) => s + i.cantidad * i.precio_unitario, 0);
  items.push(...extras);
  const subtotal = subOrden + subExtras;
  // El descuento por efectivo es sobre el servicio (la orden); los ítems extra van a precio completo.
  const desc = Math.round(subOrden * pct) / 100;
  const base = subtotal - desc;
  const condIva = fiscalGet(req.db, local.id, 'condicion_iva').valor || 'Monotributo';
  const ivaPct = (tipo === 'factura' && letra === 'A' && condIva === 'Responsable Inscripto') ? 21 : 0;
  const ivaMonto = base * ivaPct / 100;
  const total = Math.round((base + ivaMonto) * 100) / 100;
  // PAGOS-1.6.8: los pagos tienen que sumar el total (se ajustan centavos de redondeo en el último)
  const pagosOrden = esDividido ? pagosDiv : [{ medio_pago: medio, monto: total }];
  if (esDividido) {
    const suma = pagosDiv.reduce((s, p) => s + p.monto, 0);
    if (Math.abs(suma - total) > 0.5) return res.status(400).json({ error: `Los pagos (${suma.toFixed(2)}) no coinciden con el total (${total.toFixed(2)}).` });
    pagosOrden[pagosOrden.length - 1].monto = Math.round((pagosOrden[pagosOrden.length - 1].monto + total - suma) * 100) / 100;
  }
  const condPagoOrden = pagosOrden.map(p => `${p.medio_pago} $${Number(p.monto).toFixed(2)}`).join(' + ');
  const num = numerarComprobante(req.db, local.id, tipo, letra);
  const equipo = [o.equipo, o.marca, o.modelo].filter(Boolean).join(' ');
  const notas = `${esGar ? 'GARANTÍA CON COBRO PARCIAL — ' : ''}Cobro y entrega de ${o.numero} (${equipo})${pct ? ` · descuento ${pct}% por ${medio}` : ''}`;
  const r = req.db.prepare(`INSERT INTO comprobantes
    (numero,tipo,letra,punto_venta,numero_comp,orden_id,cliente_id,cliente_nombre,cliente_apellido,cliente_doc_tipo,cliente_doc_numero,cliente_condicion_iva,cliente_direccion,
     items,subtotal,descuento,iva_porcentaje,iva_monto,total,condicion_pago,notas,estado,sucursal_id,generado_por_usuario,generado_por_rol,desde_admin)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'emitido',?,?,?,?)`)
    .run(num.numero, tipo, letra, num.pv, num.numComp, o.id, o.cliente_id || null, String(req.body?.cliente_nombre || o.cli_nombre || '').slice(0, 120), String(req.body?.cliente_apellido || '').slice(0, 120), 'DNI', String(req.body?.cliente_doc_numero || '').slice(0, 30), 'Consumidor Final', '',
      JSON.stringify(items), subtotal, desc, ivaPct, ivaMonto, total, condPagoOrden, notas, local.id, req.user.nombre || null, req.user.rol || null, admin ? 1 : 0);
  const compId = r.lastInsertRowid;
  const vend = String(req.body?.vendedor_codigo || '').trim().slice(0, 40) || null;
  if (vend) req.db.prepare('UPDATE comprobantes SET vendedor_codigo=? WHERE id=?').run(vend, compId);
  if (Object.keys(lineasExtra).length) {
    for (const [pid, c] of Object.entries(lineasExtra)) {
      moverStock(req.db, Number(pid), local.id, -c);
      regMovStock(req.db, Number(pid), 'salida', c, `Venta ${num.numero} (con orden ${o.numero})`, local.id, req.user.nombre);
    }
    req.db.prepare('UPDATE comprobantes SET stock_movido=1, stock_sucursal_id=? WHERE id=?').run(local.id, compId);
  }
  // PAGOS-1.6.8: un pago y un movimiento de caja por cada medio
  for (const p of pagosOrden) {
    req.db.prepare('INSERT INTO comprobante_pagos (comprobante_id,medio_pago,monto) VALUES (?,?,?)').run(compId, p.medio_pago, p.monto);
    req.db.prepare(`INSERT INTO caja_movimientos (caja_sesion_id,tipo,origen,medio_pago,monto,motivo,comprobante_id,usuario,vendedor_codigo,desde_admin) VALUES (?,?,?,?,?,?,?,?,?,?)`)
      .run(caja.id, 'ingreso', 'venta', p.medio_pago, p.monto, `Cobro orden ${o.numero} · ${num.numero}${esDividido ? ' · pago con varios medios' : ''}${admin ? ' · DESDE ADMIN' : ''}`, compId, req.user.nombre || '', vend, admin ? 1 : 0);
  }
  req.db.prepare("UPDATE ordenes SET estado='entregado', cobrado=1, fecha_entrega=datetime('now','localtime'), comprobante_entrega=?, sucursal_id=?, total=?, total_repuestos=? WHERE id=?")
    .run(num.numero, local.id, tReal.total, tReal.repuestos, o.id);
  _registrarComisionSeguro(req.db, o.id);
  if (enCamino) {
    req.db.prepare(`UPDATE envios_equipos SET estado='confirmado', usuario_confirmacion=?, fecha_confirmacion=CURRENT_TIMESTAMP WHERE id=?`).run((req.user?.nombre || req.user?.usuario || '') + ' (al cobrar)', enCamino.id);
    try { audit(req, 'orden.equipo_recibido', 'orden', o.id, `${o.numero}: recibido automáticamente en ${local.nombre} al cobrar y entregar`); } catch (e) {}
  }
  audit(req, 'orden.cobrar_entregar', 'orden', o.id,
    `${o.numero} (${equipo}) cobrada y entregada en ${local.nombre} → ${num.numero} · $${total} con ${condPagoOrden}${extras.length ? ` · +${extras.length} ítem(s) extra` : ''} · ${o.pago_metodo ? `taller indicó ${o.pago_metodo} (${o.pago_marcado_por || '-'})${medio !== o.pago_metodo ? ' · CAMBIÓ el método' : ''}` : 'sin indicación previa del taller'}${pct ? ` · descuento ${pct}% aplicado` : ''}${descuentoPerdido ? ` · descuento ${descuentoPerdido}% NO aplicado (cambió el método)` : ''}${admin ? ' — DESDE ADMIN' : ''}`);
  res.json({ ok: true, comprobante_id: compId, numero: num.numero, total, descuento: desc, descuento_pct: pct, descuento_perdido_pct: descuentoPerdido });
});

app.get('/api/ordenes/:id', authMiddleware, (req, res) => {
  const o = req.db.prepare(`SELECT o.*,c.nombre as cliente_nombre,c.telefono as cliente_telefono,c.email as cliente_email FROM ordenes o LEFT JOIN clientes c ON o.cliente_id=c.id WHERE o.id=?`).get(req.params.id);
  if (!o) return res.status(404).json({ error: 'No encontrado' });
  o.repuestos = req.db.prepare(`SELECT or2.*,p.nombre as producto_nombre,p.codigo as producto_codigo FROM orden_repuestos or2 JOIN productos p ON or2.producto_id=p.id WHERE or2.orden_id=?`).all(req.params.id);
  res.json(o);
});
app.post('/api/ordenes', authMiddleware, (req, res) => {
  const { cliente_id,equipo,marca,modelo,serie,falla_reportada,tecnico,prioridad,notas,mano_obra,checklist } = req.body;
  const tipoOrden = TIPOS_ORDEN.includes(req.body?.tipo_orden) ? req.body.tipo_orden : 'cliente';
  const garantiaRef = tipoOrden === 'garantia' ? String(req.body?.garantia_ref || '').trim().slice(0, 40) : '';
  // Toda orden nace con un cliente que tenga teléfono (para poder avisarle y localizarlo)
  const _cli = cliente_id ? req.db.prepare('SELECT id,telefono FROM clientes WHERE id=?').get(cliente_id) : null;
  if (!_cli) return res.status(400).json({ error: 'La orden necesita un cliente: buscalo o creá uno nuevo (nombre y teléfono).' });
  if (_telNorm(_cli.telefono).length < 6) return res.status(400).json({ error: 'Ese cliente no tiene teléfono. Completalo en Clientes antes de crear la orden.' });
  const fecha = new Date();
  const numero = `OT-${fecha.getFullYear()}${String(fecha.getMonth()+1).padStart(2,'0')}${String(fecha.getDate()).padStart(2,'0')}-${String(Math.floor(Math.random()*9000)+1000)}`;
  const r = req.db.prepare(`INSERT INTO ordenes (numero,cliente_id,equipo,marca,modelo,serie,falla_reportada,tecnico,prioridad,notas,mano_obra,checklist) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(numero,cliente_id||null,equipo||'',marca||'',modelo||'',serie||'',falla_reportada||'',tecnico||'',prioridad||'normal',notas||'',mano_obra||0,checklist||null);
  if (tipoOrden !== 'cliente') req.db.prepare('UPDATE ordenes SET tipo_orden=?, garantia_ref=? WHERE id=?').run(tipoOrden, garantiaRef || null, r.lastInsertRowid);
  // Técnico responsable (lista desplegable). Si quien carga es un técnico y no eligió, queda él mismo.
  let tecId = Number(req.body?.tecnico_id) || (req.user.rol === 'taller' && !String(tecnico || '').trim() ? req.user.usuario_id : 0);
  const tecRow = tecId ? req.db.prepare("SELECT id,nombre FROM usuarios WHERE id=? AND rol='taller'").get(tecId) : null;
  if (tecRow) req.db.prepare('UPDATE ordenes SET tecnico_id=?, tecnico=? WHERE id=?').run(tecRow.id, tecRow.nombre, r.lastInsertRowid);
  if (tipoOrden === 'gremio' && Number(req.body?.gremio_id) && req.db.prepare('SELECT 1 FROM gremios WHERE id=?').get(req.body.gremio_id)) req.db.prepare('UPDATE ordenes SET gremio_id=? WHERE id=?').run(Number(req.body.gremio_id), r.lastInsertRowid);
  if (req.user.rol !== 'admin' && req.user.sucursal_id) req.db.prepare('UPDATE ordenes SET sucursal_id=? WHERE id=?').run(req.user.sucursal_id, r.lastInsertRowid);
  // El total de la orden arranca en la mano de obra cargada (antes quedaba en $0 hasta editarla)
  if (Number(mano_obra) > 0) req.db.prepare('UPDATE ordenes SET total=? WHERE id=?').run(Number(mano_obra), r.lastInsertRowid);
  res.json({ id: r.lastInsertRowid, numero });
});
app.put('/api/ordenes/:id', authMiddleware, (req, res) => {
  let { estado,diagnostico,tecnico,mano_obra,notas,fecha_entrega,prioridad } = req.body;
  const o = req.db.prepare('SELECT * FROM ordenes WHERE id=?').get(req.params.id);
  if (!o) return res.status(404).json({ error: 'No encontrado' });
  // El técnico responsable (de él depende la comisión) solo lo cambia el admin
  if (req.user.rol !== 'admin' && o.tecnico_id) tecnico = o.tecnico;
  const tr = req.db.prepare('SELECT SUM(subtotal) as t FROM orden_repuestos WHERE orden_id=?').get(req.params.id);
  const total_repuestos = tr.t||0;
  const total = total_repuestos + (mano_obra||o.mano_obra||0);
  // Garantía con cobro parcial: el técnico define cuánto del repuesto paga el cliente (a precio de venta, con el descuento que él decida)
  let garRep = null;
  if (req.body && Object.prototype.hasOwnProperty.call(req.body, 'garantia_rep_cobrado') && o.tipo_orden === 'garantia') {
    if (o.estado === 'entregado' || o.estado === 'cancelado' || o.cobrado) return res.status(409).json({ error: 'Esta garantía ya fue entregada: no se puede cambiar el cobro.' });
    garRep = Math.round((Number(req.body.garantia_rep_cobrado) || 0) * 100) / 100;
    if (garRep < 0) return res.status(400).json({ error: 'El importe del repuesto no puede ser negativo.' });
    if (garRep > total_repuestos + 0.001) return res.status(400).json({ error: `El cliente no puede pagar más que el precio de venta de los repuestos usados ($${total_repuestos}).` });
  }
  // NADA SALE SIN COMPROBANTE: marcar "entregado" exige una Factura o Nota de Entrega
  // emitida y vinculada a esta orden (y sin cobro pendiente). Solo el admin puede
  // autorizar una excepción, con motivo, y queda en Auditoría.
  // «Cobrado» NO se edita a mano: lo marca el sistema solo cuando se cobra de verdad (Caja, comprobante con pago).
  let cobradoFinal = o.cobrado || 0;
  let comprobanteEntrega = null;
  if (estado === 'entregado' && o.estado !== 'entregado') {
    const comps = req.db.prepare(`SELECT numero,cobro_pendiente,sin_cobro_motivo FROM comprobantes WHERE orden_id=? AND tipo IN ('factura','nota_entrega') AND estado='emitido' ORDER BY id DESC`).all(o.id);
    const valido = comps.find(c => !c.cobro_pendiente);
    if (valido) { comprobanteEntrega = valido.numero; if (!valido.sin_cobro_motivo) cobradoFinal = 1; }
    else {
      const motivoExc = String(req.body?.motivo_sin_comprobante || '').trim();
      if (req.user.rol === 'admin' && req.body?.autorizo_sin_comprobante && motivoExc) {
        audit(req, 'orden.entregar_sin_comprobante', 'orden', o.id, `${o.numero}: entregada SIN comprobante, autorizado por admin. Motivo: ${motivoExc.slice(0, 200)}`);
      } else {
        audit(req, 'orden.entrega_bloqueada', 'orden', o.id, `${o.numero}: intento de entrega sin comprobante${comps.length ? ' (cobro pendiente)' : ''}`);
        return res.status(409).json({
          error: comps.length
            ? `La Nota de Entrega ${comps[0].numero} tiene el cobro pendiente: cobrala en Caja antes de entregar el equipo.`
            : `No se puede entregar: esta orden no tiene Factura ni Nota de Entrega. Emití el comprobante desde la orden, o usá «Entregar sin reparación».`,
          requiere_comprobante: true,
        });
      }
    }
  }
  req.db.prepare(`UPDATE ordenes SET estado=?,diagnostico=?,tecnico=?,mano_obra=?,notas=?,fecha_entrega=?,prioridad=?,total_repuestos=?,total=?,cobrado=? WHERE id=?`).run(estado,diagnostico,tecnico,mano_obra,notas,fecha_entrega,prioridad,total_repuestos,total,cobradoFinal,req.params.id);
  if (garRep !== null && garRep !== Number(o.garantia_rep_cobrado || 0)) {
    req.db.prepare('UPDATE ordenes SET garantia_rep_cobrado=? WHERE id=?').run(garRep, o.id);
    audit(req, 'orden.garantia_cobro', 'orden', o.id, `${o.numero}: repuesto a cobrar al cliente $${Number(o.garantia_rep_cobrado || 0)} → $${garRep} (mano de obra a cobrar $${Number(mano_obra ?? o.mano_obra ?? 0)})`);
  }
  if (req.user.rol === 'admin' && req.body && Object.prototype.hasOwnProperty.call(req.body, 'tecnico_id')) {
    const nt = req.body.tecnico_id ? req.db.prepare("SELECT id,nombre FROM usuarios WHERE id=? AND rol='taller'").get(req.body.tecnico_id) : null;
    if ((nt?.id || null) !== (o.tecnico_id || null)) {
      if (req.db.prepare("SELECT 1 FROM comisiones WHERE orden_id=? AND estado='pagada'").get(o.id)) return res.status(409).json({ error: 'La comisión de esta orden ya fue liquidada: no se puede cambiar el técnico.' });
      req.db.prepare('UPDATE ordenes SET tecnico_id=?, tecnico=? WHERE id=?').run(nt?.id || null, nt?.nombre || '', o.id);
      audit(req, 'orden.tecnico', 'orden', o.id, `${o.numero}: técnico ${o.tecnico || '—'} → ${nt?.nombre || '—'}`);
    }
  }
  if (req.user.rol === 'admin' && req.body && Object.prototype.hasOwnProperty.call(req.body, 'gremio_id')) {
    const gid = req.body.gremio_id && req.db.prepare('SELECT 1 FROM gremios WHERE id=?').get(req.body.gremio_id) ? Number(req.body.gremio_id) : null;
    if (gid !== (o.gremio_id || null)) { req.db.prepare('UPDATE ordenes SET gremio_id=? WHERE id=?').run(gid, o.id); audit(req, 'orden.gremio', 'orden', o.id, `${o.numero}: gremio asignado ${gid || '—'}`); }
  }
  if (req.user.rol === 'admin' && req.body && Object.prototype.hasOwnProperty.call(req.body, 'tipo_orden') && TIPOS_ORDEN.includes(req.body.tipo_orden) && req.body.tipo_orden !== (o.tipo_orden || 'cliente')) {
    const gref = req.body.tipo_orden === 'garantia' ? String(req.body?.garantia_ref || '').trim().slice(0, 40) : '';
    req.db.prepare('UPDATE ordenes SET tipo_orden=?, garantia_ref=? WHERE id=?').run(req.body.tipo_orden, gref || null, o.id);
    audit(req, 'orden.tipo', 'orden', o.id, `${o.numero}: tipo de orden ${o.tipo_orden || 'cliente'} → ${req.body.tipo_orden}${gref ? ` (orden original ${gref})` : ''}`);
  }
  if (req.body && Object.prototype.hasOwnProperty.call(req.body, 'cliente_id')) {
    const nuevoCli = req.body.cliente_id ? Number(req.body.cliente_id) : null;
    if (nuevoCli !== (o.cliente_id || null) && (!nuevoCli || req.db.prepare('SELECT 1 FROM clientes WHERE id=?').get(nuevoCli))) {
      req.db.prepare('UPDATE ordenes SET cliente_id=? WHERE id=?').run(nuevoCli, o.id);
      audit(req, 'orden.cliente', 'orden', o.id, `${o.numero}: cliente ${nuevoCli ? '#' + nuevoCli : 'quitado'}`);
    }
  }
  if (comprobanteEntrega) {
    req.db.prepare('UPDATE ordenes SET comprobante_entrega=? WHERE id=?').run(comprobanteEntrega, o.id);
    audit(req, 'orden.entregar', 'orden', o.id, `${o.numero} (${o.equipo || ''} ${o.marca || ''}) entregada con comprobante ${comprobanteEntrega}`);
  }
  if (estado === 'entregado' && o.estado !== 'entregado') _registrarComisionSeguro(req.db, o.id);
  res.json({ ok: true });
});
app.post('/api/ordenes/:id/repuestos', authMiddleware, (req, res) => {
  const { producto_id } = req.body;
  const cantidad = Number(req.body.cantidad);
  if (!Number.isInteger(cantidad) || cantidad <= 0) return res.status(400).json({ error: 'La cantidad tiene que ser un número entero mayor a 0' });
  const p = req.db.prepare('SELECT * FROM productos WHERE id=?').get(producto_id);
  if (!p) return res.status(404).json({ error: 'Producto no encontrado' });
  // El repuesto sale del stock del lugar donde trabaja quien lo usa (su sucursal; el admin, el depósito central)
  const lugar = lugarDeStock(req, req.body.sucursal_id);
  const disp = stockDisponible(req.db, p.id, lugar);
  if (disp < cantidad) return res.status(400).json({ error: `Stock insuficiente en ${nombreLugar(req.db, lugar)}. Disponible: ${disp}` });
  const subtotal = p.precio_venta * cantidad;
  req.db.prepare(`INSERT INTO orden_repuestos (orden_id,producto_id,cantidad,precio_unitario,subtotal,stock_sucursal_id) VALUES (?,?,?,?,?,?)`).run(req.params.id,producto_id,cantidad,p.precio_venta,subtotal,lugar);
  moverStock(req.db, p.id, lugar, -cantidad);
  regMovStock(req.db, p.id, 'salida', cantidad, 'Usado en orden', lugar, req.user.nombre, req.params.id);
  audit(req, 'orden.repuesto_agregar', 'orden', req.params.id, `${p.codigo} x${cantidad} desde ${nombreLugar(req.db, lugar)}`);
  const tr = req.db.prepare('SELECT SUM(subtotal) as t FROM orden_repuestos WHERE orden_id=?').get(req.params.id);
  const oa = req.db.prepare('SELECT mano_obra FROM ordenes WHERE id=?').get(req.params.id);
  req.db.prepare('UPDATE ordenes SET total_repuestos=?,total=? WHERE id=?').run(tr.t||0,(tr.t||0)+(oa.mano_obra||0),req.params.id);
  res.json({ ok: true });
});
app.delete('/api/ordenes/:oid/repuestos/:rid', authMiddleware, (req, res) => {
  const rep = req.db.prepare('SELECT * FROM orden_repuestos WHERE id=?').get(req.params.rid);
  if (!rep) return res.status(404).json({ error: 'No encontrado' });
  // Vuelve al mismo lugar de donde salió (los repuestos viejos, anteriores a esto, salieron del depósito central)
  const lugar = rep.stock_sucursal_id || null;
  const prod = req.db.prepare('SELECT codigo,nombre FROM productos WHERE id=?').get(rep.producto_id);
  const ord = req.db.prepare('SELECT numero,cobrado,estado,tipo_orden FROM ordenes WHERE id=?').get(rep.orden_id);
  const yaCobrada = !!(ord && (ord.cobrado || ord.estado === 'entregado'));
  const com = yaCobrada ? req.db.prepare("SELECT COUNT(*) c, MAX(estado) e FROM comisiones WHERE orden_id=?").get(rep.orden_id) : null;
  moverStock(req.db, rep.producto_id, lugar, rep.cantidad);
  regMovStock(req.db, rep.producto_id, 'entrada', rep.cantidad, yaCobrada ? 'Devuelto (orden ya cobrada)' : 'Devuelto por anulación', lugar, req.user.nombre, rep.orden_id);
  const que = `${prod ? prod.nombre + ' (' + prod.codigo + ')' : 'producto ' + rep.producto_id} x${rep.cantidad} · $${_r2(rep.subtotal)} vuelve a ${nombreLugar(req.db, lugar)}`;
  if (yaCobrada) audit(req, 'orden.repuesto_quitar_post_cobro', 'orden', rep.orden_id, `⚠️ MODIFICACIÓN DESPUÉS DE COBRAR · orden ${ord.numero}${ord.tipo_orden === 'garantia' ? ' (garantía)' : ''}: se quitó ${que}.${com && com.c ? ' La comisión ya generada (' + (com.e === 'pagada' ? 'pagada' : 'por pagar') + ') NO se recalculó sola.' : ''}`);
  else audit(req, 'orden.repuesto_quitar', 'orden', rep.orden_id, que);
  req.db.prepare('DELETE FROM orden_repuestos WHERE id=?').run(req.params.rid);
  const tr = req.db.prepare('SELECT SUM(subtotal) as t FROM orden_repuestos WHERE orden_id=?').get(req.params.oid);
  const oa = req.db.prepare('SELECT mano_obra FROM ordenes WHERE id=?').get(req.params.oid);
  req.db.prepare('UPDATE ordenes SET total_repuestos=?,total=? WHERE id=?').run(tr.t||0,(tr.t||0)+(oa.mano_obra||0),req.params.oid);
  res.json({ ok: true, post_cobro: yaCobrada });
});

// ─── NOTIFICACIONES ───────────────────────────────────────────────────────────
app.post('/api/ordenes/:id/notificacion', authMiddleware, (req, res) => {
  const { medio, mensaje } = req.body;
  req.db.prepare(`INSERT INTO notificaciones (orden_id,medio,mensaje) VALUES (?,?,?)`).run(req.params.id,medio,mensaje);
  res.json({ ok: true });
});
app.get('/api/ordenes/:id/notificaciones', authMiddleware, (req, res) => {
  res.json(req.db.prepare(`SELECT * FROM notificaciones WHERE orden_id=? ORDER BY fecha DESC`).all(req.params.id));
});

// ─── CHAT INTERNO ─────────────────────────────────────────────────────────────
app.get('/api/chat', authMiddleware, (req, res) => {
  res.json(req.db.prepare("SELECT * FROM chat ORDER BY fecha DESC LIMIT 100").all().reverse());
});
app.post('/api/chat', authMiddleware, (req, res) => {
  const { mensaje } = req.body;
  if (!mensaje || !mensaje.trim()) return res.status(400).json({ error: 'Mensaje vacío' });
  const r = req.db.prepare("INSERT INTO chat (usuario_id,usuario_nombre,rol,mensaje) VALUES (?,?,?,?)").run(req.user.usuario_id,req.user.nombre,req.user.rol,mensaje.trim());
  res.json({ id: r.lastInsertRowid });
});

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
app.get('/api/dashboard', authMiddleware, (req, res) => {
  const _pl = planes.queIncluye(req, MODO_DISTRIBUIDOR);
  if (_pl.activado && !_pl.modulos.taller) {
    // Plan sin servicio técnico: el tablero habla solo de ventas, caja y stock.
    const suc = req.user.rol === 'admin' ? null : (req.user.sucursal_id || null);
    const f = suc ? ' AND sucursal_id = ?' : '', a = suc ? [suc] : [];
    const base = "estado != 'anulado' AND tipo != 'presupuesto'";
    const sum = (cond) => req.db.prepare(`SELECT COUNT(*) c, COALESCE(SUM(total),0) t FROM comprobantes WHERE ${base} AND ${cond}${f}`).get(...a);
    const hoy = sum("date(fecha,'localtime') = date('now','localtime')");
    const mes = sum("strftime('%Y-%m', fecha,'localtime') = strftime('%Y-%m','now','localtime')");
    return res.json({
      tienda: true,
      ventas_hoy: { cantidad: hoy.c, total: hoy.t }, ventas_mes: { cantidad: mes.c, total: mes.t },
      ticket_promedio_mes: mes.c ? mes.t / mes.c : 0,
      ...(req.user.rol === 'admin' ? { fondo_garantia: tienda.resumenFondo(req.db, { conTaller: false }), comisiones_mes: tienda.calcularComisiones(req.db, { desde: new Date().toISOString().slice(0,7)+'-01' }).totales.comision } : {}),
      productos_bajo_stock: req.db.prepare(`SELECT COUNT(*) as c FROM productos WHERE stock<=stock_minimo`).get().c,
      total_productos: req.db.prepare(`SELECT COUNT(*) as c FROM productos`).get().c,
      productos_criticos: req.db.prepare(`SELECT * FROM productos WHERE stock<=stock_minimo ORDER BY stock ASC LIMIT 5`).all(),
      ultimas_ventas: req.db.prepare(`SELECT numero, tipo, COALESCE(cliente_nombre,'') AS cliente, total, fecha FROM comprobantes WHERE ${base}${f} ORDER BY fecha DESC LIMIT 5`).all(...a),
    });
  }
  res.json({
    ordenes_activas: req.db.prepare(`SELECT COUNT(*) as c FROM ordenes WHERE estado NOT IN ('entregado','cancelado')`).get().c,
    ordenes_hoy: req.db.prepare(`SELECT COUNT(*) as c FROM ordenes WHERE date(fecha_ingreso)=date('now')`).get().c,
    productos_bajo_stock: req.db.prepare(`SELECT COUNT(*) as c FROM productos WHERE stock<=stock_minimo`).get().c,
    total_productos: req.db.prepare(`SELECT COUNT(*) as c FROM productos`).get().c,
    ordenes_por_estado: req.db.prepare(`SELECT estado,COUNT(*) as cantidad FROM ordenes GROUP BY estado`).all(),
    productos_criticos: req.db.prepare(`SELECT * FROM productos WHERE stock<=stock_minimo ORDER BY stock ASC LIMIT 5`).all(),
    ultimas_ordenes: req.db.prepare(`SELECT o.numero,o.equipo,o.estado,o.fecha_ingreso,c.nombre as cliente FROM ordenes o LEFT JOIN clientes c ON o.cliente_id=c.id ORDER BY o.fecha_ingreso DESC LIMIT 5`).all(),
    cobros_pendientes: req.db.prepare(`SELECT COUNT(*) as c FROM ordenes WHERE estado='listo' AND cobrado=0`).get().c,
    garantias_activas: req.db.prepare(`SELECT COUNT(*) as c FROM ordenes WHERE tipo_orden='garantia' AND estado NOT IN ('entregado','cancelado')`).get().c,
    estados_especiales: req.db.prepare(`SELECT clave,nombre,color,cuenta_como FROM estados_orden`).all()
  });
});

app.get('/api/movimientos', authMiddleware, (req, res) => {
  res.json(req.db.prepare(`SELECT m.*,p.nombre as producto_nombre,p.codigo as producto_codigo FROM movimientos_stock m JOIN productos p ON m.producto_id=p.id ORDER BY m.fecha DESC LIMIT 100`).all());
});

// ─── CAJA — apertura/cierre de turno + ingresos/egresos manuales ───────────────

// Caja abierta en este momento (o null si no hay ninguna)
// La caja de dinero y el cobro solo están disponibles si el admin los habilitó para la sucursal
function exigirCobroHabilitado(req, res, next) {
  if (req.user.rol === 'taller' && !permisosSucursal(req).factura_habilitada) {
    return res.status(403).json({ error: 'El administrador no habilitó el cobro/caja en esta sucursal.' });
  }
  next();
}
app.get('/api/caja/actual', authMiddleware, (req, res) => {
  try {
    const { sucursal_id } = req.query;
    const sesion = req.db.prepare(`SELECT * FROM caja_sesiones WHERE estado='abierta' ${sucursal_id ? 'AND (sucursal_id=? OR sucursal_id IS NULL)' : ''} ORDER BY id DESC LIMIT 1`)
      .get(...(sucursal_id ? [sucursal_id] : []));
    if (!sesion) return res.json({ abierta: false });
    asegurarColumnasArca(req.db);   // ARCA-1.6.5: cada movimiento trae si su comprobante tiene CAE
    const movs = req.db.prepare('SELECT m.*, c.tipo AS comp_tipo, c.cae AS comp_cae, c.arca_letra AS comp_arca_letra, c.arca_pv AS comp_arca_pv, c.arca_nro AS comp_arca_nro FROM caja_movimientos m LEFT JOIN comprobantes c ON c.id=m.comprobante_id WHERE m.caja_sesion_id=? ORDER BY m.fecha ASC').all(sesion.id);
    // Todos los medios de pago habilitados arrancan en $0 — así Mercado Pago,
    // Débito, etc. siempre aparecen en pantalla para conciliar, en vez de
    // aparecer recién cuando hubo un movimiento con ese medio.
    const porMedio = {};
    MEDIOS_PAGO_VALIDOS.forEach(m => porMedio[m] = 0);
    porMedio['Efectivo'] = Number(sesion.monto_apertura || 0);
    let saldoEsperado = Number(sesion.monto_apertura || 0);
    movs.forEach(m => {
      const signo = m.tipo === 'ingreso' ? 1 : -1;
      saldoEsperado += signo * m.monto;
      porMedio[m.medio_pago] = (porMedio[m.medio_pago] || 0) + signo * m.monto;
    });
    // Resumen de ventas del turno por tipo de comprobante — directo de
    // comprobantes (no de caja_movimientos) para que sume Factura, Nota de
    // Entrega, Nota de Débito/Crédito, etc. todo junto independientemente del
    // medio de pago, y así cierre y reportes siempre cuenten lo mismo.
    const ventasPorTipo = req.db.prepare(`
      SELECT tipo, COUNT(*) as cantidad, SUM(total) as total
      FROM comprobantes
      WHERE tipo != 'presupuesto' AND estado != 'anulado' AND fecha >= ?
      GROUP BY tipo
    `).all(sesion.fecha_apertura);
    // Las Notas de Crédito son devoluciones: restan del total de ventas
    const totalVentas = ventasPorTipo.reduce((s,v) => s + (v.tipo === 'nota_credito' ? -(v.total||0) : (v.total||0)), 0);
    // Ventas del turno por vendedor: código cargado al cobrar o, si no hay, el usuario que emitió el comprobante
    const ventasPorVendedor = req.db.prepare(`
      SELECT COALESCE(NULLIF(vendedor_codigo,''), NULLIF(generado_por_usuario,''), 'Sin vendedor') as vendedor,
             COUNT(*) as cantidad,
             SUM(CASE WHEN tipo='nota_credito' THEN -total ELSE total END) as total
      FROM comprobantes
      WHERE tipo != 'presupuesto' AND estado != 'anulado' AND fecha >= ?
      GROUP BY vendedor ORDER BY total DESC
    `).all(sesion.fecha_apertura);
    res.json({ abierta: true, sesion, movimientos: movs, saldoEsperado, porMedio, ventasPorTipo, totalVentas, ventasPorVendedor });
  } catch (e) {
    // Antes, un error acá (p.ej. falta la columna sucursal_id en una base
    // vieja que no corrió la migración de sucursales) tiraba una página HTML
    // de error. El frontend esperaba JSON, el .json() fallaba, y la pantalla
    // de Caja se quedaba completamente en blanco sin avisar nada.
    console.error('Error en /api/caja/actual:', e);
    res.status(500).json({ error: 'No se pudo cargar el estado de caja: ' + e.message });
  }
});

// Abrir caja (una por vez por sucursal). El monto de apertura NO lo elige el
// cajero: es el "fondo de caja fijo" que definió el admin para esa sucursal.
// El cajero solo informa cuánto contó realmente en el cajón al recibirlo, y
// el sistema registra si coincide o no con el fondo fijo (sin bloquear la
// apertura — el admin decide qué hacer con la diferencia después).
app.post('/api/caja/abrir', authMiddleware, exigirCobroHabilitado, (req, res, next) => { res.on('finish', () => { if (res.statusCode < 400) audit(req, 'caja.abrir', 'caja', null, `Apertura de caja (sucursal ${req.body?.sucursal_id || req.user.sucursal_id || '-'})`); }); next(); }, (req, res) => {
  const { monto_recibido, monto_apertura, sucursal_id } = req.body;
  // El Depósito Central no vende ni cobra — es solo stock. No se puede abrir
  // una caja ahí aunque alguien lo intente a propósito o por error.
  let fondoFijo = 0;
  if (sucursal_id) {
    const suc = req.db.prepare('SELECT es_deposito_central, fondo_caja_fijo FROM sucursales WHERE id=?').get(sucursal_id);
    if (suc?.es_deposito_central) return res.status(400).json({ error: 'El Depósito Central no vende — no se puede abrir caja ahí.' });
    fondoFijo = Number(suc?.fondo_caja_fijo || 0);
  }
  const yaAbierta = req.db.prepare(`SELECT id FROM caja_sesiones WHERE estado='abierta' ${sucursal_id ? 'AND (sucursal_id=? OR sucursal_id IS NULL)' : ''} LIMIT 1`)
    .get(...(sucursal_id ? [sucursal_id] : []));
  if (yaAbierta) return res.status(400).json({ error: 'Ya hay una caja abierta. Cerrala antes de abrir otra.' });
  // Compatibilidad: si todavía no hay fondo fijo configurado para la sucursal
  // (fondoFijo=0 y nunca se configuró), se admite el viejo monto_apertura libre.
  const recibido = Number(monto_recibido ?? monto_apertura ?? 0);
  const diferenciaApertura = recibido - fondoFijo;
  const r = req.db.prepare(`INSERT INTO caja_sesiones (sucursal_id,usuario_apertura,monto_apertura,monto_recibido_apertura,diferencia_apertura,estado) VALUES (?,?,?,?,?,'abierta')`)
    .run(sucursal_id || null, req.user?.nombre || '', fondoFijo, recibido, diferenciaApertura);
  res.json({ id: r.lastInsertRowid, fondoFijo, recibido, diferenciaApertura });
});

// Registrar ingreso/egreso manual (lo que entra o sale de caja sin ser una venta)
app.post('/api/caja/movimiento', authMiddleware, exigirCobroHabilitado, (req, res, next) => { res.on('finish', () => { if (res.statusCode < 400) audit(req, 'caja.movimiento', 'caja', null, `${req.body?.tipo} $${req.body?.monto} (${req.body?.medio_pago}) — ${String(req.body?.motivo||'').slice(0,120)}`); }); next(); }, (req, res) => {
  const { tipo, medio_pago, monto, motivo, sucursal_id, vendedor_codigo } = req.body;
  if (!['ingreso','egreso'].includes(tipo)) return res.status(400).json({ error: 'Tipo inválido' });
  if (!monto || monto <= 0) return res.status(400).json({ error: 'El monto tiene que ser mayor a 0' });
  // Antes esto siempre tomaba "la última caja abierta" sin filtrar por
  // sucursal — con varias sucursales abriendo caja al mismo tiempo, un
  // movimiento cargado en una sucursal podía terminar en la caja de otra.
  const sesion = req.db.prepare(`SELECT * FROM caja_sesiones WHERE estado='abierta' ${sucursal_id ? 'AND (sucursal_id=? OR sucursal_id IS NULL)' : ''} ORDER BY id DESC LIMIT 1`)
    .get(...(sucursal_id ? [sucursal_id] : []));
  if (!sesion) return res.status(400).json({ error: 'No hay una caja abierta. Abrila primero.' });
  const r = req.db.prepare(`INSERT INTO caja_movimientos (caja_sesion_id,tipo,origen,medio_pago,monto,motivo,usuario,vendedor_codigo) VALUES (?,?,?,?,?,?,?,?)`)
    .run(sesion.id, tipo, 'manual', medio_pago || 'Efectivo', Number(monto), motivo || '', req.user?.nombre || '', vendedor_codigo || null);
  res.json({ id: r.lastInsertRowid });
});

// Cerrar caja: el "monto contado" es SOLO el efectivo físico de la caja — los
// medios digitales (tarjeta, transferencia, Mercado Pago, cuenta corriente) no
// se cuentan a mano, así que se concilian aparte y no entran en la diferencia.
// Igual queda guardado el esperado total (todos los medios) como referencia.
app.post('/api/caja/cerrar', authMiddleware, exigirCobroHabilitado, (req, res, next) => { res.on('finish', () => { if (res.statusCode < 400) audit(req, 'caja.cerrar', 'caja', null, `Cierre de caja`); }); next(); }, (req, res) => {
  const { contado, monto_cierre_real, notas_cierre, sucursal_id } = req.body;
  const sesion = req.db.prepare(`SELECT * FROM caja_sesiones WHERE estado='abierta' ${sucursal_id ? 'AND (sucursal_id=? OR sucursal_id IS NULL)' : ''} ORDER BY id DESC LIMIT 1`)
    .get(...(sucursal_id ? [sucursal_id] : []));
  if (!sesion) return res.status(400).json({ error: 'No hay una caja abierta' });
  const movs = req.db.prepare('SELECT tipo,monto,medio_pago FROM caja_movimientos WHERE caja_sesion_id=?').all(sesion.id);
  // Siempre se listan TODOS los medios de pago habilitados del sistema, no
  // solo los que tuvieron movimiento este turno — así Mercado Pago, Débito,
  // etc. siempre aparecen para conciliar (en $0 si no se usaron), en vez de
  // desaparecer de la pantalla de cierre cuando no hubo venta con ese medio.
  const esperadoPorMedio = {};
  MEDIOS_PAGO_VALIDOS.forEach(m => esperadoPorMedio[m] = 0);
  esperadoPorMedio['Efectivo'] = Number(sesion.monto_apertura || 0);
  movs.forEach(m => {
    const signo = m.tipo === 'ingreso' ? 1 : -1;
    esperadoPorMedio[m.medio_pago] = (esperadoPorMedio[m.medio_pago] || 0) + signo * m.monto;
  });

  // Nuevo formato: `contado` = { medio: montoContado, ... } para cada medio de
  // pago que tuvo movimiento este turno. Mantiene compatibilidad con el campo
  // viejo `monto_cierre_real` (solo efectivo) por si llega de una versión vieja.
  const contadoPorMedio = contado && typeof contado === 'object' ? contado : { 'Efectivo': Number(monto_cierre_real || 0) };

  const detalle = Object.keys(esperadoPorMedio).map(medio => {
    const esperado = esperadoPorMedio[medio];
    const contadoMedio = Number(contadoPorMedio[medio] ?? esperado);
    return { medio, esperado, contado: contadoMedio, diferencia: contadoMedio - esperado };
  });
  const esperadoTotal = detalle.reduce((s,d) => s + d.esperado, 0);
  const real = detalle.reduce((s,d) => s + d.contado, 0);
  const diferencia = detalle.reduce((s,d) => s + d.diferencia, 0);

  req.db.prepare(`UPDATE caja_sesiones SET estado='cerrada', usuario_cierre=?, monto_cierre_esperado=?, monto_cierre_real=?, diferencia=?, notas_cierre=?, cierre_detalle_json=?, fecha_cierre=CURRENT_TIMESTAMP WHERE id=?`)
    .run(req.user?.nombre || '', esperadoTotal, real, diferencia, notas_cierre || '', JSON.stringify(detalle), sesion.id);
  res.json({ ok: true, id: sesion.id, esperado: esperadoTotal, esperadoTotal, real, diferencia, detalle });
});

// Historial de cajas cerradas
app.get('/api/caja/historial', authMiddleware, (req, res) => {
  const { sucursal_id } = req.query;
  res.json(req.db.prepare(`SELECT * FROM caja_sesiones WHERE estado='cerrada' ${sucursal_id ? 'AND (sucursal_id=? OR sucursal_id IS NULL)' : ''} ORDER BY fecha_cierre DESC LIMIT 60`)
    .all(...(sucursal_id ? [sucursal_id] : [])));
});

// Planilla de cierre de caja en Excel — para que el cajero de turno la
// imprima, cuente el efectivo a mano y la firme certificando el cierre.
const TIPO_LABELS_CIERRE = { factura:'Factura', nota_entrega:'Nota de Entrega', nota_credito:'Nota de Crédito', nota_debito:'Nota de Débito' };
app.get('/api/caja/:id/excel', authMiddleware, async (req, res) => {
  try {
    const sesion = req.db.prepare('SELECT * FROM caja_sesiones WHERE id=?').get(req.params.id);
    if (!sesion) return res.status(404).json({ error: 'Turno de caja no encontrado' });
    // Un usuario de Caja solo baja la planilla de los turnos de su propia sucursal.
    if (req.user.rol !== 'admin' && sesion.sucursal_id && Number(req.user.sucursal_id || 0) !== Number(sesion.sucursal_id)) return res.status(403).json({ error: 'Ese turno es de otra sucursal.' });

    // Si ya se cerró con el detalle por medio de pago (contado/esperado/diferencia
    // real que puso el cajero), usamos eso tal cual. Si no (cierre viejo, o
    // turno todavía abierto), lo armamos en vivo solo con lo esperado.
    let detalle;
    if (sesion.cierre_detalle_json) {
      try { detalle = JSON.parse(sesion.cierre_detalle_json); } catch(e) { detalle = null; }
    }
    if (!detalle) {
      const movs = req.db.prepare('SELECT tipo,monto,medio_pago FROM caja_movimientos WHERE caja_sesion_id=?').all(sesion.id);
      const porMedioMap = { 'Efectivo': Number(sesion.monto_apertura || 0) };
      movs.forEach(m => {
        const signo = m.tipo === 'ingreso' ? 1 : -1;
        porMedioMap[m.medio_pago] = (porMedioMap[m.medio_pago] || 0) + signo * m.monto;
      });
      detalle = Object.entries(porMedioMap).map(([medio, esperado]) => ({ medio, esperado, contado: null, diferencia: null }));
    }
    const porMedio = detalle.map(d => ({ medio: d.medio, esperado: d.esperado }));

    const hasta = sesion.fecha_cierre || new Date().toISOString();
    const ventasPorTipoRaw = req.db.prepare(`
      SELECT tipo, COUNT(*) as cantidad, SUM(total) as total
      FROM comprobantes
      WHERE tipo != 'presupuesto' AND estado NOT IN ('anulado','borrador') AND fecha >= ? AND fecha <= ?
        ${sesion.sucursal_id ? 'AND sucursal_id = ?' : ''}
      GROUP BY tipo
    `).all(sesion.fecha_apertura, hasta, ...(sesion.sucursal_id ? [sesion.sucursal_id] : []));
    const ventasPorTipo = ventasPorTipoRaw.map(v => ({ ...v, label: TIPO_LABELS_CIERRE[v.tipo] || v.tipo }));

    const fecha = (sesion.fecha_cierre || sesion.fecha_apertura || '').slice(0,10) || new Date().toISOString().split('T')[0];
    const sucNombre = sesion.sucursal_id ? (req.db.prepare('SELECT nombre FROM sucursales WHERE id=?').get(sesion.sucursal_id) || {}).nombre : '';
    const buffer = await require('./informe-excel').construirCierreCaja({
      db: req.db, sesion, sucursalNombre: sucNombre || '', detalle, ventasPorTipo,
      generadoPor: req.user.usuario, uploadsDir: UPLOADS_DIR,
    });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="Cierre_Caja_${fecha}_turno${sesion.id}.xlsx"`);
    res.send(Buffer.from(buffer));
  } catch (e) {
    console.error('Error generando planilla de cierre:', e);
    res.status(500).json({ error: 'No se pudo generar la planilla: ' + e.message });
  }
});

// ─── MERCADERÍA — recepción ordenada de stock por proveedor/remito ─────────────

app.get('/api/mercaderia/ingresos', authMiddleware, (req, res) => {
  res.json(req.db.prepare('SELECT * FROM mercaderia_ingresos ORDER BY fecha DESC LIMIT 100').all());
});

app.get('/api/mercaderia/ingresos/:id', authMiddleware, (req, res) => {
  const ingreso = req.db.prepare('SELECT * FROM mercaderia_ingresos WHERE id=?').get(req.params.id);
  if (!ingreso) return res.status(404).json({ error: 'No encontrado' });
  ingreso.items = req.db.prepare(`SELECT mi.*,p.nombre as producto_nombre,p.codigo as producto_codigo
    FROM mercaderia_ingreso_items mi JOIN productos p ON mi.producto_id=p.id WHERE mi.ingreso_id=?`).all(req.params.id);
  res.json(ingreso);
});

// Carga por lote: un remito, varios productos, cada uno suma stock y puede
// actualizar su costo — así el ingreso de mercadería queda en un solo paso
// en vez de ir ajustando stock producto por producto.
app.post('/api/mercaderia/ingresos', authMiddleware, requierePermiso('ingreso_mercaderia'), (req, res) => {
  const { proveedor, numero_remito, notas, sucursal_id, items } = req.body;
  const itemsArr = Array.isArray(items) ? items.filter(i => i && i.producto_id && i.cantidad > 0) : [];
  if (!itemsArr.length) return res.status(400).json({ error: 'Agregá al menos un producto con cantidad mayor a 0' });

  const total = itemsArr.reduce((s,i) => s + (Number(i.cantidad) * Number(i.costo_unitario||0)), 0);
  const r = req.db.prepare(`INSERT INTO mercaderia_ingresos (proveedor,numero_remito,notas,usuario,sucursal_id,total) VALUES (?,?,?,?,?,?)`)
    .run(proveedor || '', numero_remito || '', notas || '', req.user?.nombre || '', sucursal_id || null, total);
  const ingresoId = r.lastInsertRowid;

  const insItem = req.db.prepare('INSERT INTO mercaderia_ingreso_items (ingreso_id,producto_id,cantidad,costo_unitario) VALUES (?,?,?,?)');
  const insMov = req.db.prepare(`INSERT INTO movimientos_stock (producto_id,tipo,cantidad,motivo,sucursal_id,usuario) VALUES (?,'entrada',?,?,?,?)`);
  const _sucI = sucursalOperativa(req);
  const updStock = req.db.prepare('UPDATE productos SET stock = stock + ? WHERE id=?');
  const updCosto = req.db.prepare('UPDATE productos SET costo=?, proveedor=? WHERE id=?');

  itemsArr.forEach(i => {
    insItem.run(ingresoId, i.producto_id, Number(i.cantidad), Number(i.costo_unitario||0));
    insMov.run(i.producto_id, Number(i.cantidad), `[${nombreLugar(req.db,_sucI?_sucI.id:null)}] Ingreso de mercadería${numero_remito ? ' — remito '+numero_remito : ''}`, _sucI?_sucI.id:null, req.user?.nombre||'');
    if (_sucI) ajustarStock(req.db, i.producto_id, _sucI.id, Number(i.cantidad)); else updStock.run(Number(i.cantidad), i.producto_id);
    if (i.costo_unitario > 0) updCosto.run(Number(i.costo_unitario), proveedor || '', i.producto_id);
  });

  audit(req, 'mercaderia.ingreso', 'ingreso', ingresoId, `${itemsArr.length} ítems, total $${total}, proveedor ${proveedor||'-'}, remito ${numero_remito||'-'}, en ${nombreLugar(req.db,_sucI?_sucI.id:null)}`);
  res.json({ id: ingresoId, total });
});

// ─── CARGA MASIVA POR EXCEL ─────────────────────────────────────────────────────
// El programa genera la planilla (nunca al revés) para que las columnas
// siempre coincidan con lo que el sistema espera. Tiene dos hojas: una con el
// catálogo actual para reponer stock (filtrable por categoría/subcategoría
// directamente en Excel con el autofiltro), y otra en blanco para dar de alta
// productos que todavía no existen.
app.get('/api/mercaderia/plantilla', authMiddleware, async (req, res) => {
  const productos = req.db.prepare(`
    SELECT p.codigo, p.nombre, p.stock, c.nombre as categoria, s.nombre as subcategoria
    FROM productos p
    LEFT JOIN categorias c ON c.id = p.categoria_id
    LEFT JOIN subcategorias s ON s.id = p.subcategoria_id
    WHERE p.visible = 1
    ORDER BY c.nombre, s.nombre, p.nombre
  `).all();
  const categorias = req.db.prepare(`SELECT nombre FROM categorias WHERE tipo='producto' ORDER BY nombre`).all().map(c => c.nombre);

  const wb = new ExcelJS.Workbook();
  wb.creator = 'SysTech';

  // ── Hoja 1: Reponer stock existente ──────────────────────────────────────
  const ws1 = wb.addWorksheet('Reponer Stock');
  ws1.columns = [
    { header: 'Código (NO EDITAR)', key: 'codigo', width: 16 },
    { header: 'Nombre', key: 'nombre', width: 32 },
    { header: 'Categoría', key: 'categoria', width: 18 },
    { header: 'Subcategoría', key: 'subcategoria', width: 18 },
    { header: 'Stock Depósito Central', key: 'stock', width: 20 },
    { header: 'Cantidad a Ingresar', key: 'cantidad', width: 18 },
    { header: 'Costo Unitario ($)', key: 'costo', width: 16 },
  ];
  ws1.getRow(1).font = { bold: true };
  ws1.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE4E0D5' } };
  productos.forEach(p => {
    ws1.addRow({ codigo: p.codigo, nombre: p.nombre, categoria: p.categoria||'', subcategoria: p.subcategoria||'', stock: p.stock, cantidad: null, costo: null });
  });
  ws1.autoFilter = { from: 'A1', to: 'G1' };
  ws1.views = [{ state: 'frozen', ySplit: 1 }];
  // Proteger columnas que no deben tocarse (código/nombre/categoría/stock) —
  // protección simple: el usuario puede igual editarlas, pero quedan marcadas
  // en gris para dejar claro que no hace falta tocarlas.
  for (let r = 2; r <= productos.length + 1; r++) {
    ['A','B','C','D','E'].forEach(col => { ws1.getCell(`${col}${r}`).font = { color: { argb: 'FF888888' } }; });
  }

  // ── Hoja 2: Productos nuevos (altas) ─────────────────────────────────────
  const ws2 = wb.addWorksheet('Productos Nuevos');
  ws2.columns = [
    { header: 'Código (nuevo)', key: 'codigo', width: 16 },
    { header: 'Nombre', key: 'nombre', width: 32 },
    { header: 'Categoría', key: 'categoria', width: 18 },
    { header: 'Subcategoría', key: 'subcategoria', width: 18 },
    { header: 'Stock Mínimo', key: 'stock_minimo', width: 14 },
    { header: 'Precio Costo ($)', key: 'precio_costo', width: 16 },
    { header: 'Precio Venta ($)', key: 'precio_venta', width: 16 },
    { header: 'Cantidad Inicial a Ingresar', key: 'cantidad', width: 22 },
  ];
  ws2.getRow(1).font = { bold: true };
  ws2.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE4E0D5' } };
  ws2.views = [{ state: 'frozen', ySplit: 1 }];
  // Dropdown de categoría si ya hay alguna cargada — si no hay ninguna, se
  // puede escribir una categoría nueva y el sistema la crea sola al importar.
  if (categorias.length) {
    for (let r = 2; r <= 60; r++) {
      ws2.getCell(`C${r}`).dataValidation = { type: 'list', allowBlank: true, formulae: [`"${categorias.join(',')}"`] };
    }
  }

  // ── Hoja 3: Instrucciones ─────────────────────────────────────────────────
  const ws3 = wb.addWorksheet('Instrucciones');
  ws3.columns = [{ key: 'a', width: 100 }];
  [
    'CÓMO USAR ESTA PLANILLA',
    '',
    '1) Hoja "Reponer Stock": ya tiene tu catálogo actual. Usá el autofiltro del encabezado para',
    '   filtrar por Categoría o Subcategoría y encontrar más rápido lo que necesitás cargar.',
    '   Completá "Cantidad a Ingresar" solo en los productos que recibiste. Dejá vacío el resto.',
    '',
    '2) Hoja "Productos Nuevos": para productos que todavía NO existen en el sistema.',
    '   Completá Código, Nombre, Categoría (hay una lista desplegable), Subcategoría y la cantidad',
    '   inicial. Si la categoría no existe todavía, escribila igual — se crea sola al importar.',
    '',
    '3) No cambies los nombres de las columnas ni el orden de las hojas.',
    '',
    '4) Guardá el archivo y subilo desde "Ingreso de Mercadería → Carga Masiva (Excel)".',
    '   Vas a ver una vista previa con errores marcados ANTES de que se aplique ningún cambio.',
  ].forEach(line => ws3.addRow([line]));

  const buffer = await wb.xlsx.writeBuffer();
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="plantilla_carga_masiva.xlsx"');
  res.send(Buffer.from(buffer));
});

// Lee el Excel subido y devuelve una vista previa (válidos + errores) SIN
// aplicar nada todavía — el usuario confirma recién después de ver esto.
app.post('/api/mercaderia/importar/previsualizar', authMiddleware, uploadExcel.single('archivo'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No se recibió ningún archivo' });

  const wb = new ExcelJS.Workbook();
  try {
    await wb.xlsx.load(req.file.buffer);
  } catch (e) {
    return res.status(400).json({ error: 'El archivo no es una planilla Excel válida' });
  }

  const validos = [];
  const errores = [];

  // Hoja 1: reponer stock existente
  const ws1 = wb.getWorksheet('Reponer Stock');
  if (ws1) {
    ws1.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return;
      const codigo = String(row.getCell(1).value || '').trim();
      const cantidad = row.getCell(6).value;
      const costo = row.getCell(7).value;
      if (!codigo || cantidad === null || cantidad === undefined || cantidad === '') return; // fila vacía, se ignora
      const cantNum = Number(cantidad);
      if (isNaN(cantNum) || cantNum <= 0) { errores.push({ hoja: 'Reponer Stock', fila: rowNumber, motivo: `Cantidad inválida: "${cantidad}"` }); return; }
      const producto = req.db.prepare('SELECT id, nombre FROM productos WHERE codigo=?').get(codigo);
      if (!producto) { errores.push({ hoja: 'Reponer Stock', fila: rowNumber, motivo: `Código "${codigo}" no existe en el catálogo` }); return; }
      const costoNum = costo !== null && costo !== undefined && costo !== '' ? Number(costo) : 0;
      if (isNaN(costoNum) || costoNum < 0) { errores.push({ hoja: 'Reponer Stock', fila: rowNumber, motivo: `Costo unitario inválido: "${costo}"` }); return; }
      validos.push({ tipo: 'reponer', codigo, nombre: producto.nombre, producto_id: producto.id, cantidad: cantNum, costo_unitario: costoNum });
    });
  }

  // Hoja 2: productos nuevos
  const ws2 = wb.getWorksheet('Productos Nuevos');
  if (ws2) {
    ws2.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return;
      const codigo = String(row.getCell(1).value || '').trim();
      const nombre = String(row.getCell(2).value || '').trim();
      const categoria = String(row.getCell(3).value || '').trim();
      const subcategoria = String(row.getCell(4).value || '').trim();
      const stockMinimo = row.getCell(5).value;
      const precioCosto = row.getCell(6).value;
      const precioVenta = row.getCell(7).value;
      const cantidad = row.getCell(8).value;
      if (!codigo && !nombre) return; // fila vacía
      if (!codigo) { errores.push({ hoja: 'Productos Nuevos', fila: rowNumber, motivo: 'Falta el código' }); return; }
      if (!nombre) { errores.push({ hoja: 'Productos Nuevos', fila: rowNumber, motivo: 'Falta el nombre' }); return; }
      const existe = req.db.prepare('SELECT id FROM productos WHERE codigo=?').get(codigo);
      if (existe) { errores.push({ hoja: 'Productos Nuevos', fila: rowNumber, motivo: `El código "${codigo}" ya existe — usá la hoja "Reponer Stock" para ese producto` }); return; }
      const cantNum = cantidad !== null && cantidad !== undefined && cantidad !== '' ? Number(cantidad) : 0;
      if (isNaN(cantNum) || cantNum < 0) { errores.push({ hoja: 'Productos Nuevos', fila: rowNumber, motivo: `Cantidad inicial inválida: "${cantidad}"` }); return; }
      const costoNum = precioCosto !== null && precioCosto !== undefined && precioCosto !== '' ? Number(precioCosto) : 0;
      const ventaNum = precioVenta !== null && precioVenta !== undefined && precioVenta !== '' ? Number(precioVenta) : 0;
      const minimoNum = stockMinimo !== null && stockMinimo !== undefined && stockMinimo !== '' ? Number(stockMinimo) : 1;
      validos.push({ tipo: 'nuevo', codigo, nombre, categoria, subcategoria, stock_minimo: minimoNum, precio_costo: costoNum, precio_venta: ventaNum, cantidad: cantNum, costo_unitario: costoNum });
    });
  }

  res.json({ validos, errores, total: validos.length + errores.length });
});

// Aplica la importación: crea productos nuevos (y categoría/subcategoría si
// hacen falta), y registra UN ingreso de mercadería con todos los ítems —
// todo entra al Depósito Central, igual que un ingreso manual.
app.post('/api/mercaderia/importar/confirmar', authMiddleware, requierePermiso('ingreso_mercaderia'), (req, res) => {
  const { proveedor, numero_remito, notas, filas } = req.body;
  if (!Array.isArray(filas) || !filas.length) return res.status(400).json({ error: 'No hay filas para importar' });

  const getCat = req.db.prepare(`SELECT id FROM categorias WHERE tipo='producto' AND nombre=?`);
  const insCat = req.db.prepare(`INSERT INTO categorias (tipo,nombre) VALUES ('producto',?)`);
  const getSub = req.db.prepare(`SELECT id FROM subcategorias WHERE categoria_id=? AND nombre=?`);
  const insSub = req.db.prepare(`INSERT INTO subcategorias (categoria_id,nombre) VALUES (?,?)`);
  const insProducto = req.db.prepare(`INSERT INTO productos (codigo,nombre,categoria,categoria_id,subcategoria_id,stock,stock_minimo,precio_costo,precio_venta) VALUES (?,?,?,?,?,0,?,?,?)`);

  const _sucI = sucursalOperativa(req);
  const itemsArr = [];
  for (const f of filas) {
    if (f.tipo === 'reponer') {
      itemsArr.push({ producto_id: f.producto_id, cantidad: f.cantidad, costo_unitario: f.costo_unitario||0 });
    } else if (f.tipo === 'nuevo') {
      let categoriaId = null, subcategoriaId = null;
      if (f.categoria) {
        const catRow = getCat.get(f.categoria);
        categoriaId = catRow ? catRow.id : insCat.run(f.categoria).lastInsertRowid;
        if (f.subcategoria) {
          const subRow = getSub.get(categoriaId, f.subcategoria);
          subcategoriaId = subRow ? subRow.id : insSub.run(categoriaId, f.subcategoria).lastInsertRowid;
        }
      }
      const existe = req.db.prepare('SELECT id FROM productos WHERE codigo=?').get(f.codigo);
      if (existe) continue; // por si se coló un duplicado entre previsualizar y confirmar
      const prodId = insProducto.run(f.codigo, f.nombre, f.categoria||'', categoriaId, subcategoriaId, f.stock_minimo||1, f.precio_costo||0, f.precio_venta||0).lastInsertRowid;
      if (f.cantidad > 0) itemsArr.push({ producto_id: prodId, cantidad: f.cantidad, costo_unitario: f.costo_unitario||0 });
    }
  }

  audit(req, 'mercaderia.ingreso_excel', 'ingreso', null, `${itemsArr.length} ítems, proveedor ${proveedor||'-'}, en ${nombreLugar(req.db,_sucI?_sucI.id:null)}`);
  if (!itemsArr.length) return res.json({ ok: true, ingresoId: null, productosCreados: filas.filter(f=>f.tipo==='nuevo').length, mensaje: 'Productos creados, sin cantidades para ingresar' });

  const total = itemsArr.reduce((s,i) => s + (Number(i.cantidad) * Number(i.costo_unitario||0)), 0);
  const rIngreso = req.db.prepare(`INSERT INTO mercaderia_ingresos (proveedor,numero_remito,notas,usuario,total) VALUES (?,?,?,?,?)`)
    .run(proveedor || '', numero_remito || '', (notas||'') + ' (carga masiva por Excel)', req.user?.nombre || '', total);
  const ingresoId = rIngreso.lastInsertRowid;

  const insItem = req.db.prepare('INSERT INTO mercaderia_ingreso_items (ingreso_id,producto_id,cantidad,costo_unitario) VALUES (?,?,?,?)');
  const insMov = req.db.prepare(`INSERT INTO movimientos_stock (producto_id,tipo,cantidad,motivo,sucursal_id,usuario) VALUES (?,'entrada',?,?,?,?)`);
  const updStock = req.db.prepare('UPDATE productos SET stock = stock + ? WHERE id=?');
  const updCosto = req.db.prepare('UPDATE productos SET costo=?, proveedor=? WHERE id=?');

  itemsArr.forEach(i => {
    insItem.run(ingresoId, i.producto_id, Number(i.cantidad), Number(i.costo_unitario||0));
    insMov.run(i.producto_id, Number(i.cantidad), `[${nombreLugar(req.db,_sucI?_sucI.id:null)}] Carga masiva por Excel${numero_remito ? ' — remito '+numero_remito : ''}`, _sucI?_sucI.id:null, req.user?.nombre||'');
    if (_sucI) ajustarStock(req.db, i.producto_id, _sucI.id, Number(i.cantidad)); else updStock.run(Number(i.cantidad), i.producto_id);
    if (i.costo_unitario > 0) updCosto.run(Number(i.costo_unitario), proveedor || '', i.producto_id);
  });

  res.json({ ok: true, ingresoId, total, itemsImportados: itemsArr.length });
});

// ─── INICIAR ──────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;

// Directorio de uploads persistente para Railway
const UPLOADS_DIR = process.env.UPLOADS_DIR || path.join(__dirname, 'public', 'uploads');
if (!require('fs').existsSync(UPLOADS_DIR)) require('fs').mkdirSync(UPLOADS_DIR, { recursive: true });
['productos','herramientas','planos'].forEach(sub => {
  const d = require('path').join(UPLOADS_DIR, sub);
  if (!require('fs').existsSync(d)) require('fs').mkdirSync(d, { recursive: true });
});

// Detectar IP de red local automáticamente
function getLocalIP() {
  const os = require('os');
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return 'localhost';
}
const LOCAL_IP = getLocalIP();
app.get('/api/herramientas', authMiddleware, (req, res) => {
  const { q, estado, categoria } = req.query;
  let sql = 'SELECT * FROM herramientas WHERE activa=1';
  const params = [];
  // Un no-admin solo ve las herramientas de SU sucursal, más las generales
  // (sin sucursal asignada, ej. el pool histórico que ya existía antes de
  // que esto se llevara por sucursal).
  if (req.user.rol !== 'admin') {
    sql += ' AND (sucursal_id = ? OR sucursal_id IS NULL)';
    params.push(req.user.sucursal_id || null);
  }
  if (q) { sql += ' AND (nombre LIKE ? OR codigo LIKE ? OR marca LIKE ? OR modelo LIKE ?)'; const busq = `%${q}%`; params.push(busq,busq,busq,busq); }
  if (estado) { sql += ' AND estado=?'; params.push(estado); }
  if (categoria) { sql += ' AND categoria=?'; params.push(categoria); }
  sql += ' ORDER BY nombre ASC';
  res.json(req.db.prepare(sql).all(...params));
});

// Verificar la clave de carga manual de herramientas de una sucursal —
// la genera el admin (en Sucursales) y es propia de ESE local, no una clave
// única para todo el sistema.
app.post('/api/herramientas/verificar-clave', authMiddleware, (req, res) => {
  const sucursal_id = req.user.rol === 'admin' ? req.body.sucursal_id : req.user.sucursal_id;
  if (!sucursal_id) return res.json({ ok: false });
  const s = req.db.prepare('SELECT clave_herramientas FROM sucursales WHERE id=?').get(sucursal_id);
  const ok = !!s?.clave_herramientas && s.clave_herramientas === req.body.clave;
  res.json({ ok });
});

// Un no-admin puede cargar herramientas si manda la clave correcta de SU
// sucursal — se revalida siempre acá, nunca se confía en un "desbloqueo"
// hecho solo del lado del navegador.
function adminOrClaveHerramientas(req, res, next) {
  if (req.user.rol === 'admin') return next();
  const sucursal_id = req.user.sucursal_id;
  if (!sucursal_id) return res.status(403).json({ error: 'No tenés una sucursal asignada' });
  const s = req.db.prepare('SELECT clave_herramientas FROM sucursales WHERE id=?').get(sucursal_id);
  if (!s?.clave_herramientas || s.clave_herramientas !== req.body.clave_herramientas) {
    return res.status(403).json({ error: 'Clave incorrecta — pedile al admin de tu sucursal la clave de carga manual' });
  }
  next();
}

// Búsqueda por código exacto (usada por el lector de código de barras/QR)
app.get('/api/herramientas/buscar-codigo/:codigo', authMiddleware, (req, res) => {
  const codigo = req.params.codigo.trim();
  let h = req.db.prepare('SELECT * FROM herramientas WHERE codigo=? AND activa=1').get(codigo);
  if (!h) h = req.db.prepare('SELECT * FROM herramientas WHERE codigo LIKE ? AND activa=1 ORDER BY nombre LIMIT 1').get(`%${codigo}%`);
  if (!h) return res.status(404).json({ error: 'No se encontró ninguna herramienta con ese código' });
  res.json(h);
});
app.get('/api/herramientas/:id', authMiddleware, (req, res) => {
  const h = req.db.prepare('SELECT * FROM herramientas WHERE id=?').get(req.params.id);
  if (!h) return res.status(404).json({ error: 'No encontrada' });
  h.movimientos = req.db.prepare('SELECT * FROM herramienta_movimientos WHERE herramienta_id=? ORDER BY fecha DESC LIMIT 20').all(req.params.id);
  res.json(h);
});

app.post('/api/herramientas', authMiddleware, adminOrClaveHerramientas, (req, res) => {
  const { codigo, nombre, categoria, marca, modelo, estado, ubicacion, cantidad, cantidad_minima, descripcion, numero_serie, fecha_compra, valor_compra } = req.body;
  if (!codigo || !nombre) return res.status(400).json({ error: 'Código y nombre obligatorios' });
  // Si lo carga un no-admin, queda atado a SU sucursal — nunca se crea una
  // herramienta "general" (visible para todos) desde una carga de taller.
  const sucursal_id = req.user.rol === 'admin' ? (req.body.sucursal_id || null) : req.user.sucursal_id;
  const r = req.db.prepare(`INSERT INTO herramientas (codigo,nombre,categoria,marca,modelo,estado,ubicacion,cantidad,cantidad_minima,descripcion,numero_serie,fecha_compra,valor_compra,sucursal_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(codigo,nombre,categoria||'General',marca||'',modelo||'',estado||'disponible',ubicacion||'Taller',cantidad||1,cantidad_minima||1,descripcion||'',numero_serie||'',fecha_compra||'',valor_compra||0,sucursal_id);
  res.json({ id: r.lastInsertRowid });
});

app.put('/api/herramientas/:id', authMiddleware, adminOrClaveHerramientas, (req, res) => {
  const { nombre, categoria, marca, modelo, estado, ubicacion, cantidad, cantidad_minima, descripcion, numero_serie, fecha_compra, valor_compra } = req.body;
  req.db.prepare(`UPDATE herramientas SET nombre=?,categoria=?,marca=?,modelo=?,estado=?,ubicacion=?,cantidad=?,cantidad_minima=?,descripcion=?,numero_serie=?,fecha_compra=?,valor_compra=? WHERE id=?`).run(nombre,categoria,marca,modelo,estado,ubicacion,cantidad,cantidad_minima,descripcion,numero_serie,fecha_compra,valor_compra,req.params.id);
  res.json({ ok: true });
});

app.delete('/api/herramientas/:id', authMiddleware, adminOnly, (req, res) => {
  req.db.prepare('UPDATE herramientas SET activa=0 WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// Registrar uso/préstamo de herramienta
app.post('/api/herramientas/:id/movimiento', authMiddleware, adminOnly, (req, res) => {
  const { tipo, cantidad, tecnico, motivo, orden_id } = req.body;
  const h = req.db.prepare('SELECT * FROM herramientas WHERE id=?').get(req.params.id);
  if (!h) return res.status(404).json({ error: 'No encontrada' });
  req.db.prepare('INSERT INTO herramienta_movimientos (herramienta_id,tipo,cantidad,tecnico,motivo,orden_id) VALUES (?,?,?,?,?,?)').run(req.params.id,tipo,cantidad||1,tecnico||'',motivo||'',orden_id||null);
  // Actualizar estado si se presta/devuelve
  if (tipo === 'prestamo') req.db.prepare("UPDATE herramientas SET estado='en_uso' WHERE id=?").run(req.params.id);
  if (tipo === 'devolucion') req.db.prepare("UPDATE herramientas SET estado='disponible' WHERE id=?").run(req.params.id);
  if (tipo === 'mantenimiento') req.db.prepare("UPDATE herramientas SET estado='mantenimiento' WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

// Upload foto herramienta
const storageHerr = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = require('path').join(UPLOADS_DIR, 'herramientas');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => cb(null, `herr_${req.params.id}_${Date.now()}${path.extname(file.originalname)}`)
});
const uploadHerr = multer({ storage: storageHerr, limits: { fileSize: 5*1024*1024 }, fileFilter:(req,file,cb)=>file.mimetype.startsWith('image/')?cb(null,true):cb(new Error('Solo imágenes')) });

app.post('/api/herramientas/:id/foto', authMiddleware, adminOnly, (req,res,next) => {
  uploadHerr.single('foto')(req,res,(err)=>{
    if(err) return res.status(400).json({error:err.message});
    if(!req.file) return res.status(400).json({error:'No se recibió imagen'});
    const url = `/uploads/herramientas/${req.file.filename}`;
    const h = req.db.prepare('SELECT foto_url FROM herramientas WHERE id=?').get(req.params.id);
    if(h?.foto_url){ try { const op=path.join(__dirname,'public',h.foto_url); if(fs.existsSync(op)) fs.unlinkSync(op); } catch(e){} }
    req.db.prepare('UPDATE herramientas SET foto_url=? WHERE id=?').run(url,req.params.id);
    res.json({ok:true,url});
  });
});

// Export herramientas CSV
app.get('/api/export/herramientas', authMiddleware, adminOnly, (req, res) => {
  const data = req.db.prepare('SELECT * FROM herramientas WHERE activa=1 ORDER BY nombre').all();
  const headers = ['Código','Nombre','Categoría','Marca','Modelo','Estado','Ubicación','Cantidad','Cantidad Mínima','N° Serie','Fecha Compra','Valor Compra'];
  const rows = data.map(h=>[h.codigo,h.nombre,h.categoria,h.marca,h.modelo,h.estado,h.ubicacion,h.cantidad,h.cantidad_minima,h.numero_serie,h.fecha_compra,h.valor_compra]);
  const escape = v => { if(!v&&v!==0) return ''; const s=String(v); return s.includes(',')||s.includes('"')||s.includes('\n')?`"${s.replace(/"/g,'""')}`:s; };
  const csv = [headers,...rows].map(r=>r.map(escape).join(',')).join('\r\n');
  res.setHeader('Content-Type','text/csv; charset=utf-8');
  res.setHeader('Content-Disposition','attachment; filename="herramientas.csv"');
  res.send('\uFEFF'+csv);
});

// ─── SUCURSALES Y STOCK POR SUCURSAL ─────────────────────────────────────────

// Listar sucursales (incluye depósito central)
app.get('/api/sucursales', authMiddleware, (req, res) => {
  const rows = req.db.prepare('SELECT * FROM sucursales WHERE activa=1 ORDER BY es_deposito_central DESC, nombre ASC').all();
  // La clave de herramientas es una contraseña — solo el admin la ve (la
  // necesita para mostrarla/editarla en el formulario de Sucursales).
  if (req.user.rol !== 'admin') rows.forEach(r => delete r.clave_herramientas);
  res.json(rows);
});

app.post('/api/sucursales', authMiddleware, adminOnly, (req, res) => {
  const { nombre, direccion, telefono, fondo_caja_fijo, clave_herramientas, factura_habilitada, imei_habilitado, envio_libre_habilitado } = req.body;
  if (!nombre?.trim()) return res.status(400).json({ error: 'Falta el nombre de la sucursal.' });

  const actuales = req.db.prepare('SELECT COUNT(*) AS c FROM sucursales WHERE activa=1 AND es_deposito_central=0').get().c;
  const limite = planes.queIncluye(req, MODO_DISTRIBUIDOR).limiteSucursales;
  if (actuales >= limite) {
    return res.status(402).json({
      error: MODO_DISTRIBUIDOR
        ? `Tu plan incluye ${limite} sucursal(es) además del Depósito Central y ya las estás usando. Para agregar otra, pedile a tu distribuidor que amplíe el plan.`
        : `Tu plan incluye ${limite} sucursal(es) además del Depósito Central y ya las estás usando. Para agregar otra, pedile a tu distribuidor un código con más sucursales y pegalo en Configuración → Sistema → Licencia.`,
      requiereSucursalExtra: true,
    });
  }

  const r = req.db.prepare('INSERT INTO sucursales (nombre,direccion,telefono,fondo_caja_fijo,clave_herramientas,factura_habilitada,imei_habilitado) VALUES (?,?,?,?,?,?,?)').run(nombre, direccion||'', telefono||'', Number(fondo_caja_fijo||0), clave_herramientas||null, factura_habilitada ? 1 : 0, imei_habilitado === false || imei_habilitado === 0 ? 0 : 1);
  if (envio_libre_habilitado) req.db.prepare('UPDATE sucursales SET envio_libre_habilitado=1 WHERE id=?').run(r.lastInsertRowid);
  audit(req, 'sucursal.crear', 'sucursal', r.lastInsertRowid, `${nombre}`);
  res.json({ id: r.lastInsertRowid });
});

app.put('/api/sucursales/:id', authMiddleware, adminOnly, (req, res) => {
  const { nombre, direccion, telefono, fondo_caja_fijo, clave_herramientas, factura_habilitada, imei_habilitado, envio_libre_habilitado } = req.body;
  const suc = req.db.prepare('SELECT * FROM sucursales WHERE id=?').get(req.params.id);
  if (!suc) return res.status(404).json({ error: 'Sucursal no encontrada' });
  if (suc.es_deposito_central) return res.status(400).json({ error: 'El Depósito Central no se puede editar' });
  // El fondo de caja fijo, la clave de herramientas y si factura o no SOLO
  // los toca un admin desde esta pantalla — nunca desde Caja/Herramientas/Facturación.
  const nuevaFacturaHabilitada = factura_habilitada === undefined ? (suc.factura_habilitada ? 1 : 0) : (factura_habilitada ? 1 : 0);
  const nuevoImeiHabilitado = imei_habilitado === undefined ? (suc.imei_habilitado === 0 ? 0 : 1) : (imei_habilitado ? 1 : 0);
  req.db.prepare('UPDATE sucursales SET nombre=?,direccion=?,telefono=?,fondo_caja_fijo=?,clave_herramientas=?,factura_habilitada=?,imei_habilitado=? WHERE id=?')
    .run(nombre, direccion, telefono, Number(fondo_caja_fijo ?? suc.fondo_caja_fijo ?? 0), clave_herramientas !== undefined ? (clave_herramientas || null) : suc.clave_herramientas, nuevaFacturaHabilitada, nuevoImeiHabilitado, req.params.id);
  if (envio_libre_habilitado !== undefined) req.db.prepare('UPDATE sucursales SET envio_libre_habilitado=? WHERE id=?').run(envio_libre_habilitado ? 1 : 0, req.params.id);
  audit(req, 'sucursal.editar', 'sucursal', req.params.id, `${nombre}: facturar=${nuevaFacturaHabilitada}, IMEI=${nuevoImeiHabilitado}, artículos libres=${envio_libre_habilitado===undefined?'sin cambio':(envio_libre_habilitado?1:0)}`);
  res.json({ ok: true });
});

app.delete('/api/sucursales/:id', authMiddleware, adminOnly, (req, res) => {
  const suc = req.db.prepare('SELECT * FROM sucursales WHERE id=?').get(req.params.id);
  if (suc?.es_deposito_central) return res.status(400).json({ error: 'El Depósito Central no se puede eliminar' });
  req.db.prepare('UPDATE sucursales SET activa=0 WHERE id=?').run(req.params.id);
  audit(req, 'sucursal.eliminar', 'sucursal', req.params.id, suc?.nombre || '');
  res.json({ ok: true });
});

// Ver stock de un producto distribuido en todas las sucursales
app.get('/api/productos/:id/stock-sucursales', authMiddleware, (req, res) => {
  const producto = req.db.prepare('SELECT * FROM productos WHERE id=?').get(req.params.id);
  if (!producto) return res.status(404).json({ error: 'Producto no encontrado' });
  const sucursales = req.db.prepare('SELECT * FROM sucursales WHERE activa=1 ORDER BY es_deposito_central DESC, nombre ASC').all();
  const distribuido = req.db.prepare('SELECT sucursal_id, cantidad FROM stock_sucursal WHERE producto_id=?').all(req.params.id);
  const mapaDistribuido = {};
  distribuido.forEach(d => mapaDistribuido[d.sucursal_id] = d.cantidad);

  let resultado = sucursales.map(s => ({
    sucursal_id: s.id,
    sucursal_nombre: s.nombre,
    es_deposito_central: !!s.es_deposito_central,
    // El depósito central muestra el stock SIN distribuir (producto.stock), las demás su cantidad distribuida
    cantidad: s.es_deposito_central ? producto.stock : (mapaDistribuido[s.id] || 0)
  }));

  // Ver el stock de lugares que no son el tuyo es un permiso que decide el
  // admin por usuario (ver_otras_sucursales) — sin él, solo ves tu propia
  // sucursal (para poder armar un envío desde ahí), nada más.
  if (!req.user.ver_otras_sucursales) {
    resultado = resultado.filter(r => String(r.sucursal_id) === String(req.user.sucursal_id));
  }

  res.json({ producto: { id: producto.id, codigo: producto.codigo, nombre: producto.nombre }, distribucion: resultado });
});

// Distribuir stock del depósito central hacia una sucursal.
// OJO: esto ya NO suma al destino al instante. El stock sale del depósito
// central ahora mismo (para que no se pueda enviar dos veces lo mismo), pero
// queda "en tránsito" hasta que la sucursal confirme cuánto llegó de verdad
// con POST /api/sucursales/movimientos/:id/confirmar.
app.post('/api/productos/:id/distribuir', authMiddleware, adminOnly, (req, res) => {
  const { sucursal_id, cantidad, notas } = req.body;
  const cant = parseInt(cantidad);
  if (!sucursal_id || !cant || cant <= 0) return res.status(400).json({ error: 'Sucursal y cantidad son obligatorios' });

  const producto = req.db.prepare('SELECT * FROM productos WHERE id=?').get(req.params.id);
  if (!producto) return res.status(404).json({ error: 'Producto no encontrado' });
  if (producto.stock < cant) return res.status(400).json({ error: `Stock insuficiente en el depósito central (disponible: ${producto.stock})` });

  const sucursalDestino = req.db.prepare('SELECT * FROM sucursales WHERE id=?').get(sucursal_id);
  if (!sucursalDestino) return res.status(404).json({ error: 'Sucursal no encontrada' });
  if (sucursalDestino.es_deposito_central) return res.status(400).json({ error: 'No se puede distribuir hacia el depósito central' });

  // Descontar del depósito central ahora — el destino recién lo recibe al confirmar
  req.db.prepare('UPDATE productos SET stock = stock - ? WHERE id=?').run(cant, req.params.id);

  const r = req.db.prepare(`INSERT INTO movimientos_sucursal (producto_id,sucursal_origen_id,sucursal_destino_id,cantidad,tipo,usuario,notas,estado) VALUES (?,NULL,?,?,'distribucion',?,?,'enviado')`)
    .run(req.params.id, sucursal_id, cant, req.user?.nombre||'', notas||'');

  res.json({ ok: true, id: r.lastInsertRowid, estado: 'enviado' });
});

// Devolver stock de una sucursal al depósito central — mismo circuito: sale
// de la sucursal ahora, el depósito central confirma cuánto llegó.
// Cualquier usuario puede devolver mercadería al depósito, pero solo desde
// SU PROPIA sucursal — igual criterio que Caja: el origen es donde estás
// parado, no se elige libremente. El admin sigue pudiendo hacerlo desde cualquiera.
app.post('/api/productos/:id/devolver-deposito', authMiddleware, (req, res) => {
  const { sucursal_id, cantidad, notas } = req.body;
  const cant = parseInt(cantidad);
  if (!sucursal_id || !cant || cant <= 0) return res.status(400).json({ error: 'Sucursal y cantidad son obligatorios' });
  if (req.user.rol !== 'admin' && String(sucursal_id) !== String(req.user.sucursal_id)) {
    return res.status(403).json({ error: 'Solo podés enviar mercadería desde tu propia sucursal' });
  }

  const stockActual = req.db.prepare('SELECT cantidad FROM stock_sucursal WHERE producto_id=? AND sucursal_id=?').get(req.params.id, sucursal_id);
  if (!stockActual || stockActual.cantidad < cant) {
    return res.status(400).json({ error: `Stock insuficiente en la sucursal (disponible: ${stockActual?.cantidad||0})` });
  }

  req.db.prepare('UPDATE stock_sucursal SET cantidad = cantidad - ? WHERE producto_id=? AND sucursal_id=?').run(cant, req.params.id, sucursal_id);

  const r = req.db.prepare(`INSERT INTO movimientos_sucursal (producto_id,sucursal_origen_id,sucursal_destino_id,cantidad,tipo,usuario,notas,estado) VALUES (?,?,NULL,?,'devolucion',?,?,'enviado')`)
    .run(req.params.id, sucursal_id, cant, req.user?.nombre||'', notas||'');

  res.json({ ok: true, id: r.lastInsertRowid, estado: 'enviado' });
});

// Transferir stock entre dos sucursales (no depósito) — mismo circuito de
// tránsito. Igual que arriba: un usuario común solo puede originar desde su
// propia sucursal asignada; el admin puede elegir cualquier origen.
app.post('/api/productos/:id/transferir', authMiddleware, (req, res) => {
  const { sucursal_origen_id, sucursal_destino_id, cantidad, notas } = req.body;
  const cant = parseInt(cantidad);
  if (!sucursal_origen_id || !sucursal_destino_id || !cant || cant <= 0) {
    return res.status(400).json({ error: 'Origen, destino y cantidad son obligatorios' });
  }
  if (sucursal_origen_id === sucursal_destino_id) return res.status(400).json({ error: 'Origen y destino no pueden ser iguales' });
  if (req.user.rol !== 'admin' && String(sucursal_origen_id) !== String(req.user.sucursal_id)) {
    return res.status(403).json({ error: 'Solo podés enviar mercadería desde tu propia sucursal' });
  }

  const stockOrigen = req.db.prepare('SELECT cantidad FROM stock_sucursal WHERE producto_id=? AND sucursal_id=?').get(req.params.id, sucursal_origen_id);
  if (!stockOrigen || stockOrigen.cantidad < cant) {
    return res.status(400).json({ error: `Stock insuficiente en la sucursal de origen (disponible: ${stockOrigen?.cantidad||0})` });
  }

  req.db.prepare('UPDATE stock_sucursal SET cantidad = cantidad - ? WHERE producto_id=? AND sucursal_id=?').run(cant, req.params.id, sucursal_origen_id);

  const r = req.db.prepare(`INSERT INTO movimientos_sucursal (producto_id,sucursal_origen_id,sucursal_destino_id,cantidad,tipo,usuario,notas,estado) VALUES (?,?,?,?,'transferencia',?,?,'enviado')`)
    .run(req.params.id, sucursal_origen_id, sucursal_destino_id, cant, req.user?.nombre||'', notas||'');

  res.json({ ok: true, id: r.lastInsertRowid, estado: 'enviado' });
});

// Movimientos en tránsito pendientes de confirmar recepción. Un admin ve todos;
// un usuario de sucursal (taller/caja) solo ve los que le llegan a SU sucursal
// (o, si es devolución, solo si su sucursal es el depósito central).
app.get('/api/sucursales/movimientos/pendientes', authMiddleware, (req, res) => {
  const misucursal = req.user.sucursal_id;
  let rows = req.db.prepare(`
    SELECT m.*, p.codigo, p.nombre as producto_nombre,
           so.nombre as sucursal_origen_nombre, sd.nombre as sucursal_destino_nombre,
           so.es_deposito_central as origen_es_central
    FROM movimientos_sucursal m
    JOIN productos p ON m.producto_id = p.id
    LEFT JOIN sucursales so ON m.sucursal_origen_id = so.id
    LEFT JOIN sucursales sd ON m.sucursal_destino_id = sd.id
    WHERE m.estado = 'enviado'
    ORDER BY m.fecha DESC
  `).all();

  if (req.user.rol !== 'admin') {
    if (!misucursal) return res.json([]);
    const miSucursalRow = req.db.prepare('SELECT es_deposito_central FROM sucursales WHERE id=?').get(misucursal);
    rows = rows.filter(m => {
      if (m.tipo === 'devolucion') return !!miSucursalRow?.es_deposito_central; // vuelve al depósito
      return m.sucursal_destino_id === misucursal; // distribución o transferencia: destino = mi sucursal
    });
  }
  res.json(rows);
});

// Confirmar recepción de un movimiento en tránsito. Lo hace quien recibe la
// mercadería: la sucursal destino (distribución/transferencia) o el depósito
// central (devolución). Si lo que llegó no coincide con lo que salió, la
// diferencia queda registrada — no se "ajusta en silencio".
app.post('/api/sucursales/movimientos/:id/confirmar', authMiddleware, (req, res) => {
  const mov = req.db.prepare('SELECT * FROM movimientos_sucursal WHERE id=?').get(req.params.id);
  if (!mov) return res.status(404).json({ error: 'Movimiento no encontrado' });
  if (mov.estado !== 'enviado') return res.status(400).json({ error: 'Este movimiento ya fue confirmado' });

  // Seguridad: si no es admin, solo puede confirmar lo que le corresponde a su propia sucursal
  if (req.user.rol !== 'admin') {
    const misucursal = req.user.sucursal_id;
    if (mov.tipo === 'devolucion') {
      const miSucursalRow = misucursal ? req.db.prepare('SELECT es_deposito_central FROM sucursales WHERE id=?').get(misucursal) : null;
      if (!miSucursalRow?.es_deposito_central) return res.status(403).json({ error: 'Solo el depósito central puede confirmar esta devolución' });
    } else if (mov.sucursal_destino_id !== misucursal) {
      return res.status(403).json({ error: 'Esto no te llega a vos — no podés confirmarlo' });
    }
  }

  const cantRecibida = req.body.cantidad_recibida !== undefined && req.body.cantidad_recibida !== null && req.body.cantidad_recibida !== ''
    ? parseInt(req.body.cantidad_recibida)
    : mov.cantidad;
  if (isNaN(cantRecibida) || cantRecibida < 0) return res.status(400).json({ error: 'Cantidad recibida inválida' });

  const diferencia = cantRecibida - mov.cantidad;

  if (mov.tipo === 'devolucion') {
    // Vuelve al depósito central = suma a productos.stock
    req.db.prepare('UPDATE productos SET stock = stock + ? WHERE id=?').run(cantRecibida, mov.producto_id);
  } else {
    // Distribución o transferencia: suma al stock_sucursal del destino
    const existe = req.db.prepare('SELECT id FROM stock_sucursal WHERE producto_id=? AND sucursal_id=?').get(mov.producto_id, mov.sucursal_destino_id);
    if (existe) {
      req.db.prepare('UPDATE stock_sucursal SET cantidad = cantidad + ? WHERE producto_id=? AND sucursal_id=?').run(cantRecibida, mov.producto_id, mov.sucursal_destino_id);
    } else {
      req.db.prepare('INSERT INTO stock_sucursal (producto_id,sucursal_id,cantidad) VALUES (?,?,?)').run(mov.producto_id, mov.sucursal_destino_id, cantRecibida);
    }
  }

  req.db.prepare(`UPDATE movimientos_sucursal SET estado='recibido', cantidad_recibida=?, diferencia=?, confirmado_por=?, fecha_confirmacion=CURRENT_TIMESTAMP, notas = notas || ? WHERE id=?`)
    .run(cantRecibida, diferencia, req.user?.nombre||'', req.body.notas_confirmacion ? ` | Confirmación: ${req.body.notas_confirmacion}` : '', req.params.id);

  res.json({ ok: true, diferencia, cantidad_enviada: mov.cantidad, cantidad_recibida: cantRecibida });
});

// ─── ENVÍO DE EQUIPOS (órdenes de servicio) ENTRE SUCURSALES/TALLER/CAJA ─────
// Distinto del envío de stock: acá viaja el equipo de un cliente (con TODOS
// sus datos — falla, diagnóstico, cliente, etc. ya están en la orden, no se
// duplican) desde donde está físicamente hoy hacia cualquier otro lugar.
// Mismo patrón de tránsito que el stock: se envía, y el destino confirma.

// Listar mis órdenes enviables (las que están en mi sucursal actual, o sin
// asignar todavía si mi sucursal es la de origen del taller).
app.get('/api/ordenes/enviables', authMiddleware, (req, res) => {
  const misucursal = req.user.sucursal_id;
  let rows;
  if (req.user.rol === 'admin') {
    rows = req.db.prepare(`SELECT id,numero,equipo,marca,modelo,estado,sucursal_id FROM ordenes WHERE estado NOT IN ('entregado','cancelado') ORDER BY fecha_ingreso DESC`).all();
  } else {
    rows = req.db.prepare(`SELECT id,numero,equipo,marca,modelo,estado,sucursal_id FROM ordenes WHERE estado NOT IN ('entregado','cancelado') AND (sucursal_id = ? OR sucursal_id IS NULL) ORDER BY fecha_ingreso DESC`).all(misucursal);
  }
  res.json(rows);
});

app.post('/api/ordenes/:id/enviar', authMiddleware, (req, res) => {
  const { destino_sucursal_id, notas } = req.body;
  if (!destino_sucursal_id) return res.status(400).json({ error: 'Falta el destino' });
  const orden = req.db.prepare('SELECT * FROM ordenes WHERE id=?').get(req.params.id);
  if (!orden) return res.status(404).json({ error: 'Orden no encontrada' });

  // Seguridad: un no-admin solo puede enviar equipos que están físicamente
  // en SU sucursal (o sin asignar, recién ingresados en su taller).
  if (req.user.rol !== 'admin' && orden.sucursal_id && String(orden.sucursal_id) !== String(req.user.sucursal_id)) {
    return res.status(403).json({ error: 'Este equipo no está en tu sucursal — no lo podés enviar' });
  }
  const origenId = orden.sucursal_id || req.user.sucursal_id || null;

  const r = req.db.prepare(`INSERT INTO envios_equipos (orden_id,origen_sucursal_id,destino_sucursal_id,notas,usuario_envio) VALUES (?,?,?,?,?)`)
    .run(orden.id, origenId, destino_sucursal_id, notas || '', req.user?.nombre || req.user?.usuario || '');
  res.json({ id: r.lastInsertRowid, ok: true });
});

app.get('/api/envios-equipos/pendientes', authMiddleware, (req, res) => {
  const misucursal = req.user.sucursal_id;
  let rows = req.db.prepare(`
    SELECT e.*, o.numero, o.equipo, o.marca, o.modelo, o.serie, o.estado as orden_estado,
           o.falla_reportada, o.diagnostico, o.prioridad,
           c.nombre as cliente_nombre, c.telefono as cliente_telefono,
           so.nombre as origen_nombre, sd.nombre as destino_nombre
    FROM envios_equipos e
    JOIN ordenes o ON o.id = e.orden_id
    LEFT JOIN clientes c ON c.id = o.cliente_id
    LEFT JOIN sucursales so ON so.id = e.origen_sucursal_id
    LEFT JOIN sucursales sd ON sd.id = e.destino_sucursal_id
    WHERE e.estado = 'enviado'
    ORDER BY e.fecha_envio DESC
  `).all();
  if (req.user.rol !== 'admin') {
    if (!misucursal) return res.json([]);
    rows = rows.filter(e => String(e.destino_sucursal_id) === String(misucursal));
  }
  res.json(rows);
});

app.get('/api/envios-equipos/movimientos', authMiddleware, (req, res) => {
  let rows = req.db.prepare(`
    SELECT e.*, o.numero, o.equipo, o.marca, o.modelo,
           so.nombre as origen_nombre, sd.nombre as destino_nombre
    FROM envios_equipos e
    JOIN ordenes o ON o.id = e.orden_id
    LEFT JOIN sucursales so ON so.id = e.origen_sucursal_id
    LEFT JOIN sucursales sd ON sd.id = e.destino_sucursal_id
    ORDER BY e.fecha_envio DESC
    LIMIT 100
  `).all();
  if (req.user.rol !== 'admin') {
    const mi = req.user.sucursal_id;
    rows = rows.filter(e => String(e.origen_sucursal_id) === String(mi) || String(e.destino_sucursal_id) === String(mi));
  }
  res.json(rows);
});

app.post('/api/envios-equipos/:id/confirmar', authMiddleware, (req, res) => {
  const envio = req.db.prepare('SELECT * FROM envios_equipos WHERE id=?').get(req.params.id);
  if (!envio) return res.status(404).json({ error: 'Envío no encontrado' });
  if (envio.estado !== 'enviado') return res.status(400).json({ error: 'Este envío ya fue confirmado' });
  if (req.user.rol !== 'admin' && String(envio.destino_sucursal_id) !== String(req.user.sucursal_id)) {
    return res.status(403).json({ error: 'Este equipo no te llega a vos — no podés confirmarlo' });
  }
  req.db.prepare(`UPDATE envios_equipos SET estado='confirmado', usuario_confirmacion=?, fecha_confirmacion=CURRENT_TIMESTAMP WHERE id=?`)
    .run(req.user?.nombre || req.user?.usuario || '', req.params.id);
  req.db.prepare('UPDATE ordenes SET sucursal_id=? WHERE id=?').run(envio.destino_sucursal_id, envio.orden_id);
  try { audit(req, 'orden.equipo_recibido', 'orden', envio.orden_id, `Recibió el equipo en ${nombreLugar(req.db, envio.destino_sucursal_id)}`); } catch (e) {}
  res.json({ ok: true });
});

// ─── REMITOS DE MERCADERÍA ENTRE SUCURSALES ───────────────────────────────────
// Un remito = un envío con varias líneas. Las líneas pueden ser productos del
// stock (se descuentan del origen al enviar y se suman al destino al recibir) o
// artículos libres escritos a mano (solo si el admin lo autorizó; solo registro).
// El destino confirma línea por línea: ok / diferencia / rechazado (vuelve al origen).
function sucEsCentral(db, id) {
  return !!db.prepare('SELECT es_deposito_central FROM sucursales WHERE id=?').get(id)?.es_deposito_central;
}
function stockEn(db, productoId, sucId) {
  if (sucEsCentral(db, sucId)) return db.prepare('SELECT stock FROM productos WHERE id=?').get(productoId)?.stock || 0;
  return db.prepare('SELECT cantidad FROM stock_sucursal WHERE producto_id=? AND sucursal_id=?').get(productoId, sucId)?.cantidad || 0;
}
function ajustarStock(db, productoId, sucId, delta) {
  if (!delta) return;
  if (sucEsCentral(db, sucId)) { db.prepare('UPDATE productos SET stock = stock + ? WHERE id=?').run(delta, productoId); return; }
  const ex = db.prepare('SELECT id FROM stock_sucursal WHERE producto_id=? AND sucursal_id=?').get(productoId, sucId);
  if (ex) db.prepare('UPDATE stock_sucursal SET cantidad = cantidad + ? WHERE producto_id=? AND sucursal_id=?').run(delta, productoId, sucId);
  else db.prepare('INSERT INTO stock_sucursal (producto_id,sucursal_id,cantidad) VALUES (?,?,?)').run(productoId, sucId, delta);
}
function remitoVisible(req, r) {
  if (req.user.rol === 'admin') return true;
  const mi = String(req.user.sucursal_id || '');
  return !!mi && (String(r.origen_sucursal_id) === mi || String(r.destino_sucursal_id) === mi);
}

// Stock del lugar desde donde se envía (el usuario común: siempre su sucursal; el admin elige)
app.get('/api/remitos/mi-stock', authMiddleware, (req, res) => {
  const suc = req.user.rol === 'admin' ? Number(req.query.sucursal_id) : Number(req.user.sucursal_id);
  if (!suc) return res.json([]);
  const q = `%${String(req.query.q || '').trim()}%`;
  const rows = sucEsCentral(req.db, suc)
    ? req.db.prepare('SELECT id, codigo, nombre, stock AS cantidad FROM productos WHERE stock > 0 AND (nombre LIKE ? OR codigo LIKE ?) ORDER BY nombre LIMIT 500').all(q, q)
    : req.db.prepare(`SELECT p.id, p.codigo, p.nombre, ss.cantidad FROM stock_sucursal ss JOIN productos p ON p.id = ss.producto_id
                      WHERE ss.sucursal_id = ? AND ss.cantidad > 0 AND (p.nombre LIKE ? OR p.codigo LIKE ?) ORDER BY p.nombre LIMIT 500`).all(suc, q, q);
  res.json(rows);
});

app.post('/api/remitos', authMiddleware, requierePermiso('enviar_mercaderia'), (req, res) => {
  const { destino_sucursal_id, notas, items } = req.body || {};
  const esAdmin = req.user.rol === 'admin';
  const origen = esAdmin ? Number(req.body?.origen_sucursal_id) : Number(req.user.sucursal_id);
  if (!origen) return res.status(400).json({ error: 'No se pudo determinar el origen del envío (tu usuario no tiene sucursal).' });
  if (!req.db.prepare('SELECT id FROM sucursales WHERE id=? AND activa=1').get(origen)) return res.status(400).json({ error: 'Origen inválido.' });
  const dest = req.db.prepare('SELECT id FROM sucursales WHERE id=? AND activa=1').get(destino_sucursal_id);
  if (!dest) return res.status(400).json({ error: 'Elegí un destino válido.' });
  if (dest.id === origen) return res.status(400).json({ error: 'El destino no puede ser el mismo que el origen.' });
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: 'Agregá al menos un artículo al remito.' });
  if (items.length > 100) return res.status(400).json({ error: 'Un remito admite hasta 100 líneas.' });

  const libreOk = esAdmin || permisosSucursal(req).envio_libre_habilitado;
  const lineas = [], necesario = {};
  for (const it of items) {
    const cant = Number(it.cantidad);
    if (!(cant > 0)) return res.status(400).json({ error: 'Todas las líneas necesitan una cantidad mayor a 0.' });
    if (it.producto_id) {
      const p = req.db.prepare('SELECT id, codigo, nombre FROM productos WHERE id=?').get(it.producto_id);
      if (!p) return res.status(400).json({ error: 'Hay un producto que no existe.' });
      if (!Number.isInteger(cant)) return res.status(400).json({ error: `La cantidad de "${p.nombre}" tiene que ser un número entero.` });
      necesario[p.id] = (necesario[p.id] || 0) + cant;
      lineas.push({ producto_id: p.id, descripcion: `${p.codigo} — ${p.nombre}`, cantidad: cant });
    } else {
      if (!libreOk) return res.status(403).json({ error: 'El administrador no habilitó los artículos libres en esta sucursal.' });
      const desc = String(it.descripcion || '').trim().slice(0, 200);
      if (!desc) return res.status(400).json({ error: 'Todas las líneas libres necesitan una descripción.' });
      lineas.push({ producto_id: null, descripcion: desc, cantidad: cant });
    }
  }
  for (const pid of Object.keys(necesario)) {
    const disp = stockEn(req.db, pid, origen);
    if (disp < necesario[pid]) {
      const p = req.db.prepare('SELECT nombre FROM productos WHERE id=?').get(pid);
      return res.status(400).json({ error: `Stock insuficiente de "${p.nombre}" (disponible: ${disp}, pedido: ${necesario[pid]}).` });
    }
  }
  const crear = req.db.transaction(() => {
    const r = req.db.prepare('INSERT INTO remitos (origen_sucursal_id,destino_sucursal_id,notas,usuario_envio,rol_envio) VALUES (?,?,?,?,?)')
      .run(origen, dest.id, String(notas || '').slice(0, 500), req.user?.nombre || req.user?.usuario || '', req.user.rol);
    const id = r.lastInsertRowid;
    const numero = 'RM-' + String(id).padStart(5, '0');
    req.db.prepare('UPDATE remitos SET numero=? WHERE id=?').run(numero, id);
    const ins = req.db.prepare('INSERT INTO remito_items (remito_id,producto_id,descripcion,cantidad) VALUES (?,?,?,?)');
    for (const l of lineas) {
      ins.run(id, l.producto_id, l.descripcion, l.cantidad);
      if (l.producto_id) ajustarStock(req.db, l.producto_id, origen, -l.cantidad);
    }
    return { id, numero };
  });
  const _rm = crear();
  audit(req, 'remito.crear', 'remito', _rm.id, `${_rm.numero}: ${lineas.length} línea(s) de ${nombreLugar(req.db, origen)} a ${nombreLugar(req.db, Number(destino_sucursal_id))}`);
  res.json(_rm);
});

// Lista: ?vista=pendientes (los que me toca recibir) | todos
app.get('/api/remitos', authMiddleware, (req, res) => {
  let rows = req.db.prepare(`
    SELECT r.*, so.nombre AS origen_nombre, sd.nombre AS destino_nombre,
           (SELECT COUNT(*) FROM remito_items i WHERE i.remito_id = r.id) AS lineas,
           (SELECT COALESCE(SUM(cantidad),0) FROM remito_items i WHERE i.remito_id = r.id) AS unidades
    FROM remitos r
    LEFT JOIN sucursales so ON so.id = r.origen_sucursal_id
    LEFT JOIN sucursales sd ON sd.id = r.destino_sucursal_id
    ORDER BY r.fecha_envio DESC, r.id DESC LIMIT 300`).all();
  if (req.user.rol !== 'admin') rows = rows.filter(r => remitoVisible(req, r));
  if (req.query.vista === 'pendientes') {
    rows = rows.filter(r => r.estado === 'en_transito' && (req.user.rol === 'admin' || String(r.destino_sucursal_id) === String(req.user.sucursal_id)));
  }
  res.json(rows);
});

app.get('/api/remitos/:id', authMiddleware, (req, res) => {
  const r = req.db.prepare(`
    SELECT r.*, so.nombre AS origen_nombre, sd.nombre AS destino_nombre
    FROM remitos r LEFT JOIN sucursales so ON so.id = r.origen_sucursal_id LEFT JOIN sucursales sd ON sd.id = r.destino_sucursal_id
    WHERE r.id=?`).get(req.params.id);
  if (!r || !remitoVisible(req, r)) return res.status(404).json({ error: 'Remito no encontrado' });
  r.items = req.db.prepare('SELECT * FROM remito_items WHERE remito_id=? ORDER BY id').all(r.id);
  res.json(r);
});

// Recepción línea por línea. resultado: ok | diferencia | rechazado
app.post('/api/remitos/:id/recibir', authMiddleware, (req, res) => {
  const r = req.db.prepare('SELECT * FROM remitos WHERE id=?').get(req.params.id);
  if (!r || !remitoVisible(req, r)) return res.status(404).json({ error: 'Remito no encontrado' });
  if (r.estado !== 'en_transito') return res.status(400).json({ error: 'Este remito ya fue recibido.' });
  if (req.user.rol !== 'admin' && String(r.destino_sucursal_id) !== String(req.user.sucursal_id)) {
    return res.status(403).json({ error: 'Este remito no te llega a vos — no podés recibirlo.' });
  }
  const items = req.db.prepare('SELECT * FROM remito_items WHERE remito_id=?').all(r.id);
  const lineas = Array.isArray(req.body?.lineas) ? req.body.lineas : [];
  const porId = {}; lineas.forEach(l => porId[l.id] = l);
  const decisiones = [];
  for (const it of items) {
    const l = porId[it.id];
    if (!l) return res.status(400).json({ error: `Falta confirmar la línea "${it.descripcion}".` });
    const motivo = String(l.motivo || '').trim().slice(0, 300);
    if (l.resultado === 'ok') decisiones.push({ it, resultado: 'ok', recibida: it.cantidad, motivo: '' });
    else if (l.resultado === 'rechazado') {
      if (!motivo) return res.status(400).json({ error: `Indicá el motivo del rechazo de "${it.descripcion}".` });
      decisiones.push({ it, resultado: 'rechazado', recibida: 0, motivo });
    } else if (l.resultado === 'diferencia') {
      const rec = Number(l.cantidad_recibida);
      if (!(rec >= 0) || rec === it.cantidad) return res.status(400).json({ error: `Indicá la cantidad que realmente llegó de "${it.descripcion}" (distinta de lo enviado).` });
      if (it.producto_id && !Number.isInteger(rec)) return res.status(400).json({ error: `La cantidad de "${it.descripcion}" tiene que ser entera.` });
      if (!motivo) return res.status(400).json({ error: `Indicá el motivo de la diferencia en "${it.descripcion}".` });
      decisiones.push({ it, resultado: 'diferencia', recibida: rec, motivo });
    } else return res.status(400).json({ error: `Resultado inválido en "${it.descripcion}".` });
  }
  const hacer = req.db.transaction(() => {
    for (const d of decisiones) {
      req.db.prepare('UPDATE remito_items SET cantidad_recibida=?, resultado=?, motivo=? WHERE id=?').run(d.recibida, d.resultado, d.motivo, d.it.id);
      if (d.it.producto_id) {
        if (d.recibida > 0) ajustarStock(req.db, d.it.producto_id, r.destino_sucursal_id, d.recibida);
        if (d.resultado === 'rechazado') ajustarStock(req.db, d.it.producto_id, r.origen_sucursal_id, d.it.cantidad); // vuelve al origen
      }
    }
    const todosRech = decisiones.every(d => d.resultado === 'rechazado');
    const todosOk = decisiones.every(d => d.resultado === 'ok');
    const estado = todosOk ? 'recibido' : (todosRech ? 'devuelto' : 'recibido_con_diferencias');
    req.db.prepare('UPDATE remitos SET estado=?, usuario_recepcion=?, fecha_recepcion=CURRENT_TIMESTAMP, notas_recepcion=? WHERE id=?')
      .run(estado, req.user?.nombre || req.user?.usuario || '', String(req.body?.notas || '').slice(0, 500), r.id);
    return estado;
  });
  const _est = hacer();
  audit(req, 'remito.recibir', 'remito', r.id, `${r.numero} → ${_est}`);
  res.json({ ok: true, estado: _est });
});

// Historial de movimientos entre sucursales (para el dashboard del dueño)
app.get('/api/sucursales/movimientos', authMiddleware, (req, res) => {
  const movs = req.db.prepare(`
    SELECT m.*, p.codigo, p.nombre as producto_nombre,
           so.nombre as sucursal_origen_nombre, sd.nombre as sucursal_destino_nombre
    FROM movimientos_sucursal m
    JOIN productos p ON m.producto_id = p.id
    LEFT JOIN sucursales so ON m.sucursal_origen_id = so.id
    LEFT JOIN sucursales sd ON m.sucursal_destino_id = sd.id
    ORDER BY m.fecha DESC LIMIT 200
  `).all();
  res.json(movs);
});

// Dashboard consolidado por sucursal — ventas, totales, gráficos (vista del dueño)
app.get('/api/sucursales/dashboard', authMiddleware, adminOnly, (req, res) => {
  const desde = seguridad.soloFecha(req.query.desde), hasta = seguridad.soloFecha(req.query.hasta);
  let filtroFecha = '';
  const params = [];
  if (desde && hasta) {
    filtroFecha = 'AND date(c.fecha) BETWEEN ? AND ?';
    params.push(desde, hasta);
  }

  const ventasPorSucursal = req.db.prepare(`
    SELECT s.id as sucursal_id, s.nombre as sucursal_nombre,
           COUNT(c.id) as cantidad_ventas,
           COALESCE(SUM(c.total),0) as total_facturado
    FROM sucursales s
    LEFT JOIN comprobantes c ON c.sucursal_id = s.id AND c.estado != 'anulado' ${filtroFecha}
    WHERE s.activa = 1 AND s.es_deposito_central = 0
    GROUP BY s.id ORDER BY total_facturado DESC
  `).all(...params);

  const stockPorSucursal = req.db.prepare(`
    SELECT s.id as sucursal_id, s.nombre as sucursal_nombre,
           COALESCE(SUM(ss.cantidad),0) as total_unidades,
           COUNT(DISTINCT ss.producto_id) as productos_distintos
    FROM sucursales s
    LEFT JOIN stock_sucursal ss ON ss.sucursal_id = s.id
    WHERE s.activa = 1 AND s.es_deposito_central = 0
    GROUP BY s.id
  `).all();

  res.json({ ventasPorSucursal, stockPorSucursal });
});

// ─── EXPORTAR A EXCEL (CSV compatible con Excel) ─────────────────────────────

function toCSV(headers, rows) {
  const escape = v => {
    if (v === null || v === undefined) return '';
    const s = String(v);
    return s.includes(',') || s.includes('"') || s.includes('\n')
      ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [headers, ...rows].map(r => r.map(escape).join(',')).join('\r\n');
}

app.get('/api/export/ordenes', authMiddleware, (req, res) => {
  const data = req.db.prepare(`
    SELECT o.numero, c.nombre as cliente, c.telefono, o.equipo, o.marca, o.modelo,
           o.serie, o.estado, o.prioridad, o.tecnico, o.falla_reportada, o.diagnostico,
           o.mano_obra, o.total_repuestos, o.total, o.cobrado,
           o.fecha_ingreso, o.fecha_entrega, o.notas
    FROM ordenes o LEFT JOIN clientes c ON o.cliente_id = c.id
    ORDER BY o.fecha_ingreso DESC
  `).all();
  const headers = ['N° Orden','Cliente','Teléfono','Equipo','Marca','Modelo','Serie','Estado','Prioridad','Técnico','Falla Reportada','Diagnóstico','Mano de Obra','Total Repuestos','Total','Cobrado','Fecha Ingreso','Fecha Entrega','Notas'];
  const rows = data.map(o => [o.numero,o.cliente,o.telefono,o.equipo,o.marca,o.modelo,o.serie,o.estado,o.prioridad,o.tecnico,o.falla_reportada,o.diagnostico,o.mano_obra,o.total_repuestos,o.total,o.cobrado?'Sí':'No',o.fecha_ingreso,o.fecha_entrega,o.notas]);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="ordenes.csv"');
  res.send('\uFEFF' + toCSV(headers, rows));
});

app.get('/api/export/stock', authMiddleware, (req, res) => {
  const data = req.db.prepare('SELECT * FROM productos ORDER BY nombre').all();
  const headers = ['Código','Nombre','Categoría','Stock','Stock Mínimo','Precio Costo','Precio Venta'];
  const rows = data.map(p => [p.codigo,p.nombre,p.categoria,p.stock,p.stock_minimo,p.precio_costo,p.precio_venta]);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="stock.csv"');
  res.send('\uFEFF' + toCSV(headers, rows));
});

app.get('/api/export/clientes', authMiddleware, (req, res) => {
  const data = req.db.prepare('SELECT * FROM clientes ORDER BY nombre').all();
  const headers = ['Nombre','Teléfono','Email','Dirección','Fecha Alta'];
  const rows = data.map(c => [c.nombre,c.telefono,c.email,c.direccion,c.created_at]);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="clientes.csv"');
  res.send('\uFEFF' + toCSV(headers, rows));
});

app.get('/api/export/movimientos', authMiddleware, (req, res) => {
  const data = req.db.prepare(`
    SELECT m.fecha, p.codigo, p.nombre, m.tipo, m.cantidad, m.motivo
    FROM movimientos_stock m JOIN productos p ON m.producto_id = p.id
    ORDER BY m.fecha DESC
  `).all();
  const headers = ['Fecha','Código','Producto','Tipo','Cantidad','Motivo'];
  const rows = data.map(m => [m.fecha,m.codigo,m.nombre,m.tipo,m.cantidad,m.motivo]);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="movimientos.csv"');
  res.send('\uFEFF' + toCSV(headers, rows));
});

// ─── IMPRESORAS ───────────────────────────────────────────────────────────────


app.get('/api/impresoras', authMiddleware, (req, res) => {
  res.json(req.db.prepare('SELECT * FROM impresoras WHERE activa=1 ORDER BY predeterminada DESC').all());
});

app.post('/api/impresoras', authMiddleware, adminOnly, (req, res) => {
  const { nombre, tipo, ancho, ubicacion, predeterminada } = req.body;
  if (predeterminada) req.db.prepare("UPDATE impresoras SET predeterminada=0 WHERE tipo=?").run(tipo);
  const r = req.db.prepare('INSERT INTO impresoras (nombre,tipo,ancho,ubicacion,predeterminada) VALUES (?,?,?,?,?)').run(nombre,tipo,ancho||'80mm',ubicacion||'caja',predeterminada?1:0);
  res.json({ id: r.lastInsertRowid });
});

app.put('/api/impresoras/:id', authMiddleware, adminOnly, (req, res) => {
  const { nombre, tipo, ancho, ubicacion, predeterminada } = req.body;
  if (predeterminada) req.db.prepare("UPDATE impresoras SET predeterminada=0 WHERE tipo=?").run(tipo);
  req.db.prepare('UPDATE impresoras SET nombre=?,tipo=?,ancho=?,ubicacion=?,predeterminada=? WHERE id=?').run(nombre,tipo,ancho,ubicacion,predeterminada?1:0,req.params.id);
  res.json({ ok: true });
});

app.delete('/api/impresoras/:id', authMiddleware, adminOnly, (req, res) => {
  req.db.prepare('UPDATE impresoras SET activa=0 WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// Datos para imprimir orden
app.get('/api/print/orden/:id', authMiddleware, (req, res) => {
  const o = req.db.prepare(`SELECT o.*,c.nombre as cliente_nombre,c.telefono as cliente_telefono,c.email as cliente_email,c.direccion as cliente_direccion FROM ordenes o LEFT JOIN clientes c ON o.cliente_id=c.id WHERE o.id=?`).get(req.params.id);
  if (!o) return res.status(404).json({ error: 'No encontrado' });
  o.repuestos = req.db.prepare(`SELECT or2.*,p.nombre as producto_nombre,p.codigo as producto_codigo FROM orden_repuestos or2 JOIN productos p ON or2.producto_id=p.id WHERE or2.orden_id=?`).all(req.params.id);
  const cfg = {};
  req.db.prepare('SELECT * FROM config').all().forEach(r => cfg[r.clave]=r.valor);
  o.empresa = { nombre: cfg.empresa_nombre||'Servicio Técnico', direccion: cfg.empresa_direccion||'', telefono: cfg.empresa_telefono||'', email: cfg.empresa_email||'', whatsapp: cfg.empresa_whatsapp||'' };
  res.json(o);
});

// ─── AUTOMATIZACIÓN DE MENSAJES ──────────────────────────────────────────────
const nodemailer = require('nodemailer');

// Tabla de configuración de automatización


// Función para reemplazar variables en plantilla
function procesarPlantilla(texto, datos) {
  return texto
    .replace(/{nombre}/g, datos.cliente_nombre || 'Cliente')
    .replace(/{equipo}/g, datos.equipo || '')
    .replace(/{marca}/g, datos.marca || '')
    .replace(/{modelo}/g, datos.modelo || '')
    .replace(/{numero}/g, datos.numero || '')
    .replace(/{falla}/g, datos.falla_reportada || '')
    .replace(/{total}/g, (datos.total || 0).toFixed(0))
    .replace(/{empresa}/g, datos.empresa_nombre || 'Servicio Técnico')
    .replace(/{direccion}/g, datos.empresa_direccion || '')
    .replace(/{telefono}/g, datos.empresa_telefono || '')
    .replace(/{link_cliente}/g, datos.link_cliente || '')
    .replace(/\s+/g, ' ').trim();
}

// Función enviar email
// MEJORAS-1.7.2: el servidor se deduce del correo (Gmail, Outlook, Yahoo) y los errores se explican
const SMTP_CONOCIDOS = { 'gmail.com': ['smtp.gmail.com', 587], 'googlemail.com': ['smtp.gmail.com', 587], 'outlook.com': ['smtp-mail.outlook.com', 587], 'hotmail.com': ['smtp-mail.outlook.com', 587], 'live.com': ['smtp-mail.outlook.com', 587], 'yahoo.com': ['smtp.mail.yahoo.com', 465], 'yahoo.com.ar': ['smtp.mail.yahoo.com', 465] };
function datosCorreo(config) {
  const user = String(config.smtp_user || '').trim(), pass = String(config.smtp_pass || '').replace(/\s+/g, '');
  const conocido = SMTP_CONOCIDOS[(user.split('@')[1] || '').toLowerCase()];
  const host = String(config.smtp_host || '').trim() || (conocido && conocido[0]) || '';
  const port = parseInt(config.smtp_port) || (conocido && conocido[1]) || 587;
  return { user, pass, host, port };
}
function errorCorreo(e) {
  const m = String((e && (e.code || '')) + ' ' + (e && e.message || ''));
  if (/EAUTH|535|534|Invalid login|Username and Password not accepted/i.test(m)) return 'El correo o la clave no son correctos. En Gmail tiene que ser una «clave de aplicación» de 16 letras, no la clave normal.';
  if (/ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ETIMEDOUT|ESOCKET|getaddrinfo/i.test(m)) return 'No hay conexión con el servidor de correo. Revisá que haya internet.';
  if (/no configurado/i.test(m)) return 'Falta configurar el correo del negocio (Configuración → Empresa).';
  return 'No se pudo enviar el correo: ' + String(e && e.message || e).slice(0, 160);
}
async function enviarEmail(destino, asunto, htmlBody, config) {
  const c = datosCorreo(config);
  if (!c.host || !c.user || !c.pass) throw new Error('Correo no configurado');
  const transporter = nodemailer.createTransport({
    host: c.host,
    port: c.port,
    secure: c.port === 465,
    auth: { user: c.user, pass: c.pass }
  });
  await transporter.sendMail({
    from: `"${config.empresa_nombre || 'Servicio Técnico'}" <${c.user}>`,
    replyTo: config.empresa_email || c.user,
    to: destino, subject: asunto,
    html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;border:1px solid #eee;border-radius:8px">${htmlBody}<hr style="margin-top:30px;border:none;border-top:1px solid #eee"><p style="font-size:11px;color:#888;text-align:center">${config.empresa_nombre || ''} · ${config.empresa_direccion || ''} · ${config.empresa_telefono || ''}</p></div>`
  });
}

// GET config automatización
app.get('/api/automatizacion', authMiddleware, (req, res) => {
  res.json(req.db.prepare('SELECT * FROM automatizacion ORDER BY id').all());
});

// PUT actualizar config de un evento
app.put('/api/automatizacion/:evento', authMiddleware, adminOnly, (req, res) => {
  const { activo, canal, modo, plantilla_wa, plantilla_email, asunto_email } = req.body;
  req.db.prepare('UPDATE automatizacion SET activo=?,canal=?,modo=?,plantilla_wa=?,plantilla_email=?,asunto_email=? WHERE evento=?')
    .run(activo?1:0, canal, modo, plantilla_wa, plantilla_email, asunto_email, req.params.evento);
  res.json({ ok: true });
});

// POST disparar automatización manualmente (con preview)
app.post('/api/automatizacion/preview', authMiddleware, (req, res) => {
  const { orden_id, evento } = req.body;
  const o = req.db.prepare(`SELECT o.*,c.nombre as cliente_nombre,c.telefono as cliente_telefono,c.email as cliente_email FROM ordenes o LEFT JOIN clientes c ON o.cliente_id=c.id WHERE o.id=?`).get(orden_id);
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  const cfg = {};
  req.db.prepare('SELECT * FROM config').all().forEach(r => cfg[r.clave]=r.valor);
  const auto = req.db.prepare('SELECT * FROM automatizacion WHERE evento=?').get(evento);
  if (!auto) return res.status(404).json({ error: 'Evento no encontrado' });
  const datos = { ...o, empresa_nombre: cfg.empresa_nombre, empresa_direccion: cfg.empresa_direccion, empresa_telefono: cfg.empresa_telefono, link_cliente: `http://${LOCAL_IP}:${PORT}/cliente/` };
  res.json({
    wa: procesarPlantilla(auto.plantilla_wa || '', datos),
    email: procesarPlantilla(auto.plantilla_email || '', datos),
    asunto: procesarPlantilla(auto.asunto_email || '', datos),
    cliente_telefono: o.cliente_telefono,
    cliente_email: o.cliente_email,
    canal: auto.canal,
    modo: auto.modo
  });
});

// POST enviar automáticamente
app.post('/api/automatizacion/enviar', authMiddleware, async (req, res) => {
  const { orden_id, evento, canal_override } = req.body;
  const o = req.db.prepare(`SELECT o.*,c.nombre as cliente_nombre,c.telefono as cliente_telefono,c.email as cliente_email FROM ordenes o LEFT JOIN clientes c ON o.cliente_id=c.id WHERE o.id=?`).get(orden_id);
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  const cfg = {};
  req.db.prepare('SELECT * FROM config').all().forEach(r => cfg[r.clave]=r.valor);
  const auto = req.db.prepare('SELECT * FROM automatizacion WHERE evento=?').get(evento);
  if (!auto || !auto.activo) return res.json({ ok: false, msg: 'Automatización inactiva' });
  const datos = { ...o, empresa_nombre: cfg.empresa_nombre, empresa_direccion: cfg.empresa_direccion, empresa_telefono: cfg.empresa_telefono, link_cliente: `http://${LOCAL_IP}:${PORT}/cliente/` };
  const canal = canal_override || auto.canal;
  const resultados = [];

  // WhatsApp
  if ((canal === 'whatsapp' || canal === 'ambos') && o.cliente_telefono) {
    const msg = procesarPlantilla(auto.plantilla_wa || '', datos);
    const waUrl = telefono.enlaceWhatsApp(o.cliente_telefono, msg, cfg.pais_telefono || '54');   // MEJORAS-1.7.2
    if (!waUrl) { resultados.push({ canal: 'whatsapp', estado: 'error', error: `El teléfono «${o.cliente_telefono}» no es válido. Revisalo en la ficha del cliente (con código de área).` }); }
    else {
    req.db.prepare('INSERT INTO log_automatizacion (orden_id,evento,canal,estado,detalle) VALUES (?,?,?,?,?)').run(orden_id,evento,'whatsapp','enviado',msg);
    req.db.prepare('INSERT INTO notificaciones (orden_id,medio,mensaje) VALUES (?,?,?)').run(orden_id,'whatsapp',msg);
    resultados.push({ canal: 'whatsapp', url: waUrl, mensaje: msg });
    }
  }

  // Email
  if ((canal === 'email' || canal === 'ambos') && o.cliente_email) {
    const htmlBody = procesarPlantilla(auto.plantilla_email || '', datos);
    const asunto = procesarPlantilla(auto.asunto_email || '', datos);
    try {
      await enviarEmail(o.cliente_email, asunto, htmlBody, { ...cfg });
      req.db.prepare('INSERT INTO log_automatizacion (orden_id,evento,canal,estado,detalle) VALUES (?,?,?,?,?)').run(orden_id,evento,'email','enviado',asunto);
      req.db.prepare('INSERT INTO notificaciones (orden_id,medio,mensaje) VALUES (?,?,?)').run(orden_id,'email',asunto);
      resultados.push({ canal: 'email', estado: 'enviado' });
    } catch(e) {
      req.db.prepare('INSERT INTO log_automatizacion (orden_id,evento,canal,estado,detalle) VALUES (?,?,?,?,?)').run(orden_id,evento,'email','error',e.message);
      resultados.push({ canal: 'email', estado: 'error', error: e.message });
    }
  }
  res.json({ ok: true, resultados });
});

// GET log
app.get('/api/automatizacion/log', authMiddleware, (req, res) => {
  res.json(req.db.prepare('SELECT l.*,o.numero FROM log_automatizacion l LEFT JOIN ordenes o ON l.orden_id=o.id ORDER BY l.fecha DESC LIMIT 100').all());
});

// ─── FACTURACIÓN / PRESUPUESTOS ──────────────────────────────────────────────
// GET config fiscal "operativa" — para cualquier rol autenticado (cajera
// incluida). Solo devuelve lo mínimo que hace falta para cobrar (si aplica
// IVA, el pie de ticket) SIN exponer CUIT, razón social, dirección fiscal,
// logo ni certificados — eso queda exclusivamente en el endpoint de abajo,
// que ahora es adminOnly.
app.get('/api/fiscal/config/operativo', authMiddleware, (req, res) => {
  const cfg = {};
  req.db.prepare('SELECT * FROM config_fiscal').all().forEach(r => cfg[r.clave] = r.valor);
  const sucursalId = req.query.sucursal_id ? Number(req.query.sucursal_id) : null;
  if (sucursalId) {
    req.db.prepare('SELECT * FROM config_fiscal_sucursal WHERE sucursal_id=?').all(sucursalId).forEach(r => cfg[r.clave] = r.valor);
  }
  res.json({ condicion_iva: cfg.condicion_iva || 'Monotributo', pie_factura: cfg.pie_factura || '' });
});

// GET config fiscal — solo admin. Antes cualquier rol autenticado (incluida
// una cajera) podía pedir este endpoint y ver CUIT, razón social, logo, etc.
// Ahora exige adminOnly como ya exigía el PUT.
// ?sucursal_id=X trae la config global con los overrides de esa sucursal
// pisados encima (punto de venta/numeración propios, si el admin los definió).
app.get('/api/fiscal/config', authMiddleware, adminOnly, (req, res) => {
  const cfg = {};
  req.db.prepare('SELECT * FROM config_fiscal').all().forEach(r => cfg[r.clave] = r.valor);
  const sucursalId = req.query.sucursal_id ? Number(req.query.sucursal_id) : null;
  const sucursalesConOverride = {};
  if (sucursalId) {
    req.db.prepare('SELECT * FROM config_fiscal_sucursal WHERE sucursal_id=?').all(sucursalId).forEach(r => { cfg[r.clave] = r.valor; sucursalesConOverride[r.clave] = true; });
  }
  res.json({ ...cfg, _overrides: sucursalesConOverride });
});

// PUT config fiscal — si el body trae sucursal_id, los valores se guardan como
// override de ESA sucursal (config_fiscal_sucursal) en vez de pisar la config
// global; así cada sucursal puede tener su propio punto de venta/numeración
// de AFIP, decidido por el admin, sin afectar a las demás.
app.put('/api/fiscal/config', authMiddleware, adminOnly, (req, res) => {
  const { sucursal_id, ...resto } = req.body;
  Object.entries(resto).forEach(([k,v]) => {
    if (sucursal_id) {
      req.db.prepare('INSERT OR REPLACE INTO config_fiscal_sucursal (sucursal_id,clave,valor) VALUES (?,?,?)').run(Number(sucursal_id), k, v);
    } else {
      req.db.prepare('INSERT OR REPLACE INTO config_fiscal (clave,valor) VALUES (?,?)').run(k, v);
    }
  });
  res.json({ ok: true });
});

// GET comprobantes — el admin ve todas las sucursales y puede filtrar; un
// usuario no-admin solo ve los comprobantes de SU sucursal asignada, sin
// importar qué filtro mande (nunca se confía en el query del cliente para
// decidir qué sucursal ve alguien que no es admin).
app.get('/api/comprobantes', authMiddleware, (req, res) => {
  const { sucursal_id, desde, hasta, tipo, vendedor_codigo } = req.query;
  const where = [];
  const params = [];
  if (req.user.rol !== 'admin') {
    where.push('sucursal_id = ?');
    params.push(req.user.sucursal_id || null);
  } else if (sucursal_id) {
    where.push('sucursal_id = ?');
    params.push(sucursal_id);
  }
  if (desde && hasta) { where.push('date(fecha) BETWEEN ? AND ?'); params.push(desde, hasta); }
  if (req.user.rol === 'caja') where.push("tipo IN ('presupuesto','nota_credito')");
  if (tipo) { where.push('tipo = ?'); params.push(tipo); }
  if (vendedor_codigo) { where.push('vendedor_codigo = ?'); params.push(vendedor_codigo); }
  const sql = `SELECT * FROM comprobantes ${where.length ? 'WHERE '+where.join(' AND ') : ''} ORDER BY fecha DESC`;
  const filas = req.db.prepare(sql).all(...params);
  if (req.user.rol !== 'admin') filas.forEach(f => { delete f.retiro_codigo; });
  res.json(filas);
});

app.get('/api/comprobantes/:id', authMiddleware, (req, res) => {
  const c = req.db.prepare('SELECT * FROM comprobantes WHERE id=?').get(req.params.id);
  if (!c) return res.status(404).json({ error: 'No encontrado' });
  c.items = JSON.parse(c.items || '[]');
  if (req.user.rol !== 'admin') delete c.retiro_codigo;
  res.json(c);
});

// POST crear comprobante
// Medios de pago válidos en Argentina para el split de pagos
const MEDIOS_PAGO_VALIDOS = ['Efectivo','Débito','Crédito','Transferencia','Mercado Pago','Cuenta Corriente'];

app.post('/api/comprobantes', authMiddleware, (req, res) => {
  const { tipo, letra, orden_id, cliente_id, cliente_nombre, cliente_apellido,
    cliente_doc_tipo, cliente_doc_numero, cliente_condicion_iva, cliente_direccion,
    items, descuento, condicion_pago, notas, condicion_iva_emisor, sucursal_id: sucursalPedida, pagos, vendedor_codigo, retiro } = req.body;
  // 1.7.4: quien no es admin emite SIEMPRE en su sucursal asignada (igual que la lista de
  // comprobantes, que solo le muestra los de su sucursal). Solo el admin elige el local.
  const sucursal_id = req.user.rol === 'admin' ? sucursalPedida : (req.user.sucursal_id || null);

  // Pagos múltiples: si viene el array "pagos" ([{medio_pago, monto}]), lo
  // validamos acá. Si no viene, se sigue aceptando el string condicion_pago
  // de siempre (compatibilidad con comprobantes viejos / presupuestos sin pago).
  let pagosArr = Array.isArray(pagos) ? pagos.filter(p => p && p.monto > 0) : [];
  for (const p of pagosArr) {
    if (!MEDIOS_PAGO_VALIDOS.includes(p.medio_pago)) {
      return res.status(400).json({ error: `Medio de pago inválido: ${p.medio_pago}` });
    }
  }

  // No todos los talleres facturan/cobran — si el admin desactivó la
  // facturación para esta sucursal, solo puede emitir Presupuesto o Nota de
  // Entrega (entregar el equipo al cliente sin que sea un cobro real).
  // Esto se valida siempre en el servidor, nunca confiando en el frontend.
  // Caja cobra: Factura, Nota de Entrega, Presupuesto y Nota de Crédito. La Nota de Débito la emite el administrador.
  if (req.user.rol === 'caja' && !['presupuesto', 'nota_credito', 'factura', 'nota_entrega'].includes(tipo)) {
    return res.status(403).json({ error: 'Desde Caja se emiten Presupuestos, Notas de Entrega, Facturas y Notas de Crédito.' });
  }
  if (req.user.rol === 'taller') {
    const facturaHabilitada = permisosSucursal(req).factura_habilitada;
    if (!facturaHabilitada && tipo !== 'presupuesto' && tipo !== 'nota_entrega') {
      return res.status(403).json({ error: 'El administrador no habilitó el cobro/facturación en este taller. Solo podés hacer Presupuesto o Nota de Entrega.' });
    }
  }

  // Admin: Factura / Nota de Entrega siempre a nombre de un local concreto y
  // con la caja de ese local abierta (así las cuentas cuadran y el cajero sabe).
  const desdeAdmin = req.user.rol === 'admin' ? 1 : 0;
  // Venta con retiro en otro local: solo el admin; el cobro ya se hizo por fuera
  // (redes/plataforma), no entra efectivo al cajón. sucursal_id = local de retiro.
  const esRetiro = !!retiro;
  if (esRetiro) {
    if (!desdeAdmin) return res.status(403).json({ error: 'Solo un administrador puede registrar una venta con retiro en otro local.' });
    if (tipo !== 'factura' && tipo !== 'nota_entrega') return res.status(400).json({ error: 'La venta con retiro es una Factura o una Nota de Entrega.' });
    if (!pagosArr.length) return res.status(400).json({ error: 'Indicá con qué medio se cobró (cobro externo).' });
    const MEDIOS_EXT = ['Débito', 'Crédito', 'Transferencia', 'Mercado Pago'];
    if (pagosArr.some(p => !MEDIOS_EXT.includes(p.medio_pago))) {
      return res.status(400).json({ error: 'El cobro externo solo admite Débito, Crédito, Transferencia o Mercado Pago (el efectivo se cobra en la caja del local).' });
    }
  }
  if (desdeAdmin && (tipo === 'factura' || tipo === 'nota_entrega')) {
    const sucAdm = sucursal_id ? req.db.prepare('SELECT id,nombre,es_deposito_central FROM sucursales WHERE id=?').get(sucursal_id) : null;
    if (!sucAdm || sucAdm.es_deposito_central) {
      return res.status(400).json({ error: 'Elegí el local desde el que se factura. Desde el Depósito Central no se emiten Facturas ni Notas de Entrega.' });
    }
    const cajaLocal = esRetiro ? true : req.db.prepare(`SELECT id FROM caja_sesiones WHERE estado='abierta' AND (sucursal_id=? OR sucursal_id IS NULL) LIMIT 1`).get(sucursal_id);
    if (!cajaLocal) {
      return res.status(409).json({ error: `La caja de "${sucAdm.nombre}" está cerrada. Pedile al cajero que la abra para poder facturar.` });
    }
  }

  // Calcular totales
  const itemsArr = items || [];
  // Stock: una Factura/Nota de Entrega saca mercadería del lugar de quien vende; una Nota de Crédito
  // la devuelve. Presupuestos y Notas de Débito no mueven stock. Se verifica ANTES de numerar el comprobante.
  const stockDir = (tipo === 'factura' || tipo === 'nota_entrega') ? -1 : (tipo === 'nota_credito' ? 1 : 0);
  const lugarStock = lugarDeStock(req, sucursal_id);
  const lineasStock = {};
  if (stockDir) itemsArr.forEach(i => {
    const pid = Number(i._producto_id || i.producto_id || 0), c = Number(i.cantidad);
    if (pid && c > 0) lineasStock[pid] = (lineasStock[pid] || 0) + c;
  });
  if (stockDir === -1) {
    for (const [pid, c] of Object.entries(lineasStock)) {
      const disp = stockDisponible(req.db, Number(pid), lugarStock);
      if (disp < c) {
        const pn = req.db.prepare('SELECT nombre FROM productos WHERE id=?').get(pid)?.nombre || ('#' + pid);
        return res.status(400).json({ error: `Stock insuficiente de "${pn}" en ${nombreLugar(req.db, lugarStock)}. Disponible: ${disp}, pedido: ${c}.` });
      }
    }
  }
  const subtotal = itemsArr.reduce((sum, i) => sum + (i.cantidad * i.precio_unitario), 0);
  const desc = descuento || 0;
  const baseImponible = subtotal - desc;
  let iva_porcentaje = 0;
  let iva_monto = 0;
  // Nota de Entrega SÍ es una venta real (se cobra en el momento y mueve caja),
  // pero no es un comprobante fiscal con CAE, así que no calcula IVA — igual
  // que un Presupuesto en ese sentido. Solo Factura calcula IVA.
  if (condicion_iva_emisor === 'Responsable Inscripto' && tipo !== 'presupuesto' && tipo !== 'nota_entrega') {
    iva_porcentaje = 21;
    iva_monto = baseImponible * 0.21;
  }
  const total = baseImponible + iva_monto;

  // Si vino el split de pagos, tiene que cubrir el total del comprobante
  // (el presupuesto no lleva pago real, así que no se exige ahí)
  if (pagosArr.length && tipo !== 'presupuesto') {
    const sumaPagos = pagosArr.reduce((s,p) => s + Number(p.monto||0), 0);
    if (Math.abs(sumaPagos - total) > 0.5) {
      return res.status(400).json({ error: `Los pagos ingresados (${sumaPagos.toFixed(2)}) no coinciden con el total (${total.toFixed(2)}).` });
    }
  }
  // Texto de condición de pago legible, derivado del split si existe
  const condicionPagoFinal = pagosArr.length
    ? pagosArr.map(p => `${p.medio_pago} $${Number(p.monto).toFixed(2)}`).join(' + ')
    : (condicion_pago || 'Contado');

  // Número correlativo — cada tipo de comprobante lleva su propio contador,
  // independiente (antes, Factura C y Nota de Débito caían por error en el
  // mismo contador que Nota de Crédito, pisándose los números entre sí).
  const tipoKey = tipo === 'presupuesto' ? 'proximo_numero_presupuesto' :
    tipo === 'nota_entrega' ? 'proximo_numero_nota_entrega' :
    tipo === 'factura' && letra === 'A' ? 'proximo_numero_factura_a' :
    tipo === 'factura' && letra === 'B' ? 'proximo_numero_factura_b' :
    tipo === 'factura' && letra === 'C' ? 'proximo_numero_factura_c' :
    tipo === 'nota_debito' ? 'proximo_numero_nota_debito' :
    tipo === 'nota_credito' ? 'proximo_numero_nota_credito' :
    'proximo_numero_presupuesto'; // resguardo: nunca compartir contador con Notas de Crédito por error
  // Cada sucursal puede tener su propio punto de venta/numeración (si el admin
  // lo configuró); si no, usa el global — así no se rompe una instalación de
  // un solo local, y una sucursal con numeración propia no pisa a las demás.
  const proximoFiscal = fiscalGet(req.db, sucursal_id, tipoKey);
  const numComp = parseInt(proximoFiscal.valor || '1');
  const pv = fiscalGet(req.db, sucursal_id, 'punto_venta').valor || '1';
  const pvPad = String(pv).padStart(4,'0');
  const numPad = String(numComp).padStart(8,'0');
  // El prefijo tiene que distinguir tipo de comprobante, no solo letra — antes,
  // una Factura C y una Nota de Crédito C podían generar el mismo número interno
  // (ej: las dos primeras de cada tipo daban "C0001-00000001"), y como el campo
  // es único en la base, la segunda fallaba con error de SQLite.
  const TIPO_ABREV = { presupuesto: 'PRES', factura: 'FC', nota_credito: 'NC', nota_debito: 'ND', nota_entrega: 'ENT' };
  const prefijo = tipo === 'presupuesto' ? 'PRES' : `${TIPO_ABREV[tipo] || tipo.toUpperCase()}-${letra || 'X'}${pvPad}`;
  const numero = `${prefijo}-${numPad}`;

  // Actualizar próximo número (INSERT OR REPLACE: nunca falla en silencio
  // aunque la fila no exista todavía, a diferencia de un UPDATE simple).
  // Si la sucursal tiene numeración propia, el contador avanza en SU fila;
  // si no, avanza en la global, igual que antes.
  fiscalSet(req.db, sucursal_id, tipoKey, numComp + 1, proximoFiscal.scoped);

  const r = req.db.prepare(`INSERT INTO comprobantes
    (numero,tipo,letra,punto_venta,numero_comp,orden_id,cliente_id,cliente_nombre,cliente_apellido,
     cliente_doc_tipo,cliente_doc_numero,cliente_condicion_iva,cliente_direccion,
     items,subtotal,descuento,iva_porcentaje,iva_monto,total,condicion_pago,notas,estado,sucursal_id,vendedor_codigo,
     generado_por_usuario,generado_por_rol,desde_admin)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'borrador',?,?,?,?,?)`
  ).run(numero,tipo,letra||'X',parseInt(pv),numComp,orden_id||null,cliente_id||null,
    cliente_nombre||'',cliente_apellido||'',cliente_doc_tipo||'DNI',cliente_doc_numero||'',
    cliente_condicion_iva||'Consumidor Final',cliente_direccion||'',
    JSON.stringify(itemsArr),subtotal,desc,iva_porcentaje,iva_monto,total,
    condicionPagoFinal,notas||'',sucursal_id||null,vendedor_codigo||null,
    req.user?.nombre||null,req.user?.rol||null,desdeAdmin);

  const comprobanteId = r.lastInsertRowid;

  // Venta con retiro: código de entrega de un solo uso (6 caracteres sin
  // ambigüedades) que el cajero del local ingresa para entregar.
  let retiroCodigo = null;
  if (esRetiro) {
    const ALFA = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
    for (let intento = 0; intento < 20 && !retiroCodigo; intento++) {
      let cod = '';
      for (let i = 0; i < 6; i++) cod += ALFA[crypto.randomInt(ALFA.length)];
      if (!req.db.prepare('SELECT 1 FROM comprobantes WHERE retiro_codigo=?').get(cod)) retiroCodigo = cod;
    }
    req.db.prepare(`UPDATE comprobantes SET cobro_externo=1, retiro_codigo=?, retiro_estado='pendiente' WHERE id=?`).run(retiroCodigo, comprobanteId);
  }

  // Mover el stock del lugar que corresponde y dejar constancia
  if (stockDir && Object.keys(lineasStock).length) {
    for (const [pid, c] of Object.entries(lineasStock)) {
      moverStock(req.db, Number(pid), lugarStock, stockDir * c);
      regMovStock(req.db, Number(pid), stockDir === -1 ? 'salida' : 'entrada', c, `${stockDir === -1 ? 'Venta' : 'Devolución'} ${numero}`, lugarStock, req.user.nombre);
    }
    req.db.prepare('UPDATE comprobantes SET stock_movido=1, stock_sucursal_id=? WHERE id=?').run(lugarStock, comprobanteId);
  }
  tienda.registrarFondoVenta(req.db, comprobanteId, tipo, itemsArr);   // costo real + reserva del fondo de garantía
  const _resumenItems = itemsArr.map(i => `${i.cantidad}× ${String(i.descripcion || '').slice(0, 40)}`).join(', ').slice(0, 220);
  const _resumenPagos = pagosArr.map(p => `${p.medio_pago} $${Number(p.monto)}`).join(' + ');
  audit(req, 'comprobante.crear', 'comprobante', comprobanteId, `${numero} (${tipo}) total $${total} · ${nombreLugar(req.db, lugarStock)} · cliente: ${[cliente_nombre, cliente_apellido].filter(Boolean).join(' ') || '-'} · ítems: ${_resumenItems || '-'}${_resumenPagos ? ' · pagos: ' + _resumenPagos : ''}${desdeAdmin ? ' — DESDE ADMIN en ' + nombreLugar(req.db, sucursal_id || null) : ''}${esRetiro ? ' — RETIRO en ese local, cobro externo' : ''}`);

  // Guardar el detalle del split de pagos
  if (pagosArr.length) {
    const insPago = req.db.prepare('INSERT INTO comprobante_pagos (comprobante_id,medio_pago,monto) VALUES (?,?,?)');
    pagosArr.forEach(p => insPago.run(comprobanteId, p.medio_pago, Number(p.monto)));

    // Si hay una caja abierta y el comprobante mueve plata real, cada medio de
    // pago queda asentado en caja — como ingreso (factura/nota de entrega/nota
    // de débito) o como egreso (nota de crédito: se le devuelve dinero al cliente).
    // Si NO hay caja abierta, el comprobante se emite igual (no se bloquea la
    // venta), pero avisamos al frontend para que el usuario sepa que esta
    // plata no va a aparecer en ningún cierre de caja.
    if (tipo !== 'presupuesto' && !esRetiro) {
      const cajaAbierta = req.db.prepare(`SELECT id FROM caja_sesiones WHERE estado='abierta' ${sucursal_id ? 'AND (sucursal_id=? OR sucursal_id IS NULL)' : ''} ORDER BY id DESC LIMIT 1`)
        .get(...(sucursal_id ? [sucursal_id] : []));
      if (cajaAbierta) {
        const tipoMov = tipo === 'nota_credito' ? 'egreso' : 'ingreso';
        const insMov = req.db.prepare(`INSERT INTO caja_movimientos
          (caja_sesion_id,tipo,origen,medio_pago,monto,motivo,comprobante_id,usuario,vendedor_codigo,desde_admin)
          VALUES (?,?,?,?,?,?,?,?,?,?)`);
        pagosArr.forEach(p => insMov.run(cajaAbierta.id, tipoMov, 'venta', p.medio_pago, Number(p.monto),
          `${tipo==='nota_credito'?'Devolución':'Venta'} ${numero}${desdeAdmin ? ' · DESDE ADMIN' : ''}`, comprobanteId, req.user?.nombre || req.user?.usuario || '', vendedor_codigo || null, desdeAdmin));
      } else {
        return res.json({ id: comprobanteId, numero, total, cajaAbierta: false });
      }
    }
  }

  res.json({ id: comprobanteId, numero, total, cajaAbierta: !esRetiro, retiro_codigo: retiroCodigo });
});

// ─── RETIROS: ventas del admin que se entregan en un local ───────────────────
// El cajero NUNCA ve el código: lo recibe del cliente (impreso/QR) y lo ingresa.
app.get('/api/retiros/pendientes', authMiddleware, (req, res) => {
  if (!['caja', 'admin'].includes(req.user.rol)) return res.status(403).json({ error: 'Sin acceso.' });
  const suc = req.user.rol === 'admin' ? (req.query.sucursal_id || null) : (req.user.sucursal_id || -1);
  const filas = req.db.prepare(`SELECT id,numero,tipo,fecha,cliente_nombre,cliente_apellido,cliente_doc_numero,items,total,sucursal_id,retiro_estado,retiro_codigo
      FROM comprobantes WHERE retiro_estado='pendiente' AND estado!='anulado' ${suc ? 'AND sucursal_id=?' : ''} ORDER BY fecha ASC`).all(...(suc ? [suc] : []));
  filas.forEach(f => { try { f.items = JSON.parse(f.items || '[]'); } catch (e) { f.items = []; } if (req.user.rol !== 'admin') delete f.retiro_codigo; });
  res.json(filas);
});

const retiroFallos = new Map(); // usuario_id -> [timestamps] de códigos inválidos
// Valida el código contra un comprobante. Devuelve el comprobante o responde el error (y devuelve null).
function retiroValidar(req, res, codigo) {
  if (!['caja', 'admin'].includes(req.user.rol)) { res.status(403).json({ error: 'Sin acceso.' }); return null; }
  if (!codigo) { res.status(400).json({ error: 'Ingresá el código de retiro.' }); return null; }
  const ahora = Date.now();
  const fallos = (retiroFallos.get(req.user.usuario_id) || []).filter(t => ahora - t < 10 * 60 * 1000);
  if (fallos.length >= 8) { res.status(429).json({ error: 'Demasiados códigos incorrectos. Esperá unos minutos o avisá al administrador.' }); return null; }
  const c = req.db.prepare('SELECT * FROM comprobantes WHERE retiro_codigo=?').get(codigo);
  if (!c) {
    fallos.push(ahora); retiroFallos.set(req.user.usuario_id, fallos);
    audit(req, 'retiro.codigo_invalido', 'comprobante', null, `Código inválido ingresado: ${codigo.slice(0, 12)}`);
    res.status(404).json({ error: 'Código incorrecto.' }); return null;
  }
  if (req.user.rol === 'caja' && Number(c.sucursal_id) !== Number(req.user.sucursal_id)) {
    audit(req, 'retiro.otro_local', 'comprobante', c.id, `${c.numero}: intento de entrega en un local que no corresponde`);
    res.status(403).json({ error: 'Este retiro corresponde a otro local.' }); return null;
  }
  if (c.estado === 'anulado' || c.retiro_estado === 'anulada') { res.status(409).json({ error: `El comprobante ${c.numero} fue anulado: no se puede entregar.` }); return null; }
  if (c.retiro_estado === 'entregada') {
    res.status(409).json({ error: `El comprobante ${c.numero} ya fue entregado el ${c.retiro_entregado_fecha} (${c.retiro_entregado_por}).` }); return null;
  }
  return c;
}
function resumenItemsComp(c) {
  let it = []; try { it = JSON.parse(c.items || '[]'); } catch (e) {}
  return it.map(i => `${i.cantidad}× ${String(i.descripcion || '').slice(0, 40)}`).join(', ').slice(0, 220);
}

// Paso 1: el cajero ingresa el código y el sistema le muestra a QUÉ comprobante pertenece.
app.post('/api/retiros/consultar', authMiddleware, (req, res) => {
  const codigo = String(req.body?.codigo || '').trim().toUpperCase();
  const c = retiroValidar(req, res, codigo);
  if (!c) return;
  let items = []; try { items = JSON.parse(c.items || '[]'); } catch (e) {}
  audit(req, 'retiro.consultar', 'comprobante', c.id, `${c.numero}: código verificado para entrega`);
  res.json({
    numero: c.numero, tipo: c.tipo, fecha: c.fecha, total: c.total,
    cliente: [c.cliente_nombre, c.cliente_apellido].filter(Boolean).join(' '), cliente_doc: c.cliente_doc_numero || '',
    items, emitido_por: c.generado_por_usuario, desde_admin: !!c.desde_admin, local: nombreLugar(req.db, c.sucursal_id),
  });
});

// Paso 2: confirma la entrega. Si llega "numero", tiene que coincidir con el comprobante del código.
app.post('/api/retiros/entregar', authMiddleware, (req, res) => {
  const codigo = String(req.body?.codigo || '').trim().toUpperCase();
  const nombre = String(req.body?.retira_nombre || '').trim().slice(0, 120);
  const doc = String(req.body?.retira_doc || '').trim().slice(0, 40);
  if (!codigo) return res.status(400).json({ error: 'Ingresá el código de retiro.' });
  if (!nombre && !doc) return res.status(400).json({ error: 'Anotá el nombre o el DNI de quien retira.' });
  const c = retiroValidar(req, res, codigo);
  if (!c) return;
  const numeroPedido = String(req.body?.numero || '').trim();
  if (numeroPedido && numeroPedido !== c.numero) {
    audit(req, 'retiro.numero_no_coincide', 'comprobante', c.id, `El código pertenece a ${c.numero} pero se intentó entregar contra ${numeroPedido.slice(0, 40)}`);
    return res.status(409).json({ error: `El código no corresponde al comprobante ${numeroPedido}.` });
  }
  req.db.prepare(`UPDATE comprobantes SET retiro_estado='entregada', retiro_entregado_por=?, retiro_entregado_fecha=datetime('now','localtime'), retiro_retira_nombre=?, retiro_retira_doc=? WHERE id=?`)
    .run(req.user.nombre || req.user.usuario || '', nombre, doc, c.id);
  audit(req, 'retiro.entregar', 'comprobante', c.id,
    `${c.numero} (${c.tipo}) total $${c.total} · código ${codigo} · local ${nombreLugar(req.db, c.sucursal_id)} · emitido por ${c.generado_por_usuario || '-'}${c.desde_admin ? ' (DESDE ADMIN)' : ''} · ítems: ${resumenItemsComp(c) || '-'} · entregado a ${nombre || '-'} (DNI ${doc || '-'})`);
  res.json({ ok: true, numero: c.numero, cliente: [c.cliente_nombre, c.cliente_apellido].filter(Boolean).join(' ') });
});

// ─── EQUIPO SIN REPARACIÓN: Nota de Entrega marcada + cobro de revisión opcional ───
// El admin define (Configuración → Revisión) si se cobra revisión y cuánto. El técnico
// no cobra: emite la Nota de Entrega "SIN REPARACIÓN"; si corresponde cobro, queda
// pendiente y lo cobra la Caja (y recién ahí el equipo sale). Si hay dificultades con
// el cliente, el técnico puede entregar SIN COBRO escribiendo una nota: queda registrado.
function numerarNotaEntrega(db, sucursal_id) {
  const prox = fiscalGet(db, sucursal_id, 'proximo_numero_nota_entrega');
  const numComp = parseInt(prox.valor || '1');
  const pv = fiscalGet(db, sucursal_id, 'punto_venta').valor || '1';
  const pvPad = String(pv).padStart(4, '0');
  fiscalSet(db, sucursal_id, 'proximo_numero_nota_entrega', numComp + 1, prox.scoped);
  return { numero: `ENT-X${pvPad}-${String(numComp).padStart(8, '0')}`, numComp, pv: parseInt(pv) };
}

app.post('/api/ordenes/:id/entregar-sin-reparacion', authMiddleware, (req, res) => {
  const o = req.db.prepare('SELECT o.*, c.nombre AS cli_nombre FROM ordenes o LEFT JOIN clientes c ON c.id=o.cliente_id WHERE o.id=?').get(req.params.id);
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  if (o.estado === 'entregado') return res.status(409).json({ error: 'Esta orden ya fue entregada.' });
  if (req.user.rol !== 'admin' && o.sucursal_id && String(o.sucursal_id) !== String(req.user.sucursal_id)) {
    return res.status(403).json({ error: 'Este equipo no está en tu sucursal.' });
  }
  const nota = String(req.body?.nota || '').trim().slice(0, 500);
  if (!nota) return res.status(400).json({ error: 'Escribí una nota: por qué sale sin reparación.' });
  const cfg = {}; req.db.prepare("SELECT clave,valor FROM config WHERE clave IN ('revision_cobra','revision_monto')").all().forEach(r => cfg[r.clave] = r.valor);
  const monto = Number(cfg.revision_monto || 0);
  const cobra = cfg.revision_cobra === '1' && monto > 0;
  const sinCobro = !!req.body?.sin_cobro;
  const cobrarAhora = cobra && !sinCobro;
  const sucId = o.sucursal_id || req.user.sucursal_id || null;
  const num = numerarNotaEntrega(req.db, sucId);
  const equipo = [o.equipo, o.marca, o.modelo].filter(Boolean).join(' ');
  const items = [{ descripcion: `Revisión técnica — EQUIPO SIN REPARACIÓN (${equipo}) · Orden ${o.numero}`, cantidad: 1, precio_unitario: cobrarAhora ? monto : 0 }];
  const total = cobrarAhora ? monto : 0;
  const condicion = cobrarAhora ? 'Pendiente de cobro en Caja' : (cobra ? 'Sin cargo (autorizado)' : 'Sin cargo');
  const r = req.db.prepare(`INSERT INTO comprobantes
    (numero,tipo,letra,punto_venta,numero_comp,orden_id,cliente_id,cliente_nombre,cliente_apellido,cliente_doc_tipo,cliente_doc_numero,cliente_condicion_iva,cliente_direccion,
     items,subtotal,descuento,iva_porcentaje,iva_monto,total,condicion_pago,notas,estado,sucursal_id,generado_por_usuario,generado_por_rol,desde_admin,
     sin_reparacion,cobro_pendiente,sin_cobro_motivo,sin_cobro_por)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'emitido',?,?,?,?,?,?,?,?)`)
    .run(num.numero, 'nota_entrega', 'X', num.pv, num.numComp, o.id, o.cliente_id || null, o.cli_nombre || '', '', 'DNI', '', 'Consumidor Final', '',
      JSON.stringify(items), total, 0, 0, 0, total, condicion, `SIN REPARACIÓN — ${nota}`, sucId, req.user.nombre || null, req.user.rol || null, req.user.rol === 'admin' ? 1 : 0,
      1, cobrarAhora ? 1 : 0, (cobra && sinCobro) ? nota : null, (cobra && sinCobro) ? (req.user.nombre || '') : null);
  const compId = r.lastInsertRowid;
  if (cobrarAhora) {
    // Queda pendiente: la Caja cobra la revisión y recién ahí se entrega.
    if (o.estado !== 'listo') req.db.prepare("UPDATE ordenes SET estado='listo' WHERE id=?").run(o.id);
  } else {
    req.db.prepare("UPDATE ordenes SET estado='entregado', fecha_entrega=datetime('now','localtime'), cobrado=?, comprobante_entrega=? WHERE id=?")
      .run((cobra && sinCobro) ? 0 : 1, num.numero, o.id);
  }
  audit(req, 'orden.entregar_sin_reparacion', 'orden', o.id,
    `${o.numero} (${equipo}) → ${num.numero} · ${cobrarAhora ? `revisión $${monto} PENDIENTE de cobro en Caja` : (cobra ? `SIN COBRO autorizado por ${req.user.nombre}` : 'sin cargo (la revisión no se cobra)')} · nota: ${nota.slice(0, 160)}`);
  res.json({ ok: true, comprobante_id: compId, numero: num.numero, cobro_pendiente: cobrarAhora, monto: total });
});

// Entrega de una orden de GARANTÍA del local: Nota de Entrega sin cargo (queda registrada y auditada)
app.post('/api/ordenes/:id/entregar-garantia', authMiddleware, (req, res) => {
  if (!['caja', 'admin', 'taller'].includes(req.user.rol)) return res.status(403).json({ error: 'Sin acceso.' });
  const o = req.db.prepare('SELECT o.*, c.nombre AS cli_nombre FROM ordenes o LEFT JOIN clientes c ON c.id=o.cliente_id WHERE o.id=?').get(req.params.id);
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  if (o.tipo_orden !== 'garantia') return res.status(409).json({ error: 'Esta orden no es una garantía del local.' });
  if (cobroGarantia(o).total > 0) return res.status(409).json({ error: `Esta garantía tiene un cobro al cliente de $${cobroGarantia(o).total}: se cobra en «Cobrar y entregar».` });
  if (o.estado === 'entregado' || o.estado === 'cancelado') return res.status(409).json({ error: 'Esta orden ya fue entregada o cancelada.' });
  if (o.estado !== 'listo') return res.status(409).json({ error: 'Todavía no está «Listo para entregar».' });
  if (req.db.prepare("SELECT 1 FROM envios_equipos WHERE orden_id=? AND estado='enviado'").get(o.id)) return res.status(409).json({ error: 'El equipo está en camino: recibilo primero.' });
  if (req.user.rol !== 'admin' && o.sucursal_id && String(o.sucursal_id) !== String(req.user.sucursal_id)) return res.status(403).json({ error: 'Este equipo no está en tu sucursal.' });
  const sucId = o.sucursal_id || req.user.sucursal_id || null;
  const num = numerarNotaEntrega(req.db, sucId);
  const equipo = [o.equipo, o.marca, o.modelo].filter(Boolean).join(' ');
  const nota = `GARANTÍA DEL LOCAL — sin cargo${o.garantia_ref ? ` (reparación original ${o.garantia_ref})` : ''}`;
  const items = [{ descripcion: `Garantía — ${equipo} · Orden ${o.numero}`, cantidad: 1, precio_unitario: 0 }];
  const r = req.db.prepare(`INSERT INTO comprobantes
    (numero,tipo,letra,punto_venta,numero_comp,orden_id,cliente_id,cliente_nombre,cliente_apellido,cliente_doc_tipo,cliente_doc_numero,cliente_condicion_iva,cliente_direccion,
     items,subtotal,descuento,iva_porcentaje,iva_monto,total,condicion_pago,notas,estado,sucursal_id,generado_por_usuario,generado_por_rol,desde_admin,sin_cobro_motivo,sin_cobro_por)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'emitido',?,?,?,?,?,?)`)
    .run(num.numero, 'nota_entrega', 'X', num.pv, num.numComp, o.id, o.cliente_id || null, o.cli_nombre || '', '', 'DNI', '', 'Consumidor Final', '',
      JSON.stringify(items), 0, 0, 0, 0, 0, 'Garantía sin cargo', nota, sucId, req.user.nombre || null, req.user.rol || null, req.user.rol === 'admin' ? 1 : 0, 'Garantía del local', req.user.nombre || '');
  req.db.prepare("UPDATE ordenes SET estado='entregado', fecha_entrega=datetime('now','localtime'), cobrado=0, comprobante_entrega=? WHERE id=?").run(num.numero, o.id);
  _registrarComisionSeguro(req.db, o.id);
  audit(req, 'orden.entregar_garantia', 'orden', o.id, `${o.numero} (${equipo}) entregada como GARANTÍA sin cargo → ${num.numero}`);
  res.json({ ok: true, comprobante_id: r.lastInsertRowid, numero: num.numero });
});

// Cobros de revisión pendientes (los cobra la Caja del local)
app.get('/api/cobros-pendientes', authMiddleware, (req, res) => {
  if (!['caja', 'admin'].includes(req.user.rol)) return res.status(403).json({ error: 'Sin acceso.' });
  const suc = req.user.rol === 'admin' ? (req.query.sucursal_id || null) : (req.user.sucursal_id || -1);
  res.json(req.db.prepare(`SELECT id,numero,fecha,cliente_nombre,total,sucursal_id,orden_id,notas FROM comprobantes
    WHERE cobro_pendiente=1 AND estado='emitido' ${suc ? 'AND sucursal_id=?' : ''} ORDER BY fecha ASC`).all(...(suc ? [suc] : [])));
});

app.post('/api/comprobantes/:id/cobrar-pendiente', authMiddleware, (req, res) => {
  if (!['caja', 'admin'].includes(req.user.rol)) return res.status(403).json({ error: 'Sin acceso.' });
  const c = req.db.prepare('SELECT * FROM comprobantes WHERE id=?').get(req.params.id);
  if (!c || !c.cobro_pendiente || c.estado !== 'emitido') return res.status(404).json({ error: 'No hay un cobro pendiente en ese comprobante.' });
  if (req.user.rol === 'caja' && Number(c.sucursal_id) !== Number(req.user.sucursal_id)) return res.status(403).json({ error: 'Este cobro corresponde a otro local.' });
  const pagos = (Array.isArray(req.body?.pagos) ? req.body.pagos : []).filter(p => p && p.monto > 0);
  if (!pagos.length || pagos.some(p => !MEDIOS_PAGO_VALIDOS.includes(p.medio_pago))) return res.status(400).json({ error: 'Indicá el medio de pago.' });
  const suma = pagos.reduce((a, p) => a + Number(p.monto), 0);
  if (Math.abs(suma - c.total) > 0.5) return res.status(400).json({ error: `Los pagos (${suma.toFixed(2)}) no coinciden con el total (${Number(c.total).toFixed(2)}).` });
  const caja = req.db.prepare(`SELECT id FROM caja_sesiones WHERE estado='abierta' AND (sucursal_id=? OR sucursal_id IS NULL) ORDER BY id DESC LIMIT 1`).get(c.sucursal_id);
  if (!caja) return res.status(409).json({ error: 'La caja de este local está cerrada: abrila para registrar el cobro.' });
  const insPago = req.db.prepare('INSERT INTO comprobante_pagos (comprobante_id,medio_pago,monto) VALUES (?,?,?)');
  const insMov = req.db.prepare(`INSERT INTO caja_movimientos (caja_sesion_id,tipo,origen,medio_pago,monto,motivo,comprobante_id,usuario,desde_admin) VALUES (?,?,?,?,?,?,?,?,?)`);
  const admin = req.user.rol === 'admin' ? 1 : 0;
  pagos.forEach(p => {
    insPago.run(c.id, p.medio_pago, Number(p.monto));
    insMov.run(caja.id, 'ingreso', 'venta', p.medio_pago, Number(p.monto), `Revisión sin reparación ${c.numero}${admin ? ' · DESDE ADMIN' : ''}`, c.id, req.user.nombre || '', admin);
  });
  req.db.prepare('UPDATE comprobantes SET cobro_pendiente=0, condicion_pago=? WHERE id=?')
    .run(pagos.map(p => `${p.medio_pago} $${Number(p.monto).toFixed(2)}`).join(' + '), c.id);
  if (c.orden_id) {
    req.db.prepare("UPDATE ordenes SET estado='entregado', fecha_entrega=datetime('now','localtime'), cobrado=1, comprobante_entrega=? WHERE id=?").run(c.numero, c.orden_id);
    _registrarComisionSeguro(req.db, c.orden_id);
  }
  audit(req, 'comprobante.cobro_pendiente', 'comprobante', c.id, `${c.numero} cobrado $${c.total} (${pagos.map(p => p.medio_pago).join('+')}) · equipo entregado`);
  res.json({ ok: true, numero: c.numero });
});

app.put('/api/comprobantes/:id', authMiddleware, (req, res) => {
  const { estado, notas, cae, cae_vencimiento } = req.body;
  const c = req.db.prepare('SELECT * FROM comprobantes WHERE id=?').get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Comprobante no encontrado' });
  const anulando = estado === 'anulado' && c.estado !== 'anulado';
  if (anulando && c.desde_admin && req.user.rol !== 'admin') {
    return res.status(403).json({ error: 'Este comprobante fue emitido desde ADMIN: solo un administrador puede anularlo.' });
  }
  if (anulando && !permisosDe(req.db, req.user.usuario_id, req.user.rol).anular_comprobantes) {
    return res.status(403).json({ error: 'Tu usuario no tiene permiso para: Anular comprobantes. Pedíselo al administrador.' });
  }
  try {
    req.db.prepare('UPDATE comprobantes SET estado=COALESCE(?,estado),notas=COALESCE(?,notas),cae=COALESCE(?,cae),cae_vencimiento=COALESCE(?,cae_vencimiento) WHERE id=?')
      .run(estado ?? null, notas ?? null, cae ?? null, cae_vencimiento ?? null, req.params.id);
  } catch (e) {
    audit(req, 'comprobante.cambio_bloqueado', 'comprobante', c.id, `${c.numero}: ${e.message}`.slice(0, 250));
    return res.status(409).json({ error: String(e.message).replace(/^.*?:\s*/, '') });
  }
  if (anulando) {
    // Anular deshace el movimiento de stock que hizo el comprobante (una venta devuelve; una nota de crédito vuelve a sacar)
    if (c.stock_movido) {
      let items = []; try { items = JSON.parse(c.items || '[]'); } catch (e) {}
      const dir = (c.tipo === 'factura' || c.tipo === 'nota_entrega') ? 1 : (c.tipo === 'nota_credito' ? -1 : 0);
      const lugar = c.stock_sucursal_id || null;
      items.forEach(i => {
        const pid = Number(i._producto_id || i.producto_id || 0), cant = Number(i.cantidad);
        if (!dir || !pid || !(cant > 0)) return;
        moverStock(req.db, pid, lugar, dir * cant);
        regMovStock(req.db, pid, dir === 1 ? 'entrada' : 'salida', cant, `Anulación ${c.numero}`, lugar, req.user.nombre);
      });
    }
    if (c.retiro_estado === 'pendiente') req.db.prepare(`UPDATE comprobantes SET retiro_estado='anulada' WHERE id=?`).run(c.id);
    audit(req, 'comprobante.anular', 'comprobante', c.id, `${c.numero} (${c.tipo}) total $${c.total}`);
  } else if (estado || cae) {
    audit(req, 'comprobante.actualizar', 'comprobante', c.id, `${c.numero}: estado ${estado||c.estado}`);
  }
  res.json({ ok: true });
});

app.delete('/api/comprobantes/:id', authMiddleware, adminOnly, (req, res) => {
  const _cd = req.db.prepare('SELECT numero,tipo,total,estado FROM comprobantes WHERE id=?').get(req.params.id);
  if (_cd && _cd.estado !== 'borrador' && _cd.tipo !== 'presupuesto') {
    audit(req, 'comprobante.borrado_bloqueado', 'comprobante', req.params.id, `${_cd.numero} (${_cd.tipo}): un comprobante emitido no se borra, solo se anula`);
    return res.status(409).json({ error: 'Un comprobante emitido no se puede borrar: se anula (queda el registro y el número).' });
  }
  audit(req, 'comprobante.eliminar', 'comprobante', req.params.id, _cd ? `${_cd.numero} (${_cd.tipo}) $${_cd.total}` : '');
  req.db.prepare('DELETE FROM comprobantes WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// Datos para imprimir comprobante
app.get('/api/fiscal/print/:id', authMiddleware, (req, res) => {
  const c = req.db.prepare('SELECT * FROM comprobantes WHERE id=?').get(req.params.id);
  if (!c) return res.status(404).json({ error: 'No encontrado' });
  c.items = JSON.parse(c.items || '[]');
  // TICKET-1.6.9: forma de pago para la impresión (uno o varios medios)
  try { c.pagos = req.db.prepare('SELECT medio_pago, monto FROM comprobante_pagos WHERE comprobante_id=? ORDER BY id').all(c.id); } catch (e) { c.pagos = []; }
  if (req.user.rol !== 'admin') delete c.retiro_codigo;
  // Dónde y quién generó el comprobante (taller/tienda/caja/admin), para
  // mostrarlo en la impresión sin importar en qué sector se haya emitido.
  if (c.sucursal_id) {
    const sucOrigen = req.db.prepare('SELECT nombre FROM sucursales WHERE id=?').get(c.sucursal_id);
    c.sucursal_nombre = sucOrigen?.nombre || null;
  }
  const cfg = {};
  req.db.prepare('SELECT * FROM config_fiscal').all().forEach(r => cfg[r.clave]=r.valor);
  // Si el comprobante se emitió en una sucursal con punto de venta/razón
  // social propios (cargados por el admin), esos valores pisan a los globales
  // para que el ticket impreso muestre los datos correctos de ESA sucursal.
  if (c.sucursal_id) {
    req.db.prepare('SELECT * FROM config_fiscal_sucursal WHERE sucursal_id=?').all(c.sucursal_id).forEach(r => cfg[r.clave]=r.valor);
  }
  const cfgGen = {};
  req.db.prepare('SELECT * FROM config').all().forEach(r => cfgGen[r.clave]=r.valor);
  c.emisor = { ...cfg, empresa_nombre: cfgGen.empresa_nombre, empresa_telefono: cfgGen.empresa_telefono, empresa_email: cfgGen.empresa_email, logo_empresa: cfgGen.logo_empresa };
  res.json(c);
});

// ─── GENERAR EXCEL CON GRÁFICOS ───────────────────────────────────────────────
const { execSync } = require('child_process');

// Informe de sucursal en Excel, con membrete (logo y datos del negocio). No usa Python: funciona en cualquier PC.
// Lo usan la ruta de descarga y AsystenBot: las mismas reglas de período, sucursal y permisos para los dos.
async function prepararInforme(req, { desde: d0, hasta: h0, sucursal_id }) {
  const hoyTxt = new Date().toLocaleDateString('sv-SE');
  let hasta = seguridad.soloFecha(h0) || hoyTxt;
  let desde = seguridad.soloFecha(d0) || (hasta.slice(0, 8) + '01');
  if (desde > hasta) return { status: 400, error: 'La fecha "Desde" no puede ser posterior a "Hasta".' };
  if ((new Date(hasta) - new Date(desde)) / 86400000 > 400) return { status: 400, error: 'Elegí un período de hasta 13 meses.' };
  const sucs = req.db.prepare('SELECT id, nombre FROM sucursales WHERE activa=1 AND es_deposito_central=0 ORDER BY nombre').all();
  let sel, todas = false;
  if (req.user.rol === 'admin') {
    const q = String(sucursal_id || 'todas');
    if (q === 'todas') { sel = sucs; todas = true; }
    else {
      const s = sucs.find(x => String(x.id) === q);
      if (!s) {
        const dep = req.db.prepare('SELECT id FROM sucursales WHERE es_deposito_central=1').get();
        return { status: 400, error: dep && String(dep.id) === q ? 'El Depósito Central no vende por sí solo: elegí una sucursal o "Todas" (ahí se incluye su stock).' : 'Esa sucursal no existe.' };
      }
      sel = [s];
    }
  } else {
    const s = sucs.find(x => x.id === Number(req.user.sucursal_id || 0));
    if (!s) return { status: 400, error: 'Tu usuario no tiene una sucursal asignada.' };
    sel = [s];
  }
  if (!sel.length) return { status: 400, error: 'Todavía no hay sucursales creadas para informar.' };
  const perm = permisosDe(req.db, req.user.usuario_id, req.user.rol);
  const buffer = await require('./informe-excel').construirInforme({
    db: req.db, desde, hasta, sucursales: sel, todas,
    verCostos: !!perm.ver_costos, taller: !!planes.queIncluye(req, MODO_DISTRIBUIDOR).modulos.taller,
    generadoPor: req.user.usuario, uploadsDir: UPLOADS_DIR,
  });
  const nombreArch = `Informe_${todas ? 'Todas' : sel[0].nombre}_${desde}_a_${hasta}.xlsx`.replace(/[^\w.\-]+/g, '_');
  const desc = `${todas ? 'Todas las sucursales' : sel[0].nombre} · ${desde} → ${hasta}`;
  return { buffer: Buffer.from(buffer), nombreArch, desc, todas, desde, hasta };
}
app.get('/api/informe-sucursal/excel', authMiddleware, requierePermiso('ver_reportes'), async (req, res) => {
  try {
    const r = await prepararInforme(req, req.query);
    if (r.error) return res.status(r.status).json({ error: r.error });
    audit(req, 'informe.excel', 'informe', null, r.desc);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${r.nombreArch}"`);
    res.send(r.buffer);
  } catch (e) {
    console.error('Error generando informe de sucursal:', e);
    res.status(500).json({ error: 'No se pudo generar el informe: ' + e.message });
  }
});

app.get('/api/reportes/excel', authMiddleware, requierePermiso('ver_reportes'), (req, res) => {
  // "Excel con gráficos" es parte de los planes con hosting. En el plan local está el Informe de sucursal (sin Python).
  if (!MODO_DISTRIBUIDOR) return res.status(403).json({ error: 'El Excel con gráficos es parte de los planes con hosting. Para descargar tus datos usá "Informe de sucursal (Excel)".' });
  try {
    const desde = seguridad.soloFecha(req.query.desde), hasta = seguridad.soloFecha(req.query.hasta);
    const filtroFecha = desde && hasta
      ? `AND date(fecha_ingreso) BETWEEN '${desde}' AND '${hasta}'` : '';

    const datos = {
      ordenesPorEstado: req.db.prepare(`SELECT estado, COUNT(*) as cantidad FROM ordenes WHERE 1=1 ${filtroFecha} GROUP BY estado`).all(),
      ordenesPorMes: req.db.prepare(`SELECT strftime('%Y-%m', fecha_ingreso) as mes, COUNT(*) as cantidad, SUM(total) as total FROM ordenes WHERE 1=1 ${filtroFecha} GROUP BY mes ORDER BY mes DESC LIMIT 12`).all().reverse(),
      repuestosMasUsados: req.db.prepare(`SELECT p.nombre, p.codigo, SUM(or2.cantidad) as total_usado, SUM(or2.subtotal) as total_facturado FROM orden_repuestos or2 JOIN productos p ON or2.producto_id=p.id GROUP BY p.id ORDER BY total_usado DESC LIMIT 10`).all(),
      ingresosPorTecnico: req.db.prepare(`SELECT tecnico, COUNT(*) as ordenes, SUM(total) as total FROM ordenes WHERE tecnico IS NOT NULL AND tecnico != '' ${filtroFecha} GROUP BY tecnico ORDER BY total DESC`).all(),
      stockCritico: req.db.prepare(`SELECT nombre, codigo, stock, stock_minimo FROM productos WHERE stock <= stock_minimo ORDER BY stock ASC`).all(),
      resumen: req.db.prepare(`SELECT COUNT(*) as total_ordenes, SUM(total) as total_facturado, AVG(total) as ticket_promedio, COUNT(CASE WHEN cobrado=1 THEN 1 END) as cobradas, COUNT(CASE WHEN estado='entregado' THEN 1 END) as entregadas FROM ordenes WHERE 1=1 ${filtroFecha}`).get(),
      ordenesPorEquipo: req.db.prepare(`SELECT equipo, COUNT(*) as cantidad FROM ordenes WHERE 1=1 ${filtroFecha} GROUP BY equipo ORDER BY cantidad DESC LIMIT 8`).all(),
      movimientosStock: req.db.prepare(`SELECT strftime('%Y-%m', fecha) as mes, tipo, SUM(cantidad) as cantidad FROM movimientos_stock GROUP BY mes, tipo ORDER BY mes DESC LIMIT 24`).all()
    };

    const fecha = new Date().toISOString().split('T')[0];
    const outputPath = require('path').join(UPLOADS_DIR, `reporte_${fecha}.xlsx`);
    const scriptPath = path.join(__dirname, 'generar_reporte.py');

    ejecutarScriptPython(scriptPath, datos, outputPath);

    res.download(outputPath, `Reporte_SysTech_${fecha}.xlsx`, () => {
      try { require('fs').unlinkSync(outputPath); } catch(e) {}
    });
  } catch(e) {
    console.error('Error generando reporte:', e.message);
    res.status(500).json({ error: 'Error al generar el reporte: ' + e.message });
  }
});

// Datos para etiqueta de producto
app.get('/api/print/producto/:id', authMiddleware, (req, res) => {
  const p = req.db.prepare('SELECT * FROM productos WHERE id=?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'No encontrado' });
  const cfg = {};
  req.db.prepare('SELECT * FROM config').all().forEach(r => cfg[r.clave]=r.valor);
  p.empresa = cfg.empresa_nombre || 'Servicio Técnico';
  p.logo    = cfg.logo_empresa || '';
  res.json(p);
});

// ─── GARANTÍA Y CONDICIONES DE ENTREGA ───────────────────────────────────────
// GET texto de garantía (admin)
app.get('/api/garantia/config', authMiddleware, (req, res) => {
  const rows = req.db.prepare('SELECT * FROM garantia_config').all();
  const cfg = {};
  rows.forEach(r => cfg[r.clave] = r.valor);
  res.json(cfg);
});

// PUT actualizar texto de garantía (solo admin)
app.put('/api/garantia/config', authMiddleware, adminOnly, (req, res) => {
  const { texto_garantia, exigir_aceptacion } = req.body;
  if (texto_garantia !== undefined) req.db.prepare("INSERT OR REPLACE INTO garantia_config (clave,valor) VALUES ('texto_garantia',?)").run(texto_garantia);
  if (exigir_aceptacion !== undefined) req.db.prepare("INSERT OR REPLACE INTO garantia_config (clave,valor) VALUES ('exigir_aceptacion',?)").run(exigir_aceptacion?'1':'0');
  res.json({ ok: true });
});

// GET texto de garantía (público, para el cliente que va a aceptar)
app.get('/api/garantia/texto/:ordenId', (req, res) => {
  const o = req.db.prepare('SELECT id,numero,estado FROM ordenes WHERE id=?').get(req.params.ordenId);
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  const texto = req.db.prepare("SELECT valor FROM garantia_config WHERE clave='texto_garantia'").get();
  const yaAcepto = req.db.prepare('SELECT id, fecha_aceptacion FROM garantia_aceptaciones WHERE orden_id=?').get(req.params.ordenId);
  res.json({
    numero: o.numero,
    estado: o.estado,
    texto: texto?.valor || '',
    ya_acepto: !!yaAcepto,
    fecha_aceptacion: yaAcepto?.fecha_aceptacion || null
  });
});

// POST aceptar garantía (el cliente firma digitalmente al retirar)
app.post('/api/garantia/aceptar/:ordenId', (req, res) => {
  const { cliente_nombre, firma_digital } = req.body;
  const o = req.db.prepare('SELECT id FROM ordenes WHERE id=?').get(req.params.ordenId);
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });

  const yaAcepto = req.db.prepare('SELECT id FROM garantia_aceptaciones WHERE orden_id=?').get(req.params.ordenId);
  if (yaAcepto) return res.json({ ok: true, ya_existia: true });

  const texto = req.db.prepare("SELECT valor FROM garantia_config WHERE clave='texto_garantia'").get();
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '';

  req.db.prepare(`INSERT INTO garantia_aceptaciones (orden_id,cliente_nombre,ip_origen,firma_digital,texto_aceptado) VALUES (?,?,?,?,?)`)
    .run(req.params.ordenId, cliente_nombre || '', ip, firma_digital || '', texto?.valor || '');

  res.json({ ok: true });
});

// GET ver aceptación de una orden (para admin/caja)
app.get('/api/garantia/aceptacion/:ordenId', authMiddleware, (req, res) => {
  const a = req.db.prepare('SELECT * FROM garantia_aceptaciones WHERE orden_id=?').get(req.params.ordenId);
  res.json(a || null);
});

// ─── MEJORAS-1.7.2: garantía aceptada por WhatsApp, correo o en el local (lo marca el negocio) ───
app.post('/api/garantia/marcar/:ordenId', authMiddleware, (req, res) => {
  const o = req.db.prepare('SELECT o.id, o.numero, c.nombre as cliente_nombre FROM ordenes o LEFT JOIN clientes c ON o.cliente_id=c.id WHERE o.id=?').get(req.params.ordenId);
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  if (req.db.prepare('SELECT id FROM garantia_aceptaciones WHERE orden_id=?').get(o.id)) return res.json({ ok: true, ya_existia: true });
  const medio = ['WhatsApp', 'correo', 'en el local'].includes(req.body && req.body.medio) ? req.body.medio : 'WhatsApp';
  const texto = req.db.prepare("SELECT valor FROM garantia_config WHERE clave='texto_garantia'").get();
  const quien = (req.user && (req.user.nombre || req.user.usuario)) || '';
  req.db.prepare('INSERT INTO garantia_aceptaciones (orden_id,cliente_nombre,ip_origen,firma_digital,texto_aceptado) VALUES (?,?,?,?,?)')
    .run(o.id, o.cliente_nombre || '', 'registrado por ' + quien, medio === 'en el local' ? 'Firmó en el local' : 'Aceptó por ' + medio, texto?.valor || '');
  audit(req, 'garantia.aceptada', 'orden', o.id, `Orden ${o.numero}: aceptó por ${medio}`);
  res.json({ ok: true });
});

// ─── MEJORAS-1.7.2: correo del negocio ───
function configNegocio(db) { const cfg = {}; db.prepare('SELECT * FROM config').all().forEach(r => cfg[r.clave] = r.valor); return cfg; }
app.get('/api/correo/estado', authMiddleware, (req, res) => {
  const c = datosCorreo(configNegocio(req.db));
  res.json({ configurado: !!(c.host && c.user && c.pass) });
});
app.post('/api/correo/probar', authMiddleware, adminOnly, async (req, res) => {
  const cfg = configNegocio(req.db), b = req.body || {};
  const prueba = { ...cfg, smtp_user: b.smtp_user || cfg.smtp_user, smtp_pass: b.smtp_pass || cfg.smtp_pass, smtp_host: b.smtp_host || '', smtp_port: b.smtp_port || '' };
  const c = datosCorreo(prueba);
  if (!c.user || !c.pass) return res.json({ ok: false, error: 'Completá el correo y la clave de aplicación.' });
  try {
    await enviarEmail(c.user, 'Prueba de SysTech: el correo funciona ✓', `<p>¡Listo! Este es un correo de prueba.</p><p>Desde ahora los avisos y las garantías les llegan a tus clientes desde <b>${c.user}</b>.</p>`, prueba);
    res.json({ ok: true, para: c.user });
  } catch (e) { res.json({ ok: false, error: errorCorreo(e) }); }
});
app.post('/api/correo/enviar', authMiddleware, async (req, res) => {
  const { para, asunto, texto, orden_id } = req.body || {};
  if (!para || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(para).trim())) return res.json({ ok: false, error: 'El correo del cliente no es válido.' });
  const cfg = configNegocio(req.db);
  const html = String(texto || '').replace(/[&<>]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[ch]).replace(/\n/g, '<br>');
  try {
    await enviarEmail(String(para).trim(), String(asunto || 'Mensaje de ' + (cfg.empresa_nombre || 'Servicio Técnico')).slice(0, 200), html, cfg);
    if (orden_id) req.db.prepare('INSERT INTO log_automatizacion (orden_id,evento,canal,estado,detalle) VALUES (?,?,?,?,?)').run(orden_id, 'manual', 'email', 'enviado', String(asunto || '').slice(0, 200));
    res.json({ ok: true });
  } catch (e) { res.json({ ok: false, error: errorCorreo(e) }); }
});

// ─── RECURSOS TÉCNICOS — ACCESOS RÁPIDOS Y PLANOS ESQUEMÁTICOS ───────────────
const ENCRYPT_KEY = seguridad.claveCifrado();
function encryptPass(text) {
  if (!text) return '';
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', ENCRYPT_KEY, iv);
  const encrypted = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
  return iv.toString('hex') + ':' + encrypted.toString('hex');
}
function decryptConClave(encrypted, clave) {
  const [ivHex, dataHex] = encrypted.split(':');
  const decipher = crypto.createDecipheriv('aes-256-cbc', clave, Buffer.from(ivHex, 'hex'));
  return Buffer.concat([decipher.update(Buffer.from(dataHex, 'hex')), decipher.final()]).toString('utf8');
}
function decryptPass(encrypted) {
  if (!encrypted || !encrypted.includes(':')) return '';
  try { return decryptConClave(encrypted, ENCRYPT_KEY); } catch(e) {}
  // Guardado con la clave anterior (la que estaba escrita en el código): se lee y,
  // al listar, se vuelve a cifrar con la clave propia de esta instalación.
  try { return decryptConClave(encrypted, seguridad.CLAVE_CIFRADO_ANTERIOR); } catch(e) { return ''; }
}
function migrarCifradoAccesos(db) {
  db.prepare('SELECT id, password_enc FROM recursos_accesos WHERE password_enc IS NOT NULL AND password_enc != ""').all().forEach(r => {
    try { decryptConClave(r.password_enc, ENCRYPT_KEY); }
    catch(e) {
      const claro = decryptPass(r.password_enc);
      if (claro) db.prepare('UPDATE recursos_accesos SET password_enc=? WHERE id=?').run(encryptPass(claro), r.id);
    }
  });
}

// ── ACCESOS RÁPIDOS (herramientas con login) ──
// El admin decide qué ve/hace el técnico con estos accesos:
//  - por acceso: 'ninguno' | 'usar' (abre el link y copia usuario/clave sin verlos) | 'completo'
//  - global: "técnico gestiona todo" (crear/editar/borrar y ver claves)
// Todo se aplica acá en el servidor; las claves de un acceso en modo 'usar'
// NUNCA viajan en el listado — solo salen por /credencial, al hacer clic.
function tecnicoGestionaAccesos(db) {
  return db.prepare("SELECT valor FROM config WHERE clave='tecnico_gestiona_accesos'").get()?.valor === '1';
}
const puedeGestionarAccesos = (req, res, next) =>
  (req.user.rol === 'admin' || tecnicoGestionaAccesos(req.db))
    ? next()
    : res.status(403).json({ error: 'Solo el administrador puede gestionar los accesos' });

app.get('/api/recursos/accesos-permisos', authMiddleware, (req, res) => {
  res.json({ gestiona: req.user.rol === 'admin' || tecnicoGestionaAccesos(req.db), tecnico_gestiona: tecnicoGestionaAccesos(req.db) });
});

app.put('/api/recursos/accesos-permisos', authMiddleware, adminOnly, (req, res) => {
  req.db.prepare("INSERT OR REPLACE INTO config (clave,valor) VALUES ('tecnico_gestiona_accesos',?)").run(req.body.tecnico_gestiona ? '1' : '0');
  res.json({ ok: true });
});

app.get('/api/recursos/accesos', authMiddleware, (req, res) => {
  migrarCifradoAccesos(req.db);
  const data = req.db.prepare('SELECT * FROM recursos_accesos WHERE activo=1 ORDER BY nombre').all();
  const full = r => ({ ...r, password: decryptPass(r.password_enc), password_enc: undefined });
  if (req.user.rol === 'admin' || tecnicoGestionaAccesos(req.db)) return res.json(data.map(full));
  res.json(data.filter(r => r.acceso_tecnico === 'usar' || r.acceso_tecnico === 'completo').map(r =>
    r.acceso_tecnico === 'completo' ? full(r) : ({
      id: r.id, nombre: r.nombre, categoria: r.categoria, url: r.url, notas: r.notas,
      codigo_promo: r.codigo_promo, descuento: r.descuento, acceso_tecnico: 'usar',
      tiene_usuario: !!r.usuario, tiene_password: !!r.password_enc
    })));
});

// Entrega usuario/clave solo para copiarlos al portapapeles (no se muestran).
app.post('/api/recursos/accesos/:id/credencial', authMiddleware, (req, res) => {
  const r = req.db.prepare('SELECT * FROM recursos_accesos WHERE id=? AND activo=1').get(req.params.id);
  if (!r) return res.status(404).json({ error: 'Acceso no encontrado' });
  const permitido = req.user.rol === 'admin' || tecnicoGestionaAccesos(req.db) || r.acceso_tecnico === 'usar' || r.acceso_tecnico === 'completo';
  if (!permitido) return res.status(403).json({ error: 'El administrador no habilitó este acceso' });
  console.log(`[accesos] ${req.user.nombre} (${req.user.rol}) copió credenciales de "${r.nombre}"`);
  res.json({ usuario: r.usuario || '', password: decryptPass(r.password_enc) });
});

app.post('/api/recursos/accesos', authMiddleware, puedeGestionarAccesos, (req, res) => {
  const { nombre, categoria, url, usuario, password, codigo_promo, descuento, notas, acceso_tecnico } = req.body;
  if (!nombre) return res.status(400).json({ error: 'El nombre es obligatorio' });
  if (url && !/^https?:\/\//i.test(url)) return res.status(400).json({ error: 'El link tiene que empezar con http:// o https://' });
  // Solo el admin define qué nivel de acceso tiene el técnico
  const nivel = req.user.rol === 'admin' && ['ninguno','usar','completo'].includes(acceso_tecnico) ? acceso_tecnico : 'ninguno';
  const r = req.db.prepare(`INSERT INTO recursos_accesos (nombre,categoria,url,usuario,password_enc,codigo_promo,descuento,notas,acceso_tecnico) VALUES (?,?,?,?,?,?,?,?,?)`)
    .run(nombre, categoria||'Esquemáticos', url||'', usuario||'', encryptPass(password), codigo_promo||'', descuento||'', notas||'', nivel);
  res.json({ id: r.lastInsertRowid });
});

app.put('/api/recursos/accesos/:id', authMiddleware, puedeGestionarAccesos, (req, res) => {
  const { nombre, categoria, url, usuario, password, codigo_promo, descuento, notas, acceso_tecnico } = req.body;
  if (url && !/^https?:\/\//i.test(url)) return res.status(400).json({ error: 'El link tiene que empezar con http:// o https://' });
  // Si no envían password nueva, mantener la actual
  const actual = req.db.prepare('SELECT password_enc, acceso_tecnico FROM recursos_accesos WHERE id=?').get(req.params.id);
  const passEnc = password ? encryptPass(password) : (actual?.password_enc || '');
  const nivel = req.user.rol === 'admin' && ['ninguno','usar','completo'].includes(acceso_tecnico) ? acceso_tecnico : (actual?.acceso_tecnico || 'ninguno');
  req.db.prepare(`UPDATE recursos_accesos SET nombre=?,categoria=?,url=?,usuario=?,password_enc=?,codigo_promo=?,descuento=?,notas=?,acceso_tecnico=? WHERE id=?`)
    .run(nombre, categoria, url, usuario, passEnc, codigo_promo, descuento, notas, nivel, req.params.id);
  res.json({ ok: true });
});

app.delete('/api/recursos/accesos/:id', authMiddleware, puedeGestionarAccesos, (req, res) => {
  req.db.prepare('UPDATE recursos_accesos SET activo=0 WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ── PLANOS ESQUEMÁTICOS (archivos) ──
const storagePlanos = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = require('path').join(UPLOADS_DIR, 'planos');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => cb(null, `plano_${Date.now()}_${file.originalname.replace(/[^a-zA-Z0-9.\-_]/g,'_')}`)
});
const uploadPlano = multer({ storage: storagePlanos, limits: { fileSize: 20*1024*1024 } });

app.get('/api/recursos/planos', authMiddleware, adminOnly, (req, res) => {
  const { q, categoria } = req.query;
  let sql = 'SELECT * FROM recursos_planos WHERE activo=1';
  const params = [];
  if (q) { sql += ' AND (titulo LIKE ? OR marca LIKE ? OR modelo LIKE ?)'; const b=`%${q}%`; params.push(b,b,b); }
  if (categoria) { sql += ' AND categoria=?'; params.push(categoria); }
  sql += ' ORDER BY created_at DESC';
  res.json(req.db.prepare(sql).all(...params));
});

// Catálogo para técnicos/caja: NO devuelve archivo_url salvo que ya esté comprado (o sea admin).
// Así el esquema no se puede "ver" sin pagar, aunque se liste en el catálogo.
app.get('/api/recursos/planos/catalogo', authMiddleware, (req, res) => {
  const { q, categoria } = req.query;
  let sql = 'SELECT * FROM recursos_planos WHERE activo=1';
  const params = [];
  if (q) { sql += ' AND (titulo LIKE ? OR marca LIKE ? OR modelo LIKE ?)'; const b=`%${q}%`; params.push(b,b,b); }
  if (categoria) { sql += ' AND categoria=?'; params.push(categoria); }
  sql += ' ORDER BY created_at DESC';
  const planos = req.db.prepare(sql).all(...params);
  const comprados = new Set(
    req.db.prepare('SELECT plano_id FROM plano_compras WHERE usuario_id=?').all(req.user.usuario_id).map(c => c.plano_id)
  );
  res.json(planos.map(p => {
    const desbloqueado = req.user.rol === 'admin' || comprados.has(p.id);
    const { archivo_url, archivo_nombre, ...resto } = p;
    return { ...resto, desbloqueado, ...(desbloqueado ? { archivo_url, archivo_nombre } : {}) };
  }));
});

// Comprar/desbloquear un esquema con créditos
app.post('/api/recursos/planos/:id/comprar', authMiddleware, (req, res) => {
  const plano = req.db.prepare('SELECT * FROM recursos_planos WHERE id=? AND activo=1').get(req.params.id);
  if (!plano) return res.status(404).json({ error: 'Esquema no encontrado' });

  const yaComprado = req.db.prepare('SELECT id FROM plano_compras WHERE usuario_id=? AND plano_id=?').get(req.user.usuario_id, plano.id);
  if (yaComprado || req.user.rol === 'admin') return res.json({ ok: true, ya_desbloqueado: true });

  const usuario = req.db.prepare('SELECT creditos FROM usuarios WHERE id=?').get(req.user.usuario_id);
  if ((usuario?.creditos || 0) < plano.precio_creditos) {
    return res.status(402).json({ error: `Créditos insuficientes. Necesitás ${plano.precio_creditos}, tenés ${usuario?.creditos || 0}` });
  }

  const tx = req.db.transaction(() => {
    req.db.prepare('UPDATE usuarios SET creditos = creditos - ? WHERE id=?').run(plano.precio_creditos, req.user.usuario_id);
    req.db.prepare('INSERT INTO plano_compras (usuario_id,plano_id,precio_pagado) VALUES (?,?,?)').run(req.user.usuario_id, plano.id, plano.precio_creditos);
    req.db.prepare(`INSERT INTO creditos_movimientos (usuario_id,tipo,cantidad,motivo) VALUES (?,'gasto',?,?)`).run(req.user.usuario_id, plano.precio_creditos, `Esquema: ${plano.titulo}`);
  });
  tx();
  res.json({ ok: true });
});

// Saldo de créditos del usuario logueado
app.get('/api/mis-creditos', authMiddleware, (req, res) => {
  const u = req.db.prepare('SELECT creditos FROM usuarios WHERE id=?').get(req.user.usuario_id);
  res.json({ creditos: u?.creditos || 0 });
});

// Cargar créditos a un usuario (solo admin — hasta integrar pasarela de pago real)
app.post('/api/usuarios/:id/creditos', authMiddleware, adminOnly, (req, res) => {
  const cantidad = parseInt(req.body.cantidad);
  const motivo = req.body.motivo || 'Carga manual';
  if (!cantidad || cantidad === 0) return res.status(400).json({ error: 'Cantidad inválida' });
  const tx = req.db.transaction(() => {
    req.db.prepare('UPDATE usuarios SET creditos = MAX(0, creditos + ?) WHERE id=?').run(cantidad, req.params.id);
    req.db.prepare(`INSERT INTO creditos_movimientos (usuario_id,tipo,cantidad,motivo) VALUES (?,?,?,?)`).run(req.params.id, cantidad > 0 ? 'carga' : 'ajuste', Math.abs(cantidad), motivo);
  });
  tx();
  const u = req.db.prepare('SELECT creditos FROM usuarios WHERE id=?').get(req.params.id);
  res.json({ ok: true, creditos: u.creditos });
});

app.post('/api/recursos/planos', authMiddleware, adminOnly, (req, res, next) => {
  uploadPlano.single('archivo')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    const { titulo, marca, modelo, categoria, descripcion, precio_creditos } = req.body;
    if (!titulo) return res.status(400).json({ error: 'El título es obligatorio' });
    const archivo_url = req.file ? `/uploads/planos/${req.file.filename}` : '';
    const archivo_nombre = req.file ? req.file.originalname : '';
    const r = req.db.prepare(`INSERT INTO recursos_planos (titulo,marca,modelo,categoria,archivo_url,archivo_nombre,descripcion,precio_creditos) VALUES (?,?,?,?,?,?,?,?)`)
      .run(titulo, marca||'', modelo||'', categoria||'Celular', archivo_url, archivo_nombre, descripcion||'', parseInt(precio_creditos)||0);
    res.json({ id: r.lastInsertRowid });
  });
});

app.delete('/api/recursos/planos/:id', authMiddleware, adminOnly, (req, res) => {
  const p = req.db.prepare('SELECT archivo_url FROM recursos_planos WHERE id=?').get(req.params.id);
  if (p?.archivo_url) { try { const fp=path.join(__dirname,'public',p.archivo_url); if(fs.existsSync(fp)) fs.unlinkSync(fp); } catch(e){} }
  req.db.prepare('UPDATE recursos_planos SET activo=0 WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ─── TECNIBOT: asistente de IA con base de conocimiento propia ────────────────
// Addon PAGO por taller: lo habilita el distribuidor (vos) desde el panel de
// gestión de talleres. Sin esto activado en el taller, el módulo entero queda
// bloqueado — no importa el rol del usuario dentro del taller.
// Hosting: lo habilita el distribuidor en el negocio. Instalación local: lo trae el código de activación (y se apaga solo al vencer su fecha).
// Lo que ya estaba habilitado en el registro del negocio sigue habilitado: esto solo SUMA la vía del código.
function tecnibotIncluido(req) {
  if (req.tenant && planes.tecnibotTaller(req.tenant)) return true;
  return !MODO_DISTRIBUIDOR && planes.queIncluye(req, false).addons.tecnibot === true;
}
function tecnibotHabilitado(req, res, next) {
  if (!tecnibotIncluido(req)) {
    return res.status(402).json({ error: 'Tecnibot no está incluido en tu plan actual. Contactá a SysTech para contratar el addon.' });
  }
  next();
}

// Info pública (para que el frontend sepa si mostrar el módulo en el menú, sin
// exponer nada sensible del taller)
app.get('/api/tecnibot/estado', authMiddleware, (req, res) => {
  res.json({ habilitado: tecnibotIncluido(req) });
});

function tecnibotCfg(db) {
  const rows = db.prepare('SELECT clave,valor FROM tecnibot_config').all();
  const cfg = {}; rows.forEach(r => cfg[r.clave] = r.valor);
  return cfg;
}

// ─── De dónde sale la IA de Tecnibot ──────────────────────────────────────────
//  1) Clave propia del negocio (Configuración de Tecnibot): como siempre, sin cupo.
//  2) Servidor de SysTech con clave central (TECNIBOT_API_KEY, o la de AsystenBot): incluida en el plan,
//     con un cupo de consultas por mes y por negocio (TECNIBOT_CUPO_DEFECTO, o el cupo propio del negocio).
//  3) Instalación local sin clave propia: pide cada respuesta al servidor central (relevo), que valida el
//     código de licencia firmado (que incluya Tecnibot y no esté vencido) y descuenta del cupo de ese negocio.
// La clave central nunca sale del servidor de SysTech.
masterDb.exec(`CREATE TABLE IF NOT EXISTS tecnibot_consumo (clave TEXT NOT NULL, mes TEXT NOT NULL, consultas INTEGER DEFAULT 0, llamadas INTEGER DEFAULT 0, PRIMARY KEY (clave, mes))`);
const TECNIBOT_URL_API = () => process.env.TECNIBOT_API_URL || 'https://api.anthropic.com/v1/messages';   // la variable existe para las pruebas
const tecnibotCupoDefecto = () => Number(process.env.TECNIBOT_CUPO_DEFECTO) || 300;
const mesActualTb = () => planes.hoyLocal().slice(0, 7);
function claveCentralTecnibot() {
  const env = (process.env.TECNIBOT_API_KEY || process.env.ASYSTENBOT_API_KEY || '').trim();
  if (env) return env;
  try { return fs.readFileSync(path.join(__dirname, 'data', 'asistente-clave.txt'), 'utf8').trim(); } catch (e) { return ''; }
}
function consumoTecnibot(clave) {
  return masterDb.prepare('SELECT consultas, llamadas FROM tecnibot_consumo WHERE clave=? AND mes=?').get(clave, mesActualTb()) || { consultas: 0, llamadas: 0 };
}
function sumarConsumoTecnibot(clave, consultas, llamadas) {
  masterDb.prepare(`INSERT INTO tecnibot_consumo (clave, mes, consultas, llamadas) VALUES (?,?,?,?)
    ON CONFLICT(clave, mes) DO UPDATE SET consultas = consultas + excluded.consultas, llamadas = llamadas + excluded.llamadas`).run(clave, mesActualTb(), consultas, llamadas);
}
// Con la clave central no se usa el modelo más caro: el costo lo pagás vos.
function modeloCentralTecnibot(pedido) {
  const m = process.env.TECNIBOT_MODELO || pedido || 'claude-sonnet-4-6';
  return /opus/i.test(m) ? (process.env.TECNIBOT_MODELO || 'claude-sonnet-4-6') : m;
}
function fuenteTecnibot(req, cfg) {
  if (cfg.tecnibot_api_key) return { tipo: 'directa', clave: cfg.tecnibot_api_key, central: false };
  const c = claveCentralTecnibot();
  if (c) {
    const clave = req.tenant && req.tenant.subdominio ? 't:' + req.tenant.subdominio : 't:default';
    return { tipo: 'directa', clave: c, central: true, cupo: Number(req.tenant && req.tenant.tecnibot_cupo) || tecnibotCupoDefecto(), claveConsumo: clave };
  }
  const url = central.urlCentral(), lic = (() => { try { return licencia.leerLicenciaActual(); } catch (e) { return null; } })();
  if (!MODO_DISTRIBUIDOR && url && lic && lic.codigo) return { tipo: 'relevo', url, codigo: lic.codigo, central: true };
  return null;
}
async function llamarClaudeTecnibot(f, cuerpo, esPrimera) {
  if (f.tipo === 'relevo') {
    const r = await fetch(`${f.url}/api/tecnibot/relevo`, { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ codigo: f.codigo, nueva: !!esPrimera, cuerpo }), signal: AbortSignal.timeout(60000) });
    const data = await r.json().catch(() => ({}));
    return { ok: r.ok, status: r.status, data };
  }
  const r = await fetch(TECNIBOT_URL_API(), { method: 'POST', signal: AbortSignal.timeout(60000),
    headers: { 'Content-Type': 'application/json', 'x-api-key': f.clave, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify(f.central ? { ...cuerpo, model: modeloCentralTecnibot(cuerpo.model) } : cuerpo) });
  const data = await r.json().catch(() => ({}));
  return { ok: r.ok, status: r.status, data };
}

// SERVIDOR CENTRAL: relevo de Tecnibot para las instalaciones locales (solo responde si acá está la clave central).
app.post('/api/tecnibot/relevo', async (req, res) => {
  const clave = claveCentralTecnibot();
  if (!clave || !MODO_DISTRIBUIDOR) return res.status(404).json({ error: 'Este equipo no es el servidor central de SysTech.' });
  try {
    const datos = licencia.verificarCodigo(req.body && req.body.codigo);
    if (!datos) return res.status(401).json({ error: 'Licencia no válida. Reactivá el sistema con tu código de activación.' });
    if (!datos.tecnibot) return res.status(402).json({ error: 'Tecnibot no está incluido en tu plan. Podés sumarlo en Configuración → Sistema → Comprar o renovar.' });
    if (datos.tecnibotHasta && datos.tecnibotHasta < planes.hoyLocal()) return res.status(402).json({ error: 'Tecnibot venció. Renovalo en Configuración → Sistema → Comprar o renovar.', vencido: true });
    const cuerpo = req.body.cuerpo || {};
    if (!Array.isArray(cuerpo.messages) || !cuerpo.messages.length) return res.status(400).json({ error: 'Faltan mensajes' });
    const claveConsumo = 'n:' + datos.negocioId, cupo = tecnibotCupoDefecto(), cons = consumoTecnibot(claveConsumo), nueva = !!req.body.nueva;
    if (nueva && cons.consultas >= cupo) return res.status(429).json({ error: `Se agotó el cupo de consultas de Tecnibot de este mes (${cupo}). Se renueva el mes próximo.`, cupo_agotado: true });
    if (cons.llamadas >= cupo * 6) return res.status(429).json({ error: 'Se superó el tope técnico de llamadas de este mes. Consultá con SysTech.', cupo_agotado: true });
    const limpio = { model: modeloCentralTecnibot(cuerpo.model), max_tokens: Math.min(Number(cuerpo.max_tokens) || 800, 1500),
      system: String(cuerpo.system || '').slice(0, 60000), messages: cuerpo.messages.slice(-30), ...(Array.isArray(cuerpo.tools) ? { tools: cuerpo.tools.slice(0, 12) } : {}) };
    const r = await llamarClaudeTecnibot({ tipo: 'directa', clave, central: true }, limpio, false);
    sumarConsumoTecnibot(claveConsumo, nueva ? 1 : 0, 1);
    if (!r.ok) { console.error('[Tecnibot relevo] API:', r.status); return res.status(502).json({ error: 'No pude comunicarme con el servicio de IA. Probá de nuevo en un rato.' }); }
    res.json({ ...r.data, _cupo: { usadas: cons.consultas + (nueva ? 1 : 0), total: cupo } });
  } catch (e) {
    console.error('[Tecnibot relevo]', e.message);
    res.status(500).json({ error: 'No se pudo completar la consulta.' });
  }
});

// Config (solo admin) — la API key nunca sale de acá, nunca pasa por /api/config
app.get('/api/tecnibot/config', authMiddleware, tecnibotHabilitado, adminOnly, (req, res) => {
  const cfg = tecnibotCfg(req.db);
  res.json({
    tecnibot_activo: cfg.tecnibot_activo || '0',
    tecnibot_modelo: cfg.tecnibot_modelo || 'claude-sonnet-4-6',
    api_key_configurada: !!(cfg.tecnibot_api_key && cfg.tecnibot_api_key.length > 10),
    api_key_preview: cfg.tecnibot_api_key ? `${cfg.tecnibot_api_key.slice(0,10)}••••••••${cfg.tecnibot_api_key.slice(-4)}` : '',
    ...(() => {   // si no hay clave propia: ¿usa el servicio de SysTech incluido en el plan? (y cuánto cupo le queda)
      const f = fuenteTecnibot(req, cfg);
      if (!f || !f.central) return { servicio_systech: false };
      return { servicio_systech: true, ...(f.tipo === 'directa' ? { cupo: { usadas: consumoTecnibot(f.claveConsumo).consultas, total: f.cupo } } : {}) };
    })()
  });
});
app.put('/api/tecnibot/config', authMiddleware, tecnibotHabilitado, adminOnly, (req, res) => {
  const { tecnibot_api_key, tecnibot_activo, tecnibot_modelo } = req.body;
  const stmt = req.db.prepare('INSERT OR REPLACE INTO tecnibot_config (clave,valor) VALUES (?,?)');
  if (tecnibot_api_key) stmt.run('tecnibot_api_key', tecnibot_api_key.trim()); // solo pisa si mandaron una nueva
  if (tecnibot_activo !== undefined) stmt.run('tecnibot_activo', tecnibot_activo ? '1' : '0');
  if (tecnibot_modelo) stmt.run('tecnibot_modelo', tecnibot_modelo);
  res.json({ ok: true });
});

// Base de conocimiento — CRUD (solo admin la edita; todos los roles la consultan a través del chat)
app.get('/api/tecnibot/articulos', authMiddleware, tecnibotHabilitado, adminOnly, (req, res) => {
  const { q } = req.query;
  let sql = 'SELECT * FROM tecnibot_articulos WHERE activo=1';
  const params = [];
  if (q) { sql += ' AND (titulo LIKE ? OR contenido LIKE ? OR palabras_clave LIKE ?)'; const b=`%${q}%`; params.push(b,b,b); }
  sql += ' ORDER BY categoria, titulo';
  res.json(req.db.prepare(sql).all(...params));
});
app.post('/api/tecnibot/articulos', authMiddleware, tecnibotHabilitado, adminOnly, (req, res) => {
  const { categoria, marca, titulo, contenido, modelo_aplicable, palabras_clave } = req.body;
  if (!titulo || !contenido) return res.status(400).json({ error: 'Título y contenido son obligatorios' });
  const r = req.db.prepare(`INSERT INTO tecnibot_articulos (categoria,marca,titulo,contenido,modelo_aplicable,palabras_clave) VALUES (?,?,?,?,?,?)`)
    .run(categoria||'General', marca||'Multimarca', titulo, contenido, modelo_aplicable||'Todos', palabras_clave||'');
  res.json({ id: r.lastInsertRowid });
});
app.put('/api/tecnibot/articulos/:id', authMiddleware, tecnibotHabilitado, adminOnly, (req, res) => {
  const { categoria, marca, titulo, contenido, modelo_aplicable, palabras_clave } = req.body;
  if (!titulo || !contenido) return res.status(400).json({ error: 'Título y contenido son obligatorios' });
  req.db.prepare(`UPDATE tecnibot_articulos SET categoria=?,marca=?,titulo=?,contenido=?,modelo_aplicable=?,palabras_clave=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
    .run(categoria||'General', marca||'Multimarca', titulo, contenido, modelo_aplicable||'Todos', palabras_clave||'', req.params.id);
  res.json({ ok: true });
});
app.delete('/api/tecnibot/articulos/:id', authMiddleware, tecnibotHabilitado, adminOnly, (req, res) => {
  req.db.prepare('UPDATE tecnibot_articulos SET activo=0 WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// Búsqueda simple por palabras clave en la base de conocimiento (igual idea que el Tecnibot original)
function buscarConocimientoTecnibot(db, mensaje) {
  const palabras = mensaje.toLowerCase()
    .split(/\s+/).map(p => p.replace(/[.,;:!?¿¡]/g, '')).filter(p => p.length > 3);
  if (!palabras.length) return [];
  const condiciones = palabras.map(() => '(titulo LIKE ? OR contenido LIKE ? OR palabras_clave LIKE ?)').join(' OR ');
  const params = [];
  palabras.forEach(p => { const b = `%${p}%`; params.push(b,b,b); });
  const candidatos = db.prepare(`SELECT * FROM tecnibot_articulos WHERE activo=1 AND (${condiciones})`).all(...params);
  // Relevancia simple: cuántas palabras clave de la consulta matchean cada artículo
  const puntuados = candidatos.map(a => {
    const texto = `${a.titulo} ${a.contenido} ${a.palabras_clave}`.toLowerCase();
    const score = palabras.reduce((acc,p) => acc + (texto.includes(p) ? 1 : 0), 0);
    return { ...a, score };
  }).sort((a,b) => b.score - a.score);
  return puntuados.slice(0, 6);
}

const TECNIBOT_SYSTEM_PROMPT = `Sos Tecnibot, un asistente técnico especializado en diagnóstico y reparación de
dispositivos electrónicos (celulares, tablets, notebooks, PC), con foco en Apple y marcas Android.
Trabajás para técnicos de taller reales.

- Respondés como un colega técnico con experiencia real, directo y práctico.
- Si el síntoma es vago, pedís el dato clave que falta (modelo exacto, mensaje que muestra el
  equipo, historial de reparaciones previas) antes de tirar un diagnóstico.
- Cuando corresponda, das el protocolo de diagnóstico paso a paso, con valores exactos de
  voltaje/corriente a medir.
- Sos claro sobre qué ES reparable y qué NO. Nunca prometés recuperar algo (como Face ID o Touch
  ID pareado) si la base de conocimiento indica que no tiene solución de terceros.
- Si la consulta excede tu base de conocimiento actual, lo decís con honestidad en vez de inventar.
- Además del diagnóstico técnico, podés responder consultas administrativas del taller (órdenes,
  stock, clientes, comprobantes) usando las herramientas disponibles.
- Respuestas concisas, en español rioplatense, con terminología técnica real. Sin asteriscos de
  Markdown para negritas — tu respuesta se muestra en una burbuja de chat de texto plano.`;

// Versión para Caja: SIN conocimiento técnico de reparación a propósito — Caja
// no diagnostica equipos, solo necesita el lado administrativo (facturación,
// estado de órdenes, clientes). Si le preguntan algo técnico, tiene que decir
// que no es su función, no inventar ni improvisar un diagnóstico.
const ASISTENTE_CAJA_SYSTEM_PROMPT = `Sos el Asistente de SysTech para el sector de Caja/Facturación de un
taller técnico. NO sos un asistente de diagnóstico técnico — no tenés conocimiento de reparación de
dispositivos y no debés intentar responder sobre eso.

- Ayudás con consultas administrativas: estado de órdenes, comprobantes/facturas emitidos, datos de
  clientes, y resumen general del taller (cobros pendientes, etc.) usando las herramientas disponibles.
- Si te preguntan algo técnico de reparación (diagnóstico, qué falla tiene un equipo, cómo arreglar
  algo), respondé con amabilidad que eso lo maneja Tecnibot en el sector de Taller, no vos.
- Solo CONSULTÁS información, nunca la modificás. Si piden crear/editar algo, explicás que hay que
  hacerlo desde el sistema directamente.
- Respuestas concisas, en español rioplatense. Sin asteriscos de Markdown — se muestra en una
  burbuja de chat de texto plano.`;

// ─── HERRAMIENTAS PARA EL ASISTENTE (Tecnibot y Asistente de Caja comparten estas) ─
// Solo lectura a propósito: le da datos reales del taller sin riesgo de que
// modifique algo por error o por una consulta mal interpretada. Si más adelante
// querés que también cree/edite cosas, se puede sumar como acción con
// confirmación explícita del usuario antes de ejecutarla.
const TECNIBOT_TOOLS = [
  {
    name: 'buscar_orden',
    description: 'Busca órdenes de trabajo por número, nombre de cliente o equipo. Usar cuando pregunten por el estado de una reparación.',
    input_schema: { type: 'object', properties: {
      texto: { type: 'string', description: 'Número de orden, nombre de cliente o modelo de equipo a buscar' }
    }, required: ['texto'] }
  },
  {
    name: 'consultar_stock',
    description: 'Busca productos/repuestos en el stock por nombre o código. Usar para saber si hay stock de un repuesto y su precio.',
    input_schema: { type: 'object', properties: {
      texto: { type: 'string', description: 'Nombre o código del producto a buscar' }
    }, required: ['texto'] }
  },
  {
    name: 'consultar_cliente',
    description: 'Busca datos de contacto de un cliente por nombre o teléfono.',
    input_schema: { type: 'object', properties: {
      texto: { type: 'string', description: 'Nombre o teléfono del cliente' }
    }, required: ['texto'] }
  },
  {
    name: 'consultar_comprobante',
    description: 'Busca facturas, presupuestos y notas emitidas por número o nombre de cliente. Usar para consultas de facturación: si se emitió, el total, el estado, la fecha.',
    input_schema: { type: 'object', properties: {
      texto: { type: 'string', description: 'Número de comprobante o nombre de cliente' }
    }, required: ['texto'] }
  },
  {
    name: 'resumen_taller',
    description: 'Trae un resumen general del estado del taller ahora mismo: órdenes activas, cobros pendientes, productos con stock bajo. Usar para preguntas generales tipo "cómo estamos hoy" o "qué hay pendiente".',
    input_schema: { type: 'object', properties: {} }
  }
];

function ejecutarHerramientaTecnibot(db, nombre, input) {
  const b = `%${(input.texto||'').trim()}%`;
  switch (nombre) {
    case 'buscar_orden': {
      const rows = db.prepare(`
        SELECT o.numero,o.equipo,o.marca,o.modelo,o.estado,o.total,o.cobrado,o.fecha_ingreso,c.nombre as cliente
        FROM ordenes o LEFT JOIN clientes c ON o.cliente_id=c.id
        WHERE o.numero LIKE ? OR o.equipo LIKE ? OR c.nombre LIKE ?
        ORDER BY o.fecha_ingreso DESC LIMIT 8
      `).all(b,b,b);
      return rows.length ? rows : { mensaje: 'No se encontraron órdenes con ese criterio.' };
    }
    case 'consultar_stock': {
      const rows = db.prepare(`SELECT codigo,nombre,categoria,stock,stock_minimo,precio_venta FROM productos WHERE nombre LIKE ? OR codigo LIKE ? ORDER BY nombre LIMIT 8`).all(b,b);
      return rows.length ? rows : { mensaje: 'No se encontraron productos con ese criterio.' };
    }
    case 'consultar_cliente': {
      const rows = db.prepare(`SELECT nombre,telefono,email,direccion FROM clientes WHERE nombre LIKE ? OR telefono LIKE ? LIMIT 8`).all(b,b);
      return rows.length ? rows : { mensaje: 'No se encontraron clientes con ese criterio.' };
    }
    case 'consultar_comprobante': {
      const rows = db.prepare(`
        SELECT numero,tipo,letra,cliente_nombre,cliente_apellido,total,estado,fecha
        FROM comprobantes WHERE numero LIKE ? OR cliente_nombre LIKE ? OR cliente_apellido LIKE ?
        ORDER BY fecha DESC LIMIT 8
      `).all(b,b,b);
      return rows.length ? rows : { mensaje: 'No se encontraron comprobantes con ese criterio.' };
    }
    case 'resumen_taller': {
      return {
        ordenes_activas: db.prepare(`SELECT COUNT(*) as c FROM ordenes WHERE estado NOT IN ('entregado','cancelado')`).get().c,
        cobros_pendientes: db.prepare(`SELECT COUNT(*) as c FROM ordenes WHERE estado='listo' AND cobrado=0`).get().c,
        productos_bajo_stock: db.prepare(`SELECT COUNT(*) as c FROM productos WHERE stock<=stock_minimo`).get().c,
        ordenes_por_estado: db.prepare(`SELECT estado,COUNT(*) as cantidad FROM ordenes GROUP BY estado`).all()
      };
    }
    default:
      return { error: 'Herramienta desconocida' };
  }
}

// CELULAR-1.7.1: el chat es una función para que lo use también el celular conectado por QR
const tecnibotChat = async (req, res) => {
  if (req.user.rol === 'caja') return res.status(403).json({ error: 'Tecnibot no está disponible para este usuario.' });
  try {
    const cfg = tecnibotCfg(req.db);
    if (cfg.tecnibot_activo !== '1') return res.status(403).json({ error: 'Tecnibot está desactivado. Activalo desde Configuración.' });
    const fuente = fuenteTecnibot(req, cfg);
    if (!fuente) return res.status(500).json({ error: 'Tecnibot todavía no tiene conexión con la IA: cargá una clave en Configuración → Tecnibot, o pedile a SysTech que active el servicio incluido en tu plan.' });
    if (fuente.tipo === 'directa' && fuente.central && consumoTecnibot(fuente.claveConsumo).consultas >= fuente.cupo) {
      return res.status(429).json({ error: `Se agotó el cupo de consultas de Tecnibot de este mes (${fuente.cupo}). Se renueva el mes próximo; para ampliarlo, consultá con SysTech.`, cupo_agotado: true });
    }

    const { messages } = req.body;
    if (!messages || !Array.isArray(messages) || !messages.length) return res.status(400).json({ error: 'Faltan mensajes' });

    // Taller y Admin tienen el diagnóstico técnico completo. Caja tiene la misma
    // "cabeza" (Claude + mismas herramientas de consulta), pero sin la base de
    // conocimiento técnica — así no puede improvisar un diagnóstico de reparación.
    const tieneAccesoTecnico = ['taller', 'admin'].includes(req.user.rol);

    const ultimoMensaje = messages[messages.length - 1];
    let systemPrompt;
    let articulos = [];

    if (tieneAccesoTecnico) {
      articulos = buscarConocimientoTecnibot(req.db, ultimoMensaje.content || '');
      const conocimiento = articulos.length
        ? articulos.map(a => `### ${a.titulo}\n${a.contenido}`).join('\n\n---\n\n')
        : '(Sin artículos relevantes en la base de conocimiento para esta consulta.)';
      systemPrompt = `${TECNIBOT_SYSTEM_PROMPT}\n\nADEMÁS DE DIAGNÓSTICO TÉCNICO, PODÉS AYUDAR CON TAREAS ADMINISTRATIVAS del taller:\n` +
        `estado de órdenes, stock de repuestos, datos de clientes, comprobantes y resúmenes generales,\n` +
        `usando las herramientas disponibles. Solo podés consultar información, no modificarla — si te\n` +
        `piden crear, editar o borrar algo, explicá que eso todavía hay que hacerlo desde el sistema.\n\n` +
        `BASE DE CONOCIMIENTO TÉCNICO RELEVANTE PARA ESTA CONSULTA:\n${conocimiento}`;
    } else {
      systemPrompt = ASISTENTE_CAJA_SYSTEM_PROMPT;
    }

    let conversacion = messages.map(m => ({ role: m.role, content: m.content }));
    let replyText = '';
    const MAX_TURNOS_HERRAMIENTA = 4;

    for (let turno = 0; turno < MAX_TURNOS_HERRAMIENTA; turno++) {
      const respuesta = await llamarClaudeTecnibot(fuente, {
        model: cfg.tecnibot_modelo || 'claude-sonnet-4-6',
        max_tokens: 800,
        system: systemPrompt,
        tools: TECNIBOT_TOOLS,
        messages: conversacion
      }, turno === 0);
      const data = respuesta.data;
      if (fuente.tipo === 'directa' && fuente.central) sumarConsumoTecnibot(fuente.claveConsumo, turno === 0 ? 1 : 0, 1);
      if (!respuesta.ok) {
        console.error('Error de la API de Claude:', respuesta.status, data && data.error);
        if (fuente.tipo === 'relevo' && [401, 402, 429].includes(respuesta.status)) return res.status(respuesta.status === 401 ? 402 : respuesta.status).json({ error: data.error || 'El servicio de IA no está disponible para tu licencia.', cupo_agotado: !!data.cupo_agotado });
        return res.status(502).json({ error: (data && (typeof data.error === 'string' ? data.error : data.error && data.error.message)) || 'Error al contactar a Claude' });
      }

      replyText = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n');

      if (data.stop_reason !== 'tool_use') break; // respuesta final, sin más herramientas que ejecutar

      const bloquesHerramienta = data.content.filter(b => b.type === 'tool_use');
      conversacion.push({ role: 'assistant', content: data.content });
      conversacion.push({
        role: 'user',
        content: bloquesHerramienta.map(tb => ({
          type: 'tool_result',
          tool_use_id: tb.id,
          content: JSON.stringify(ejecutarHerramientaTecnibot(req.db, tb.name, tb.input))
        }))
      });
      // el próximo ciclo del for vuelve a llamar a Claude con el resultado de la herramienta
    }

    // Guardamos el historial (útil para revisar qué preguntan los técnicos y qué le falta a la base)
    const insertConv = req.db.prepare(`INSERT INTO tecnibot_conversaciones (usuario_id,usuario_nombre,rol,mensaje) VALUES (?,?,?,?)`);
    insertConv.run(req.user.usuario_id, req.user.nombre, 'usuario', ultimoMensaje.content);
    insertConv.run(req.user.usuario_id, req.user.nombre, 'asistente', replyText);

    res.json({ reply: replyText, fuentes: articulos.map(a => a.titulo) });
  } catch (e) {
    console.error('Error en /api/tecnibot/chat:', e);
    res.status(500).json({ error: 'Hubo un problema generando la respuesta. Intentá de nuevo.' });
  }
};
app.post('/api/tecnibot/chat', authMiddleware, tecnibotHabilitado, tecnibotChat);
// CELULAR-1.7.1: Tecnibot en el celular (QR, un solo celular por sistema)
require('./tecnibot-celular').montar(app, { authMiddleware, tecnibotHabilitado, tecnibotChat, puerto: () => PORT });

// Historial de conversaciones (admin) — para ver qué preguntan los técnicos
app.get('/api/tecnibot/historial', authMiddleware, tecnibotHabilitado, adminOnly, (req, res) => {
  res.json(req.db.prepare('SELECT * FROM tecnibot_conversaciones ORDER BY fecha DESC LIMIT 200').all());
});

// Qué le habilitó el admin a la sucursal del usuario (siempre se valida acá).
// Admin: todo habilitado. Taller: factura_habilitada manda (por defecto no cobra).
// Caja: siempre factura y cobra (es su función). IMEI: depende del flag de la sucursal.
function permisosSucursal(req) {
  if (req.user.rol === 'admin') return { factura_habilitada: true, imei_habilitado: true, envio_libre_habilitado: true };
  const s = req.user.sucursal_id ? req.db.prepare('SELECT factura_habilitada, imei_habilitado, envio_libre_habilitado FROM sucursales WHERE id=?').get(req.user.sucursal_id) : null;
  return {
    envio_libre_habilitado: !!s?.envio_libre_habilitado,
    factura_habilitada: req.user.rol === 'taller' ? !!s?.factura_habilitada : true,
    imei_habilitado: s ? s.imei_habilitado !== 0 : true
  };
}
app.get('/api/mis-permisos', authMiddleware, (req, res) => res.json({ ...permisosSucursal(req), permisos: permisosDe(req.db, req.user.usuario_id, req.user.rol) }));

// ─── CHEQUEO DE IMEI ROBADO/BLOQUEADO — SERVICIO DE SYSTECH (suscripción mensual) ──
// La clave del proveedor NUNCA está en la instalación del cliente ni se carga
// desde ninguna pantalla del sistema: es tuya.
//  - En TU servidor (multi-taller): variable de entorno IMEICHECK_API_KEY, y el
//    servicio se habilita por taller desde el panel de distribuidor (igual que Tecnibot).
//  - En una instalación local del cliente: la consulta se reenvía a tu servidor
//    central (SERVIDOR_CENTRAL_URL), que es quien verifica que la mensualidad
//    esté al día y hace la consulta real con tu clave.
const IMEI_SERVICIO_ID = process.env.IMEICHECK_SERVICE_ID || '5'; // 5 = Blacklist GSMA

function imeiServicioPropio() { return !!process.env.IMEICHECK_API_KEY; }

// ¿Este cliente tiene contratado el servicio? (para mostrar/ocultar el botón)
function imeiServicioContratado(req) {
  if (imeiServicioPropio()) return req.tenant?.imei_habilitado === 1 || Number(req.tenant?.imei_saldo) > 0;
  return !!central.urlCentral() && !!licencia.leerLicenciaActual();
}

app.get('/api/imeicheck/estado', authMiddleware, (req, res) => {
  res.json({ contratado: imeiServicioContratado(req) });
});

// Interpreta la respuesta del proveedor (solo corre del lado de tu servidor).
function consultarProveedorImei(imei) {
  const url = `${process.env.IMEICHECK_API_URL || 'https://alpha.imeicheck.com/api/php-api/create'}?key=${encodeURIComponent(process.env.IMEICHECK_API_KEY)}&service=${encodeURIComponent(IMEI_SERVICIO_ID)}&imei=${encodeURIComponent(imei)}`;   // IMEICHECK_API_URL: solo para pruebas
  return fetch(url, { signal: AbortSignal.timeout(20000) }).then(r => r.json()).then(data => {
    if (data.status === 'error' || data.status === 'failed') {
      // El detalle (IP no autorizada, sin crédito...) es asunto tuyo: va al log, no al cliente.
      console.error('[IMEI] Error del proveedor:', data);
      return { error: 'El servicio de chequeo de IMEI no está disponible en este momento. Intentá más tarde o contactá a SysTech.' };
    }
    const obj = data.object || {};
    let robado = null;
    for (const campo of ['blacklisted','blacklist','isBlacklisted','black_list_status']) {
      if (obj[campo] !== undefined) {
        robado = obj[campo] === true || /clean|no|false/i.test(String(obj[campo])) ? (/clean/i.test(String(obj[campo])) ? false : !!obj[campo]) : true;
        break;
      }
    }
    return { robado, resultadoTexto: data.result || null, marca: obj.brand || obj.manufacturer || undefined, modelo: obj.model || obj.name || undefined };
  });
}

// Misma consulta, pero si ese IMEI ya se consultó en las últimas 24 h devuelve la copia guardada (no se paga dos veces).
async function consultarImeiConCache(imei) {
  const cacheado = masterDb.prepare("SELECT resultado FROM imei_cache WHERE imei=? AND fecha > datetime('now','-1 day')").get(imei);
  if (cacheado) return { resultado: JSON.parse(cacheado.resultado), desdeCache: true };
  const resultado = await consultarProveedorImei(imei);
  if (!resultado.error) masterDb.prepare('INSERT OR REPLACE INTO imei_cache (imei,resultado,fecha) VALUES (?,?,CURRENT_TIMESTAMP)').run(imei, JSON.stringify(resultado));
  return { resultado, desdeCache: false };
}

app.post('/api/imeicheck/verificar', authMiddleware, async (req, res) => {
  try {
    const imei = String(req.body.imei || '').replace(/\s/g, '');
    if (!permisosSucursal(req).imei_habilitado) {
      return res.status(403).json({ error: 'El administrador no habilitó el chequeo de IMEI en este taller/sucursal.' });
    }
    if (!/^\d{14,16}$/.test(imei)) {
      return res.status(400).json({ error: 'IMEI inválido — tiene que ser un número de 14 a 16 dígitos' });
    }

    // A) Este servidor es el de SysTech: verifica la suscripción del taller y consulta.
    // Mensualidad vieja (imei_habilitado) = sin límite, como siempre. Paquetes comprados online = saldo de consultas:
    // cada consulta nueva descuenta una; repetir el mismo IMEI dentro de las 24 h no descuenta (sale de la copia guardada).
    if (imeiServicioPropio()) {
      const mensual = req.tenant?.imei_habilitado === 1;
      if (!mensual && !(Number(req.tenant?.imei_saldo) > 0)) {
        return res.status(402).json({ error: req.tenant && req.tenant.imei_saldo !== null && req.tenant.imei_saldo !== undefined && Number(req.tenant.imei_saldo) === 0 && req.tenant.imei_habilitado !== 1
          ? 'Te quedaste sin consultas de IMEI. Comprá otro paquete en Configuración → Sistema → Comprar o renovar.'
          : 'El chequeo de IMEI es un servicio adicional y no está incluido en tu plan. Podés sumarlo en Configuración → Sistema → Comprar o renovar.', sin_saldo_imei: true });
      }
      const { resultado: r, desdeCache } = await consultarImeiConCache(imei);
      if (r.error) return res.status(502).json(r);
      if (!mensual && !desdeCache) {
        masterDb.prepare('UPDATE talleres SET imei_saldo = imei_saldo - 1 WHERE subdominio = ? AND imei_saldo > 0').run(req.tenant.subdominio);
      }
      const quedan = mensual ? null : masterDb.prepare('SELECT imei_saldo FROM talleres WHERE subdominio = ?').get(req.tenant.subdominio)?.imei_saldo;
      return res.json({ ...r, ...(quedan !== null && quedan !== undefined ? { consultas_restantes: quedan } : {}) });
    }

    // B) Instalación local: se pide al servidor central de SysTech, que valida la mensualidad.
    const urlC = central.urlCentral();
    const lic = licencia.leerLicenciaActual();
    if (!urlC || !lic) {
      return res.status(402).json({ error: 'El chequeo de IMEI es un servicio adicional. Contactá a SysTech para contratarlo.' });
    }
    const resp = await fetch(`${urlC}/api/imei/verificar`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ instalacionId: lic.instalacionId, codigo: lic.codigo || null, imei }),
      signal: AbortSignal.timeout(25000),
    });
    const d = await resp.json().catch(() => ({}));
    if (!resp.ok) return res.status(resp.status === 402 ? 402 : 502).json({ error: d.error || 'No se pudo consultar el servicio de IMEI. Verificá tu conexión a internet.' });
    res.json(d);
  } catch (e) {
    console.error('Error en /api/imeicheck/verificar:', e.message);
    res.status(500).json({ error: 'No se pudo completar la consulta. Verificá tu conexión e intentá de nuevo.' });
  }
});


// ─── SERVIDOR CENTRAL DE IMEI (solo responde si ESTE servidor es el de SysTech: tiene IMEICHECK_API_KEY) ───
// Las instalaciones locales de los clientes llaman acá. Se valida: (1) el código de licencia está firmado
// por SysTech, (2) el negocio tiene el servicio habilitado y la mensualidad al día, (3) no pasó el tope diario.
// Se cachea 24 h por IMEI para no pagar dos veces la misma consulta.
masterDb.exec(`
  CREATE TABLE IF NOT EXISTS imei_clientes (
    negocio_id TEXT PRIMARY KEY, nombre TEXT, habilitado INTEGER DEFAULT 1, vence TEXT,
    consultas_total INTEGER DEFAULT 0, ultima_consulta DATETIME, creado DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS imei_consultas_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, negocio_id TEXT, imei TEXT, resultado TEXT, desde_cache INTEGER DEFAULT 0, fecha DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS imei_cache (imei TEXT PRIMARY KEY, resultado TEXT, fecha DATETIME DEFAULT CURRENT_TIMESTAMP);
`);
try { masterDb.exec('ALTER TABLE imei_clientes ADD COLUMN saldo INTEGER'); } catch (e) {}   // paquetes de consultas comprados online (vacío = mensualidad)
const IMEI_TOPE_DIARIO = Number(process.env.IMEI_TOPE_DIARIO) || 200;
app.post('/api/imei/verificar', async (req, res) => {
  if (!imeiServicioPropio()) return res.status(404).json({ error: 'Este equipo no es el servidor central de SysTech.' });
  try {
    const imei = String(req.body?.imei || '').replace(/\s/g, '');
    if (!/^\d{14,16}$/.test(imei)) return res.status(400).json({ error: 'IMEI inválido — tiene que ser un número de 14 a 16 dígitos' });
    const datos = licencia.verificarCodigo(req.body?.codigo);
    if (!datos) return res.status(401).json({ error: 'Licencia no válida. Reactivá el sistema con tu código de activación.' });
    const cli = masterDb.prepare('SELECT * FROM imei_clientes WHERE negocio_id=?').get(datos.negocioId);
    if (!cli || !cli.habilitado) return res.status(402).json({ error: 'El chequeo de IMEI es un servicio adicional y no está incluido en tu plan. Contactá a SysTech para contratarlo.' });
    if (cli.vence && cli.vence < new Date().toISOString().slice(0, 10)) return res.status(402).json({ error: 'La mensualidad del chequeo de IMEI está vencida. Contactá a SysTech para renovarla.' });
    // Paquetes comprados online: saldo de consultas (vacío = mensualidad vieja, sin límite de saldo)
    const conSaldo = cli.saldo !== null && cli.saldo !== undefined;
    if (conSaldo && !(Number(cli.saldo) > 0)) return res.status(402).json({ error: 'Te quedaste sin consultas de IMEI. Comprá otro paquete en Configuración → Sistema → Comprar o renovar.', sin_saldo_imei: true });
    const hoy = masterDb.prepare("SELECT COUNT(*) AS c FROM imei_consultas_log WHERE negocio_id=? AND desde_cache=0 AND date(fecha)=date('now')").get(datos.negocioId).c;
    if (hoy >= IMEI_TOPE_DIARIO) return res.status(429).json({ error: 'Llegaste al tope de consultas de hoy. Probá mañana o contactá a SysTech.' });

    const cacheado = masterDb.prepare("SELECT resultado FROM imei_cache WHERE imei=? AND fecha > datetime('now','-1 day')").get(imei);
    let resultado, desdeCache = 0;
    if (cacheado) { resultado = JSON.parse(cacheado.resultado); desdeCache = 1; }
    else {
      resultado = await consultarProveedorImei(imei);
      if (resultado.error) return res.status(502).json(resultado);
      masterDb.prepare('INSERT OR REPLACE INTO imei_cache (imei,resultado,fecha) VALUES (?,?,CURRENT_TIMESTAMP)').run(imei, JSON.stringify(resultado));
    }
    masterDb.prepare('INSERT INTO imei_consultas_log (negocio_id,imei,resultado,desde_cache) VALUES (?,?,?,?)').run(datos.negocioId, imei, resultado.robado === true ? 'reportado' : (resultado.robado === false ? 'limpio' : 'sin_dato'), desdeCache);
    masterDb.prepare('UPDATE imei_clientes SET consultas_total=consultas_total+1, ultima_consulta=CURRENT_TIMESTAMP WHERE negocio_id=?').run(datos.negocioId);
    if (conSaldo && !desdeCache) masterDb.prepare('UPDATE imei_clientes SET saldo = saldo - 1 WHERE negocio_id=? AND saldo > 0').run(datos.negocioId);
    const quedan = conSaldo ? masterDb.prepare('SELECT saldo FROM imei_clientes WHERE negocio_id=?').get(datos.negocioId)?.saldo : null;
    res.json({ ...resultado, ...(quedan !== null && quedan !== undefined ? { consultas_restantes: quedan } : {}) });
  } catch (e) {
    console.error('Error en servidor central IMEI:', e.message);
    res.status(500).json({ error: 'No se pudo completar la consulta. Intentá de nuevo en unos minutos.' });
  }
});
app.get('/api/distribuidor/imei-clientes', distribuidorAuth, (req, res) => {
  res.json(masterDb.prepare('SELECT * FROM imei_clientes ORDER BY creado DESC').all());
});
app.put('/api/distribuidor/imei-clientes/:negocioId', distribuidorAuth, (req, res) => {
  const { nombre, habilitado, vence } = req.body || {};
  const id = String(req.params.negocioId || '').trim();
  if (!/^[0-9a-f-]{36}$/i.test(id)) return res.status(400).json({ error: 'El negocioId no es válido (es el que te muestra generar-licencia.js).' });
  masterDb.prepare(`INSERT INTO imei_clientes (negocio_id,nombre,habilitado,vence) VALUES (?,?,?,?)
    ON CONFLICT(negocio_id) DO UPDATE SET nombre=excluded.nombre, habilitado=excluded.habilitado, vence=excluded.vence`)
    .run(id, String(nombre || '').slice(0, 120), habilitado ? 1 : 0, vence ? String(vence).slice(0, 10) : null);
  res.json({ ok: true });
});
app.delete('/api/distribuidor/imei-clientes/:negocioId', distribuidorAuth, (req, res) => {
  masterDb.prepare('DELETE FROM imei_clientes WHERE negocio_id=?').run(req.params.negocioId);
  res.json({ ok: true });
});

// ─── REPORTES ─────────────────────────────────────────────────────────────────
app.get('/api/reportes/datos', authMiddleware, requierePermiso('ver_reportes'), (req, res) => {
  const desde = seguridad.soloFecha(req.query.desde), hasta = seguridad.soloFecha(req.query.hasta);
  const filtroFecha = desde && hasta ? `AND date(o.fecha_ingreso) BETWEEN '${desde}' AND '${hasta}'` : '';

  const ordenesPorEstado = req.db.prepare(`SELECT estado, COUNT(*) as cantidad FROM ordenes WHERE 1=1 ${filtroFecha.replace('o.','').replace('date(o.fecha_ingreso)','date(fecha_ingreso)')} GROUP BY estado`).all();
  const ordenesPorMes = req.db.prepare(`SELECT strftime('%Y-%m', fecha_ingreso) as mes, COUNT(*) as cantidad, SUM(total) as total FROM ordenes WHERE 1=1 ${filtroFecha.replace('o.','').replace('date(o.fecha_ingreso)','date(fecha_ingreso)')} GROUP BY mes ORDER BY mes DESC LIMIT 12`).all().reverse();
  const repuestosMasUsados = req.db.prepare(`SELECT p.nombre, p.codigo, SUM(or2.cantidad) as total_usado, SUM(or2.subtotal) as total_facturado FROM orden_repuestos or2 JOIN productos p ON or2.producto_id=p.id GROUP BY p.id ORDER BY total_usado DESC LIMIT 10`).all();
  const ingresosPorTecnico = req.db.prepare(`SELECT tecnico, COUNT(*) as ordenes, SUM(total) as total FROM ordenes WHERE tecnico IS NOT NULL AND tecnico != '' ${filtroFecha.replace('o.','').replace('date(o.fecha_ingreso)','date(fecha_ingreso)')} GROUP BY tecnico ORDER BY total DESC`).all();
  const stockCritico = req.db.prepare(`SELECT nombre, codigo, stock, stock_minimo FROM productos WHERE stock <= stock_minimo ORDER BY stock ASC`).all();
  const resumen = req.db.prepare(`SELECT COUNT(*) as total_ordenes, SUM(total) as total_facturado, AVG(total) as ticket_promedio, COUNT(CASE WHEN cobrado=1 THEN 1 END) as cobradas, COUNT(CASE WHEN estado='entregado' THEN 1 END) as entregadas FROM ordenes WHERE 1=1 ${filtroFecha.replace('o.','').replace('date(o.fecha_ingreso)','date(fecha_ingreso)')}`).get();
  const ordenesPorEquipo = req.db.prepare(`SELECT equipo, COUNT(*) as cantidad FROM ordenes WHERE 1=1 ${filtroFecha.replace('o.','').replace('date(o.fecha_ingreso)','date(fecha_ingreso)')} GROUP BY equipo ORDER BY cantidad DESC LIMIT 8`).all();
  const movimientosStock = req.db.prepare(`SELECT strftime('%Y-%m', fecha) as mes, tipo, SUM(cantidad) as cantidad FROM movimientos_stock GROUP BY mes, tipo ORDER BY mes DESC LIMIT 24`).all();

  // ─── VENTAS DEL LOCAL (comprobantes) — antes este reporte solo miraba
  // órdenes de servicio técnico y no veía nada de lo que se factura en el
  // mostrador (productos, mercadería). Se agrega acá, con su propio filtro
  // de fecha porque comprobantes usa "fecha", no "fecha_ingreso".
  const filtroFechaComp = desde && hasta ? `AND date(fecha) BETWEEN '${desde}' AND '${hasta}'` : '';

  const ventasPorTipo = req.db.prepare(`SELECT tipo, COUNT(*) as cantidad, SUM(total) as total FROM comprobantes
    WHERE estado != 'anulado' AND tipo != 'presupuesto' ${filtroFechaComp} GROUP BY tipo`).all();

  const ventasPorMes = req.db.prepare(`SELECT strftime('%Y-%m', fecha) as mes, COUNT(*) as cantidad, SUM(total) as total FROM comprobantes
    WHERE estado != 'anulado' AND tipo != 'presupuesto' GROUP BY mes ORDER BY mes DESC LIMIT 12`).all().reverse();

  const ventasPorMedioPago = req.db.prepare(`SELECT cp.medio_pago, COUNT(*) as cantidad, SUM(cp.monto) as total
    FROM comprobante_pagos cp JOIN comprobantes c ON c.id = cp.comprobante_id
    WHERE c.estado != 'anulado' ${filtroFechaComp.replace('fecha','c.fecha')} GROUP BY cp.medio_pago ORDER BY total DESC`).all();

  const resumenLocal = req.db.prepare(`SELECT COUNT(*) as total_comprobantes, SUM(total) as total_facturado, AVG(total) as ticket_promedio
    FROM comprobantes WHERE estado != 'anulado' AND tipo != 'presupuesto' ${filtroFechaComp}`).get();

  // ─── CAJA — ingresos y egresos internos (no ligados a una venta puntual) ───
  const filtroFechaCaja = desde && hasta ? `AND date(cm.fecha) BETWEEN '${desde}' AND '${hasta}'` : '';
  const cajaPorTipo = req.db.prepare(`SELECT cm.tipo, cm.origen, COUNT(*) as cantidad, SUM(cm.monto) as total
    FROM caja_movimientos cm WHERE 1=1 ${filtroFechaCaja} GROUP BY cm.tipo, cm.origen`).all();
  const egresosManuales = req.db.prepare(`SELECT cm.motivo, cm.monto, cm.medio_pago, cm.fecha, cm.usuario
    FROM caja_movimientos cm WHERE cm.tipo='egreso' AND cm.origen='manual' ${filtroFechaCaja} ORDER BY cm.fecha DESC LIMIT 50`).all();

  res.json({
    ordenesPorEstado, ordenesPorMes, repuestosMasUsados, ingresosPorTecnico, stockCritico, resumen, ordenesPorEquipo, movimientosStock,
    ventasPorTipo, ventasPorMes, ventasPorMedioPago, resumenLocal,
    cajaPorTipo, egresosManuales
  });
});

// ─── VENTAS POR VENDEDOR ──────────────────────────────────────────────────────
// Quién vendió cuánto, en qué sucursal. El admin ve todas las sucursales y
// puede filtrar por una puntual; un usuario no-admin (taller/caja) solo ve
// su propia sucursal — así cada local ve a sus propios vendedores, nunca a
// los de otro local.
app.get('/api/reportes/ventas-vendedor', authMiddleware, requierePermiso('ver_reportes'), (req, res) => {
  const desde = seguridad.soloFecha(req.query.desde), hasta = seguridad.soloFecha(req.query.hasta);
  let { sucursal_id } = req.query;
  if (req.user.rol !== 'admin') sucursal_id = req.user.sucursal_id || null;

  const where = [`c.estado != 'anulado'`, `c.tipo != 'presupuesto'`];
  const params = [];
  if (desde && hasta) { where.push('date(c.fecha) BETWEEN ? AND ?'); params.push(desde, hasta); }
  if (sucursal_id) { where.push('c.sucursal_id = ?'); params.push(sucursal_id); }

  const filas = req.db.prepare(`
    SELECT COALESCE(NULLIF(c.vendedor_codigo,''),'Sin código') as vendedor,
           c.sucursal_id, s.nombre as sucursal_nombre,
           COUNT(*) as comprobantes, SUM(c.total) as total
    FROM comprobantes c
    LEFT JOIN sucursales s ON s.id = c.sucursal_id
    WHERE ${where.join(' AND ')}
    GROUP BY vendedor, c.sucursal_id
    ORDER BY total DESC
  `).all(...params);

  res.json(filas);
});

// ─── PRODUCTOS MÁS VENDIDOS ───────────────────────────────────────────────────
// Los items de cada comprobante se guardan como JSON suelto (no están atados
// a un producto_id — vienen como texto libre desde Caja/Facturación), así que
// se agrupan por descripción tal cual quedó cargada.
app.get('/api/reportes/productos-mas-vendidos', authMiddleware, requierePermiso('ver_reportes'), (req, res) => {
  const desde = seguridad.soloFecha(req.query.desde), hasta = seguridad.soloFecha(req.query.hasta);
  let { sucursal_id } = req.query;
  if (req.user.rol !== 'admin') sucursal_id = req.user.sucursal_id || null;

  const where = [`estado != 'anulado'`, `tipo != 'presupuesto'`];
  const params = [];
  if (desde && hasta) { where.push('date(fecha) BETWEEN ? AND ?'); params.push(desde, hasta); }
  if (sucursal_id) { where.push('sucursal_id = ?'); params.push(sucursal_id); }

  const comps = req.db.prepare(`SELECT items FROM comprobantes WHERE ${where.join(' AND ')}`).all(...params);
  const porProducto = {};
  comps.forEach(c => {
    let items = [];
    try { items = JSON.parse(c.items || '[]'); } catch (e) {}
    items.forEach(it => {
      const key = (it.descripcion || 'Sin descripción').trim() || 'Sin descripción';
      if (!porProducto[key]) porProducto[key] = { descripcion: key, cantidad: 0, total: 0 };
      porProducto[key].cantidad += Number(it.cantidad) || 0;
      porProducto[key].total += (Number(it.cantidad) || 0) * (Number(it.precio_unitario) || 0);
    });
  });
  const resultado = Object.values(porProducto).sort((a,b) => b.cantidad - a.cantidad).slice(0, 30);
  res.json(resultado);
});

// ─── ARCA / AFIP — FACTURACIÓN ELECTRÓNICA ───────────────────────────────────
const { obtenerToken }                       = require('./arca/wsaa');
const { solicitarCAE, ultimoComprobante, consultarComprobante, serverStatus, TIPO_COMP, TIPO_DOC } = require('./arca/wsfe');
const multerArca = require('multer');

// Config ARCA por defecto
// Subir certificado (.crt) y clave (.key)
// ARREGLO-ARCA-1.6.1 + ASISTENTE-ARCA-1.6.1
// Certificado de ARCA, por taller (cada uno en su carpeta arca/certs/<taller>/):
//  - "Generar pedido": el programa crea la clave privada (queda guardada acá, nunca se muestra) y entrega el .csr
//    para subir a ARCA. Así el cliente no usa comandos.
//  - "Subir certificado": el .crt que devuelve ARCA; se controla que haga pareja con la clave (la del pedido o la cargada).
//  - También se puede subir un .crt + .key propios (quien ya los generó por su cuenta).
//  - Primero se valida que sea el administrador y recién después se guarda cualquier archivo.
const carpetaCertsArca = req => {
  const t = req.tenant || {};
  const id = String(t.subdominio || t.id || 'default').replace(/[^a-zA-Z0-9_-]/g, '') || 'default';
  return path.join(__dirname, 'arca', 'certs', id);
};
const storageArca = multerArca.diskStorage({
  destination:(req,file,cb)=>{
    const d=carpetaCertsArca(req);
    if(!fs.existsSync(d)) fs.mkdirSync(d,{recursive:true});
    cb(null,d);
  },
  filename:(req,file,cb)=>cb(null,file.fieldname+'.nuevo'+(file.fieldname==='cert'?'.crt':'.key'))
});
const uploadArca = multerArca({storage:storageArca, limits:{fileSize:64*1024}});
const arcaSet = (db, clave, valor) => db.prepare("INSERT OR REPLACE INTO config_fiscal (clave,valor) VALUES (?,?)").run(clave, valor);
const arcaDel = (db, clave) => db.prepare("DELETE FROM config_fiscal WHERE clave=?").run(clave);
// Lee un certificado: acepta PEM o DER (por si ARCA lo entrega en binario).
function leerCertArca(buf) {
  const forge = require('node-forge');
  const txt = buf.toString('utf8');
  if (txt.includes('-----BEGIN CERTIFICATE-----')) return forge.pki.certificateFromPem(txt);
  const asn1 = forge.asn1.fromDer(forge.util.createBuffer(buf.toString('binary')));
  return forge.pki.certificateFromAsn1(asn1);
}
const certAPem = cert => require('node-forge').pki.certificateToPem(cert);
const cuitDeCert = cert => { const a = cert.subject.attributes.find(x => x.name === 'serialNumber' || x.type === '2.5.4.5'); const m = a && String(a.value).match(/(\d{11})/); return m ? m[1] : null; };

// 1) Generar el pedido de certificado (.csr) con su clave privada
app.post('/api/arca/generar-pedido', authMiddleware, adminOnly, (req,res)=>{
  try {
    const forge = require('node-forge');
    const cuit = String((req.body||{}).cuit||'').replace(/\D/g,'');
    const nombre = String((req.body||{}).nombre||'').normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^A-Za-z0-9 .,&-]/g,' ').replace(/\s+/g,' ').trim().slice(0,60);
    if (!/^\d{11}$/.test(cuit)) return res.status(400).json({error:'El CUIT tiene que tener 11 números (sin guiones).'});
    if (nombre.length < 3) return res.status(400).json({error:'Escribí el nombre o la razón social tal como figura en ARCA.'});
    const { privateKey } = require('crypto').generateKeyPairSync('rsa', { modulusLength: 2048 });
    const keyPem = privateKey.export({ type: 'pkcs1', format: 'pem' });
    const key = forge.pki.privateKeyFromPem(keyPem);
    const csr = forge.pki.createCertificationRequest();
    csr.publicKey = forge.pki.setRsaPublicKey(key.n, key.e);
    csr.setSubject([{ name:'countryName', value:'AR' }, { name:'organizationName', value:nombre }, { name:'commonName', value:'systech' }, { type:'2.5.4.5', value:'CUIT '+cuit }]);
    csr.sign(key, forge.md.sha256.create());
    const csrPem = forge.pki.certificationRequestToPem(csr);
    const dir = carpetaCertsArca(req); if(!fs.existsSync(dir)) fs.mkdirSync(dir,{recursive:true});
    const keyPath = path.join(dir, 'key.pendiente.key');
    fs.writeFileSync(keyPath, keyPem, { mode: 0o600 });
    arcaSet(req.db, 'arca_key_pend_path', keyPath);
    arcaSet(req.db, 'arca_csr_pend', csrPem);
    arcaSet(req.db, 'arca_csr_pend_fecha', new Date().toISOString());
    arcaSet(req.db, 'arca_csr_pend_cuit', cuit);
    const cfg = getArcaCfg(req.db); if (!cfg.arca_cuit) arcaSet(req.db, 'arca_cuit', cuit);
    res.json({ ok:true, csr: csrPem, archivo: "systech.csr" });
  } catch (e) { res.status(500).json({ error: 'No se pudo generar el pedido: ' + e.message }); }
});

// 2) Estado del certificado (para la pantalla)
app.get('/api/arca/estado-cert', authMiddleware, adminOnly, (req,res)=>{
  const forge = require('node-forge');
  const cfg = getArcaCfg(req.db), out = { tiene_cert:false, tiene_key:false, pareja:null, vence:null, vencido:false, cuit_cert:null, pendiente:null };
  let cert = null, key = null;
  try { if (cfg.arca_cert_path && fs.existsSync(cfg.arca_cert_path)) { cert = leerCertArca(fs.readFileSync(cfg.arca_cert_path)); out.tiene_cert = true; out.vence = cert.validity.notAfter.toISOString().slice(0,10); out.vencido = cert.validity.notAfter < new Date(); out.cuit_cert = cuitDeCert(cert); } } catch (e) {}
  try { if (cfg.arca_key_path && fs.existsSync(cfg.arca_key_path)) { key = forge.pki.privateKeyFromPem(fs.readFileSync(cfg.arca_key_path,'utf8')); out.tiene_key = true; } } catch (e) {}
  if (cert && key) out.pareja = cert.publicKey.n.compareTo(key.n) === 0;
  if (cfg.arca_csr_pend && cfg.arca_key_pend_path && fs.existsSync(cfg.arca_key_pend_path)) out.pendiente = { cuit: cfg.arca_csr_pend_cuit || null, fecha: cfg.arca_csr_pend_fecha || null };
  res.json(out);
});

// 3) Volver a descargar el pedido pendiente
app.get('/api/arca/pedido-csr', authMiddleware, adminOnly, (req,res)=>{
  const cfg = getArcaCfg(req.db);
  if (!cfg.arca_csr_pend) return res.status(404).json({error:'No hay ningún pedido generado.'});
  res.json({ csr: cfg.arca_csr_pend, archivo: "systech.csr" });
});

// 4) Subir certificado (.crt) y/o clave (.key)
app.post('/api/arca/upload-cert', authMiddleware, adminOnly, uploadArca.fields([
  {name:'cert',maxCount:1},{name:'key',maxCount:1}
]), (req,res)=>{
  const forge = require('node-forge');
  const files = req.files || {};
  const borrar = () => { for (const k of ['cert','key']) if (files[k]) { try { fs.unlinkSync(files[k][0].path); } catch (e) {} } };
  try {
    if (!files.cert && !files.key) throw new Error('No llegó ningún archivo.');
    const cfg = getArcaCfg(req.db);
    let cert = null, key = null, keyPem = null;
    if (files.cert) {
      try { cert = leerCertArca(fs.readFileSync(files.cert[0].path)); }
      catch (e) { throw new Error('El archivo del certificado no es válido. Tiene que ser el .crt que descargaste de ARCA.'); }
    }
    if (files.key) {
      const txt = fs.readFileSync(files.key[0].path, 'utf8');
      if (/ENCRYPTED/.test(txt)) throw new Error('La clave privada tiene contraseña. Generala de nuevo sin contraseña o usá "Generar pedido".');
      try { key = forge.pki.privateKeyFromPem(txt); keyPem = txt; }
      catch (e) { throw new Error('El archivo de la clave no es válido. Tiene que ser el .key que generaste en tu computadora.'); }
    }
    if (cert && cert.validity.notAfter < new Date()) throw new Error('Ese certificado está vencido. Generá un pedido nuevo y pedí otro en ARCA.');
    const dir = carpetaCertsArca(req);
    const pareja = (c, k) => c && k && c.publicKey.n.compareTo(k.n) === 0;
    const leerKey = p => { try { return p && fs.existsSync(p) ? forge.pki.privateKeyFromPem(fs.readFileSync(p,'utf8')) : null; } catch (e) { return null; } };
    let usarPendiente = false, aviso = null;
    if (cert && !key) {
      // ¿Es el certificado del pedido que generó el programa? ¿o de la clave que ya estaba cargada?
      const kp = leerKey(cfg.arca_key_pend_path), ka = leerKey(cfg.arca_key_path);
      if (pareja(cert, kp)) usarPendiente = true;
      else if (!pareja(cert, ka)) {
        if (!kp && !ka) aviso = 'Certificado guardado. Falta la clave: usá "Generar pedido" (y subí a ARCA ese pedido) o subí tu archivo .key.';
        else throw new Error('Este certificado no corresponde a la clave del programa. Asegurate de subir a ARCA el último pedido (.csr) que generaste acá y descargar el certificado de ESE alias.');
      }
    }
    if (key && !cert) {
      const ca = (()=>{ try { return cfg.arca_cert_path && fs.existsSync(cfg.arca_cert_path) ? leerCertArca(fs.readFileSync(cfg.arca_cert_path)) : null; } catch (e) { return null; } })();
      if (ca && !pareja(ca, key)) aviso = 'Clave guardada. Ojo: no hace pareja con el certificado cargado; subí el .crt que corresponde.';
    }
    if (cert && key && !pareja(cert, key)) throw new Error('El certificado y la clave no son pareja. Subí el .crt que ARCA generó con el pedido (.csr) hecho con ESTA clave.');
    if (cert) {
      const destino = path.join(dir, 'cert.crt');
      fs.writeFileSync(destino, certAPem(cert)); try { fs.unlinkSync(files.cert[0].path); } catch (e) {}
      arcaSet(req.db, 'arca_cert_path', destino);
      const c = cuitDeCert(cert); if (c) arcaSet(req.db, 'arca_cuit', c);
    }
    if (key) {
      const destino = path.join(dir, 'key.key');
      fs.writeFileSync(destino, keyPem, { mode: 0o600 }); try { fs.unlinkSync(files.key[0].path); } catch (e) {}
      arcaSet(req.db, 'arca_key_path', destino);
    }
    if (usarPendiente) {   // el pedido se completó: su clave pasa a ser la clave en uso
      const destino = path.join(dir, 'key.key');
      fs.copyFileSync(cfg.arca_key_pend_path, destino); try { fs.chmodSync(destino, 0o600); } catch (e) {}
      try { fs.unlinkSync(cfg.arca_key_pend_path); } catch (e) {}
      arcaSet(req.db, 'arca_key_path', destino);
      for (const k of ['arca_key_pend_path','arca_csr_pend','arca_csr_pend_fecha','arca_csr_pend_cuit']) arcaDel(req.db, k);
    }
    const vence = cert ? cert.validity.notAfter.toISOString().slice(0, 10) : null;
    res.json({ok:true, cert:!!files.cert, key:!!files.key || usarPendiente, vence, aviso});
  } catch (e) {
    borrar();
    res.status(400).json({ok:false, error:e.message});
  }
});

// Helper: obtener config ARCA (recibe la base del taller actual)
function getArcaCfg(tenantDb) {
  const rows = tenantDb.prepare('SELECT * FROM config_fiscal').all();
  const c={};rows.forEach(r=>c[r.clave]=r.valor);
  return c;
}

// Helper: leer cert y key
function leerCreds(cfg) {
  if(!cfg.arca_cert_path||!cfg.arca_key_path) throw new Error('Certificado o clave no configurados');
  if(!fs.existsSync(cfg.arca_cert_path)) throw new Error('Archivo de certificado no encontrado');
  if(!fs.existsSync(cfg.arca_key_path))  throw new Error('Archivo de clave no encontrado');
  return {
    cert: fs.readFileSync(cfg.arca_cert_path,'utf8'),
    key:  fs.readFileSync(cfg.arca_key_path,'utf8')
  };
}

// Test de conexión con ARCA
app.get('/api/arca/test', authMiddleware, adminOnly, async(req,res)=>{
  try {
    const cfg  = getArcaCfg(req.db);
    const prod = cfg.arca_produccion==='1';
    const {cert,key} = leerCreds(cfg);
    const auth = await obtenerToken(cert,key,'wsfe',prod);
    const status = await serverStatus(auth,cfg.arca_cuit,prod);
    req.db.prepare("INSERT INTO arca_log (accion,response,resultado) VALUES (?,?,?)").run('test',JSON.stringify(status),'OK');
    res.json({ok:true, ambiente:prod?'PRODUCCIÓN':'HOMOLOGACIÓN (prueba)', ...status});
  } catch(e) {
    res.status(500).json({ok:false,error:e.message});
  }
});

// Emitir factura electrónica con CAE
// ARCA-1.6.5 — pedir el CAE (una sola función para el botón, la Caja y el cobro de órdenes)
const ARCA_COLS = new WeakSet();
function asegurarColumnasArca(db) {
  if (ARCA_COLS.has(db)) return;
  for (const col of ['arca_letra TEXT', 'arca_tipo INTEGER', 'arca_pv INTEGER', 'arca_nro INTEGER']) { try { db.exec(`ALTER TABLE comprobantes ADD COLUMN ${col}`); } catch (e) {} }
  ARCA_COLS.add(db);
}
// De a un pedido por vez: dos ventas al mismo tiempo no pueden pedir el mismo número a ARCA.
let colaArca = Promise.resolve();
function emitirCAE(db, compId) { const p = colaArca.then(() => emitirCAE0(db, compId)); colaArca = p.catch(() => {}); return p; }
async function emitirCAE0(db, compId) {
  const mal = (code, error) => ({ code, body: { ok:false, error } });
  try {
    const cfg  = getArcaCfg(db);
    if (cfg.arca_habilitado!=='1') return mal(400, 'ARCA no está habilitado en la configuración');
    asegurarColumnasArca(db);
    const comp = db.prepare('SELECT * FROM comprobantes WHERE id=?').get(compId);
    if (!comp) return mal(404, 'Comprobante no encontrado');
    if (comp.tipo==='presupuesto') return mal(400, 'Los presupuestos no se envían a ARCA');
    if (comp.tipo==='nota_entrega') return mal(400, 'Las Notas de Entrega son remitos, no comprobantes fiscales — no se envían a ARCA');
    if (comp.cae) return mal(400, 'Este comprobante ya tiene CAE: '+comp.cae);
    if (comp.estado==='anulado') return mal(400, 'Este comprobante está anulado: no se envía a ARCA.');
    if (comp.estado==='borrador') return mal(400, 'Primero emití el comprobante (está en borrador).');
    if (!(Number(comp.total) > 0)) return mal(400, 'El comprobante no tiene importe.');

    const prod = cfg.arca_produccion==='1';
    const {cert,key} = leerCreds(cfg);
    const cuit = String(cfg.arca_cuit||'').replace(/[-]/g,'');
    // La factura sale con el CUIT de los Datos fiscales; tiene que ser el mismo del certificado.
    { const cf = String(fiscalGet(db, comp.sucursal_id, 'cuit').valor || '').replace(/\D/g, ''), ca = cuit.replace(/\D/g, '');
      if (cf && cf !== ca) return mal(400, `El CUIT de los Datos fiscales (${cf}) no es el del certificado de ARCA (${ca}). La factura saldría con el CUIT equivocado: corregí uno de los dos y probá de nuevo.`); }
    const ptoVenta = parseInt(cfg.arca_punto_venta||'1');
    const condicion = cfg.arca_condicion||'monotributo';
    const letraEfectiva = condicion==='monotributo' ? 'C' : (comp.letra||'B');
    const sufijoLetra = letraEfectiva.toLowerCase();
    let tipoComp;
    if (comp.tipo === 'nota_credito') tipoComp = TIPO_COMP[`nota_credito_${sufijoLetra}`];
    else if (comp.tipo === 'nota_debito') tipoComp = TIPO_COMP[`nota_debito_${sufijoLetra}`];
    else if (comp.tipo === 'factura') tipoComp = condicion==='monotributo' ? TIPO_COMP['factura_c_monotributo'] : TIPO_COMP[`factura_${sufijoLetra}`];
    if (!tipoComp) return mal(400, `No se pudo determinar el tipo de comprobante de ARCA para "${comp.tipo}" letra ${letraEfectiva}`);

    const auth = await obtenerToken(cert,key,'wsfe',prod);
    const logArca = (resp, estado) => { try { db.prepare("UPDATE arca_log SET response=?,resultado=? WHERE id=(SELECT MAX(id) FROM arca_log WHERE comprobante_id=?)").run(JSON.stringify(resp), estado, comp.id); } catch (e) {} };
    const guardarCAE = (r, nro, recuperado) => {
      const v = String(r.vencimientoCAE || '');
      const vFmt = v.length === 8 ? `${v.slice(6,8)}/${v.slice(4,6)}/${v.slice(0,4)}` : v;
      db.prepare('UPDATE comprobantes SET cae=?,cae_vencimiento=?,arca_letra=?,arca_tipo=?,arca_pv=?,arca_nro=? WHERE id=?').run(r.cae, vFmt, letraEfectiva, tipoComp, ptoVenta, nro, comp.id);
      logArca({ ...r, nro, recuperado: !!recuperado }, 'APROBADO');
      return { code: 200, body: { ok:true, cae:r.cae, vencimiento:vFmt, numero:nro, letra:letraEfectiva, pv:ptoVenta, recuperado: !!recuperado } };
    };

    const docNro  = comp.cliente_doc_numero || '0';
    const docNroNum = parseInt(String(docNro).replace(/\D/g,''))||0;
    const docTipo = !docNroNum ? 99 : (String(docNroNum).length === 11 ? 80 : (TIPO_DOC[comp.cliente_doc_tipo] || 96));   // DOC-1.6.7: 11 números = CUIT
    const importeTotal = parseFloat(comp.total)||0;
    const importeIVA   = parseFloat(comp.iva_monto)||0;
    const importeNeto  = importeTotal - importeIVA;

    // Un pedido anterior de ESTE comprobante que ARCA aprobó pero no se guardó (corte, error): se recupera ese CAE en vez
    // de pedir otro, así no se duplica la factura. Se miran exactamente los números que se le pidieron a ARCA para este
    // comprobante (quedan anotados en arca_log), del más nuevo al más viejo.
    const pedidos = db.prepare("SELECT request FROM arca_log WHERE comprobante_id=? AND resultado='ENVIANDO' ORDER BY id DESC").all(comp.id)
      .map(r => { try { const q = JSON.parse(r.request || '{}'); return Number(q.ptoVenta) === ptoVenta && Number(q.tipoComp) === tipoComp ? Number(q.cbteNro) : 0; } catch (e) { return 0; } })
      .filter(n => n > 0);
    for (const n of [...new Set(pedidos)]) {
      if (db.prepare('SELECT id FROM comprobantes WHERE arca_pv=? AND arca_tipo=? AND arca_nro=?').get(ptoVenta, tipoComp, n)) continue;
      let previo = null; try { previo = await consultarComprobante(auth,cuit,ptoVenta,tipoComp,n,prod); } catch (e) { previo = null; }
      if (previo && Math.abs(previo.total - importeTotal) < 0.01 && previo.docNro === docNroNum) return guardarCAE(previo, n, true);
    }
    const ultimoNro = await ultimoComprobante(auth,cuit,ptoVenta,tipoComp,prod);
    const cbteNro = ultimoNro + 1;
    const datos = { cuit, ptoVenta, tipoComp, cbteNro, cbteDesde:cbteNro, cbteHasta:cbteNro, docTipo, docNro: docNroNum,
      importeTotal, importeNeto, importeIVA, condicionIVA: comp.cliente_condicion_iva, concepto:1 };
    db.prepare("INSERT INTO arca_log (comprobante_id,accion,request,resultado) VALUES (?,?,?,?)").run(comp.id,'solicitar_cae',JSON.stringify(datos),'ENVIANDO');
    const resultado = await solicitarCAE(auth,datos,prod);
    if (resultado.ok) return guardarCAE(resultado, cbteNro, false);
    logArca(resultado, 'RECHAZADO');
    return mal(400, resultado.error);
  } catch (e) {
    return mal(500, e.message);
  }
}
// Botón «CAE» (Facturación y la pestaña ARCA)
app.post('/api/arca/emitir/:compId', authMiddleware, async (req, res) => {
  const r = await emitirCAE(req.db, req.params.compId);
  res.status(r.code).json(r.body);
});
// Pedido automático al emitir una Factura (Caja, Facturación, cobro de órdenes). Si falla, el comprobante queda hecho.
async function autoCAE(db, id) {
  try {
    const cfg = getArcaCfg(db); if (cfg.arca_habilitado !== '1') return null;
    const c = db.prepare('SELECT tipo,total,cae,estado FROM comprobantes WHERE id=?').get(id);
    if (!c || c.tipo !== 'factura' || c.cae || c.estado !== 'emitido' || !(Number(c.total) > 0)) return null;
    const r = await emitirCAE(db, id);
    return r.code === 200 ? r.body : { ok:false, error: r.body.error };
  } catch (e) { return { ok:false, error: e.message }; }
}
// Pestaña ARCA: facturas y notas con su estado en ARCA
app.get('/api/arca/comprobantes', authMiddleware, adminOnly, (req, res) => {
  asegurarColumnasArca(req.db);
  const f = req.query.estado === 'sin' ? " AND (cae IS NULL OR cae='')" : req.query.estado === 'con' ? " AND length(cae)>0" : '';
  res.json(req.db.prepare(`SELECT id,numero,tipo,letra,cliente_nombre,cliente_apellido,total,fecha,estado,cae,cae_vencimiento,arca_letra,arca_pv,arca_nro
    FROM comprobantes WHERE tipo IN ('factura','nota_credito','nota_debito') AND estado!='anulado'${f} ORDER BY id DESC LIMIT 100`).all());
});

// Log de operaciones ARCA
app.get('/api/arca/log', authMiddleware, adminOnly, (req,res)=>{
  res.json(req.db.prepare('SELECT l.*,c.numero as comp_numero FROM arca_log l LEFT JOIN comprobantes c ON l.comprobante_id=c.id ORDER BY l.fecha DESC LIMIT 100').all());
});

// Config ARCA
app.get('/api/arca/config', authMiddleware, adminOnly, (req,res)=>{
  const cfg=getArcaCfg(req.db);
  res.json({
    produccion:  cfg.arca_produccion==='1',
    cuit:        cfg.arca_cuit||'',
    punto_venta: cfg.arca_punto_venta||'1',
    condicion:   cfg.arca_condicion||'monotributo',
    habilitado:  cfg.arca_habilitado==='1',
    tiene_cert:  !!(cfg.arca_cert_path && fs.existsSync(cfg.arca_cert_path)),
    tiene_key:   !!(cfg.arca_key_path  && fs.existsSync(cfg.arca_key_path))
  });
});

app.put('/api/arca/config', authMiddleware, adminOnly, (req,res)=>{
  const {produccion,cuit,punto_venta,condicion,habilitado}=req.body;
  const updates={
    arca_produccion:  produccion?'1':'0',
    arca_cuit:        cuit||'',
    arca_punto_venta: String(punto_venta||1),
    arca_condicion:   condicion||'monotributo',
    arca_habilitado:  habilitado?'1':'0'
  };
  Object.entries(updates).forEach(([k,v])=>req.db.prepare('INSERT OR REPLACE INTO config_fiscal (clave,valor) VALUES (?,?)').run(k,v));
  res.json({ok:true});
});

// Endpoint para que el frontend sepa la IP correcta del servidor
app.get('/api/server-info', (req, res) => {
  res.json({ ip: LOCAL_IP, port: PORT, url: `http://${LOCAL_IP}:${PORT}` });
});

// ─── PORTAL CLIENTE (público, sin auth) ──────────────────────────────────────

// Buscar orden por número
app.get('/api/cliente/orden/:numero', (req, res) => {
  const o = req.db.prepare(`
    SELECT o.numero, o.equipo, o.marca, o.modelo, o.estado, o.prioridad,
           o.falla_reportada, o.diagnostico, o.mano_obra, o.total_repuestos,
           o.total, o.fecha_ingreso, o.fecha_entrega, o.tecnico, o.cobrado,
           o.presupuesto_aprobado, o.comentario_cliente,
           c.nombre as cliente_nombre
    FROM ordenes o
    LEFT JOIN clientes c ON o.cliente_id = c.id
    WHERE o.numero = ?
  `).get(req.params.numero.toUpperCase());
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  res.json(o);
});

// Buscar órdenes por teléfono
app.get('/api/cliente/telefono/:tel', (req, res) => {
  const tel = req.params.tel.replace(/\D/g, '');
  const ordenes = req.db.prepare(`
    SELECT o.numero, o.equipo, o.marca, o.modelo, o.estado, o.prioridad,
           o.fecha_ingreso, o.total, o.cobrado
    FROM ordenes o
    JOIN clientes c ON o.cliente_id = c.id
    WHERE REPLACE(REPLACE(REPLACE(c.telefono,'-',''),' ',''),'(','') LIKE ?
    ORDER BY o.fecha_ingreso DESC
  `).all(`%${tel}%`);
  if (!ordenes.length) return res.status(404).json({ error: 'No se encontraron órdenes para ese teléfono' });
  res.json(ordenes);
});

// Cliente aprueba o rechaza presupuesto
app.post('/api/cliente/orden/:numero/presupuesto', (req, res) => {
  const { aprobado, comentario } = req.body;
  const o = req.db.prepare('SELECT id FROM ordenes WHERE numero = ?').get(req.params.numero.toUpperCase());
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  req.db.prepare('UPDATE ordenes SET presupuesto_aprobado = ?, comentario_cliente = ? WHERE id = ?')
    .run(aprobado ? 1 : 0, comentario || '', o.id);
  res.json({ ok: true });
});

// Cliente deja comentario
app.post('/api/cliente/orden/:numero/comentario', (req, res) => {
  const { comentario } = req.body;
  const o = req.db.prepare('SELECT id FROM ordenes WHERE numero = ?').get(req.params.numero.toUpperCase());
  if (!o) return res.status(404).json({ error: 'Orden no encontrada' });
  req.db.prepare('UPDATE ordenes SET comentario_cliente = ? WHERE id = ?').run(comentario, o.id);
  res.json({ ok: true });
});

// Config pública (nombre empresa, colores)
app.get('/api/cliente/config', (req, res) => {
  const rows = req.db.prepare("SELECT * FROM config").all();
  const cfg = {};
  rows.forEach(r => cfg[r.clave] = r.valor);
  res.json({
    empresa_nombre: cfg.empresa_nombre || 'Servicio Técnico',
    empresa_telefono: cfg.empresa_telefono || '',
    empresa_whatsapp: cfg.empresa_whatsapp || '',
    color_accent: cfg.color_accent || '#4f8ef7',
    color_accent2: cfg.color_accent2 || '#38d9a9'
  });
});

// ─── DISTRIBUIDOR: PANEL DE CONTROL MULTI-TENANT ─────────────────────────────
// Sistema separado del login de cada taller — es exclusivamente para vos,
// el dueño del negocio, para ver y administrar todos los talleres dados de alta.

function distribuidorAuth(req, res, next) {
  const token = req.headers['x-distribuidor-token'];
  const sesion = validarSesionDistribuidor(token);
  if (!sesion) return res.status(401).json({ error: 'Sesión de distribuidor inválida o expirada' });
  req.distribuidorUser = sesion;
  next();
}

// Login del distribuidor
app.post('/api/distribuidor/login', (req, res) => {
  const { usuario, password } = req.body;
  if (!usuario || !password) return res.status(400).json({ error: 'Usuario y contraseña son obligatorios' });
  const clave = `dist|${req.ip}`;
  const espera = seguridad.loginBloqueado(clave);
  if (espera) return res.status(429).json({ error: `Demasiados intentos. Probá de nuevo en ${espera} minuto(s).` });
  const sesion = loginDistribuidor(usuario, password);
  if (!sesion) { seguridad.loginFallo(clave); return res.status(401).json({ error: 'Usuario o contraseña incorrectos' }); }
  seguridad.loginOk(clave);
  res.json(sesion);
});

// Estado de seguridad del distribuidor: el panel muestra un aviso rojo mientras siga con la clave de fábrica
app.get('/api/distribuidor/seguridad', distribuidorAuth, (req, res) => {
  const u = masterDb.prepare('SELECT password FROM distribuidor_usuarios WHERE usuario=?').get(req.distribuidorUser.usuario);
  const fabrica = !!(u && u.password === seguridad.hashLegacy('systech2026'));
  let archivo = false;
  try { archivo = fs.existsSync(path.join(__dirname, 'data', 'DISTRIBUIDOR-CLAVE-INICIAL.txt')); } catch (e) {}
  res.json({ clave_de_fabrica: fabrica, archivo_clave_inicial: archivo });
});

// Cambiar contraseña del distribuidor
app.post('/api/distribuidor/cambiar-password', distribuidorAuth, (req, res) => {
  const { password_actual, password_nueva } = req.body;
  if (!password_actual || !password_nueva) return res.status(400).json({ error: 'Faltan datos' });
  if (password_nueva.length < 6) return res.status(400).json({ error: 'La nueva contraseña debe tener al menos 6 caracteres' });
  try {
    cambiarPasswordDistribuidor(req.distribuidorUser.usuario, password_actual, password_nueva);
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Listar todos los talleres con info calculada (días para vencer, estado)
app.get('/api/distribuidor/talleres', distribuidorAuth, (req, res) => {
  const talleres = listarTalleres().map(t => {
    let diasParaVencer = null;
    let vencido = false;
    if (t.fecha_vencimiento) {
      const hoy = new Date();
      const venc = new Date(t.fecha_vencimiento);
      diasParaVencer = Math.ceil((venc - hoy) / (1000 * 60 * 60 * 24));
      vencido = diasParaVencer < 0;
    }
    const pl = planes.desdeTaller(t);
    return { ...t, dias_para_vencer: diasParaVencer, vencido, plan_etiqueta: pl.etiqueta, estado_venc: pl.estadoVenc, gracia_hasta: pl.graciaHasta, gracia_dias: pl.graciaDias };
  });
  res.json(talleres);
});

// Crear un nuevo taller (alta manual al confirmar el pago de un cliente)
app.post('/api/distribuidor/talleres', distribuidorAuth, (req, res) => {
  const { subdominio, nombre, plan, email_contacto, telefono_contacto, notas, fecha_vencimiento, tecnibot_habilitado, imei_habilitado, modulo_taller, modulo_tienda, limite_sucursales, ia_habilitada } = req.body;
  if (!subdominio || !nombre) return res.status(400).json({ error: 'Subdominio y nombre son obligatorios' });
  if (!/^[a-z0-9-]+$/.test(subdominio)) {
    return res.status(400).json({ error: 'El subdominio solo puede tener letras minúsculas, números y guiones' });
  }
  try {
    if (modulo_taller !== undefined && modulo_tienda !== undefined && !modulo_taller && !modulo_tienda) return res.status(400).json({ error: 'El negocio tiene que tener al menos un módulo: Taller o Tienda.' });
    crearTaller({ subdominio, nombre, plan, email_contacto, telefono_contacto, notas, fecha_vencimiento, tecnibot_habilitado, imei_habilitado, modulo_taller, modulo_tienda, limite_sucursales: limite_sucursales === undefined ? undefined : Number(limite_sucursales), ia_habilitada });
    registrarHistorialDist(req, subdominio, 'alta', `Alta de «${nombre}» · Taller: ${modulo_taller === undefined || modulo_taller ? 'sí' : 'no'} · Tienda: ${modulo_tienda === undefined || modulo_tienda ? 'sí' : 'no'} · Sucursales: ${limite_sucursales === undefined ? 2 : limite_sucursales} · Vence: ${fecha_vencimiento ? String(fecha_vencimiento).slice(0,10) : '(sin fecha)'}`);
    res.json({
      ok: true,
      subdominio,
      url: central.urlNegocio(subdominio),
      mensaje: `Taller "${nombre}" creado correctamente. Usuario admin por defecto: admin / admin123`
    });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Historial de lo que se cambia desde el panel (quién, cuándo, qué)
function registrarHistorialDist(req, subdominio, accion, detalle) {
  try { masterDb.prepare('INSERT INTO distribuidor_historial (usuario, subdominio, accion, detalle) VALUES (?,?,?,?)').run(req.distribuidorUser?.usuario || '', subdominio, accion, detalle || ''); } catch (e) {}
}
const ROTULOS_TALLER = { nombre: 'Nombre', plan: 'Tipo', email_contacto: 'Email', telefono_contacto: 'Teléfono', notas: 'Notas', fecha_vencimiento: 'Vencimiento',
  activo: 'Estado', tecnibot_habilitado: 'Tecnibot', imei_habilitado: 'IMEI', modulo_taller: 'Módulo Taller', modulo_tienda: 'Módulo Tienda', limite_sucursales: 'Sucursales', ia_habilitada: 'IA' };
function textoCambio(campo, v) {
  if (v === null || v === undefined || v === '') return '(vacío)';
  if (['activo', 'tecnibot_habilitado', 'imei_habilitado', 'modulo_taller', 'modulo_tienda', 'ia_habilitada'].includes(campo)) return (v === true || v === 1) ? 'sí' : 'no';
  if (campo === 'fecha_vencimiento') return String(v).slice(0, 10);
  return String(v);
}
function resumirCambios(antes, cambios) {
  const out = [];
  Object.keys(ROTULOS_TALLER).forEach(c => {
    if (cambios[c] === undefined) return;
    const n = typeof cambios[c] === 'boolean' ? (cambios[c] ? 1 : 0) : cambios[c];
    const a = antes[c] === undefined ? null : antes[c];
    if (String(a === null ? '' : a).slice(0, c === 'fecha_vencimiento' ? 10 : 9999) === String(n === null ? '' : n).slice(0, c === 'fecha_vencimiento' ? 10 : 9999)) return;
    out.push(`${ROTULOS_TALLER[c]}: ${textoCambio(c, a)} → ${textoCambio(c, cambios[c])}`);
  });
  return out.join(' · ');
}

// Editar datos de un taller (plan, módulos, sucursales, vencimiento, contacto, notas)
app.put('/api/distribuidor/talleres/:subdominio', distribuidorAuth, (req, res) => {
  if (req.params.subdominio === 'default') {
    return res.status(400).json({ error: 'El taller "default" (instalación local) no se gestiona desde aquí' });
  }
  const antes = listarTalleres().find(t => t.subdominio === req.params.subdominio);
  if (!antes) return res.status(404).json({ error: 'No existe ese negocio' });
  if (req.body && req.body.limite_sucursales !== undefined) {
    const n = Number(req.body.limite_sucursales);
    if (!Number.isInteger(n) || n < 1 || n > 99) return res.status(400).json({ error: 'El límite de sucursales tiene que ser un número entero entre 1 y 99.' });
    req.body.limite_sucursales = n;
  }
  if (req.body && req.body.fecha_vencimiento) {
    if (!/^\d{4}-\d{2}-\d{2}/.test(String(req.body.fecha_vencimiento)) || isNaN(new Date(String(req.body.fecha_vencimiento).slice(0, 10)))) return res.status(400).json({ error: 'La fecha de vencimiento no es válida.' });
  }
  const quedaTaller = req.body.modulo_taller === undefined ? antes.modulo_taller !== 0 : !!req.body.modulo_taller;
  const quedaTienda = req.body.modulo_tienda === undefined ? antes.modulo_tienda !== 0 : !!req.body.modulo_tienda;
  if (!quedaTaller && !quedaTienda) return res.status(400).json({ error: 'El negocio tiene que tener al menos un módulo: Taller o Tienda.' });
  try {
    actualizarTaller(req.params.subdominio, req.body);
    const resumen = resumirCambios(antes, req.body);
    if (resumen) registrarHistorialDist(req, req.params.subdominio, 'editar', resumen);
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Renovar: suma meses o años al vencimiento. Si todavía está vigente suma desde esa fecha; si ya venció, desde hoy.
app.post('/api/distribuidor/talleres/:subdominio/renovar', distribuidorAuth, (req, res) => {
  const t = listarTalleres().find(x => x.subdominio === req.params.subdominio);
  if (!t || t.subdominio === 'default') return res.status(404).json({ error: 'No existe ese negocio' });
  const meses = Number(req.body?.meses);
  if (!Number.isInteger(meses) || meses < 1 || meses > 60) return res.status(400).json({ error: 'Indicá cuántos meses renovar (1 a 60).' });
  const hoy = planes.hoyLocal();
  const actual = t.fecha_vencimiento ? String(t.fecha_vencimiento).slice(0, 10) : null;
  const base = actual && actual >= hoy ? actual : hoy;
  const d = new Date(base + 'T00:00:00Z');
  const diaOrig = d.getUTCDate();
  d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() + meses);
  const finMes = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  d.setUTCDate(Math.min(diaOrig, finMes));
  const nueva = d.toISOString().slice(0, 10);
  actualizarTaller(t.subdominio, { fecha_vencimiento: nueva, activo: 1 });
  registrarHistorialDist(req, t.subdominio, 'renovar', `Renovado ${meses} mes(es): vencimiento ${actual || '(sin fecha)'} → ${nueva}`);
  res.json({ ok: true, fecha_vencimiento: nueva });
});

// Historial de cambios de un negocio
app.get('/api/distribuidor/talleres/:subdominio/historial', distribuidorAuth, (req, res) => {
  res.json(masterDb.prepare('SELECT id, fecha, usuario, accion, detalle FROM distribuidor_historial WHERE subdominio=? ORDER BY id DESC LIMIT 200').all(req.params.subdominio));
});

// Soporte remoto: levantar el bloqueo de login de un taller (por ej. el admin que se equivocó de clave)
app.post('/api/distribuidor/talleres/:subdominio/desbloquear', distribuidorAuth, (req, res) => {
  res.json({ ok: true, desbloqueados: seguridad.desbloquear(req.params.subdominio, req.body?.usuario || '') });
});

// Activar / desactivar un taller (pausa por falta de pago, reactivación, etc.)
app.put('/api/distribuidor/talleres/:subdominio/estado', distribuidorAuth, (req, res) => {
  const { activo } = req.body;
  actualizarTaller(req.params.subdominio, { activo: activo ? 1 : 0 });
  registrarHistorialDist(req, req.params.subdominio, activo ? 'reactivar' : 'pausar', activo ? 'Negocio reactivado' : 'Negocio pausado (no puede entrar nadie)');
  res.json({ ok: true });
});

// Eliminar un taller definitivamente (cancelación, borra todos sus datos)
app.delete('/api/distribuidor/talleres/:subdominio', distribuidorAuth, (req, res) => {
  try {
    eliminarTaller(req.params.subdominio);
    registrarHistorialDist(req, req.params.subdominio, 'eliminar', 'Negocio eliminado definitivamente');
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// ─── INICIAR SERVIDOR ─────────────────────────────────────────────────────────
// ─── ACTUALIZACIONES AUTOMÁTICAS (solo para instalaciones locales) ────────────
// Chequea contra un archivo público (version.json) si hay una versión más
// nueva, y si el admin confirma, descarga el zip y lo aplica — SIN TOCAR
// NUNCA la carpeta data/ ni arca/certs/ (ahí vive todo lo del cliente).
const AdmZip = require('adm-zip');
const VERSION_URL = process.env.UPDATE_VERSION_URL || 'https://raw.githubusercontent.com/systechsolucionez-ui/systech-web/main/updates/sistema-tecnico/version.json';
const VERSION_ACTUAL = (() => {
  try { return require('fs').readFileSync(require('path').join(__dirname, 'VERSION'), 'utf-8').trim(); }
  catch { return '0.0.0'; }
})();

function versionEsMasNueva(remota, local) {
  const a = remota.split('.').map(Number), b = local.split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((a[i]||0) > (b[i]||0)) return true; if ((a[i]||0) < (b[i]||0)) return false; }
  return false;
}

// Identificador de esta versión del código: la pantalla lo compara para avisar si el servidor
// que está corriendo es una versión vieja (pasa cuando queda un SysTech anterior abierto).
const BUILD_ID = '2026-10-08-etapa4-v61';
app.get('/api/build', (req, res) => { res.set('Cache-Control', 'no-store'); res.json({ build: BUILD_ID }); });

app.get('/api/sistema/version', authMiddleware, (req, res) => {
  res.json({ version_actual: VERSION_ACTUAL });
});

async function leerVersionRemota() {
  const r = await fetch(VERSION_URL + (VERSION_URL.includes('?') ? '&' : '?') + 't=' + Date.now(), { signal: AbortSignal.timeout(15000) });
  if (!r.ok) throw new Error('El servidor de actualizaciones respondió ' + r.status);
  return r.json();
}

// "Actualizaciones hasta": una versión publicada DESPUÉS de esa fecha necesita que la licencia siga al día.
// Las correcciones marcadas como críticas se ofrecen siempre. Una versión sin fecha (manifiesto viejo) se ofrece igual que antes.
function actualizacionFueraDeLicencia(req, remoto) {
  if (MODO_DISTRIBUIDOR) return null;
  const hasta = planes.queIncluye(req, false).actualizacionesHasta;
  if (!hasta || !remoto.fecha || remoto.critica === true) return null;
  if (String(remoto.fecha).slice(0, 10) <= String(hasta).slice(0, 10)) return null;
  return `Hay una versión nueva (v${remoto.version}), pero tu licencia incluye actualizaciones hasta el ${String(hasta).slice(0, 10).split('-').reverse().join('/')}. Contactá a SysTech para renovar el soporte. Las correcciones urgentes se instalan igual.`;
}
app.get('/api/sistema/buscar-actualizacion', authMiddleware, adminOnly, async (req, res) => {
  try {
    const remoto = await leerVersionRemota();
    let hayNueva = versionEsMasNueva(String(remoto.version || '0.0.0'), VERSION_ACTUAL);
    const bloqueo = hayNueva ? actualizacionFueraDeLicencia(req, remoto) : null;
    if (bloqueo) hayNueva = false;
    res.json({ version_actual: VERSION_ACTUAL, version_disponible: remoto.version, hay_actualizacion: hayNueva, notas: remoto.notas || '', puede_aplicar: !MODO_DISTRIBUIDOR, bloqueada_por_licencia: !!bloqueo, mensaje: bloqueo || undefined });
  } catch (e) {
    console.error('Error buscando actualización:', e.message);
    res.status(500).json({ error: 'No se pudo conectar al servidor de actualizaciones. Revisá tu conexión a internet.' });
  }
});

// Lo que NUNCA toca una actualización: datos del cliente, certificados, licencia, fotos, claves.
const ACTUALIZACION_PROTEGIDO = [/^data\//, /^arca\/certs\//, /^node_modules\//, /^public\/uploads\//, /^licencia\.local\.json$/, /^licencia-privada\.pem$/,
  /^modo-distribuidor\.flag$/, /^\.env/, /\.db(-journal|-wal|-shm)?$/i, /^server-log\.txt$/, /^generar-licencia\.js$/, /^rotar-llave-licencia\.js$/, /^runtime\//, /^puerto\.txt$/, /^armar-version-cliente\.js$/, /^publicar-actualizacion\.js$/, /^public\/distribuidor\.html$/, /^\.git\//];

app.post('/api/sistema/aplicar-actualizacion', authMiddleware, adminOnly, async (req, res) => {
  if (MODO_DISTRIBUIDOR) return res.status(400).json({ error: 'Este es el servidor de SysTech: se actualiza subiendo el código, no desde acá.' });
  const fsx = require('fs'), pathx = require('path');
  let carpetaBackup = null; const escritos = [], reemplazados = [];
  const revertir = () => {
    try {
      escritos.forEach(f => { try { fsx.unlinkSync(f); } catch (e) {} });
      reemplazados.forEach(({ destino, copia }) => { try { fsx.copyFileSync(copia, destino); } catch (e) {} });
    } catch (e) {}
  };
  try {
    const remoto = await leerVersionRemota();
    if (!versionEsMasNueva(String(remoto.version || '0.0.0'), VERSION_ACTUAL)) return res.json({ ok: true, mensaje: 'Ya estás en la última versión.' });
    const bloqueoLic = actualizacionFueraDeLicencia(req, remoto);
    if (bloqueoLic) return res.status(402).json({ error: bloqueoLic });
    if (!remoto.zip_url || !/^(https:\/\/|http:\/\/(localhost|127\.0\.0\.1)[:\/])/.test(remoto.zip_url)) return res.status(500).json({ error: 'El servidor de actualizaciones no informó dónde bajar el archivo.' });
    // 1) Autenticidad: la actualización tiene que estar FIRMADA por SysTech. Sin firma válida no se instala nada.
    // Si el manifiesto trae fecha/crítica, esos datos también tienen que venir firmados (no se pueden cambiar en el camino).
    const datosFirmados = !remoto.fecha || (remoto.firma2 && licencia.verificarFirmaTexto(`${remoto.version}|${remoto.sha256}|${remoto.fecha}|${remoto.critica ? 1 : 0}`, remoto.firma2));
    if (!remoto.sha256 || !remoto.firma || !datosFirmados || !licencia.verificarFirmaTexto(`${remoto.version}|${remoto.sha256}`, remoto.firma)) {
      console.error('[Actualización] Firma inválida o ausente — se rechaza.');
      return res.status(400).json({ error: 'La actualización no está firmada por SysTech. Por seguridad no se instaló nada.' });
    }
    const zipResp = await fetch(remoto.zip_url + '?t=' + Date.now(), { signal: AbortSignal.timeout(120000) });
    if (!zipResp.ok) return res.status(502).json({ error: 'No se pudo descargar el archivo de actualización' });
    const buffer = Buffer.from(await zipResp.arrayBuffer());
    if (buffer.length > 150 * 1024 * 1024) return res.status(400).json({ error: 'El archivo de actualización es demasiado grande.' });
    // 2) Integridad: el zip descargado tiene que ser exactamente el que se firmó.
    if (crypto.createHash('sha256').update(buffer).digest('hex') !== remoto.sha256) {
      return res.status(400).json({ error: 'El archivo descargado no coincide con el firmado (descarga corrupta). No se instaló nada.' });
    }

    const zip = new AdmZip(buffer);
    const entradas = zip.getEntries().filter(e => !e.isDirectory).map(e => ({ e, rel: e.entryName.replace(/\\/g, '/').replace(/^\.\//, '') }))
      .filter(x => x.rel && !x.rel.startsWith('/') && !x.rel.split('/').includes('..') && !ACTUALIZACION_PROTEGIDO.some(rx => rx.test(x.rel)));
    if (!entradas.length) return res.status(400).json({ error: 'El archivo de actualización está vacío.' });

    // 3) Copia de seguridad del código que se va a reemplazar (para volver atrás si algo falla)
    const sello = new Date().toISOString().replace(/[:.]/g, '-');
    carpetaBackup = pathx.join(__dirname, 'data', 'respaldos-codigo', `${sello}_v${VERSION_ACTUAL}`);
    const pkgAntes = fsx.existsSync(pathx.join(__dirname, 'package.json')) ? fsx.readFileSync(pathx.join(__dirname, 'package.json')) : null;
    for (const { rel } of entradas) {
      const destino = pathx.join(__dirname, rel);
      if (fsx.existsSync(destino)) {
        const copia = pathx.join(carpetaBackup, rel);
        fsx.mkdirSync(pathx.dirname(copia), { recursive: true });
        fsx.copyFileSync(destino, copia);
        reemplazados.push({ destino, copia });
      }
    }
    // 4) Aplicar
    for (const { e, rel } of entradas) {
      const destino = pathx.join(__dirname, rel);
      if (!fsx.existsSync(destino)) escritos.push(destino);
      fsx.mkdirSync(pathx.dirname(destino), { recursive: true });
      fsx.writeFileSync(destino, e.getData());
    }
    fsx.writeFileSync(pathx.join(__dirname, 'VERSION'), String(remoto.version));
    // 5) Si cambiaron las dependencias, instalarlas (necesita internet, que ya hay porque se acaba de descargar)
    const pkgDespues = fsx.existsSync(pathx.join(__dirname, 'package.json')) ? fsx.readFileSync(pathx.join(__dirname, 'package.json')) : null;
    if (pkgAntes && pkgDespues && !pkgAntes.equals(pkgDespues)) {
      require('child_process').execSync('npm install --omit=dev --no-audit --no-fund', { cwd: __dirname, timeout: 240000, stdio: 'ignore' });
    }
    audit(req, 'sistema.actualizar', 'sistema', null, `v${VERSION_ACTUAL} → v${remoto.version} (${entradas.length} archivos)`);
    const reinicioAuto = process.env.SYSTECH_REINICIO_AUTO === '1';
    res.json({ ok: true, version_nueva: remoto.version, reinicia_solo: reinicioAuto,
      mensaje: reinicioAuto ? 'Actualización instalada. El sistema se reinicia solo en unos segundos.' : `Actualización instalada (${entradas.length} archivos). Cerrá SysTech y volvelo a abrir para que tome los cambios.` });
    // Código 75 = "reiniciame": lo entienden los .bat de inicio (INICIAR.bat / iniciar-systech.bat)
    if (reinicioAuto) setTimeout(() => process.exit(75), 1500);
  } catch (e) {
    console.error('Error aplicando actualización:', e.message);
    revertir();
    res.status(500).json({ error: 'No se pudo aplicar la actualización. Se volvió a la versión anterior y no se perdió nada.' });
  }
});

// ============================================================
// LICENCIA — activación offline (código firmado, no necesita
// internet). Ampliar sucursales también es un código nuevo.
// ============================================================

// Qué incluye el plan de este negocio (módulos, sucursales, addons). Lo usa el menú; el servidor es quien lo hace cumplir.
tienda.registrar(app, { authMiddleware, adminOnly, audit, moverStock, regMovStock, stockDisponible, lugarDeStock, planes, MODO_DISTRIBUIDOR });
asistente.registrar(app, { authMiddleware, adminOnly, audit, planes, MODO_DISTRIBUIDOR, masterDb, tienda, licencia, distribuidorAuth, prepararInforme, permisosDe, centralUrl: () => central.urlCentral() });
// Venta online con Mercado Pago (servidor central) y compras desde adentro del sistema (ver ventas.js)
const ventas = require('./ventas').registrar(app, { MODO_DISTRIBUIDOR, masterDb, crearTaller, actualizarTaller, getDbForTenant, licencia, planes, central, seguridad, distribuidorAuth, authMiddleware, adminOnly });
app.get('/api/mi-plan', authMiddleware, (req, res) => {
  const p = planes.queIncluye(req, MODO_DISTRIBUIDOR);
  limpiarCategoriasEjemploTienda(req);
  const usadas = req.db.prepare('SELECT COUNT(*) AS c FROM sucursales WHERE activa=1 AND es_deposito_central=0').get().c;
  res.json({ ...p, sucursalesUsadas: usadas, sucursalesBase: planes.SUCURSALES_BASE, sucursalesMaxPaquetes: planes.SUCURSALES_MAX_PAQUETES });
});

// Público (todavía no hay sesión antes de activar el sistema).
app.get('/api/licencia/estado', (req, res) => {
  // Hosting (modo distribuidor): el plan del negocio lo define el panel del distribuidor, no hay código que pegar.
  if (MODO_DISTRIBUIDOR && req.tenant) {
    const p = planes.queIncluye(req, MODO_DISTRIBUIDOR);
    return res.json({ activado: true, tienda: p.modulos.tienda, taller: p.modulos.taller, tecnibot: p.addons.tecnibot, limiteSucursales: p.limiteSucursales, fuente: 'hosting' });
  }
  const actual = licencia.leerLicenciaActual();
  res.json({
    activado: !!actual,
    tienda: actual?.tienda || false,
    taller: actual?.taller || false,
    tecnibot: actual?.tecnibot || false,
    limiteSucursales: actual ? licencia.limiteSucursalesActual() : 0,
  });
});

// Solo Tienda: la instalación local trae categorías de ejemplo de taller (Repuestos, etc.).
// Las que nadie usó se sacan: el negocio arma las suyas. Idempotente y no toca categorías con productos.
function limpiarCategoriasEjemploTienda(req) {
  try {
    const p = planes.queIncluye(req, MODO_DISTRIBUIDOR);
    if (!p.activado || p.modulos.taller) return;
    const db = req.db;
    try { db.prepare("UPDATE config SET valor='Mi Negocio' WHERE clave='empresa_nombre' AND valor='Mi Servicio Técnico'").run(); } catch (e) {}
    if (db.prepare("SELECT valor FROM config_fiscal WHERE clave='cat_ejemplo_limpiadas'").get()) return; // una sola vez
    db.prepare("INSERT OR REPLACE INTO config_fiscal (clave,valor) VALUES ('cat_ejemplo_limpiadas','1')").run();
    const sinUso = db.prepare(`SELECT id FROM categorias WHERE tipo='producto' AND id NOT IN (SELECT categoria_id FROM productos WHERE categoria_id IS NOT NULL)`).all();
    for (const c of sinUso) { db.prepare('DELETE FROM subcategorias WHERE categoria_id=?').run(c.id); db.prepare('DELETE FROM categorias WHERE id=?').run(c.id); }
  } catch (e) { console.error('[Planes] limpieza de categorías:', e.message); }
}
app.post('/api/licencia/activar', (req, res) => {
  try {
    const resultado = licencia.activar(req.body.codigo);
    limpiarCategoriasEjemploTienda(req);
    res.json({ ok: true, licencia: resultado });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Sucursales extra: ya no se pagan online. Se amplían con un código nuevo (con el total de sucursales dentro, firmado)
// que el cliente pega en Configuración → Sistema → Licencia. Estas dos rutas quedan solo para avisar a quien las llame.
app.post('/api/licencia/sucursal-extra/iniciar-pago', (req, res) => {
  res.status(410).json({ error: 'Las sucursales extra se agregan con un código nuevo. Pedíselo a tu distribuidor y pegalo en Configuración → Sistema → Licencia.' });
});
app.post('/api/licencia/sincronizar', (req, res) => {
  res.json({ sincronizado: false, motivo: 'obsoleto' });
});


// ─── RESPALDOS AUTOMÁTICOS ────────────────────────────────────────────────────
// Una copia consistente de todas las bases al iniciar y cada 24 horas, en
// data/respaldos/AAAA-MM-DD_HH-MM. Se conservan las últimas 14.
async function hacerRespaldo() {
  try {
    const d = new Date();
    const pad = n => String(n).padStart(2, '0');
    const nombre = `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}`;
    const base = path.join(__dirname, 'data', 'respaldos');
    const destino = path.join(base, nombre);
    fs.mkdirSync(destino, { recursive: true });
    await masterDb.backup(path.join(destino, 'master.db'));
    for (const t of listarTalleres()) {
      try { await getDbForTenant(t.subdominio).backup(path.join(destino, `${t.subdominio}.db`)); }
      catch (e) { console.error(`[respaldo] No se pudo respaldar ${t.subdominio}:`, e.message); }
    }
    const carpetas = fs.readdirSync(base).filter(n => /^\d{4}-\d{2}-\d{2}_/.test(n)).sort();
    carpetas.slice(0, Math.max(0, carpetas.length - 14)).forEach(n => fs.rmSync(path.join(base, n), { recursive: true, force: true }));
    console.log(`💾 Respaldo guardado: data/respaldos/${nombre}`);
  } catch (e) {
    console.error('[respaldo] Error:', e.message);
  }
}

// API: lo que no existe responde en JSON claro (si ves esto en una función nueva, el servidor es una versión vieja)
app.use('/api', (req, res) => res.status(404).json({ error: 'Esta función no existe en el servidor que está corriendo (versión vieja). Cerrá las ventanas negras y ejecutá REINICIAR.bat.' }));
// Cualquier error interno llega a la pantalla con su mensaje (antes devolvía una página HTML y la pantalla no mostraba nada)
app.use((err, req, res, next) => {
  console.error('[error]', req.method, req.originalUrl, err && err.stack || err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'Error interno del servidor: ' + (err && err.message || err) });
});

const _srv = app.listen(PORT, '0.0.0.0', () => {
  hacerRespaldo();
  setInterval(hacerRespaldo, 24 * 60 * 60 * 1000).unref();
  console.log(`\n✅ Sistema SysTech iniciado`);
  console.log(`📡 Acceso en esta PC: http://localhost:${PORT}`);
  console.log(`🌐 Acceso en red (celulares/otras PCs): http://${LOCAL_IP}:${PORT}`);
  console.log(`🏢 Talleres registrados: ${listarTalleres().length}`);
  console.log(`(Usuario y contraseña del admin: ver PRIMEROS-PASOS.txt)\n`);

  // La primera vez, dejamos las credenciales por defecto en un archivo
  // — NO en la consola, que queda visible todo el tiempo que el
  // sistema está prendido.
  const archivoInstrucciones = path.join(__dirname, 'PRIMEROS-PASOS.txt');
  if (!fs.existsSync(archivoInstrucciones)) {
    fs.writeFileSync(archivoInstrucciones,
      'SYSTECH — PRIMEROS PASOS\n' +
      '=========================\n\n' +
      'Usuario admin por defecto: admin\n' +
      'Contraseña provisoria: admin123\n\n' +
      'El sistema te va a pedir cambiarla apenas entres:\n' +
      'no se puede usar nada hasta elegir una contraseña nueva.\n\n' +
      'Este archivo es solo para vos — no lo compartas.\n'
    );
  }
});
_srv.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error(`\n❌ El puerto ${PORT} YA ESTÁ EN USO: hay otro SysTech abierto (una versión anterior).`);
    console.error('   Lo que ves en el navegador sigue siendo la versión VIEJA del servidor.');
    console.error('   Solución: cerrá esta ventana y ejecutá REINICIAR.bat (cierra el anterior y arranca el nuevo).\n');
  } else {
    console.error('❌ No se pudo iniciar el servidor:', e.message);
  }
  process.exit(1);
});
