// ============================================================
// VENTA ONLINE — cobro automático con Mercado Pago
//
// Corre en el SERVIDOR CENTRAL de SysTech (modo distribuidor): la página de compra, el cobro,
// el aviso de Mercado Pago y la entrega. Las instalaciones locales compran y renuevan a través de él.
//
//  · Precios en DÓLARES (CATALOGO, acá abajo). Se cobran en PESOS a la cotización que cargás en el
//    panel del distribuidor (por defecto 1600). El navegador nunca manda montos: los calcula el servidor.
//  · El pago se confirma SIEMPRE preguntándole a Mercado Pago (nunca se confía en el aviso solo):
//    aprobado, en pesos, por el monto exacto de la orden, y se entrega UNA sola vez.
//  · Entrega automática:
//      - Hosting: crea el negocio (o renueva / suma complementos) con su vencimiento.
//      - Instalación local: firma un código de activación nuevo; la instalación lo busca y lo aplica sola.
//  · Débito automático: suscripciones de Mercado Pago (una por ítem que se renueva). Cada cobro
//    aprobado extiende ese ítem un período.
//
// Variables de entorno (en el servidor central):
//   MP_ACCESS_TOKEN        token de Mercado Pago (TEST-... para pruebas, APP_USR-... para cobrar)
//   URL_BASE o SYSTECH_DOMINIO   dirección pública del sitio (para volver del pago y recibir avisos)
//   LICENCIA_PRIVADA_ARCHIVO     clave privada para firmar códigos (o licencia-privada.pem junto a server.js)
//   SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM   (opcional) mails de confirmación
//   DESCARGA_URL           (opcional) link de descarga del instalador para quien compra la versión local
//   CONTACTO_EMAIL, CONTACTO_WHATSAPP  (recomendado) contacto y botón de arrepentimiento de la página de compra
// ============================================================
const crypto = require('crypto');

// ─── CATÁLOGO (USD) ────────────────────────────────────────────────────────────
// meses: cuánto extiende cada compra (0 = pago único). anual = 10 meses.
const CATALOGO = {
  lic_taller:        { usd: 125,  meses: 0,  label: 'Licencia Solo Taller' },
  lic_tienda:        { usd: 125,  meses: 0,  label: 'Licencia Solo Tienda' },
  lic_combo:         { usd: 215,  meses: 0,  label: 'Licencia Taller + Tienda' },
  hosting_taller_m:  { usd: 12.5, meses: 1,  label: 'Hosting Solo Taller (mensual)' },
  hosting_taller_a:  { usd: 125,  meses: 12, label: 'Hosting Solo Taller (anual)' },
  hosting_tienda_m:  { usd: 12.5, meses: 1,  label: 'Hosting Solo Tienda (mensual)' },
  hosting_tienda_a:  { usd: 125,  meses: 12, label: 'Hosting Solo Tienda (anual)' },
  hosting_combo_m:   { usd: 21.5, meses: 1,  label: 'Hosting Taller + Tienda (mensual)' },
  hosting_combo_a:   { usd: 215,  meses: 12, label: 'Hosting Taller + Tienda (anual)' },
  sucursal_m:        { usd: 4.5,  meses: 1,  label: 'Sucursal extra (mensual)' },
  sucursal_a:        { usd: 45,   meses: 12, label: 'Sucursal extra (anual)' },
  pack_m:            { usd: 42,   meses: 1,  label: 'Pack Full IA (mensual)' },
  pack_a:            { usd: 420,  meses: 12, label: 'Pack Full IA (anual)' },
  tecnibot_m:        { usd: 13.5, meses: 1,  label: 'Bot Técnico IA + Soporte (mensual)' },
  tecnibot_a:        { usd: 135,  meses: 12, label: 'Bot Técnico IA + Soporte (anual)' },
  ia_m:              { usd: 17,   meses: 1,  label: 'IA por Voz + Proyección de Ventas (mensual)' },
  ia_a:              { usd: 170,  meses: 12, label: 'IA por Voz + Proyección de Ventas (anual)' },
  actualizaciones_a: { usd: 45,   meses: 12, label: 'Actualizaciones por un año (instalación local)' },
  imei_50:           { usd: 19,   meses: 0,  label: 'Reporte IMEI: 50 consultas', imei: 50 },
  imei_100:          { usd: 30,   meses: 0,  label: 'Reporte IMEI: 100 consultas', imei: 100 },
};
const COTIZACION_DEFECTO = 1600;
const SUCURSALES_INCLUIDAS = 2;
const MAX_SUCURSALES_EXTRA = 4;            // 2 incluidas + 4 = 6 (más es un plan a medida)
const SUBDOMINIOS_RESERVADOS = new Set(['www', 'api', 'admin', 'app', 'mail', 'smtp', 'ftp', 'default', 'panel', 'central', 'soporte', 'ayuda', 'blog', 'tienda', 'comprar', 'pagos', 'systech', 'distribuidor', 'static', 'cdn', 'test', 'demo']);
const PLANES = { taller: { taller: 1, tienda: 0 }, tienda: { taller: 0, tienda: 1 }, combo: { taller: 1, tienda: 1 } };
const PERIODOS = { mensual: 'm', anual: 'a' };
// Ítems que se pueden poner en débito automático (uno por suscripción)
const RECURRENTES = ['hosting', 'pack', 'tecnibot', 'ia', 'actualizaciones'];

const fechaHoy = () => new Date().toLocaleDateString('sv-SE');
const redondearPesos = n => Math.round(Number(n) || 0);
const emailValido = e => typeof e === 'string' && e.length <= 120 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);
const tokenIgual = (a, b) => { a = String(a || ''); b = String(b || ''); return a.length > 0 && a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b)); };
const limpiar = (t, max) => String(t || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, max);

/** Suma meses a una fecha AAAA-MM-DD. Si la fecha ya pasó (o no hay), suma desde hoy. */
function sumarMeses(actual, meses, hoy = fechaHoy()) {
  const a = actual ? String(actual).slice(0, 10) : null;
  const base = a && a >= hoy ? a : hoy;
  const d = new Date(base + 'T00:00:00Z');
  const dia = d.getUTCDate();
  d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() + meses);
  const finMes = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  d.setUTCDate(Math.min(dia, finMes));
  return d.toISOString().slice(0, 10);
}
function mesesRestantes(hasta, hoy = fechaHoy()) {
  if (!hasta || String(hasta).slice(0, 10) <= hoy) return 1;
  const dias = (new Date(String(hasta).slice(0, 10) + 'T00:00:00Z') - new Date(hoy + 'T00:00:00Z')) / 86400000;
  return Math.max(1, Math.round(dias / 30.4));
}

function registrar(app, d) {
  const { MODO_DISTRIBUIDOR, masterDb, crearTaller, actualizarTaller, getDbForTenant, licencia, planes, central, seguridad,
    distribuidorAuth, authMiddleware, adminOnly } = d;
  const fetchFn = d.fetch || ((...a) => fetch(...a));
  const MP_API = () => String(process.env.MP_API_URL || 'https://api.mercadopago.com').replace(/\/+$/, '');   // la variable existe para las pruebas
  const tokenMP = () => String(process.env.MP_ACCESS_TOKEN || '').trim();

  // ─── Tablas (base maestra del servidor central) ───
  masterDb.exec(`
    CREATE TABLE IF NOT EXISTS ventas_config (clave TEXT PRIMARY KEY, valor TEXT);
    CREATE TABLE IF NOT EXISTS ventas_ordenes (
      id TEXT PRIMARY KEY, token TEXT NOT NULL, creado DATETIME DEFAULT CURRENT_TIMESTAMP,
      estado TEXT NOT NULL DEFAULT 'pendiente',       -- pendiente | procesando | entregada | error
      tipo TEXT NOT NULL,                             -- nuevo | existente
      destino TEXT NOT NULL,                          -- hosting | local
      nombre TEXT, email TEXT, telefono TEXT, subdominio TEXT, negocio_id TEXT,
      items TEXT NOT NULL, total_usd REAL NOT NULL, cotizacion REAL NOT NULL, total_ars INTEGER NOT NULL,
      licencia_previa TEXT,                           -- (instalación local que compra) lo que traía su código
      mp_preference_id TEXT, mp_payment_id TEXT, mp_estado TEXT,
      resultado TEXT, error TEXT, entregada_en DATETIME
    );
    CREATE INDEX IF NOT EXISTS idx_ventas_ordenes_estado ON ventas_ordenes(estado);
    CREATE TABLE IF NOT EXISTS ventas_pagos (mp_payment_id TEXT PRIMARY KEY, referencia TEXT, monto REAL, fecha DATETIME DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS ventas_suscripciones (
      id TEXT PRIMARY KEY, creado DATETIME DEFAULT CURRENT_TIMESTAMP,
      destino TEXT NOT NULL, subdominio TEXT, negocio_id TEXT,
      item TEXT NOT NULL, periodo TEXT NOT NULL, monto_ars INTEGER NOT NULL, email TEXT,
      mp_preapproval_id TEXT, estado TEXT NOT NULL DEFAULT 'pendiente',   -- pendiente | activa | pausada | cancelada
      ultimo_cobro DATETIME, cobros INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS ventas_clientes_locales (
      negocio_id TEXT PRIMARY KEY, nombre TEXT, email TEXT, telefono TEXT,
      taller INTEGER DEFAULT 0, tienda INTEGER DEFAULT 0, limite_sucursales INTEGER DEFAULT 2,
      tecnibot INTEGER DEFAULT 0, tecnibot_hasta TEXT, ia INTEGER DEFAULT 0, ia_hasta TEXT,
      actualizaciones_hasta TEXT, vence TEXT,
      ultimo_codigo TEXT, emitido TEXT, creado DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  const cfgGet = (k, def) => { const r = masterDb.prepare('SELECT valor FROM ventas_config WHERE clave=?').get(k); return r ? r.valor : def; };
  const cfgSet = (k, v) => masterDb.prepare('INSERT OR REPLACE INTO ventas_config (clave,valor) VALUES (?,?)').run(k, String(v));
  const cotizacion = () => { const n = Number(cfgGet('cotizacion', COTIZACION_DEFECTO)); return n > 0 ? n : COTIZACION_DEFECTO; };
  const precioArs = usd => redondearPesos(usd * cotizacion());

  // ─── Mercado Pago ───
  async function mp(metodo, ruta, cuerpo) {
    const r = await fetchFn(MP_API() + ruta, {
      method: metodo, signal: AbortSignal.timeout(20000),
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tokenMP()}`, ...(metodo === 'POST' ? { 'X-Idempotency-Key': crypto.randomUUID() } : {}) },
      ...(cuerpo ? { body: JSON.stringify(cuerpo) } : {}),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(`Mercado Pago respondió ${r.status}`); e.status = r.status; e.data = data; throw e; }
    return data;
  }

  // ─── Mails (opcional) ───
  async function enviarMail(para, asunto, html) {
    if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS || !emailValido(para)) return false;
    try {
      const nodemailer = require('nodemailer');
      const port = Number(process.env.SMTP_PORT) || 587;
      const t = nodemailer.createTransport({ host: process.env.SMTP_HOST, port, secure: port === 465, auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } });
      await t.sendMail({ from: process.env.SMTP_FROM || `"SysTech" <${process.env.SMTP_USER}>`, to: para, subject: asunto, html });
      return true;
    } catch (e) { console.error('[Ventas] No se pudo mandar el mail:', e.message); return false; }
  }
  const escHtml = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

  // ─── Armado de la compra (los montos los calcula SIEMPRE el servidor) ───
  // pedido: { plan, modalidad, periodo, pack, tecnibot, ia, imei, sucursales_extra, renovar_hosting, actualizaciones }
  // contexto: { tipo:'nuevo'|'existente', destino:'hosting'|'local', taller?: fila del negocio, local?: datos del código }
  function armarItems(pedido, ctx) {
    const p = pedido || {}, items = [];
    const per = v => (v === 'mensual' || v === 'anual') ? PERIODOS[v] : null;
    const agregar = (codigo, cantidad = 1, usdUnit) => {
      const c = CATALOGO[codigo]; if (!c) throw new Error('Producto inválido.');
      items.push({ codigo, cantidad, usd: Math.round(((usdUnit === undefined ? c.usd : usdUnit) * cantidad) * 100) / 100, label: c.label + (cantidad > 1 ? ` × ${cantidad}` : '') });
    };
    const extras = Number.isInteger(Number(p.sucursales_extra)) ? Number(p.sucursales_extra) : 0;
    if (extras < 0 || extras > MAX_SUCURSALES_EXTRA) throw new Error(`Las sucursales extra van de 0 a ${MAX_SUCURSALES_EXTRA}. Para más, consultá un plan a medida.`);
    const imei = Number(p.imei) || 0;
    if (![0, 50, 100].includes(imei)) throw new Error('El paquete de IMEI es de 50 o de 100 consultas.');
    const tb = p.tecnibot ? per(p.tecnibot) : null, ia = p.ia ? per(p.ia) : null;
    if ((p.tecnibot && !tb) || (p.ia && !ia)) throw new Error('El período de un complemento tiene que ser mensual o anual.');

    if (ctx.tipo === 'nuevo') {
      if (!PLANES[p.plan]) throw new Error('Elegí un plan: Solo Taller, Solo Tienda o Taller + Tienda.');
      if (!['local', 'hosting'].includes(p.modalidad)) throw new Error('Elegí cómo lo vas a usar: instalado en tu PC o en hosting.');
      agregar('lic_' + p.plan);
      if (p.modalidad === 'hosting') {
        const ph = per(p.periodo); if (!ph) throw new Error('Elegí si el hosting es mensual o anual.');
        if (p.pack) {
          if (p.plan !== 'combo') throw new Error('El Pack Full IA es para Taller + Tienda.');
          agregar('pack_' + ph);
        } else agregar(`hosting_${p.plan}_${ph}`);
        if (extras) agregar('sucursal_' + ph, extras);
      } else {
        if (p.pack) throw new Error('El Pack Full IA es solo para hosting.');
        if (extras) throw new Error('Las sucursales extra se suman en hosting. Para la instalación local, consultá a SysTech.');
      }
      if (tb && !p.pack) agregar('tecnibot_' + tb);
      if (ia && !p.pack) agregar('ia_' + ia);
    } else if (ctx.destino === 'hosting') {
      const t = ctx.taller;
      const plan = t.modulo_taller !== 0 && t.modulo_tienda !== 0 ? 'combo' : (t.modulo_taller !== 0 ? 'taller' : 'tienda');
      const ph = p.renovar_hosting ? per(p.renovar_hosting) : null;
      if (p.renovar_hosting && !ph) throw new Error('El período del hosting tiene que ser mensual o anual.');
      const pk = p.pack ? per(p.pack) : null;
      if (p.pack && (!pk || plan !== 'combo')) throw new Error(plan !== 'combo' ? 'El Pack Full IA es para Taller + Tienda.' : 'El período del pack tiene que ser mensual o anual.');
      if (pk && ph) throw new Error('El Pack Full IA ya incluye el hosting: elegí uno de los dos.');
      const extrasActuales = Math.max(0, (Number(t.limite_sucursales) || SUCURSALES_INCLUIDAS) - SUCURSALES_INCLUIDAS);
      if (pk) { agregar('pack_' + pk); if (extrasActuales) agregar('sucursal_' + pk, extrasActuales); }
      if (ph) { agregar(`hosting_${plan}_${ph}`); if (extrasActuales) agregar('sucursal_' + ph, extrasActuales); }
      if (extras) {
        if ((Number(t.limite_sucursales) || SUCURSALES_INCLUIDAS) + extras > SUCURSALES_INCLUIDAS + MAX_SUCURSALES_EXTRA) throw new Error('Con eso superarías 6 sucursales: consultá un plan a medida.');
        // Sucursal nueva: se cobra lo que falta hasta el próximo vencimiento del hosting (o lo que se esté renovando).
        const hasta = (ph || pk) ? sumarMeses(t.fecha_vencimiento, CATALOGO[`hosting_combo_${ph || pk}`].meses) : t.fecha_vencimiento;
        const meses = mesesRestantes(hasta);
        agregar('sucursal_m', extras, meses >= 12 ? Math.round(CATALOGO.sucursal_a.usd * meses / 12 * 100) / 100 : CATALOGO.sucursal_m.usd * meses);
        items[items.length - 1].sucursalesNuevas = extras;
        items[items.length - 1].label = `Sucursal extra × ${extras} (hasta el ${String(hasta || '').slice(0, 10) || 'próximo vencimiento'})`;
      }
      if (tb && !pk) agregar('tecnibot_' + tb);
      if (ia && !pk) agregar('ia_' + ia);
    } else {   // instalación local que ya tiene licencia
      if (p.pack || p.renovar_hosting || extras) throw new Error('Desde la instalación local se pueden sumar Tecnibot, la IA, paquetes IMEI y actualizaciones.');
      if (p.actualizaciones) agregar('actualizaciones_a');
      if (tb) agregar('tecnibot_' + tb);
      if (ia) agregar('ia_' + ia);
    }
    if (imei) agregar('imei_' + imei);
    if (!items.length) throw new Error('Elegí al menos un producto.');
    const totalUsd = Math.round(items.reduce((a, i) => a + i.usd, 0) * 100) / 100;
    return { items, totalUsd, totalArs: precioArs(totalUsd) };
  }

  function nuevaOrden({ tipo, destino, nombre, email, telefono, subdominio, negocio_id, armado, licencia_previa }) {
    const id = 'o_' + crypto.randomBytes(9).toString('hex'), token = crypto.randomBytes(18).toString('hex');
    masterDb.prepare(`INSERT INTO ventas_ordenes (id, token, tipo, destino, nombre, email, telefono, subdominio, negocio_id, items, total_usd, cotizacion, total_ars, licencia_previa)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(id, token, tipo, destino, nombre || '', email || '', telefono || '', subdominio || null, negocio_id || null,
      JSON.stringify(armado.items), armado.totalUsd, cotizacion(), armado.totalArs, licencia_previa ? JSON.stringify(licencia_previa) : null);
    return { id, token };
  }

  async function crearPreferencia(orden) {
    const base = central.urlPrincipal();
    if (!base) throw Object.assign(new Error('Falta configurar la dirección pública del sitio (URL_BASE o SYSTECH_DOMINIO).'), { publico: true });
    if (!tokenMP()) throw Object.assign(new Error('El cobro online todavía no está configurado (falta el token de Mercado Pago).'), { publico: true });
    const items = JSON.parse(orden.items);
    const vuelta = `${base}/pago.html?id=${orden.id}&t=${orden.token}`;
    const pref = await mp('POST', '/checkout/preferences', {
      items: [{ id: orden.id, title: ('SysTech — ' + items.map(i => i.label).join(' + ')).slice(0, 250), quantity: 1, unit_price: orden.total_ars, currency_id: 'ARS' }],
      payer: emailValido(orden.email) ? { email: orden.email } : undefined,
      external_reference: 'ord:' + orden.id,
      back_urls: { success: vuelta, failure: vuelta, pending: vuelta },
      auto_return: 'approved',
      notification_url: `${base}/api/ventas/webhook`,
      statement_descriptor: 'SYSTECH',
      metadata: { orden: orden.id },
    });
    masterDb.prepare('UPDATE ventas_ordenes SET mp_preference_id=? WHERE id=?').run(pref.id || null, orden.id);
    const prueba = /^TEST-/.test(tokenMP());
    return (prueba && pref.sandbox_init_point) || pref.init_point;
  }

  // ─── Entrega ───
  function claveInicial() {
    const letras = 'abcdefghjkmnpqrstuvwxyz', nums = '23456789';
    const pick = (s, n) => Array.from(crypto.randomBytes(n)).map(b => s[b % s.length]).join('');
    return pick(letras, 4) + '-' + pick(nums, 4) + '-' + pick(letras, 4);
  }
  function subdominioLibre(base) {
    let sub = base, n = 2;
    while (masterDb.prepare('SELECT 1 FROM talleres WHERE subdominio=?').get(sub)) sub = `${base}-${n++}`;
    return sub;
  }

  // Aplica ítems a un negocio en hosting. Devuelve lo que cambió.
  function aplicarHosting(sub, items) {
    const t = masterDb.prepare('SELECT * FROM talleres WHERE subdominio=?').get(sub);
    if (!t) throw new Error('No existe el negocio ' + sub);
    const c = {};
    let vence = t.fecha_vencimiento ? String(t.fecha_vencimiento).slice(0, 10) : null;
    let tbV = t.tecnibot_vence, iaV = t.ia_vence;
    for (const it of items) {
      const cat = CATALOGO[it.codigo], cod = it.codigo;
      if (/^hosting_/.test(cod)) { vence = sumarMeses(vence, cat.meses); c.fecha_vencimiento = vence; }
      else if (/^pack_/.test(cod)) {
        vence = sumarMeses(vence, cat.meses); c.fecha_vencimiento = vence;
        tbV = sumarMeses(tbV, cat.meses); iaV = sumarMeses(iaV, cat.meses);
        Object.assign(c, { tecnibot_habilitado: 1, tecnibot_vence: tbV, ia_habilitada: 1, ia_vence: iaV, modulo_taller: 1, modulo_tienda: 1 });
      }
      else if (/^tecnibot_/.test(cod)) { tbV = sumarMeses(tbV, cat.meses); Object.assign(c, { tecnibot_habilitado: 1, tecnibot_vence: tbV }); }
      else if (/^ia_/.test(cod)) { iaV = sumarMeses(iaV, cat.meses); Object.assign(c, { ia_habilitada: 1, ia_vence: iaV }); }
      else if (/^imei_/.test(cod)) c.imei_saldo = (c.imei_saldo !== undefined ? c.imei_saldo : (Number(t.imei_saldo) || 0)) + cat.imei * (it.cantidad || 1);
      else if (it.sucursalesNuevas) c.limite_sucursales = (c.limite_sucursales || Number(t.limite_sucursales) || SUCURSALES_INCLUIDAS) + it.sucursalesNuevas;
    }
    if (c.fecha_vencimiento) c.activo = 1;
    actualizarTaller(sub, c);
    return c;
  }

  // Instalación local: aplica ítems a su ficha y firma un código nuevo con TODO lo que tiene.
  function aplicarLocal(negocioId, items, datosBase) {
    let f = masterDb.prepare('SELECT * FROM ventas_clientes_locales WHERE negocio_id=?').get(negocioId);
    if (!f) {
      const b = datosBase || {};
      masterDb.prepare(`INSERT INTO ventas_clientes_locales (negocio_id, nombre, email, telefono, taller, tienda, limite_sucursales, tecnibot, tecnibot_hasta, ia, ia_hasta, actualizaciones_hasta, vence)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(negocioId, b.nombre || '', b.email || '', b.telefono || '', b.taller ? 1 : 0, b.tienda ? 1 : 0,
        Number(b.limiteSucursales) || SUCURSALES_INCLUIDAS, b.tecnibot ? 1 : 0, b.tecnibotHasta || null, b.ia ? 1 : 0, b.iaHasta || null, b.actualizacionesHasta || null, b.vence || null);
      f = masterDb.prepare('SELECT * FROM ventas_clientes_locales WHERE negocio_id=?').get(negocioId);
    }
    const c = { ...f };
    let imeiSumar = 0;
    for (const it of items) {
      const cat = CATALOGO[it.codigo], cod = it.codigo;
      if (cod === 'lic_taller') Object.assign(c, { taller: 1 });
      else if (cod === 'lic_tienda') Object.assign(c, { tienda: 1 });
      else if (cod === 'lic_combo') Object.assign(c, { taller: 1, tienda: 1 });
      if (/^lic_/.test(cod)) c.actualizaciones_hasta = sumarMeses(c.actualizaciones_hasta, 12);
      else if (cod === 'actualizaciones_a') c.actualizaciones_hasta = sumarMeses(c.actualizaciones_hasta, 12);
      else if (/^tecnibot_/.test(cod)) { c.tecnibot = 1; c.tecnibot_hasta = sumarMeses(c.tecnibot_hasta, cat.meses); }
      else if (/^ia_/.test(cod)) { c.ia = 1; c.ia_hasta = sumarMeses(c.ia_hasta, cat.meses); }
      else if (/^imei_/.test(cod)) imeiSumar += cat.imei * (it.cantidad || 1);
    }
    const codigo = licencia.generarCodigo({
      taller: !!c.taller, tienda: !!c.tienda, tecnibot: !!c.tecnibot, ia: !!c.ia,
      limiteSucursales: Number(c.limite_sucursales) || SUCURSALES_INCLUIDAS, negocioId,
      vence: c.vence || undefined, tecnibotHasta: c.tecnibot_hasta || undefined, iaHasta: c.ia_hasta || undefined,
      actualizacionesHasta: c.actualizaciones_hasta || undefined,
    });
    const emitido = licencia.verificarCodigo(codigo).emitido;
    masterDb.prepare(`UPDATE ventas_clientes_locales SET taller=?, tienda=?, tecnibot=?, tecnibot_hasta=?, ia=?, ia_hasta=?, actualizaciones_hasta=?, ultimo_codigo=?, emitido=? WHERE negocio_id=?`)
      .run(c.taller, c.tienda, c.tecnibot, c.tecnibot_hasta, c.ia, c.ia_hasta, c.actualizaciones_hasta, codigo, emitido, negocioId);
    // Servicios del servidor central para esa instalación: AsystenBot (IA) y saldo de IMEI.
    if (c.ia && c.ia_hasta) {
      masterDb.prepare(`INSERT INTO asistente_clientes (negocio_id, nombre, habilitado, vence) VALUES (?,?,1,?)
        ON CONFLICT(negocio_id) DO UPDATE SET habilitado=1, vence=excluded.vence`).run(negocioId, c.nombre || '', c.ia_hasta);
    }
    if (imeiSumar) {
      masterDb.prepare(`INSERT INTO imei_clientes (negocio_id, nombre, habilitado, vence, saldo) VALUES (?,?,1,NULL,?)
        ON CONFLICT(negocio_id) DO UPDATE SET habilitado=1, saldo=COALESCE(saldo,0)+excluded.saldo`).run(negocioId, c.nombre || '', imeiSumar);
    }
    return { codigo, emitido };
  }

  // Entrega una orden pagada. Idempotente: si ya se entregó, no hace nada.
  async function entregarOrden(ordenId, pagoId) {
    const tomada = masterDb.prepare("UPDATE ventas_ordenes SET estado='procesando', mp_payment_id=COALESCE(?, mp_payment_id) WHERE id=? AND estado IN ('pendiente','error')").run(pagoId || null, ordenId);
    if (!tomada.changes) return false;
    const o = masterDb.prepare('SELECT * FROM ventas_ordenes WHERE id=?').get(ordenId);
    const items = JSON.parse(o.items);
    try {
      let resultado;
      if (o.destino === 'hosting' && o.tipo === 'nuevo') {
        const lic = items.find(i => /^lic_/.test(i.codigo)).codigo.slice(4);
        const sub = subdominioLibre(o.subdominio);
        const extras = items.filter(i => /^sucursal_/.test(i.codigo)).reduce((a, i) => a + (i.cantidad || 0), 0);
        crearTaller({ subdominio: sub, nombre: o.nombre, plan: 'hosting', email_contacto: o.email, telefono_contacto: o.telefono,
          notas: `Alta automática por venta online (orden ${o.id})`, fecha_vencimiento: null, tecnibot_habilitado: false, imei_habilitado: false,
          modulo_taller: !!PLANES[lic].taller, modulo_tienda: !!PLANES[lic].tienda, limite_sucursales: SUCURSALES_INCLUIDAS + extras, ia_habilitada: false });
        aplicarHosting(sub, items);
        const clave = claveInicial();
        getDbForTenant(sub).prepare("UPDATE usuarios SET password=?, debe_cambiar_password=1 WHERE usuario='admin'").run(seguridad.hashPassword(clave));
        resultado = { tipo: 'hosting', subdominio: sub, url: central.urlNegocio(sub), usuario: 'admin', clave_inicial: clave };
      } else if (o.destino === 'hosting') {
        resultado = { tipo: 'hosting', subdominio: o.subdominio, url: central.urlNegocio(o.subdominio), cambios: aplicarHosting(o.subdominio, items) };
      } else {
        const negocioId = o.negocio_id || crypto.randomUUID();
        if (!o.negocio_id) masterDb.prepare('UPDATE ventas_ordenes SET negocio_id=? WHERE id=?').run(negocioId, o.id);
        const previa = o.licencia_previa ? JSON.parse(o.licencia_previa) : null;
        const { codigo } = aplicarLocal(negocioId, items, { ...(previa || {}), nombre: o.nombre, email: o.email, telefono: o.telefono });
        resultado = { tipo: 'local', negocio_id: negocioId, codigo, descarga: process.env.DESCARGA_URL || null, nuevo: o.tipo === 'nuevo' };
      }
      masterDb.prepare("UPDATE ventas_ordenes SET estado='entregada', resultado=?, error=NULL, entregada_en=CURRENT_TIMESTAMP WHERE id=?").run(JSON.stringify(resultado), o.id);
      avisarEntrega(o, resultado).catch(() => {});
      return true;
    } catch (e) {
      console.error('[Ventas] Error al entregar la orden', o.id, e);
      masterDb.prepare("UPDATE ventas_ordenes SET estado='error', error=? WHERE id=?").run(String(e.message || e).slice(0, 500), o.id);
      return false;
    }
  }

  async function avisarEntrega(o, r) {
    const items = JSON.parse(o.items).map(i => `<li>${escHtml(i.label)}</li>`).join('');
    let cuerpo = `<p>¡Gracias por tu compra!</p><ul>${items}</ul><p>Total pagado: $${Number(o.total_ars).toLocaleString('es-AR')}</p>`;
    if (r.tipo === 'hosting' && r.clave_inicial) cuerpo += `<p><b>Tu sistema:</b> <a href="${escHtml(r.url)}">${escHtml(r.url)}</a><br>Usuario: <b>admin</b><br>Contraseña inicial: <b>${escHtml(r.clave_inicial)}</b><br>Al entrar te va a pedir que elijas una contraseña nueva.</p>`;
    else if (r.tipo === 'hosting') cuerpo += `<p>Ya quedó aplicado en tu sistema: <a href="${escHtml(r.url)}">${escHtml(r.url)}</a></p>`;
    else if (r.nuevo) cuerpo += `<p><b>Tu código de activación</b> (pegalo la primera vez que abras el sistema):</p><p style="font-family:monospace;word-break:break-all;background:#f3f3f3;padding:10px">${escHtml(r.codigo)}</p>${r.descarga ? `<p>Descargá el sistema: <a href="${escHtml(r.descarga)}">${escHtml(r.descarga)}</a></p>` : ''}`;
    else cuerpo += `<p>Tu sistema se actualiza solo en los próximos minutos (necesita internet). Si querés hacerlo ya: Configuración → Sistema → Comprar o renovar → «Buscar mi compra».</p>`;
    await enviarMail(o.email, 'SysTech — compra confirmada', cuerpo);
  }

  // ─── Confirmación del pago (siempre contra la API de Mercado Pago) ───
  async function procesarPago(pagoId) {
    const pago = await mp('GET', `/v1/payments/${encodeURIComponent(pagoId)}`);
    const ref = String(pago.external_reference || '');
    if (ref.startsWith('ord:')) return procesarPagoOrden(ref.slice(4), pago);
    if (ref.startsWith('sus:')) return procesarPagoSuscripcion(ref.slice(4), pago);
    return { ignorado: true };
  }
  async function procesarPagoOrden(ordenId, pago) {
    const o = masterDb.prepare('SELECT * FROM ventas_ordenes WHERE id=?').get(ordenId);
    if (!o) return { ignorado: true };
    masterDb.prepare('UPDATE ventas_ordenes SET mp_estado=? WHERE id=? AND estado != ?').run(String(pago.status || ''), o.id, 'entregada');
    if (pago.status !== 'approved') return { estado: pago.status };
    if (String(pago.currency_id) !== 'ARS' || Math.abs(Number(pago.transaction_amount) - Number(o.total_ars)) > 0.5) {
      console.error('[Ventas] Pago con monto o moneda distintos a la orden', o.id, pago.transaction_amount, pago.currency_id);
      masterDb.prepare("UPDATE ventas_ordenes SET estado='error', error=? WHERE id=? AND estado IN ('pendiente','error')").run(`El pago ${pago.id} no coincide con la orden (monto ${pago.transaction_amount} ${pago.currency_id}). Revisalo en Mercado Pago.`, o.id);
      return { error: 'monto' };
    }
    const nuevo = masterDb.prepare('INSERT OR IGNORE INTO ventas_pagos (mp_payment_id, referencia, monto) VALUES (?,?,?)').run(String(pago.id), 'ord:' + o.id, Number(pago.transaction_amount));
    if (!nuevo.changes && o.estado === 'entregada') return { yaEntregada: true };
    await entregarOrden(o.id, String(pago.id));
    return { entregada: true };
  }

  // Busca activamente el pago de una orden (por si el aviso de Mercado Pago no llegó).
  async function conciliarOrden(ordenId) {
    const o = masterDb.prepare('SELECT * FROM ventas_ordenes WHERE id=?').get(ordenId);
    if (!o || o.estado === 'entregada' || !tokenMP()) return;
    const r = await mp('GET', `/v1/payments/search?external_reference=${encodeURIComponent('ord:' + o.id)}&sort=date_created&criteria=desc&limit=10`);
    const aprobado = (r.results || []).find(p => p.status === 'approved');
    if (aprobado) await procesarPagoOrden(o.id, aprobado);
    else if (r.results && r.results[0]) masterDb.prepare('UPDATE ventas_ordenes SET mp_estado=? WHERE id=?').run(String(r.results[0].status || ''), o.id);
  }

  // ─── Débito automático ───
  function infoRecurrente(item, periodo, destino, sujeto) {
    // Devuelve { codigo, monto, vence } del ítem que se renueva, con el precio de hoy.
    const ph = periodo === 'a' ? 'a' : 'm';
    if (destino === 'hosting') {
      const t = masterDb.prepare('SELECT * FROM talleres WHERE subdominio=?').get(sujeto);
      if (!t) throw new Error('No existe ese negocio.');
      const plan = t.modulo_taller !== 0 && t.modulo_tienda !== 0 ? 'combo' : (t.modulo_taller !== 0 ? 'taller' : 'tienda');
      const extras = Math.max(0, (Number(t.limite_sucursales) || SUCURSALES_INCLUIDAS) - SUCURSALES_INCLUIDAS);
      const suc = extras ? CATALOGO['sucursal_' + ph].usd * extras : 0;
      if (item === 'hosting') return { codigos: [`hosting_${plan}_${ph}`].concat(extras ? [`sucursal_${ph}`] : []), extras, usd: CATALOGO[`hosting_${plan}_${ph}`].usd + suc, vence: t.fecha_vencimiento };
      if (item === 'pack') { if (plan !== 'combo') throw new Error('El Pack Full IA es para Taller + Tienda.'); return { codigos: [`pack_${ph}`].concat(extras ? [`sucursal_${ph}`] : []), extras, usd: CATALOGO['pack_' + ph].usd + suc, vence: t.fecha_vencimiento }; }
      if (item === 'tecnibot') return { codigos: ['tecnibot_' + ph], usd: CATALOGO['tecnibot_' + ph].usd, vence: t.tecnibot_vence };
      if (item === 'ia') return { codigos: ['ia_' + ph], usd: CATALOGO['ia_' + ph].usd, vence: t.ia_vence };
    } else {
      const f = masterDb.prepare('SELECT * FROM ventas_clientes_locales WHERE negocio_id=?').get(sujeto);
      if (!f) throw new Error('Todavía no hay compras registradas para esta instalación.');
      if (item === 'tecnibot') return { codigos: ['tecnibot_' + ph], usd: CATALOGO['tecnibot_' + ph].usd, vence: f.tecnibot_hasta };
      if (item === 'ia') return { codigos: ['ia_' + ph], usd: CATALOGO['ia_' + ph].usd, vence: f.ia_hasta };
      if (item === 'actualizaciones') return { codigos: ['actualizaciones_a'], usd: CATALOGO.actualizaciones_a.usd, vence: f.actualizaciones_hasta, periodo: 'a' };
    }
    throw new Error('Ese producto no se puede renovar automáticamente acá.');
  }

  async function crearSuscripcion({ destino, sujeto, item, periodo, email }) {
    if (!RECURRENTES.includes(item)) throw Object.assign(new Error('Ese producto no tiene renovación automática.'), { publico: true });
    const info = infoRecurrente(item, periodo, destino, sujeto);
    const per = info.periodo || (periodo === 'a' ? 'a' : 'm');
    const base = central.urlPrincipal();
    if (!base || !tokenMP()) throw Object.assign(new Error('El cobro online todavía no está configurado.'), { publico: true });
    const yaActiva = masterDb.prepare(`SELECT id FROM ventas_suscripciones WHERE destino=? AND COALESCE(subdominio, negocio_id)=? AND item=? AND estado IN ('activa','pausada')`).get(destino, sujeto, item);
    if (yaActiva) throw Object.assign(new Error('Ese producto ya tiene la renovación automática activa.'), { publico: true });
    // Pedidos anteriores de ese mismo producto que nunca se autorizaron: se descartan (queda uno solo).
    for (const v of masterDb.prepare(`SELECT * FROM ventas_suscripciones WHERE destino=? AND COALESCE(subdominio, negocio_id)=? AND item=? AND estado='pendiente'`).all(destino, sujeto, item)) {
      try { if (v.mp_preapproval_id) await mp('PUT', `/preapproval/${encodeURIComponent(v.mp_preapproval_id)}`, { status: 'cancelled' }); } catch (e) { /* si Mercado Pago no responde, igual se descarta acá */ }
      masterDb.prepare("UPDATE ventas_suscripciones SET estado='cancelada' WHERE id=?").run(v.id);
    }
    const monto = precioArs(info.usd);
    const id = 's_' + crypto.randomBytes(9).toString('hex');
    masterDb.prepare(`INSERT INTO ventas_suscripciones (id, destino, subdominio, negocio_id, item, periodo, monto_ars, email) VALUES (?,?,?,?,?,?,?,?)`)
      .run(id, destino, destino === 'hosting' ? sujeto : null, destino === 'local' ? sujeto : null, item, per, monto, email || '');
    // Primer débito: el día que vence lo ya pagado (si ya venció, en unos minutos).
    const hoy = fechaHoy(), vence = info.vence ? String(info.vence).slice(0, 10) : null;
    const inicio = vence && vence > hoy ? new Date(vence + 'T12:00:00Z') : new Date(Date.now() + 10 * 60 * 1000);
    const labels = { hosting: 'Hosting', pack: 'Pack Full IA', tecnibot: 'Bot Técnico IA', ia: 'IA por Voz', actualizaciones: 'Actualizaciones' };
    const pre = await mp('POST', '/preapproval', {
      reason: `SysTech — ${labels[item]} (${per === 'a' ? 'anual' : 'mensual'})`,
      external_reference: 'sus:' + id,
      payer_email: emailValido(email) ? email : undefined,
      back_url: `${base}/pago.html?sus=${id}`,
      auto_recurring: { frequency: per === 'a' ? 12 : 1, frequency_type: 'months', transaction_amount: monto, currency_id: 'ARS', start_date: inicio.toISOString() },
      status: 'pending',
    });
    masterDb.prepare('UPDATE ventas_suscripciones SET mp_preapproval_id=? WHERE id=?').run(pre.id || null, id);
    return { id, init_point: pre.init_point, monto, primer_debito: inicio.toISOString().slice(0, 10) };
  }

  async function actualizarEstadoSuscripcion(preapprovalId) {
    const pre = await mp('GET', `/preapproval/${encodeURIComponent(preapprovalId)}`);
    const ref = String(pre.external_reference || '');
    if (!ref.startsWith('sus:')) return;
    const estado = { authorized: 'activa', paused: 'pausada', cancelled: 'cancelada', pending: 'pendiente' }[pre.status] || null;
    if (estado) masterDb.prepare('UPDATE ventas_suscripciones SET estado=?, mp_preapproval_id=COALESCE(mp_preapproval_id, ?) WHERE id=?').run(estado, String(pre.id), ref.slice(4));
  }

  async function procesarPagoSuscripcion(susId, pago) {
    const s = masterDb.prepare('SELECT * FROM ventas_suscripciones WHERE id=?').get(susId);
    if (!s || pago.status !== 'approved') return { estado: pago.status };
    if (String(pago.currency_id) !== 'ARS' || Math.abs(Number(pago.transaction_amount) - Number(s.monto_ars)) > 0.5) {
      console.error('[Ventas] Débito con monto distinto a la suscripción', s.id, pago.transaction_amount);
      return { error: 'monto' };
    }
    const nuevo = masterDb.prepare('INSERT OR IGNORE INTO ventas_pagos (mp_payment_id, referencia, monto) VALUES (?,?,?)').run(String(pago.id), 'sus:' + s.id, Number(pago.transaction_amount));
    if (!nuevo.changes) return { repetido: true };
    const info = infoRecurrente(s.item, s.periodo, s.destino, s.destino === 'hosting' ? s.subdominio : s.negocio_id);
    const items = info.codigos.map(c => ({ codigo: c, cantidad: /^sucursal_/.test(c) ? info.extras : 1 }))
      .filter(i => !/^sucursal_/.test(i.codigo));   // las sucursales ya están en el límite: solo se cobran
    if (s.destino === 'hosting') aplicarHosting(s.subdominio, items);
    else aplicarLocal(s.negocio_id, items);
    masterDb.prepare("UPDATE ventas_suscripciones SET estado='activa', ultimo_cobro=CURRENT_TIMESTAMP, cobros=cobros+1 WHERE id=?").run(s.id);
    return { renovada: true };
  }

  async function cancelarSuscripcion(s) {
    if (s.mp_preapproval_id) await mp('PUT', `/preapproval/${encodeURIComponent(s.mp_preapproval_id)}`, { status: 'cancelled' });
    masterDb.prepare("UPDATE ventas_suscripciones SET estado='cancelada' WHERE id=?").run(s.id);
  }

  // ─── Estado público de una orden (página de resultado) ───
  function vistaOrden(o) {
    const r = o.resultado ? JSON.parse(o.resultado) : null;
    const items = JSON.parse(o.items);
    const recurrentes = [];
    if (o.estado === 'entregada' && r) {
      const tipoItem = c => /^hosting_/.test(c) ? 'hosting' : /^pack_/.test(c) ? 'pack' : /^tecnibot_/.test(c) ? 'tecnibot' : /^ia_/.test(c) ? 'ia'
        : (c === 'actualizaciones_a' || (r.tipo === 'local' && /^lic_/.test(c))) ? 'actualizaciones' : null;
      for (const i of items) {
        const item = tipoItem(i.codigo);
        if (!item || recurrentes.find(x => x.item === item)) continue;
        const periodo = item === 'actualizaciones' || i.codigo.endsWith('_a') ? 'a' : 'm';
        recurrentes.push({ item, periodo, label: item === 'actualizaciones' ? CATALOGO.actualizaciones_a.label : CATALOGO[i.codigo].label });
      }
      const sujeto = r.tipo === 'hosting' ? r.subdominio : r.negocio_id;
      recurrentes.forEach(x => {
        const s = masterDb.prepare(`SELECT estado FROM ventas_suscripciones WHERE destino=? AND COALESCE(subdominio, negocio_id)=? AND item=? ORDER BY creado DESC LIMIT 1`).get(r.tipo, sujeto, x.item);
        x.debito = s ? s.estado : null;
      });
    }
    return { id: o.id, estado: o.estado, mp_estado: o.mp_estado, tipo: o.tipo, destino: o.destino, items: items.map(i => i.label), total_ars: o.total_ars,
      resultado: r, recurrentes, error: o.estado === 'error' ? 'Hubo un problema al activar tu compra. Ya quedó registrado y SysTech lo resuelve; no hace falta pagar de nuevo.' : null };
  }

  // ════════════════════════ RUTAS DEL SERVIDOR CENTRAL ════════════════════════
  const soloCentral = (req, res, next) => MODO_DISTRIBUIDOR ? next() : res.status(404).json({ error: 'La venta online funciona en el servidor de SysTech.' });
  const porIp = new Map();
  const limite = (req, res, next) => {   // 20 órdenes por hora por IP
    const k = req.ip, t = Date.now(), lista = (porIp.get(k) || []).filter(x => t - x < 3600000);
    if (lista.length >= 20) return res.status(429).json({ error: 'Demasiados intentos. Probá de nuevo en un rato.' });
    lista.push(t); porIp.set(k, lista); next();
  };
  const errorPublico = (res, e) => {
    if (e.publico || e instanceof RangeError) return res.status(400).json({ error: e.message });
    if (e.status && e.data) { console.error('[Ventas] Mercado Pago:', e.status, JSON.stringify(e.data).slice(0, 400)); return res.status(502).json({ error: 'Mercado Pago no respondió bien. Probá de nuevo en unos minutos.' }); }
    return res.status(400).json({ error: e.message || 'No se pudo completar.' });
  };

  app.get('/api/ventas/catalogo', soloCentral, (req, res) => {
    const items = {};
    for (const [k, v] of Object.entries(CATALOGO)) items[k] = { usd: v.usd, ars: precioArs(v.usd), label: v.label };
    res.json({ cotizacion: cotizacion(), items, sucursales_incluidas: SUCURSALES_INCLUIDAS, max_sucursales_extra: MAX_SUCURSALES_EXTRA,
      dominio: central.dominioBase() || null, activo: !!(tokenMP() && central.urlPrincipal()),
      contacto_email: process.env.CONTACTO_EMAIL || null, contacto_whatsapp: String(process.env.CONTACTO_WHATSAPP || '').replace(/\D/g, '') || null });
  });

  app.get('/api/ventas/subdominio/:sub', soloCentral, (req, res) => {
    const sub = String(req.params.sub || '').toLowerCase();
    if (!/^[a-z0-9-]{3,30}$/.test(sub) || /^-|-$/.test(sub)) return res.json({ libre: false, motivo: 'De 3 a 30 letras minúsculas, números o guiones (sin empezar ni terminar con guion).' });
    if (SUBDOMINIOS_RESERVADOS.has(sub)) return res.json({ libre: false, motivo: 'Ese nombre está reservado. Probá con otro.' });
    if (masterDb.prepare('SELECT 1 FROM talleres WHERE subdominio=?').get(sub)) return res.json({ libre: false, motivo: 'Ese nombre ya está en uso. Probá con otro.' });
    res.json({ libre: true, url: central.urlNegocio(sub) });
  });

  // Cliente nuevo (página de compra pública)
  app.post('/api/ventas/orden', soloCentral, limite, async (req, res) => {
    try {
      const b = req.body || {};
      if (b.acepto !== true) return res.status(400).json({ error: 'Para seguir, aceptá las condiciones de compra.' });
      const nombre = limpiar(b.nombre, 80), email = limpiar(b.email, 120).toLowerCase(), telefono = limpiar(b.telefono, 30);
      if (nombre.length < 2) return res.status(400).json({ error: 'Escribí el nombre de tu negocio.' });
      if (!emailValido(email)) return res.status(400).json({ error: 'Revisá el email: ahí te mandamos los datos de tu compra.' });
      let subdominio = null;
      if (b.modalidad === 'hosting') {
        subdominio = String(b.subdominio || '').toLowerCase();
        if (!/^[a-z0-9-]{3,30}$/.test(subdominio) || /^-|-$/.test(subdominio) || SUBDOMINIOS_RESERVADOS.has(subdominio)) return res.status(400).json({ error: 'Elegí otra dirección para tu sistema (de 3 a 30 letras minúsculas, números o guiones).' });
        if (masterDb.prepare('SELECT 1 FROM talleres WHERE subdominio=?').get(subdominio)) return res.status(400).json({ error: 'Esa dirección ya está en uso. Probá con otra.' });
      }
      const armado = armarItems(b, { tipo: 'nuevo', destino: b.modalidad });
      const { id, token } = nuevaOrden({ tipo: 'nuevo', destino: b.modalidad, nombre, email, telefono, subdominio, armado });
      const url = await crearPreferencia(masterDb.prepare('SELECT * FROM ventas_ordenes WHERE id=?').get(id));
      res.json({ id, token, init_point: url, total_ars: armado.totalArs });
    } catch (e) { errorPublico(res, e); }
  });

  // Instalación local que compra (llamada servidor a servidor desde su sistema, con su código de licencia)
  app.post('/api/ventas/orden-local', soloCentral, limite, async (req, res) => {
    try {
      const datos = licencia.verificarCodigo(req.body && req.body.codigo);
      if (!datos || !datos.negocioId) return res.status(401).json({ error: 'Licencia no válida.' });
      const email = limpiar(req.body.email, 120).toLowerCase();
      const armado = armarItems(req.body.pedido, { tipo: 'existente', destino: 'local', local: datos });
      const previa = { taller: datos.taller, tienda: datos.tienda, limiteSucursales: datos.limiteSucursales, tecnibot: datos.tecnibot, tecnibotHasta: datos.tecnibotHasta,
        ia: datos.ia, iaHasta: datos.iaHasta, actualizacionesHasta: datos.actualizacionesHasta, vence: datos.vence };
      const { id, token } = nuevaOrden({ tipo: 'existente', destino: 'local', nombre: limpiar(req.body.nombre, 80), email: emailValido(email) ? email : '', negocio_id: datos.negocioId, armado, licencia_previa: previa });
      const url = await crearPreferencia(masterDb.prepare('SELECT * FROM ventas_ordenes WHERE id=?').get(id));
      res.json({ id, token, init_point: url, total_ars: armado.totalArs });
    } catch (e) { errorPublico(res, e); }
  });

  const ultimaConciliacion = new Map();
  app.get('/api/ventas/orden/:id', soloCentral, async (req, res) => {
    let o = masterDb.prepare('SELECT * FROM ventas_ordenes WHERE id=?').get(String(req.params.id));
    if (!o || !tokenIgual(req.query.t, o.token)) {
      return res.status(404).json({ error: 'No encontramos esa compra.' });
    }
    // Si sigue pendiente, se le pregunta a Mercado Pago (como mucho cada 10 segundos por orden).
    if (o.estado === 'pendiente' && Date.now() - (ultimaConciliacion.get(o.id) || 0) > 10000) {
      ultimaConciliacion.set(o.id, Date.now());
      if (ultimaConciliacion.size > 5000) ultimaConciliacion.clear();
      try { await conciliarOrden(o.id); } catch (e) { /* sin conexión con MP: se reintenta en la próxima consulta */ }
      o = masterDb.prepare('SELECT * FROM ventas_ordenes WHERE id=?').get(o.id);
    }
    res.json(vistaOrden(o));
  });

  // Activar el débito automático desde la página de resultado (con el token de la orden)
  app.post('/api/ventas/orden/:id/debito', soloCentral, limite, async (req, res) => {
    try {
      const o = masterDb.prepare('SELECT * FROM ventas_ordenes WHERE id=?').get(String(req.params.id));
      if (!o || !tokenIgual((req.body || {}).t, o.token) || o.estado !== 'entregada') return res.status(404).json({ error: 'No encontramos esa compra.' });
      const r = JSON.parse(o.resultado);
      const item = String(req.body.item || '');
      const rec = vistaOrden(o).recurrentes.find(x => x.item === item);
      if (!rec) return res.status(400).json({ error: 'Ese producto no está en esta compra.' });
      const s = await crearSuscripcion({ destino: r.tipo, sujeto: r.tipo === 'hosting' ? r.subdominio : r.negocio_id, item, periodo: rec.periodo, email: o.email });
      res.json(s);
    } catch (e) { errorPublico(res, e); }
  });

  // Aviso de Mercado Pago (pagos y suscripciones). Siempre se re-consulta a la API.
  app.post('/api/ventas/webhook', async (req, res) => {
    res.status(200).json({ ok: true });   // responder rápido: Mercado Pago reintenta si tarda
    if (!MODO_DISTRIBUIDOR || !tokenMP()) return;
    const b = req.body || {}, q = req.query || {};
    const tipo = String(b.type || q.type || b.topic || q.topic || '');
    const id = String((b.data && b.data.id) || q['data.id'] || b.id || q.id || '');
    if (!id || !/^[\w-]{1,64}$/.test(id)) return;
    try {
      if (tipo === 'payment') await procesarPago(id);
      else if (tipo === 'subscription_preapproval' || tipo === 'preapproval') await actualizarEstadoSuscripcion(id);
      else if (tipo === 'subscription_authorized_payment' || tipo === 'authorized_payment') {
        const ap = await mp('GET', `/authorized_payments/${encodeURIComponent(id)}`);
        const pagoId = ap && ap.payment && ap.payment.id;
        if (pagoId) {
          const pago = await mp('GET', `/v1/payments/${encodeURIComponent(pagoId)}`);
          const ref = String(pago.external_reference || '');
          let susId = ref.startsWith('sus:') ? ref.slice(4) : null;
          if (!susId && ap.preapproval_id) { const s = masterDb.prepare('SELECT id FROM ventas_suscripciones WHERE mp_preapproval_id=?').get(String(ap.preapproval_id)); susId = s && s.id; }
          if (susId) await procesarPagoSuscripcion(susId, pago);
        }
      }
    } catch (e) { console.error('[Ventas] Webhook', tipo, id, e.message, e.data ? JSON.stringify(e.data).slice(0, 300) : ''); }
  });

  // La instalación local pregunta si hay un código más nuevo para su negocio (compras y renovaciones).
  app.post('/api/ventas/licencia', soloCentral, (req, res) => {
    const datos = licencia.verificarCodigo(req.body && req.body.codigo);
    if (!datos || !datos.negocioId) return res.status(401).json({ error: 'Licencia no válida.' });
    const f = masterDb.prepare('SELECT ultimo_codigo, emitido FROM ventas_clientes_locales WHERE negocio_id=?').get(datos.negocioId);
    const subs = masterDb.prepare(`SELECT id, item, periodo, monto_ars, estado, ultimo_cobro FROM ventas_suscripciones WHERE negocio_id=? AND estado != 'cancelada' ORDER BY creado DESC`).all(datos.negocioId);
    const imei = masterDb.prepare('SELECT saldo FROM imei_clientes WHERE negocio_id=?').get(datos.negocioId);
    res.json({ codigo: f && f.ultimo_codigo && (!datos.emitido || f.emitido > datos.emitido) ? f.ultimo_codigo : null, suscripciones: subs, imei_saldo: imei && imei.saldo !== null ? imei.saldo : null });
  });
  app.post('/api/ventas/debito-local', soloCentral, limite, async (req, res) => {
    try {
      const datos = licencia.verificarCodigo(req.body && req.body.codigo);
      if (!datos || !datos.negocioId) return res.status(401).json({ error: 'Licencia no válida.' });
      if (req.body.cancelar) {
        const s = masterDb.prepare("SELECT * FROM ventas_suscripciones WHERE id=? AND negocio_id=? AND estado != 'cancelada'").get(String(req.body.cancelar), datos.negocioId);
        if (!s) return res.status(404).json({ error: 'No encontramos esa renovación automática.' });
        await cancelarSuscripcion(s);
        return res.json({ ok: true });
      }
      const s = await crearSuscripcion({ destino: 'local', sujeto: datos.negocioId, item: String(req.body.item || ''), periodo: req.body.periodo === 'a' ? 'a' : 'm', email: limpiar(req.body.email, 120) });
      res.json(s);
    } catch (e) { errorPublico(res, e); }
  });

  // ─── Panel del distribuidor ───
  app.get('/api/distribuidor/ventas', distribuidorAuth, (req, res) => {
    let clavePrivada = false;
    try { clavePrivada = require('fs').existsSync(process.env.LICENCIA_PRIVADA_ARCHIVO || require('path').join(__dirname, 'licencia-privada.pem')); } catch (e) {}
    const token = tokenMP();
    res.json({
      config: { cotizacion: cotizacion(), mp: token ? (/^TEST-/.test(token) ? 'prueba' : 'produccion') : 'falta', url_principal: central.urlPrincipal() || null,
        dominio: central.dominioBase() || null, clave_privada: clavePrivada, mail: !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) },
      ordenes: masterDb.prepare('SELECT id, creado, estado, tipo, destino, nombre, email, subdominio, negocio_id, items, total_usd, total_ars, cotizacion, mp_payment_id, mp_estado, error, entregada_en FROM ventas_ordenes ORDER BY creado DESC LIMIT 300').all()
        .map(o => ({ ...o, items: JSON.parse(o.items).map(i => i.label) })),
      suscripciones: masterDb.prepare('SELECT * FROM ventas_suscripciones ORDER BY creado DESC LIMIT 300').all(),
      catalogo: Object.fromEntries(Object.entries(CATALOGO).map(([k, v]) => [k, { usd: v.usd, ars: precioArs(v.usd), label: v.label }])),
    });
  });
  app.put('/api/distribuidor/ventas/config', distribuidorAuth, (req, res) => {
    const n = Number(req.body && req.body.cotizacion);
    if (!(n >= 100 && n <= 1000000)) return res.status(400).json({ error: 'La cotización tiene que ser un número entre 100 y 1.000.000.' });
    cfgSet('cotizacion', Math.round(n * 100) / 100);
    res.json({ ok: true, cotizacion: cotizacion() });
  });
  app.post('/api/distribuidor/ventas/orden/:id/verificar', distribuidorAuth, async (req, res) => {
    try {
      const o = masterDb.prepare('SELECT * FROM ventas_ordenes WHERE id=?').get(String(req.params.id));
      if (!o) return res.status(404).json({ error: 'No existe esa orden.' });
      if (o.estado === 'error' && o.mp_payment_id) {
        const pago = await mp('GET', `/v1/payments/${encodeURIComponent(o.mp_payment_id)}`);
        if (pago.status === 'approved' && String(pago.currency_id) === 'ARS' && Math.abs(Number(pago.transaction_amount) - Number(o.total_ars)) <= 0.5) await entregarOrden(o.id, String(pago.id));
      } else await conciliarOrden(o.id);
      const n = masterDb.prepare('SELECT estado, mp_estado, error FROM ventas_ordenes WHERE id=?').get(o.id);
      res.json(n);
    } catch (e) { errorPublico(res, e); }
  });

  // ════════════════════════ RUTAS DENTRO DEL SISTEMA DEL CLIENTE ════════════════════════
  // Mismas rutas para hosting (el negocio está en este servidor) e instalación local (se pasa por el central).
  const esHosting = req => MODO_DISTRIBUIDOR && req.tenant && req.tenant.subdominio !== 'default';
  async function alCentral(ruta, cuerpo) {
    const url = central.urlCentral();
    if (!url) throw Object.assign(new Error('Para comprar desde acá el sistema necesita la dirección del servidor de SysTech. Contactá a SysTech.'), { publico: true });
    const r = await fetchFn(url + ruta, { method: cuerpo ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(20000), ...(cuerpo ? { body: JSON.stringify(cuerpo) } : {}) });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw Object.assign(new Error(data.error || 'El servidor de SysTech no respondió. Revisá la conexión a internet.'), { publico: true });
    return data;
  }
  const codigoLocal = () => { try { const l = licencia.leerLicenciaActual(); return l && l.codigo ? l.codigo : ''; } catch (e) { return ''; } };

  app.get('/api/compras/estado', authMiddleware, adminOnly, async (req, res) => {
    try {
      const pl = planes.queIncluye(req, MODO_DISTRIBUIDOR);
      if (esHosting(req)) {
        const t = masterDb.prepare('SELECT * FROM talleres WHERE subdominio=?').get(req.tenant.subdominio);
        const items = {}; for (const [k, v] of Object.entries(CATALOGO)) items[k] = { usd: v.usd, ars: precioArs(v.usd), label: v.label };
        const subs = masterDb.prepare(`SELECT id, item, periodo, monto_ars, estado, ultimo_cobro FROM ventas_suscripciones WHERE destino='hosting' AND subdominio=? AND estado != 'cancelada' ORDER BY creado DESC`).all(t.subdominio);
        return res.json({ disponible: !!(tokenMP() && central.urlPrincipal()), modo: 'hosting', plan: pl, vence: t.fecha_vencimiento, tecnibot_vence: t.tecnibot_vence, ia_vence: t.ia_vence,
          imei_saldo: Number(t.imei_saldo) || 0, limite_sucursales: t.limite_sucursales, items, suscripciones: subs, email: t.email_contacto || '' });
      }
      if (MODO_DISTRIBUIDOR) return res.json({ disponible: false, modo: 'central', motivo: 'Este es el sistema principal de SysTech: las compras se hacen desde la página de compra.' });
      const codigo = codigoLocal();
      if (!codigo) return res.json({ disponible: false, modo: 'local', motivo: 'Este sistema todavía no tiene un código de activación.' });
      const [cat, est] = await Promise.all([alCentral('/api/ventas/catalogo'), alCentral('/api/ventas/licencia', { codigo })]);
      res.json({ disponible: !!cat.activo, modo: 'local', plan: pl, items: cat.items, suscripciones: est.suscripciones || [], imei_saldo: est.imei_saldo, hay_codigo_nuevo: !!est.codigo });
    } catch (e) {
      res.json({ disponible: false, modo: esHosting(req) ? 'hosting' : 'local', motivo: e.publico ? e.message : 'No se pudo conectar con SysTech. Revisá la conexión a internet.' });
    }
  });

  app.post('/api/compras/orden', authMiddleware, adminOnly, async (req, res) => {
    try {
      const pedido = (req.body && req.body.pedido) || {};
      if (esHosting(req)) {
        const t = masterDb.prepare('SELECT * FROM talleres WHERE subdominio=?').get(req.tenant.subdominio);
        const armado = armarItems(pedido, { tipo: 'existente', destino: 'hosting', taller: t });
        const { id, token } = nuevaOrden({ tipo: 'existente', destino: 'hosting', nombre: t.nombre, email: t.email_contacto, telefono: t.telefono_contacto, subdominio: t.subdominio, armado });
        const url = await crearPreferencia(masterDb.prepare('SELECT * FROM ventas_ordenes WHERE id=?').get(id));
        return res.json({ id, token, init_point: url, total_ars: armado.totalArs });
      }
      if (MODO_DISTRIBUIDOR) return res.status(400).json({ error: 'Las compras se hacen desde la página de compra.' });
      const codigo = codigoLocal();
      if (!codigo) return res.status(400).json({ error: 'Este sistema todavía no tiene un código de activación.' });
      const cfgEmail = (() => { try { return req.db.prepare("SELECT valor FROM config WHERE clave='empresa_email'").get()?.valor || ''; } catch (e) { return ''; } })();
      const nombre = (() => { try { return req.db.prepare("SELECT valor FROM config WHERE clave='empresa_nombre'").get()?.valor || ''; } catch (e) { return ''; } })();
      res.json(await alCentral('/api/ventas/orden-local', { codigo, pedido, email: req.body.email || cfgEmail, nombre }));
    } catch (e) { errorPublico(res, e); }
  });

  app.post('/api/compras/debito', authMiddleware, adminOnly, async (req, res) => {
    try {
      const b = req.body || {};
      if (esHosting(req)) {
        const t = masterDb.prepare('SELECT * FROM talleres WHERE subdominio=?').get(req.tenant.subdominio);
        if (b.cancelar) {
          const s = masterDb.prepare("SELECT * FROM ventas_suscripciones WHERE id=? AND destino='hosting' AND subdominio=? AND estado != 'cancelada'").get(String(b.cancelar), t.subdominio);
          if (!s) return res.status(404).json({ error: 'No encontramos esa renovación automática.' });
          await cancelarSuscripcion(s);
          return res.json({ ok: true });
        }
        return res.json(await crearSuscripcion({ destino: 'hosting', sujeto: t.subdominio, item: String(b.item || ''), periodo: b.periodo === 'a' ? 'a' : 'm', email: b.email || t.email_contacto }));
      }
      if (MODO_DISTRIBUIDOR) return res.status(400).json({ error: 'No disponible acá.' });
      const codigo = codigoLocal();
      if (!codigo) return res.status(400).json({ error: 'Este sistema todavía no tiene un código de activación.' });
      res.json(await alCentral('/api/ventas/debito-local', { codigo, item: b.item, periodo: b.periodo, email: b.email, cancelar: b.cancelar }));
    } catch (e) { errorPublico(res, e); }
  });

  // Instalación local: trae y aplica el código más nuevo de su negocio (también corre solo cada 6 horas).
  async function sincronizarLicencia() {
    if (MODO_DISTRIBUIDOR) return { cambiado: false };
    const codigo = codigoLocal();
    if (!codigo || !central.urlCentral()) return { cambiado: false };
    const r = await alCentral('/api/ventas/licencia', { codigo });
    if (r.codigo && r.codigo !== codigo) {
      licencia.activar(r.codigo);
      console.log('🔑 Licencia actualizada automáticamente con la última compra.');
      return { cambiado: true };
    }
    return { cambiado: false };
  }
  app.post('/api/compras/sincronizar', authMiddleware, adminOnly, async (req, res) => {
    try { res.json(await sincronizarLicencia()); }
    catch (e) { res.status(400).json({ error: e.publico ? e.message : 'No se pudo conectar con SysTech. Revisá la conexión a internet.' }); }
  });
  if (!MODO_DISTRIBUIDOR && !process.env.SYSTECH_SIN_SINCRONIZAR) {
    setTimeout(() => sincronizarLicencia().catch(() => {}), 30 * 1000).unref();
    setInterval(() => sincronizarLicencia().catch(() => {}), 6 * 60 * 60 * 1000).unref();
  }

  return { CATALOGO, armarItems, sumarMeses, sincronizarLicencia, entregarOrden, cotizacion };
}

module.exports = { registrar, CATALOGO, sumarMeses, mesesRestantes };
