// ─── SISTEMA MULTI-TENANT — GESTIÓN DE TALLERES ──────────────────────────────
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const seguridad = require('./seguridad');

// El panel de distribuidor (alta de clientes, licencias, desbloqueos) SOLO existe en TU copia.
// Se activa con la variable SYSTECH_DISTRIBUIDOR=1 o con un archivo vacío "modo-distribuidor.flag"
// junto a server.js. La copia que se le entrega al cliente no lo trae: ni la pantalla,
// ni la API, ni el usuario.
const MODO_DISTRIBUIDOR = process.env.SYSTECH_DISTRIBUIDOR === '1' || fs.existsSync(path.join(__dirname, 'modo-distribuidor.flag'));

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const MASTER_DB_PATH = path.join(DATA_DIR, 'master.db');
const masterDb = new Database(MASTER_DB_PATH);

masterDb.exec(`
  CREATE TABLE IF NOT EXISTS talleres (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subdominio TEXT UNIQUE NOT NULL,
    nombre TEXT NOT NULL,
    plan TEXT DEFAULT 'local',
    email_contacto TEXT,
    telefono_contacto TEXT,
    activo INTEGER DEFAULT 1,
    fecha_alta DATETIME DEFAULT CURRENT_TIMESTAMP,
    fecha_vencimiento DATETIME,
    notas TEXT
  );

  CREATE TABLE IF NOT EXISTS distribuidor_usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    nombre TEXT,
    activo INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS distribuidor_sesiones (
    token TEXT PRIMARY KEY,
    usuario_id INTEGER NOT NULL,
    usuario TEXT,
    expires DATETIME NOT NULL
  );
`);

// Migración: addon pago de Tecnibot por taller (para instalaciones ya existentes)
try { masterDb.exec(`ALTER TABLE talleres ADD COLUMN tecnibot_habilitado INTEGER DEFAULT 0`); } catch(e) {}
// Addon pago: chequeo de IMEI robado (suscripción mensual, la clave del proveedor es de SysTech)
try { masterDb.exec(`ALTER TABLE talleres ADD COLUMN imei_habilitado INTEGER DEFAULT 0`); } catch(e) {}
// Planes (qué incluye cada negocio). Los negocios que ya existían conservan todo lo que tenían (taller + tienda, sin tope práctico);
// los nuevos arrancan con 2 sucursales incluidas.
// Historial de cambios hechos desde el panel del distribuidor (quién, cuándo, qué cambió)
masterDb.exec(`
  CREATE TABLE IF NOT EXISTS distribuidor_historial (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    usuario TEXT,
    subdominio TEXT NOT NULL,
    accion TEXT NOT NULL,
    detalle TEXT
  );
`);
try { masterDb.exec(`ALTER TABLE talleres ADD COLUMN modulo_taller INTEGER DEFAULT 1`); } catch(e) {}
try { masterDb.exec(`ALTER TABLE talleres ADD COLUMN modulo_tienda INTEGER DEFAULT 1`); } catch(e) {}
try { masterDb.exec(`ALTER TABLE talleres ADD COLUMN limite_sucursales INTEGER DEFAULT 99`); } catch(e) {}
try { masterDb.exec(`ALTER TABLE talleres ADD COLUMN ia_habilitada INTEGER DEFAULT 0`); } catch(e) {}

// Crear el usuario distribuidor por defecto si no existe ninguno todavía
const distribuidorExiste = masterDb.prepare('SELECT id FROM distribuidor_usuarios LIMIT 1').get();
if (!distribuidorExiste && MODO_DISTRIBUIDOR) {
  // Clave aleatoria: no existe ninguna clave "de fábrica" que alguien pueda adivinar o leer en el código.
  const claveInicial = crypto.randomBytes(9).toString('base64url');
  masterDb.prepare('INSERT INTO distribuidor_usuarios (usuario,password,nombre) VALUES (?,?,?)')
    .run('distribuidor', seguridad.hashPassword(claveInicial), 'Administrador SysTech');
  try {
    fs.writeFileSync(path.join(DATA_DIR, 'DISTRIBUIDOR-CLAVE-INICIAL.txt'),
      `Usuario distribuidor: distribuidor\nClave inicial: ${claveInicial}\n\nCambiala apenas entres y borrá este archivo.\n`, { mode: 0o600 });
  } catch (e) {}
  console.log('🔑 Usuario distribuidor creado. La clave inicial quedó en data/DISTRIBUIDOR-CLAVE-INICIAL.txt (cambiala y borrá el archivo).');
} else if (distribuidorExiste && MODO_DISTRIBUIDOR) {
  // Instalaciones anteriores: si todavía tiene la clave de fábrica vieja, avisar fuerte
  const dist = masterDb.prepare("SELECT password FROM distribuidor_usuarios WHERE usuario='distribuidor'").get();
  if (dist && dist.password === seguridad.hashLegacy('systech2026')) {
    console.log('🚨 El usuario distribuidor TODAVÍA tiene la clave de fábrica. Cambiala ya desde el panel de distribuidor.');
  }
}

// Cache de conexiones abiertas (para no reabrir el archivo en cada request)
const connectionCache = new Map();

/**
 * Devuelve la ruta del archivo de base de datos de un taller específico
 */
function getDbPathForTenant(subdominio) {
  const safeName = subdominio.replace(/[^a-z0-9\-]/gi, '');
  return path.join(DATA_DIR, `taller_${safeName}.db`);
}

/**
 * Inicializa el esquema completo (tablas, migraciones y datos por defecto)
 * en la base de datos de UN taller específico. Se ejecuta automáticamente
 * la primera vez que se abre la conexión de cada taller (es seguro llamarla
 * múltiples veces — todo usa "IF NOT EXISTS" o verificación previa).
 */
function inicializarBaseTaller(db, subdominio) {
  // ─── BASE DE DATOS ────────────────────────────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      usuario TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      rol TEXT NOT NULL DEFAULT 'taller',
      activo INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS config (
      clave TEXT PRIMARY KEY,
      valor TEXT
    );
    CREATE TABLE IF NOT EXISTS productos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      codigo TEXT UNIQUE NOT NULL,
      nombre TEXT NOT NULL,
      categoria TEXT,
      stock INTEGER DEFAULT 0,
      stock_minimo INTEGER DEFAULT 1,
      precio_costo REAL DEFAULT 0,
      precio_venta REAL DEFAULT 0,
      visible INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS sucursales (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      direccion TEXT,
      telefono TEXT,
      es_deposito_central INTEGER DEFAULT 0,
      activa INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS stock_sucursal (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      producto_id INTEGER NOT NULL,
      sucursal_id INTEGER NOT NULL,
      cantidad INTEGER DEFAULT 0,
      UNIQUE(producto_id, sucursal_id),
      FOREIGN KEY (producto_id) REFERENCES productos(id),
      FOREIGN KEY (sucursal_id) REFERENCES sucursales(id)
    );
    CREATE TABLE IF NOT EXISTS movimientos_sucursal (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      producto_id INTEGER NOT NULL,
      sucursal_origen_id INTEGER,
      sucursal_destino_id INTEGER,
      cantidad INTEGER NOT NULL,
      tipo TEXT NOT NULL,
      usuario TEXT,
      notas TEXT,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (producto_id) REFERENCES productos(id)
    );
    CREATE TABLE IF NOT EXISTS clientes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      telefono TEXT,
      email TEXT,
      direccion TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS ordenes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      numero TEXT UNIQUE NOT NULL,
      cliente_id INTEGER,
      equipo TEXT NOT NULL,
      marca TEXT,
      modelo TEXT,
      serie TEXT,
      falla_reportada TEXT,
      diagnostico TEXT,
      estado TEXT DEFAULT 'recibido',
      prioridad TEXT DEFAULT 'normal',
      tecnico TEXT,
      fecha_ingreso DATETIME DEFAULT CURRENT_TIMESTAMP,
      fecha_entrega DATETIME,
      presupuesto REAL DEFAULT 0,
      total_repuestos REAL DEFAULT 0,
      mano_obra REAL DEFAULT 0,
      total REAL DEFAULT 0,
      notas TEXT,
      checklist TEXT,
      cobrado INTEGER DEFAULT 0,
      FOREIGN KEY (cliente_id) REFERENCES clientes(id)
    );
    CREATE TABLE IF NOT EXISTS orden_repuestos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      orden_id INTEGER NOT NULL,
      producto_id INTEGER NOT NULL,
      cantidad INTEGER NOT NULL,
      precio_unitario REAL NOT NULL,
      subtotal REAL NOT NULL,
      FOREIGN KEY (orden_id) REFERENCES ordenes(id),
      FOREIGN KEY (producto_id) REFERENCES productos(id)
    );
    CREATE TABLE IF NOT EXISTS movimientos_stock (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      producto_id INTEGER NOT NULL,
      tipo TEXT NOT NULL,
      cantidad INTEGER NOT NULL,
      motivo TEXT,
      orden_id INTEGER,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (producto_id) REFERENCES productos(id)
    );
    CREATE TABLE IF NOT EXISTS notificaciones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      orden_id INTEGER NOT NULL,
      medio TEXT NOT NULL,
      mensaje TEXT,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (orden_id) REFERENCES ordenes(id)
    );
    CREATE TABLE IF NOT EXISTS chat (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL,
      usuario_nombre TEXT NOT NULL,
      rol TEXT NOT NULL,
      mensaje TEXT NOT NULL,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS sesiones (
      token TEXT PRIMARY KEY,
      usuario_id INTEGER NOT NULL,
      rol TEXT NOT NULL,
      nombre TEXT NOT NULL,
      expires DATETIME NOT NULL
    );
  `);

  // Migraciones seguras
  [
    ['checklist', 'TEXT'],
    ['cobrado', 'INTEGER DEFAULT 0'],
    ['presupuesto_aprobado', 'INTEGER DEFAULT -1'],
    ['comentario_cliente', 'TEXT']
  ].forEach(([col, type]) => {
    try { db.exec(`ALTER TABLE ordenes ADD COLUMN ${col} ${type}`); } catch(e) {}
  });
  // Migración foto producto
  try { db.exec(`ALTER TABLE productos ADD COLUMN foto_url TEXT`); } catch(e) {}
  // Migración sucursal en comprobantes
  try { db.exec(`ALTER TABLE comprobantes ADD COLUMN sucursal_id INTEGER`); } catch(e) {}

  // ─── SUCURSALES: crear depósito central por defecto ────────────────────────
  const depositoExiste = db.prepare("SELECT id FROM sucursales WHERE es_deposito_central=1").get();
  if (!depositoExiste) {
    db.prepare("INSERT INTO sucursales (nombre,es_deposito_central,activa) VALUES ('Depósito Central',1,1)").run();
  }

  // ─── DATOS INICIALES ──────────────────────────────────────────────────────────
  try { db.exec(`ALTER TABLE usuarios ADD COLUMN debe_cambiar_password INTEGER DEFAULT 0`); } catch(e) {}
  // Permisos finos por usuario (JSON; vacío = los de su rol por defecto)
  try { db.exec(`ALTER TABLE usuarios ADD COLUMN permisos TEXT`); } catch(e) {}
  // Stock por sucursal: dónde se movió cada cosa, para poder auditar
  try { db.exec(`ALTER TABLE movimientos_stock ADD COLUMN sucursal_id INTEGER`); } catch(e) {}
  try { db.exec(`ALTER TABLE movimientos_stock ADD COLUMN usuario TEXT`); } catch(e) {}
  // Registro de auditoría: quién hizo qué, cuándo y desde dónde
  db.exec(`
    CREATE TABLE IF NOT EXISTS auditoria (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      usuario TEXT, rol TEXT, sucursal_id INTEGER,
      accion TEXT NOT NULL, entidad TEXT, entidad_id TEXT, detalle TEXT, ip TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_auditoria_fecha ON auditoria(fecha);
  `);
  const adminExiste = db.prepare("SELECT id FROM usuarios WHERE rol='admin'").get();
  if (!adminExiste) {
    // La clave de fábrica solo sirve para el primer ingreso: el sistema obliga a cambiarla.
    db.prepare("INSERT INTO usuarios (nombre,usuario,password,rol,debe_cambiar_password) VALUES (?,?,?,?,1)").run('Administrador','admin',seguridad.hashPassword('admin123'),'admin');
  }
  // Instalaciones anteriores que todavía usan admin123 (con el hash viejo): también deben cambiarla
  db.prepare("UPDATE usuarios SET debe_cambiar_password=1 WHERE password=?").run(seguridad.hashLegacy('admin123'));

  const configDefaults = {
    empresa_nombre: 'Mi Servicio Técnico',
    empresa_direccion: '',
    empresa_telefono: '',
    empresa_email: '',
    empresa_whatsapp: '',
    color_accent: '#4f8ef7',
    color_accent2: '#38d9a9',
    columnas_ocultas: '[]',
    tipos_equipo_activos: '["celular","notebook","pc","tablet","consola"]'
  };
  Object.entries(configDefaults).forEach(([k,v]) => {
    const existe = db.prepare("SELECT clave FROM config WHERE clave=?").get(k);
    if (!existe) db.prepare("INSERT INTO config (clave,valor) VALUES (?,?)").run(k,v);
  });



  // ─── HERRAMIENTAS DEL TALLER ──────────────────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS herramientas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      codigo TEXT UNIQUE NOT NULL,
      nombre TEXT NOT NULL,
      categoria TEXT DEFAULT 'General',
      marca TEXT,
      modelo TEXT,
      estado TEXT DEFAULT 'disponible',
      ubicacion TEXT DEFAULT 'Taller',
      cantidad INTEGER DEFAULT 1,
      cantidad_minima INTEGER DEFAULT 1,
      descripcion TEXT,
      numero_serie TEXT,
      fecha_compra TEXT,
      valor_compra REAL DEFAULT 0,
      foto_url TEXT,
      activa INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS herramienta_movimientos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      herramienta_id INTEGER NOT NULL,
      tipo TEXT NOT NULL,
      cantidad INTEGER DEFAULT 1,
      tecnico TEXT,
      motivo TEXT,
      orden_id INTEGER,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (herramienta_id) REFERENCES herramientas(id)
    );
  `);



  db.exec(`
    CREATE TABLE IF NOT EXISTS impresoras (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      tipo TEXT NOT NULL DEFAULT 'termica',
      ancho TEXT NOT NULL DEFAULT '80mm',
      ubicacion TEXT DEFAULT 'caja',
      predeterminada INTEGER DEFAULT 0,
      activa INTEGER DEFAULT 1
    );
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS automatizacion (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      evento TEXT UNIQUE NOT NULL,
      activo INTEGER DEFAULT 0,
      canal TEXT DEFAULT 'ambos',
      modo TEXT DEFAULT 'manual',
      plantilla_wa TEXT,
      plantilla_email TEXT,
      asunto_email TEXT
    );
    CREATE TABLE IF NOT EXISTS log_automatizacion (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      orden_id INTEGER,
      evento TEXT,
      canal TEXT,
      estado TEXT,
      detalle TEXT,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Insertar eventos por defecto si no existen
  const eventosDefecto = [
    { evento: 'recibido',    plantilla_wa: 'Hola {nombre}! 📱 Confirmamos que recibimos tu *{equipo} {marca}* en {empresa}. Tu N° de orden es: *{numero}*. Podés consultar el estado en: {link_cliente} 🔧',
      plantilla_email: '<h2>Recibimos tu equipo</h2><p>Hola <b>{nombre}</b>,</p><p>Confirmamos el ingreso de tu <b>{equipo} {marca} {modelo}</b> a nuestro servicio técnico.</p><p><b>N° de Orden:</b> {numero}<br><b>Falla reportada:</b> {falla}</p><p>Podés consultar el estado en cualquier momento: <a href="{link_cliente}">{link_cliente}</a></p><p>Gracias por confiar en nosotros!<br><b>{empresa}</b></p>',
      asunto_email: 'Recibimos tu equipo - Orden {numero}' },
    { evento: 'diagnostico', plantilla_wa: 'Hola {nombre}! 🔍 Estamos realizando el diagnóstico de tu *{equipo} {marca}*. En breve te informamos el resultado. N° orden: *{numero}*',
      plantilla_email: '<h2>En diagnóstico</h2><p>Hola <b>{nombre}</b>,</p><p>Estamos analizando tu <b>{equipo} {marca}</b>. Pronto tendremos el diagnóstico completo.</p><p><b>N° Orden:</b> {numero}</p><p>Seguí el estado en: <a href="{link_cliente}">{link_cliente}</a></p><p><b>{empresa}</b></p>',
      asunto_email: 'Diagnóstico en proceso - Orden {numero}' },
    { evento: 'presupuesto', plantilla_wa: 'Hola {nombre}! 💰 Tenemos el diagnóstico de tu *{equipo} {marca}*. El costo de la reparación es *${total}*. Podés aprobar o rechazar desde: {link_cliente} N° orden: *{numero}*',
      plantilla_email: '<h2>Presupuesto listo</h2><p>Hola <b>{nombre}</b>,</p><p>Ya tenemos el diagnóstico de tu <b>{equipo} {marca}</b>.</p><p><b>Costo de reparación: ${total}</b></p><p>Por favor aprobá o rechazá el presupuesto desde: <a href="{link_cliente}">{link_cliente}</a></p><p><b>N° Orden:</b> {numero}<br><b>{empresa}</b></p>',
      asunto_email: 'Presupuesto listo - Orden {numero} - ${total}' },
    { evento: 'reparando',   plantilla_wa: 'Hola {nombre}! 🔧 Buenas noticias: comenzamos la reparación de tu *{equipo} {marca}*. Te avisamos cuando esté listo. N° orden: *{numero}*',
      plantilla_email: '<h2>Reparación en curso</h2><p>Hola <b>{nombre}</b>,</p><p>Comenzamos la reparación de tu <b>{equipo} {marca}</b>. Te notificaremos cuando esté listo.</p><p><b>N° Orden:</b> {numero}</p><p><a href="{link_cliente}">{link_cliente}</a></p><p><b>{empresa}</b></p>',
      asunto_email: 'Reparación iniciada - Orden {numero}' },
    { evento: 'listo',       plantilla_wa: 'Hola {nombre}! ✅ Tu *{equipo} {marca}* está *LISTO PARA RETIRAR*! 🎉 Monto a abonar: *${total}*. Te esperamos en {empresa}. N° orden: *{numero}*',
      plantilla_email: '<h2>¡Tu equipo está listo! ✅</h2><p>Hola <b>{nombre}</b>,</p><p>Tu <b>{equipo} {marca}</b> está listo para retirar.</p><p><b>Monto a abonar: ${total}</b></p><p>Podés pasar cuando quieras por el local.<br><b>N° Orden:</b> {numero}</p><p><b>{empresa}</b><br>{direccion}<br>{telefono}</p>',
      asunto_email: '✅ Tu equipo está listo - Orden {numero}' }
  ];

  eventosDefecto.forEach(e => {
    const existe = db.prepare('SELECT id FROM automatizacion WHERE evento=?').get(e.evento);
    if (!existe) db.prepare('INSERT INTO automatizacion (evento,canal,modo,plantilla_wa,plantilla_email,asunto_email) VALUES (?,?,?,?,?,?)').run(e.evento,'ambos','manual',e.plantilla_wa,e.plantilla_email,e.asunto_email);
  });

  db.exec(`
    CREATE TABLE IF NOT EXISTS comprobantes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      numero TEXT UNIQUE NOT NULL,
      tipo TEXT NOT NULL DEFAULT 'presupuesto',
      letra TEXT DEFAULT 'X',
      punto_venta INTEGER DEFAULT 1,
      numero_comp INTEGER,
      orden_id INTEGER,
      cliente_id INTEGER,
      cliente_nombre TEXT,
      cliente_apellido TEXT,
      cliente_doc_tipo TEXT DEFAULT 'DNI',
      cliente_doc_numero TEXT,
      cliente_condicion_iva TEXT DEFAULT 'Consumidor Final',
      cliente_direccion TEXT,
      items TEXT NOT NULL DEFAULT '[]',
      subtotal REAL DEFAULT 0,
      descuento REAL DEFAULT 0,
      iva_porcentaje REAL DEFAULT 0,
      iva_monto REAL DEFAULT 0,
      total REAL DEFAULT 0,
      condicion_pago TEXT DEFAULT 'Contado',
      notas TEXT,
      estado TEXT DEFAULT 'borrador',
      cae TEXT,
      cae_vencimiento TEXT,
      sucursal_id INTEGER,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (orden_id) REFERENCES ordenes(id),
      FOREIGN KEY (cliente_id) REFERENCES clientes(id),
      FOREIGN KEY (sucursal_id) REFERENCES sucursales(id)
    );
    CREATE TABLE IF NOT EXISTS config_fiscal (
      clave TEXT PRIMARY KEY,
      valor TEXT
    );
  `);

  // Config fiscal por defecto
  const configFiscalDefecto = {
    razon_social: '',
    cuit: '',
    condicion_iva: 'Monotributo',
    punto_venta: '1',
    direccion_fiscal: '',
    inicio_actividades: '',
    ingresos_brutos: '',
    logo_factura: '',
    pie_factura: 'Gracias por su preferencia',
    proximo_numero_presupuesto: '1',
    proximo_numero_factura_a: '1',
    proximo_numero_factura_b: '1',
    proximo_numero_factura_c: '1',
    proximo_numero_nota_credito: '1',
    proximo_numero_nota_debito: '1',
    proximo_numero_nota_entrega: '1'
  };
  Object.entries(configFiscalDefecto).forEach(([k,v]) => {
    const existe = db.prepare('SELECT clave FROM config_fiscal WHERE clave=?').get(k);
    if (!existe) db.prepare('INSERT INTO config_fiscal (clave,valor) VALUES (?,?)').run(k,v);
  });



  db.exec(`
    CREATE TABLE IF NOT EXISTS garantia_config (
      clave TEXT PRIMARY KEY,
      valor TEXT
    );
    CREATE TABLE IF NOT EXISTS garantia_aceptaciones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      orden_id INTEGER NOT NULL,
      cliente_nombre TEXT,
      fecha_aceptacion DATETIME DEFAULT CURRENT_TIMESTAMP,
      ip_origen TEXT,
      firma_digital TEXT,
      texto_aceptado TEXT,
      FOREIGN KEY (orden_id) REFERENCES ordenes(id)
    );
  `);

  // Texto de garantía por defecto (basado en el documento del local, editable)
  const garantiaDefault = `1. El presente remito es el único elemento válido para el retiro del equipo.
  2. La garantía es sobre los repuestos reemplazados expresados en la factura.
  3. La garantía es válida únicamente acompañada de su correspondiente factura.
  4. Transcurridos los 90 días de la fecha de emisión del comprobante, el equipo que no sea retirado se considerará abandonado, sin derecho de reclamo alguno.
  5. Los equipos que ingresen presentando humedad, roturas significativas, golpes en el marco y/o carcasa, estén desarmados, seriales con falla de fabricación, posean previas reparaciones de placa y/o cambios reiterados de periféricos; no serán cubiertos por esta garantía.
  6. Los equipos que ingresen para revisión por posible garantía y se encuentren despegados, rotos, modificados o mojados (sulfatado y/o sello de humedad activo) no serán cubiertos por esta garantía.
  7. La empresa no se hará cargo por fallas presentadas en los periféricos de los equipos que ingresen apagados, sin dar imagen, bloqueados o iniciados de fábrica y no se les puedan probar funciones.
  8. La empresa no se hace responsable por daños que puedan surgir por la inadecuada manipulación del equipo (caídas, roturas o afecciones en el LCD causadas por presión).
  9. En caso de equipos que requieran una intervención en placa, dada la complejidad del trabajo y la reacción de la placa frente al mismo, la empresa no se hace responsable si luego del proceso el equipo deja de funcionar total o parcialmente.
  10. Si el equipo, luego de ser reparado en nuestro servicio, es manipulado por otro servicio técnico ajeno a la empresa, perderá la garantía vigente.
  11. No se aceptan reclamos por fallas no descritas en la garantía, posteriores a las 48 horas de entrega del equipo. De presentarse, serán evaluadas por nuestro personal técnico verificando las mismas.
  12. Respondiendo a la Ley de Defensa del Consumidor (Capítulo IV, artículo 11), las garantías a partir del momento de entrega serán de: baterías 90 días; periféricos (cámaras, flex, pin de carga, botones y afines) 60 días; reparación de placas 30 días.
  13. Los tiempos de respuesta por cobertura de garantía no están estipulados; los mismos serán dispuestos por la empresa según corresponda.
  14. La calidad de los repuestos que manejamos es la mejor del mercado, así como también comercializamos algunos repuestos originales Samsung dependiendo el modelo y la distribución de la marca. En el caso de Apple, no trabajamos con repuestos originales ya que Apple no los distribuye directamente.
  15. La garantía de este servicio es intransferible.
  16. El cliente declara haber leído y aceptado en su totalidad las condiciones de garantía aquí expuestas al momento de retirar su equipo.`;

  if (!db.prepare("SELECT clave FROM garantia_config WHERE clave='texto_garantia'").get()) {
    db.prepare("INSERT INTO garantia_config (clave,valor) VALUES ('texto_garantia',?)").run(garantiaDefault);
  }
  if (!db.prepare("SELECT clave FROM garantia_config WHERE clave='exigir_aceptacion'").get()) {
    db.prepare("INSERT INTO garantia_config (clave,valor) VALUES ('exigir_aceptacion','1')").run();
  }



  db.exec(`
    CREATE TABLE IF NOT EXISTS recursos_accesos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      categoria TEXT DEFAULT 'Esquemáticos',
      url TEXT,
      usuario TEXT,
      password_enc TEXT,
      codigo_promo TEXT,
      descuento TEXT,
      notas TEXT,
      activo INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS recursos_planos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      titulo TEXT NOT NULL,
      marca TEXT,
      modelo TEXT,
      categoria TEXT DEFAULT 'Celular',
      archivo_url TEXT,
      archivo_nombre TEXT,
      descripcion TEXT,
      precio_creditos INTEGER DEFAULT 0,
      activo INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS plano_compras (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL,
      plano_id INTEGER NOT NULL,
      precio_pagado INTEGER DEFAULT 0,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(usuario_id, plano_id),
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
      FOREIGN KEY (plano_id) REFERENCES recursos_planos(id)
    );
    CREATE TABLE IF NOT EXISTS creditos_movimientos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL,
      tipo TEXT NOT NULL,
      cantidad INTEGER NOT NULL,
      motivo TEXT,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    );
  `);
  // Migración: créditos y precio por esquema (para sistemas ya instalados)
  try { db.exec(`ALTER TABLE usuarios ADD COLUMN creditos INTEGER DEFAULT 0`); } catch(e) {}
  try { db.exec(`ALTER TABLE recursos_planos ADD COLUMN precio_creditos INTEGER DEFAULT 0`); } catch(e) {}

  // ─── TECNIBOT: asistente de IA con base de conocimiento propia ─────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS tecnibot_articulos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      categoria TEXT DEFAULT 'General',
      marca TEXT DEFAULT 'Multimarca',
      titulo TEXT NOT NULL,
      contenido TEXT NOT NULL,
      modelo_aplicable TEXT DEFAULT 'Todos',
      palabras_clave TEXT DEFAULT '',
      activo INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_tecnibot_activo ON tecnibot_articulos(activo);
    -- Config separada de la tabla "config" general: NUNCA se expone en GET /api/config
    -- (que devuelve todo a cualquier usuario logueado). Acá vive la API key, solo admin.
    CREATE TABLE IF NOT EXISTS tecnibot_config (
      clave TEXT PRIMARY KEY,
      valor TEXT
    );
    CREATE TABLE IF NOT EXISTS tecnibot_conversaciones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL,
      usuario_nombre TEXT,
      rol TEXT NOT NULL CHECK (rol IN ('usuario','asistente')),
      mensaje TEXT NOT NULL,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    -- Config del chequeo de IMEI robado/bloqueado (imeicheck.com) — separada de
    -- la config general por el mismo motivo que Tecnibot: nunca exponer la
    -- API key a través de GET /api/config.
    CREATE TABLE IF NOT EXISTS imeicheck_config (
      clave TEXT PRIMARY KEY,
      valor TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_tecnibot_conv_usuario ON tecnibot_conversaciones(usuario_id);
  `);
  const tecnibotDefaults = { tecnibot_api_key: '', tecnibot_activo: '1', tecnibot_modelo: 'claude-sonnet-4-6' };
  Object.entries(tecnibotDefaults).forEach(([k,v]) => {
    if (!db.prepare('SELECT clave FROM tecnibot_config WHERE clave=?').get(k))
      db.prepare('INSERT INTO tecnibot_config (clave,valor) VALUES (?,?)').run(k,v);
  });

  const imeicheckDefaults = { api_key: '', activo: '0', service_id: '5' };
  Object.entries(imeicheckDefaults).forEach(([k,v]) => {
    if (!db.prepare('SELECT clave FROM imeicheck_config WHERE clave=?').get(k))
      db.prepare('INSERT INTO imeicheck_config (clave,valor) VALUES (?,?)').run(k,v);
  });



  const arcaDefaults = {
    arca_produccion:   '0',
    arca_cuit:         '',
    arca_punto_venta:  '1',
    arca_cert_path:    '',
    arca_key_path:     '',
    arca_condicion:    'monotributo',
    arca_habilitado:   '0'
  };
  Object.entries(arcaDefaults).forEach(([k,v])=>{
    if(!db.prepare('SELECT clave FROM config_fiscal WHERE clave=?').get(k))
      db.prepare('INSERT INTO config_fiscal (clave,valor) VALUES (?,?)').run(k,v);
  });

  // Tabla de log ARCA
  db.exec(`CREATE TABLE IF NOT EXISTS arca_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    comprobante_id INTEGER,
    accion TEXT,
    request TEXT,
    response TEXT,
    resultado TEXT,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // ─── PAGOS MÚLTIPLES — un comprobante puede dividirse en varios medios ─────
  db.exec(`
    CREATE TABLE IF NOT EXISTS comprobante_pagos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      comprobante_id INTEGER NOT NULL,
      medio_pago TEXT NOT NULL,
      monto REAL NOT NULL DEFAULT 0,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (comprobante_id) REFERENCES comprobantes(id)
    );
    CREATE INDEX IF NOT EXISTS idx_comp_pagos_comprobante ON comprobante_pagos(comprobante_id);
  `);

  // ─── CAJA — apertura/cierre de turno + ingresos/egresos manuales ──────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS caja_sesiones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sucursal_id INTEGER,
      usuario_apertura TEXT,
      usuario_cierre TEXT,
      monto_apertura REAL NOT NULL DEFAULT 0,
      monto_cierre_esperado REAL,
      monto_cierre_real REAL,
      diferencia REAL,
      estado TEXT NOT NULL DEFAULT 'abierta',
      notas_cierre TEXT,
      fecha_apertura DATETIME DEFAULT CURRENT_TIMESTAMP,
      fecha_cierre DATETIME,
      FOREIGN KEY (sucursal_id) REFERENCES sucursales(id)
    );
    CREATE TABLE IF NOT EXISTS caja_movimientos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      caja_sesion_id INTEGER NOT NULL,
      tipo TEXT NOT NULL CHECK (tipo IN ('ingreso','egreso')),
      origen TEXT NOT NULL DEFAULT 'manual',
      medio_pago TEXT NOT NULL DEFAULT 'Efectivo',
      monto REAL NOT NULL DEFAULT 0,
      motivo TEXT,
      comprobante_id INTEGER,
      usuario TEXT,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (caja_sesion_id) REFERENCES caja_sesiones(id),
      FOREIGN KEY (comprobante_id) REFERENCES comprobantes(id)
    );
    CREATE INDEX IF NOT EXISTS idx_caja_mov_sesion ON caja_movimientos(caja_sesion_id);
  `);

  // Migración: desglose del cierre por medio de pago (esperado/contado/diferencia
  // de cada uno, no solo Efectivo) — para instalaciones que ya tenían caja_sesiones.
  try { db.exec(`ALTER TABLE caja_sesiones ADD COLUMN cierre_detalle_json TEXT`); } catch(e) {}

  // ─── Código de vendedor (SYS-xxx) — etiqueta cada venta/movimiento con quién
  // atendió, para reportes por vendedor. No es un login ni un PIN de acceso.
  try { db.exec(`ALTER TABLE comprobantes ADD COLUMN vendedor_codigo TEXT`); } catch(e) {}

  // Quién y desde dónde se generó el comprobante (taller/tienda/caja/admin),
  // para mostrarlo en la impresión sin importar en qué sector se haya hecho.
  // Qué puede hacer el técnico con cada acceso a herramientas externas
  // (ZXW, Borneo...): 'ninguno' (no lo ve), 'usar' (lo abre y copia
  // usuario/clave SIN verlos) o 'completo' (ve todo). Lo define solo el admin.
  try { db.exec(`ALTER TABLE recursos_accesos ADD COLUMN acceso_tecnico TEXT DEFAULT 'ninguno'`); } catch(e) {}
  // ─── TIENDA: costo/fondo de garantía por venta, configuración y garantías generales ───
  try { db.exec(`ALTER TABLE comprobantes ADD COLUMN costo_total REAL DEFAULT 0`); } catch(e) {}
  try { db.exec(`ALTER TABLE comprobantes ADD COLUMN fondo_garantia REAL DEFAULT 0`); } catch(e) {}
  try { db.exec(`CREATE TABLE IF NOT EXISTS tienda_config (clave TEXT PRIMARY KEY, valor TEXT)`); } catch(e) {}
  try { db.exec(`CREATE TABLE IF NOT EXISTS garantias_tienda (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      numero TEXT UNIQUE,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      comprobante_id INTEGER, comprobante_numero TEXT, fecha_venta TEXT,
      cliente_id INTEGER, cliente_nombre TEXT, vendedor_codigo TEXT,
      producto_id INTEGER, producto_nombre TEXT, item_index INTEGER, cantidad REAL DEFAULT 1,
      precio_unitario REAL DEFAULT 0, costo_unitario REAL DEFAULT 0,
      motivo TEXT, nota TEXT,
      resultado TEXT NOT NULL,              -- cambio | devolucion | rechazada
      producto_nuevo_id INTEGER, producto_nuevo_nombre TEXT, precio_nuevo_unitario REAL DEFAULT 0,
      diferencia REAL DEFAULT 0,            -- >0 el cliente paga · <0 se le devuelve
      medio_pago TEXT,
      destino_stock TEXT DEFAULT 'pendiente', -- stock | perdida | pendiente | no_aplica
      costo_perdida REAL DEFAULT 0,         -- sale del fondo de garantía
      vencida INTEGER DEFAULT 0,
      sucursal_id INTEGER, usuario TEXT, usuario_rol TEXT
    )`); } catch(e) {}
  try { db.exec(`ALTER TABLE comprobantes ADD COLUMN generado_por_usuario TEXT`); } catch(e) {}
  try { db.exec(`ALTER TABLE comprobantes ADD COLUMN generado_por_rol TEXT`); } catch(e) {}
  try { db.exec(`ALTER TABLE comprobantes ADD COLUMN stock_movido INTEGER DEFAULT 0`); } catch(e) {}
  try { db.exec(`ALTER TABLE comprobantes ADD COLUMN stock_sucursal_id INTEGER`); } catch(e) {}
  try { db.exec(`ALTER TABLE orden_repuestos ADD COLUMN stock_sucursal_id INTEGER`); } catch(e) {}
  try { db.exec(`ALTER TABLE caja_movimientos ADD COLUMN vendedor_codigo TEXT`); } catch(e) {}
  // Marca firme "Desde ADMIN": el comprobante (y su movimiento de caja) lo
  // emitió el administrador y no el personal del local. Solo lo fija el
  // servidor al crear; ningún endpoint lo modifica después.
  try {
    db.exec(`ALTER TABLE comprobantes ADD COLUMN desde_admin INTEGER DEFAULT 0`);
    // Primera vez: los comprobantes que ya había emitido un admin quedan marcados.
    db.exec(`UPDATE comprobantes SET desde_admin=1 WHERE generado_por_rol='admin'`);
  } catch(e) {}
  try { db.exec(`ALTER TABLE caja_movimientos ADD COLUMN desde_admin INTEGER DEFAULT 0`); } catch(e) {}

  // ─── Venta del admin que se retira en otro local (cobro externo + código de
  // entrega). sucursal_id del comprobante = local donde se retira; el código
  // lo ingresa el cajero de ese local para entregar sin quedar expuesto.
  [
    `cobro_externo INTEGER DEFAULT 0`,
    `retiro_codigo TEXT`,
    `retiro_estado TEXT`,          // 'pendiente' | 'entregada' | 'anulada'
    `retiro_entregado_por TEXT`,
    `retiro_entregado_fecha TEXT`,
    `retiro_retira_nombre TEXT`,
    `retiro_retira_doc TEXT`,
  ].forEach(col => { try { db.exec(`ALTER TABLE comprobantes ADD COLUMN ${col}`); } catch(e) {} });
  try { db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_comp_retiro_codigo ON comprobantes(retiro_codigo) WHERE retiro_codigo IS NOT NULL`); } catch(e) {}

  // ─── Equipo entregado sin reparación (Nota de Entrega marcada) y su cobro de
  // revisión opcional. cobro_pendiente=1 → la Caja lo cobra; sin_cobro_* deja
  // constancia de quién autorizó entregar sin cobrar y por qué.
  [
    `sin_reparacion INTEGER DEFAULT 0`,
    `cobro_pendiente INTEGER DEFAULT 0`,
    `sin_cobro_motivo TEXT`,
    `sin_cobro_por TEXT`,
  ].forEach(col => { try { db.exec(`ALTER TABLE comprobantes ADD COLUMN ${col}`); } catch(e) {} });
  try { db.exec(`ALTER TABLE ordenes ADD COLUMN comprobante_entrega TEXT`); } catch(e) {}
  try { db.exec(`ALTER TABLE clientes ADD COLUMN documento TEXT`); } catch(e) {}
  // Entrega A: tipo de orden (cliente / garantía del local / gremio) y estados especiales definidos por el admin
  try { db.exec(`ALTER TABLE ordenes ADD COLUMN tipo_orden TEXT DEFAULT 'cliente'`); } catch(e) {}
  try { db.exec(`ALTER TABLE ordenes ADD COLUMN garantia_ref TEXT`); } catch(e) {}
  // Entrega B: comisiones de técnicos, causas de garantía y gremios
  for (const col of [`tecnico_id INTEGER`, `garantia_causa_id INTEGER`, `gremio_id INTEGER`]) {
    try { db.exec(`ALTER TABLE ordenes ADD COLUMN ${col}`); } catch(e) {}
  }
  try { db.exec(`
    CREATE TABLE IF NOT EXISTS comision_reglas (
      tecnico_id INTEGER PRIMARY KEY,
      pct_mano_obra REAL DEFAULT 0,
      pct_repuesto REAL DEFAULT 0,
      monto_garantia REAL DEFAULT 0,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS garantia_causas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      absorbe TEXT DEFAULT 'local',
      descuento_tipo TEXT DEFAULT 'ninguno',
      descuento_valor REAL DEFAULT 0,
      activo INTEGER DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS gremios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      tarifa_tipo TEXT DEFAULT 'ninguna',
      tarifa_valor REAL DEFAULT 0,
      pct_mano_obra_tecnico REAL,
      activo INTEGER DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS comisiones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      orden_id INTEGER NOT NULL,
      tipo TEXT NOT NULL,
      tecnico_id INTEGER,
      tecnico_nombre TEXT,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      mano_obra_base REAL DEFAULT 0,
      pct_mano_obra REAL DEFAULT 0,
      comision_mano_obra REAL DEFAULT 0,
      repuestos_venta REAL DEFAULT 0,
      repuestos_costo REAL DEFAULT 0,
      repuestos_costo_ajustado REAL DEFAULT 0,
      recargo_pct REAL DEFAULT 0,
      margen_repuesto REAL DEFAULT 0,
      pct_repuesto REAL DEFAULT 0,
      comision_repuesto REAL DEFAULT 0,
      pago_garantia REAL DEFAULT 0,
      descuento REAL DEFAULT 0,
      total REAL DEFAULT 0,
      perdida_local REAL DEFAULT 0,
      detalle TEXT,
      estado TEXT DEFAULT 'pendiente',
      liquidacion_id INTEGER,
      UNIQUE(orden_id, tipo)
    );
  `); } catch(e) {}
  try { db.exec(`ALTER TABLE ordenes ADD COLUMN garantia_rep_cobrado REAL DEFAULT 0`); } catch(e) {}
  try { db.exec(`CREATE TABLE IF NOT EXISTS liquidaciones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tecnico_id INTEGER, tecnico_nombre TEXT,
      desde TEXT, hasta TEXT,
      cantidad INTEGER DEFAULT 0, total REAL DEFAULT 0, perdida_local REAL DEFAULT 0,
      medio TEXT, nota TEXT,
      usuario_id INTEGER, usuario_nombre TEXT,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP
    )`); } catch(e) {}
  try { db.exec(`CREATE TABLE IF NOT EXISTS estados_orden (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      clave TEXT UNIQUE NOT NULL,
      nombre TEXT NOT NULL,
      color TEXT DEFAULT '#8b90a7',
      cuenta_como TEXT DEFAULT 'reparacion',
      activo INTEGER DEFAULT 1,
      orden INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`); } catch(e) {}
  // Corrige el total de órdenes ACTIVAS que quedó en $0 (mano de obra cargada al crear, sin recalcular).
  // No toca órdenes entregadas/canceladas (historial).
  try {
    db.exec(`UPDATE ordenes SET
        total_repuestos = COALESCE((SELECT SUM(subtotal) FROM orden_repuestos WHERE orden_id=ordenes.id),0),
        total = COALESCE(mano_obra,0) + COALESCE((SELECT SUM(subtotal) FROM orden_repuestos WHERE orden_id=ordenes.id),0)
      WHERE estado NOT IN ('entregado','cancelado')
        AND ABS(COALESCE(total,0) - (COALESCE(mano_obra,0) + COALESCE((SELECT SUM(subtotal) FROM orden_repuestos WHERE orden_id=ordenes.id),0))) > 0.001`);
  } catch(e) {}
  // Fase 3: el taller indica cómo pagará el cliente y en qué local retira.
  for (const col of ['pago_metodo TEXT', 'retiro_sucursal_id INTEGER', 'pago_descuento_pct REAL DEFAULT 0', 'pago_marcado_por TEXT', 'pago_marcado_fecha TEXT']) {
    try { db.exec(`ALTER TABLE ordenes ADD COLUMN ${col}`); } catch(e) {}
  }

  // ─── Comprobantes INAMOVIBLES: una vez emitido, ni el número ni lo que
  // documenta (ítems, total, local, cliente-orden) se pueden modificar, no se
  // puede reabrir uno anulado ni borrar uno emitido (solo anular, con auditoría).
  // Se aplica en la propia base de datos: ninguna pantalla ni API lo puede saltear.
  try {
    db.exec(`
      CREATE TRIGGER IF NOT EXISTS trg_comp_inmutable
      BEFORE UPDATE OF numero,tipo,letra,punto_venta,numero_comp,orden_id,items,subtotal,descuento,iva_porcentaje,iva_monto,total,sucursal_id,fecha,generado_por_usuario,generado_por_rol,desde_admin,retiro_codigo,cobro_externo,sin_reparacion ON comprobantes
      WHEN OLD.estado IN ('emitido','anulado')
      BEGIN SELECT RAISE(ABORT, 'Comprobante emitido: no se puede modificar (solo se puede anular)'); END;

      CREATE TRIGGER IF NOT EXISTS trg_comp_no_reabrir
      BEFORE UPDATE OF estado ON comprobantes
      WHEN (OLD.estado='anulado' AND NEW.estado!='anulado') OR (OLD.estado='emitido' AND NEW.estado NOT IN ('emitido','anulado'))
      BEGIN SELECT RAISE(ABORT, 'Un comprobante emitido o anulado no se puede reabrir'); END;

      CREATE TRIGGER IF NOT EXISTS trg_comp_no_borrar
      BEFORE DELETE ON comprobantes
      WHEN OLD.estado IN ('emitido','anulado') AND OLD.tipo != 'presupuesto'
      BEGIN SELECT RAISE(ABORT, 'Un comprobante emitido no se puede borrar (solo se puede anular)'); END;
    `);
  } catch(e) { console.error('Triggers de comprobantes:', e.message); }

  // ─── Usuario asignado a una sucursal fija (una cajera siempre abre/cierra la
  // caja de SU sucursal). Admin queda sin asignar = puede operar cualquiera.
  try { db.exec(`ALTER TABLE usuarios ADD COLUMN sucursal_id INTEGER`); } catch(e) {}
  // Permiso que el admin decide por usuario: ver (solo lectura) el stock de
  // otras sucursales, para saber si conviene pedir un traslado. No habilita
  // a enviar ni tocar stock ajeno — eso sigue atado a la sucursal asignada.
  try { db.exec(`ALTER TABLE usuarios ADD COLUMN ver_otras_sucursales INTEGER DEFAULT 0`); } catch(e) {}

  // ─── Repuesto vs producto de reventa — el taller NO debe ver ni poder
  // enviar productos de venta de mostrador (celulares, accesorios), solo lo
  // que es repuesto/insumo de reparación. El admin marca cada producto al
  // cargarlo; el backend filtra por este campo para el rol taller siempre,
  // nunca confía en lo que pida el frontend.
  try { db.exec(`ALTER TABLE productos ADD COLUMN es_repuesto INTEGER DEFAULT 0`); } catch(e) {}

  // ─── Envío de equipos entre sucursales/taller/caja/central ─────────────────
  // Distinto del envío de stock/repuestos: acá se mueve el EQUIPO de un
  // cliente (una orden de servicio), con todos sus datos, no una cantidad de
  // producto. Sigue el mismo patrón de tránsito: se envía, y el destino tiene
  // que confirmar que lo recibió antes de que quede asentado ahí.
  try { db.exec(`ALTER TABLE ordenes ADD COLUMN sucursal_id INTEGER`); } catch(e) {}

  // ─── Herramientas por sucursal + clave para carga manual ───────────────────
  // Un no-admin solo CONSULTA el stock de herramientas de su propia sucursal
  // (más las "generales", sin sucursal asignada). Si necesita cargar una
  // herramienta nueva a mano, necesita la clave que el admin generó para esa
  // sucursal/taller puntual — nunca una clave única para todo el sistema.
  try { db.exec(`ALTER TABLE herramientas ADD COLUMN sucursal_id INTEGER`); } catch(e) {}
  try { db.exec(`ALTER TABLE sucursales ADD COLUMN clave_herramientas TEXT`); } catch(e) {}

  // No todos los talleres facturan/cobran — el admin decide por sucursal si
  // ese taller puede emitir Factura/Nota de Crédito/Nota de Débito (cobrar),
  // o si solo puede hacer Presupuesto y Nota de Entrega (entregar el equipo
  // sin cobrar). Por defecto habilitado para no romper instalaciones existentes.
  // Aplica al rol TALLER de esa sucursal (la caja/tienda factura siempre).
  // Por defecto el taller NO cobra: el admin tiene que habilitarlo.
  try { db.exec(`ALTER TABLE sucursales ADD COLUMN factura_habilitada INTEGER DEFAULT 0`); } catch(e) {}
  // Chequeo de IMEI (consume créditos de imeicheck.com): el admin decide por
  // sucursal/taller quién puede usarlo. Habilitado por defecto.
  try { db.exec(`ALTER TABLE sucursales ADD COLUMN imei_habilitado INTEGER DEFAULT 1`); } catch(e) {}
  // Envío libre: mandar artículos que no están cargados como producto (se escribe a mano).
  // Lo autoriza el admin por sucursal. No toca el stock: queda como registro de envío/recepción.
  try { db.exec(`ALTER TABLE sucursales ADD COLUMN envio_libre_habilitado INTEGER DEFAULT 0`); } catch(e) {}
  // Remitos de mercadería entre sucursales: un envío con varias líneas (del stock o artículos libres),
  // el destino confirma línea por línea y las diferencias/rechazos quedan registrados.
  db.exec(`
    CREATE TABLE IF NOT EXISTS remitos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      numero TEXT,
      origen_sucursal_id INTEGER NOT NULL,
      destino_sucursal_id INTEGER NOT NULL,
      estado TEXT DEFAULT 'en_transito',
      notas TEXT,
      usuario_envio TEXT,
      rol_envio TEXT,
      fecha_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
      usuario_recepcion TEXT,
      fecha_recepcion DATETIME,
      notas_recepcion TEXT
    );
    CREATE TABLE IF NOT EXISTS remito_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      remito_id INTEGER NOT NULL,
      producto_id INTEGER,
      descripcion TEXT NOT NULL,
      cantidad REAL NOT NULL,
      cantidad_recibida REAL,
      resultado TEXT DEFAULT 'pendiente',
      motivo TEXT,
      FOREIGN KEY (remito_id) REFERENCES remitos(id)
    );
    CREATE INDEX IF NOT EXISTS idx_remito_items_remito ON remito_items(remito_id);
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS envios_equipos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      orden_id INTEGER NOT NULL,
      origen_sucursal_id INTEGER,
      destino_sucursal_id INTEGER NOT NULL,
      estado TEXT DEFAULT 'enviado',
      notas TEXT,
      usuario_envio TEXT,
      usuario_confirmacion TEXT,
      fecha_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
      fecha_confirmacion DATETIME,
      FOREIGN KEY (orden_id) REFERENCES ordenes(id)
    );
  `);

  // ─── Fondo de caja fijo por sucursal: lo define el admin (no se puede
  // modificar desde Caja). Al abrir, el cajero escribe cuánto contó en el
  // cajón y el sistema compara contra este monto fijo.
  try { db.exec(`ALTER TABLE sucursales ADD COLUMN fondo_caja_fijo REAL DEFAULT 0`); } catch(e) {}
  try { db.exec(`ALTER TABLE caja_sesiones ADD COLUMN monto_recibido_apertura REAL`); } catch(e) {}
  try { db.exec(`ALTER TABLE caja_sesiones ADD COLUMN diferencia_apertura REAL`); } catch(e) {}

  // ─── Transferencias de mercadería en tránsito: distribuir/transferir/devolver
  // ya NO suman stock al destino al instante — quedan "enviado" y el destino
  // tiene que CONFIRMAR cuánto llegó de verdad antes de que se sume a su stock.
  // Así cualquier diferencia entre lo que salió y lo que llegó queda registrada,
  // en vez de perderse en el camino sin que nadie se entere.
  try { db.exec(`ALTER TABLE movimientos_sucursal ADD COLUMN estado TEXT DEFAULT 'confirmado'`); } catch(e) {}
  try { db.exec(`ALTER TABLE movimientos_sucursal ADD COLUMN cantidad_recibida INTEGER`); } catch(e) {}
  try { db.exec(`ALTER TABLE movimientos_sucursal ADD COLUMN diferencia INTEGER`); } catch(e) {}
  try { db.exec(`ALTER TABLE movimientos_sucursal ADD COLUMN confirmado_por TEXT`); } catch(e) {}
  try { db.exec(`ALTER TABLE movimientos_sucursal ADD COLUMN fecha_confirmacion DATETIME`); } catch(e) {}

  // ─── Config fiscal POR SUCURSAL — cada sucursal puede tener su propio punto
  // de venta/numeración de AFIP, decidido por el admin. Si una sucursal no
  // tiene fila acá para una clave, se usa el valor global de config_fiscal
  // (tabla ya existente) como default. No se toca config_fiscal para no
  // romper instalaciones existentes de un solo local.
  db.exec(`
    CREATE TABLE IF NOT EXISTS config_fiscal_sucursal (
      sucursal_id INTEGER NOT NULL,
      clave TEXT NOT NULL,
      valor TEXT,
      PRIMARY KEY (sucursal_id, clave),
      FOREIGN KEY (sucursal_id) REFERENCES sucursales(id)
    );
  `);

  // ─── INGRESO DE MERCADERÍA — recepción ordenada por lote/proveedor ─────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS mercaderia_ingresos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      proveedor TEXT,
      numero_remito TEXT,
      notas TEXT,
      usuario TEXT,
      sucursal_id INTEGER,
      total REAL DEFAULT 0,
      fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (sucursal_id) REFERENCES sucursales(id)
    );
    CREATE TABLE IF NOT EXISTS mercaderia_ingreso_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ingreso_id INTEGER NOT NULL,
      producto_id INTEGER NOT NULL,
      cantidad INTEGER NOT NULL DEFAULT 0,
      costo_unitario REAL DEFAULT 0,
      FOREIGN KEY (ingreso_id) REFERENCES mercaderia_ingresos(id),
      FOREIGN KEY (producto_id) REFERENCES productos(id)
    );
    CREATE INDEX IF NOT EXISTS idx_merc_items_ingreso ON mercaderia_ingreso_items(ingreso_id);
  `);
  // Migración: costo de compra en productos (para poder valuar stock)
  try { db.exec(`ALTER TABLE productos ADD COLUMN costo REAL DEFAULT 0`); } catch(e) {}
  try { db.exec(`ALTER TABLE productos ADD COLUMN proveedor TEXT`); } catch(e) {}

  // ─── CATEGORÍAS Y SUBCATEGORÍAS — catálogo genérico, reusado por Herramientas
  // y por Productos. "tipo" separa ambos catálogos: 'herramienta' viene
  // precargado con las categorías típicas de un taller; 'producto' arranca
  // vacío porque no todos los talleres venden lo mismo (este no siempre es
  // un local de accesorios de celulares) — cada negocio arma el suyo.
  db.exec(`
    CREATE TABLE IF NOT EXISTS categorias (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tipo TEXT NOT NULL CHECK (tipo IN ('herramienta','producto')),
      nombre TEXT NOT NULL,
      icono TEXT DEFAULT '📦',
      UNIQUE(tipo, nombre)
    );
    CREATE TABLE IF NOT EXISTS subcategorias (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      categoria_id INTEGER NOT NULL,
      nombre TEXT NOT NULL,
      UNIQUE(categoria_id, nombre),
      FOREIGN KEY (categoria_id) REFERENCES categorias(id)
    );
  `);
  const categoriasHerramientaDefault = [
    ['General','🔧'], ['Medición','📏'], ['Soldadura','🔥'], ['Destornilladores','🔩'],
    ['Diagnóstico','🔬'], ['Limpieza','🧹'], ['Apertura','🔓'], ['Seguridad','🛡️']
  ];
  const insCat = db.prepare('INSERT OR IGNORE INTO categorias (tipo,nombre,icono) VALUES (?,?,?)');
  categoriasHerramientaDefault.forEach(([nombre,icono]) => insCat.run('herramienta', nombre, icono));
  // tipo='producto' queda deliberadamente sin precargar para un taller nuevo —
  // lo arma cada negocio, porque no todos venden lo mismo

  // Productos pasa a referenciar el catálogo de categorías por ID (en vez de
  // texto libre) — así "Fundas" es siempre la misma categoría, sin variantes
  // de tipeo, y se puede agrupar/filtrar de verdad.
  try { db.exec(`ALTER TABLE productos ADD COLUMN categoria_id INTEGER REFERENCES categorias(id)`); } catch(e) {}
  try { db.exec(`ALTER TABLE productos ADD COLUMN subcategoria_id INTEGER REFERENCES subcategorias(id)`); } catch(e) {}

  // Precarga SOLO en la instalación local de Systech ("default") — rubro de
  // referencia: accesorios y repuestos de celular. Cualquier otro taller
  // (otro subdominio = otro cliente) arranca con tipo='producto' vacío.
  if (subdominio === 'default') {
    const yaHay = db.prepare(`SELECT COUNT(*) as c FROM categorias WHERE tipo='producto'`).get().c > 0;
    if (!yaHay) {
      const CATALOGO_DEFAULT = {
        'Repuestos': ['Pantalla','Batería','Conector de Carga','Cámara','Flex / Cable Flex','Tapa Trasera','Botones','Parlante / Auricular Interno','Placa / Módulo','Vidrio de Cámara'],
        'Fundas': [],
        'Vidrios / Protectores de Pantalla': [],
        'Aros de Luz': [],
        'Relojes Inteligentes': [],
        'Auriculares': [],
        'Cargadores y Cables': [],
        'Memorias y Almacenamiento': [],
        'Otros Accesorios': [],
      };
      const insCatProd = db.prepare(`INSERT INTO categorias (tipo,nombre,icono) VALUES ('producto',?,?)`);
      const insSub = db.prepare('INSERT INTO subcategorias (categoria_id,nombre) VALUES (?,?)');
      Object.entries(CATALOGO_DEFAULT).forEach(([nombre, subs]) => {
        const catId = insCatProd.run(nombre, '📦').lastInsertRowid;
        subs.forEach(sub => insSub.run(catId, sub));
      });
    }
  }

}

/**
 * Obtiene (o crea y cachea) la conexión de base de datos de un taller.
 * La primera vez que se abre, inicializa automáticamente su esquema completo.
 */
function getDbForTenant(subdominio) {
  if (connectionCache.has(subdominio)) {
    return connectionCache.get(subdominio);
  }
  const dbPath = getDbPathForTenant(subdominio);
  const esNueva = !fs.existsSync(dbPath);
  const db = new Database(dbPath);
  inicializarBaseTaller(db, subdominio); // Seguro de llamar siempre — usa IF NOT EXISTS
  connectionCache.set(subdominio, db);
  if (esNueva) {
    console.log(`🆕 Base de datos creada e inicializada para el taller: ${subdominio}`);
  }
  return db;
}

/**
 * Busca un taller por su subdominio en la base maestra
 */
function findTaller(subdominio) {
  return masterDb.prepare('SELECT * FROM talleres WHERE subdominio = ? AND activo = 1').get(subdominio);
}

/**
 * Crea un nuevo taller (alta manual o automática) y deja su base de datos lista
 */
function crearTaller({ subdominio, nombre, plan, email_contacto, telefono_contacto, notas, fecha_vencimiento, tecnibot_habilitado, imei_habilitado, modulo_taller, modulo_tienda, limite_sucursales, ia_habilitada }) {
  const existe = masterDb.prepare('SELECT id FROM talleres WHERE subdominio = ?').get(subdominio);
  if (existe) throw new Error(`El subdominio "${subdominio}" ya está en uso`);

  masterDb.prepare(`
    INSERT INTO talleres (subdominio, nombre, plan, email_contacto, telefono_contacto, notas, fecha_vencimiento, tecnibot_habilitado, imei_habilitado, modulo_taller, modulo_tienda, limite_sucursales, ia_habilitada)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(subdominio, nombre, plan || 'local', email_contacto || '', telefono_contacto || '', notas || '', fecha_vencimiento || null, tecnibot_habilitado ? 1 : 0, imei_habilitado ? 1 : 0,
    modulo_taller === undefined ? 1 : (modulo_taller ? 1 : 0), modulo_tienda === undefined ? 1 : (modulo_tienda ? 1 : 0),
    Number.isInteger(limite_sucursales) && limite_sucursales > 0 ? limite_sucursales : 2, ia_habilitada ? 1 : 0);

  // Crear e inicializar la base de datos del nuevo taller (con su admin/admin123 por defecto)
  const db = getDbForTenant(subdominio);
  return db;
}

/**
 * Lista TODOS los talleres, activos e inactivos (para el panel de distribuidor)
 */
function listarTalleres() {
  return masterDb.prepare('SELECT * FROM talleres ORDER BY fecha_alta DESC').all();
}

/**
 * Actualiza datos de un taller (plan, vencimiento, notas, estado activo)
 */
function actualizarTaller(subdominio, cambios) {
  const campos = [];
  const valores = [];
  ['nombre', 'plan', 'email_contacto', 'telefono_contacto', 'notas', 'fecha_vencimiento', 'activo', 'tecnibot_habilitado', 'imei_habilitado', 'modulo_taller', 'modulo_tienda', 'limite_sucursales', 'ia_habilitada'].forEach(campo => {
    if (cambios[campo] !== undefined) {
      campos.push(`${campo} = ?`);
      // better-sqlite3 no acepta booleanos: los banderas de addon van como 1/0
      valores.push(typeof cambios[campo] === 'boolean' ? (cambios[campo] ? 1 : 0) : cambios[campo]);
    }
  });
  if (!campos.length) return;
  valores.push(subdominio);
  masterDb.prepare(`UPDATE talleres SET ${campos.join(', ')} WHERE subdominio = ?`).run(...valores);
}

/**
 * Elimina por completo un taller: su registro en la base maestra y su archivo de base de datos.
 * Acción irreversible — pensada para cancelaciones definitivas, no para pausas temporales.
 */
function eliminarTaller(subdominio) {
  if (subdominio === 'default') throw new Error('No se puede eliminar el taller "default"');
  masterDb.prepare('DELETE FROM talleres WHERE subdominio = ?').run(subdominio);
  if (connectionCache.has(subdominio)) {
    connectionCache.get(subdominio).close();
    connectionCache.delete(subdominio);
  }
  const dbPath = getDbPathForTenant(subdominio);
  if (fs.existsSync(dbPath)) fs.unlinkSync(dbPath);
}

// ─── AUTENTICACIÓN DEL DISTRIBUIDOR ───────────────────────────────────────────

/**
 * Login del distribuidor (vos, dueño del negocio). Devuelve un token de sesión
 * válido por 12 horas, totalmente separado de los logins de cada taller.
 */
function loginDistribuidor(usuario, password) {
  if (typeof usuario !== 'string' || typeof password !== 'string') return null;
  const user = masterDb.prepare('SELECT * FROM distribuidor_usuarios WHERE usuario = ? AND activo = 1').get(usuario);
  const v = user ? seguridad.verificarPassword(password, user.password) : { ok: false };
  if (!user || !v.ok) return null;
  if (v.legacy) masterDb.prepare('UPDATE distribuidor_usuarios SET password = ? WHERE id = ?').run(seguridad.hashPassword(password), user.id);

  const token = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString();
  masterDb.prepare('INSERT INTO distribuidor_sesiones (token, usuario_id, usuario, expires) VALUES (?, ?, ?, ?)')
    .run(token, user.id, user.usuario, expires);
  return { token, nombre: user.nombre, usuario: user.usuario };
}

/**
 * Valida un token de sesión del distribuidor
 */
function validarSesionDistribuidor(token) {
  if (!token) return null;
  return masterDb.prepare("SELECT * FROM distribuidor_sesiones WHERE token = ? AND expires > datetime('now')").get(token);
}

/**
 * Cambia la contraseña del usuario distribuidor
 */
function cambiarPasswordDistribuidor(usuario, passwordActual, passwordNueva) {
  const user = masterDb.prepare('SELECT * FROM distribuidor_usuarios WHERE usuario = ?').get(usuario);
  if (!user || !seguridad.verificarPassword(passwordActual, user.password).ok) throw new Error('La contraseña actual es incorrecta');
  const err = seguridad.validarPasswordNueva(passwordNueva);
  if (err) throw new Error(err);
  masterDb.prepare('UPDATE distribuidor_usuarios SET password = ? WHERE id = ?').run(seguridad.hashPassword(passwordNueva), user.id);
}

/**
 * Middleware de Express: resuelve el tenant según el subdominio del Host header
 * y lo deja disponible en req.db y req.tenant
 */
function tenantMiddleware(req, res, next) {
  const host = req.headers.host || '';
  const hostname = host.split(':')[0]; // quita el puerto si existe

  let subdominio;

  // Modo desarrollo local: localhost o IP → usar taller "default"
  if (hostname === 'localhost' || /^\d+\.\d+\.\d+\.\d+$/.test(hostname)) {
    subdominio = 'default';
  } else {
    // Producción: tallerperez.systech.com → "tallerperez"
    const partes = hostname.split('.');
    subdominio = partes.length > 2 ? partes[0] : 'default';
  }

  // Asegurar que el taller "default" siempre exista (para desarrollo/instalación local)
  let taller = findTaller(subdominio);
  if (!taller && subdominio === 'default') {
    crearTaller({ subdominio: 'default', nombre: 'Mi Taller', plan: 'local' });
    taller = findTaller(subdominio);
  }

  if (!taller) {
    return res.status(404).json({ error: 'Este taller no existe o no está activo. Verificá la dirección.' });
  }

  req.tenant = taller;
  req.db = getDbForTenant(subdominio);
  next();
}

module.exports = {
  MODO_DISTRIBUIDOR,
  masterDb,
  tenantMiddleware,
  getDbForTenant,
  findTaller,
  crearTaller,
  listarTalleres,
  actualizarTaller,
  eliminarTaller,
  loginDistribuidor,
  validarSesionDistribuidor,
  cambiarPasswordDistribuidor
};
