@echo off
rem Cierra SysTech (corre en segundo plano, sin ventana). Para volver a abrirlo usa el icono.
cd /d "%~dp0"
set PUERTO=3000
if exist puerto.txt set /p PUERTO=<puerto.txt
powershell -NoProfile -WindowStyle Hidden -Command "Get-NetTCPConnection -LocalPort %PUERTO% -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }"
echo SysTech cerrado.
ping -n 3 127.0.0.1 >nul
