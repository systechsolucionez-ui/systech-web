# Venta online con Mercado Pago (versión 1.6.0)

El cliente elige su plan en `tu-dominio/comprar.html` y paga en pesos con Mercado Pago. Apenas se aprueba el pago, todo se activa solo:

- **Hosting:** se crea su negocio en `sunombre.tu-dominio`, con una contraseña inicial al azar que ve al terminar de pagar y le llega por email.
- **Instalación en su PC:** recibe su código de activación al instante.
- **Renovaciones y complementos:** el administrador del negocio los compra desde **Configuración → Sistema → Comprar o renovar**. En las instalaciones locales el código nuevo se busca y se aplica solo, sin pegar nada.
- **Débito automático (opcional):** después del primer pago, el cliente toca «Activar renovación automática» y autoriza la tarjeta en Mercado Pago. Lo cancela cuando quiere desde el mismo lugar.

Los precios están en dólares en `ventas.js` (constante `CATALOGO`) y se cobran en pesos a la cotización que cargás en el **panel del distribuidor → Ventas online** (por defecto, $1.600).

## Qué configurar en el servidor (una vez)

En el servidor central, el que tiene `SYSTECH_DISTRIBUIDOR=1`, cargá estas variables de entorno. Nunca van en el código ni en GitHub.

| Variable | Qué poner |
|---|---|
| `SYSTECH_DOMINIO` | Tu dominio, por ejemplo `systech.com.ar`. Con esto `systech.com.ar` abre el sistema principal y `tallerperez.systech.com.ar` abre el negocio «tallerperez». |
| `URL_BASE` | La dirección pública con https, por ejemplo `https://systech.com.ar`. Si no la ponés, se arma con `SYSTECH_DOMINIO`. |
| `MP_ACCESS_TOKEN` | El token de Mercado Pago. Primero el de **prueba** (`TEST-...`), después el de **producción** (`APP_USR-...`). |
| `LICENCIA_PRIVADA_ARCHIVO` | La ruta a `licencia-privada.pem` en el servidor. Sin ella no se pueden vender instalaciones locales. |
| `TECNIBOT_API_KEY` | Tu clave de Claude para el Bot Técnico incluido en el plan. Si no está, usa `ASYSTENBOT_API_KEY`. |
| `TECNIBOT_CUPO_DEFECTO` | Opcional: consultas por mes y por negocio del Bot Técnico (por defecto, 300). |
| `IMEICHECK_API_KEY` | La clave del proveedor de IMEI, para vender los paquetes de consultas. |
| `CONTACTO_EMAIL`, `CONTACTO_WHATSAPP` | Tu contacto. Arma el botón de arrepentimiento de la página de compra. |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` | Opcional, para los mails de confirmación. Sin mails, el cliente ve todo al terminar de pagar y vos lo ves en el panel. |
| `DESCARGA_URL` | Opcional: el link del instalador para quien compra la versión local. |

**DNS:** además de tu dominio, creá un registro comodín `*.tu-dominio` que apunte al mismo servidor, con un certificado https que lo cubra. Sin eso, las direcciones de los negocios no abren.

**Instalaciones locales:** necesitan saber dónde está tu servidor. Cuando el dominio esté publicado, completá `URL_CENTRAL_DEFECTO` en `central.js` con `https://tu-dominio` y publicá la actualización. También funciona con la variable `SERVIDOR_CENTRAL_URL` o con un archivo `servidor-central.txt` junto a `server.js`.

## Configurar Mercado Pago

1. En **Mercado Pago Developers → Tus integraciones**, creá una aplicación.
2. Copiá el **Access Token de prueba** en `MP_ACCESS_TOKEN`.
3. En **Webhooks**, cargá la URL `https://tu-dominio/api/ventas/webhook` y marcá estos eventos:
   - **Pagos**;
   - **Planes y suscripciones**: suscripciones y pagos autorizados.

El sistema nunca confía en el aviso solo: siempre le pregunta el pago a Mercado Pago y entrega únicamente si está aprobado, en pesos, por el monto exacto de la orden, y una sola vez. Si un aviso no llega, la página de resultado encuentra el pago igual. Desde el panel también podés tocar «Verificar pago» en cualquier orden.

## Prueba completa antes de cobrar de verdad

1. En el panel del distribuidor → **Ventas online**, revisá que todos los indicadores estén en verde (Mercado Pago va a decir «modo PRUEBA»).
2. Abrí `tu-dominio/comprar.html` desde el celular y comprá un hosting con un **comprador de prueba** de Mercado Pago.
3. Entrá a la dirección que te da, con la contraseña inicial, y revisá el plan.
4. Desde adentro, en **Configuración → Sistema → Comprar o renovar**, comprá un complemento y activá la renovación automática.
5. Repetí la compra con la opción «Instalado en tu PC» y activá el código en una PC.
6. Si todo anda, cambiá `MP_ACCESS_TOKEN` por el de **producción**. El panel tiene que pasar a «cobrando de verdad».

## Qué conviene revisar con tu abogado o contador

- Las condiciones de compra de `comprar.html` (renovación, arrepentimiento, solo lectura al vencer).
- La facturación de cada venta. El sistema cobra, pero no emite tu factura a vos mismo como vendedor.
- Si los precios incluyen IVA.
