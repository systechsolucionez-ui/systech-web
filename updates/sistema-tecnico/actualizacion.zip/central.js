// ============================================================
// Dónde está el servidor central de SysTech y cuál es el dominio de los negocios en hosting.
//
//  · urlCentral(): adonde las instalaciones locales piden los servicios pagos (compras, códigos
//    renovados, IMEI, IA). Sale de, en este orden: la variable SERVIDOR_CENTRAL_URL, el archivo
//    servidor-central.txt junto a server.js, o URL_CENTRAL_DEFECTO (el dominio oficial).
//  · dominioBase(): el dominio de los negocios en hosting (variable SYSTECH_DOMINIO, ej.
//    "systech.com.ar"). Con él, "systech.com.ar" y "www.systech.com.ar" abren el sistema principal y
//    "tallerperez.systech.com.ar" abre el negocio "tallerperez". Sin la variable se usa la regla de
//    siempre (la primera parte del nombre), que con dominios .com.ar falla.
// ============================================================
const fs = require('fs');
const path = require('path');

// Completar con el dominio oficial cuando esté publicado (ej. 'https://systech.com.ar').
const URL_CENTRAL_DEFECTO = '';

const sinBarra = u => String(u || '').trim().replace(/\/+$/, '');

function urlCentral() {
  const env = sinBarra(process.env.SERVIDOR_CENTRAL_URL);
  if (env) return env;
  try {
    const f = sinBarra(fs.readFileSync(path.join(__dirname, 'servidor-central.txt'), 'utf8'));
    if (f) return f;
  } catch (e) {}
  return sinBarra(URL_CENTRAL_DEFECTO);
}

function dominioBase() {
  return String(process.env.SYSTECH_DOMINIO || '').trim().toLowerCase()
    .replace(/^https?:\/\//, '').replace(/[/:].*$/, '').replace(/^www\./, '');
}

/** Dirección pública de un negocio en hosting. */
function urlNegocio(subdominio) {
  const d = dominioBase() || 'systech.com';
  return `https://${subdominio}.${d}`;
}

/** Dirección pública del sistema principal (la página de compra, el panel). */
function urlPrincipal() {
  const env = sinBarra(process.env.URL_BASE);
  if (env) return env;
  const d = dominioBase();
  return d ? `https://${d}` : '';
}

/** A qué negocio corresponde un nombre de host. Devuelve 'default', un subdominio, o null si no corresponde a ninguno. */
function subdominioDeHost(hostname) {
  const h = String(hostname || '').toLowerCase();
  if (!h || h === 'localhost' || /^\d+\.\d+\.\d+\.\d+$/.test(h)) return 'default';
  const base = dominioBase();
  if (base) {
    if (h === base || h === 'www.' + base) return 'default';
    if (h.endsWith('.' + base)) {
      const sub = h.slice(0, -(base.length + 1));
      return /^[a-z0-9-]+$/.test(sub) ? sub : null;
    }
  }
  // Regla de siempre (sin SYSTECH_DOMINIO): tallerperez.systech.com → "tallerperez"
  const partes = h.split('.');
  return partes.length > 2 ? partes[0] : 'default';
}

module.exports = { urlCentral, dominioBase, urlNegocio, urlPrincipal, subdominioDeHost, URL_CENTRAL_DEFECTO };
