@echo off
title SysTech - Sistema de Tienda y Taller
cd /d "%~dp0"

if not exist "node_modules\" (
  echo Primera vez arrancando el sistema, instalando lo necesario...
  echo Esto puede tardar 1-2 minutos. No cierres esta ventana.
  echo.
) else (
  echo Verificando que todo este al dia...
)

call npm install --no-fund --no-audit
if errorlevel 1 (
  echo.
  echo ================================================
  echo Hubo un error instalando. Verifica que Node.js
  echo este bien instalado ^(node -v en la terminal^).
  echo ================================================
  pause
  exit /b 1
)
echo.

if not exist "%USERPROFILE%\Desktop\SysTech.lnk" (
  echo Creando acceso directo en el escritorio...
  powershell -NoProfile -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\SysTech.lnk'); $s.TargetPath='%~dp0INICIAR.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0SysTech.ico'; $s.Description='SysTech - Sistema de Tienda y Taller'; $s.Save()" >nul 2>&1
  echo Listo -- de ahora en mas, entra directo desde el icono de SysTech en tu escritorio.
  echo.
)

start http://localhost:3000
timeout /t 2 /nobreak >nul
node server.js

pause
