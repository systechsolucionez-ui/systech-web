@echo off
rem Abre SysTech sin ventana negra (todo lo hace SysTech.vbs)
cd /d "%~dp0"
start "" wscript.exe "%~dp0SysTech.vbs"
exit
