// ============================================================
// INFORME DE SUCURSAL A EXCEL — con membrete (logo, datos del negocio, período).
// Se arma con ExcelJS (ya viene en el sistema): NO necesita Python ni nada instalado.
//
// Hojas: Resumen · Ventas · Productos vendidos · Stock actual · Caja · Órdenes de taller (si el plan incluye Taller).
// Una sola sucursal, o "Todas" (cada hoja trae su columna Sucursal para filtrar).
// Los costos y márgenes solo salen si el usuario tiene permiso para verlos.
// ============================================================
const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');

// ── Utilidades ──────────────────────────────────────────────
const hexValido = h => /^#?[0-9a-fA-F]{6}$/.test(String(h || '').trim());
const limpiarHex = h => String(h).trim().replace('#', '').toUpperCase();
const argb = hex => 'FF' + hex;
function mezclar(hex, con, pct) { // pct 0..1 de "con"
  const c = i => Math.round(parseInt(hex.substr(i, 2), 16) * (1 - pct) + parseInt(con.substr(i, 2), 16) * pct).toString(16).padStart(2, '0');
  return (c(0) + c(2) + c(4)).toUpperCase();
}
function luminancia(hex) {
  const v = [0, 2, 4].map(i => { const x = parseInt(hex.substr(i, 2), 16) / 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); });
  return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
}
const parseItems = t => { try { const a = JSON.parse(t || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } };
const pidDe = i => Number(i._producto_id || i.producto_id || 0);
const redondear = n => Math.round((Number(n) || 0) * 100) / 100;
const FMT_MONEDA = '"$" #,##0.00;[Red]-"$" #,##0.00';
const FMT_ENTERO = '#,##0;[Red]-#,##0';
const FMT_FECHA = 'dd/mm/yyyy';
const FMT_FECHAHORA = 'dd/mm/yyyy hh:mm';
const FMT_PCT = '0.0%';

// Fecha de la base (UTC, texto) → Date que Excel muestra en hora local.
function fechaLocal(txt) {
  if (!txt) return null;
  const d = new Date(String(txt).includes('T') ? txt : String(txt).replace(' ', 'T') + 'Z');
  if (isNaN(d)) return null;
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000);
}
const dmy = ymd => { const [a, m, d] = String(ymd).slice(0, 10).split('-'); return `${d}/${m}/${a}`; };

function dimensionesImagen(buf) {
  try {
    if (buf[0] === 0x89 && buf[1] === 0x50) return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) }; // PNG
    if (buf[0] === 0xFF && buf[1] === 0xD8) { // JPG
      let i = 2;
      while (i < buf.length) {
        if (buf[i] !== 0xFF) { i++; continue; }
        const m = buf[i + 1];
        if (m >= 0xC0 && m <= 0xCF && m !== 0xC4 && m !== 0xC8 && m !== 0xCC) return { h: buf.readUInt16BE(i + 5), w: buf.readUInt16BE(i + 7) };
        i += 2 + buf.readUInt16BE(i + 2);
      }
    }
  } catch (e) {}
  return null;
}

function leerConfig(db) {
  const c = {};
  try { db.prepare('SELECT clave, valor FROM config').all().forEach(r => { c[r.clave] = r.valor; }); } catch (e) {}
  try { db.prepare('SELECT clave, valor FROM config_fiscal').all().forEach(r => { if (c[r.clave] === undefined || c[r.clave] === '') c[r.clave] = r.valor; }); } catch (e) {}
  return c;
}

// ── Armado de hojas ─────────────────────────────────────────
function crearEstilo(cfg) {
  const acento = hexValido(cfg.color_accent) ? limpiarHex(cfg.color_accent) : '1E3A5F';
  // Si el color de marca es muy claro, el texto del encabezado va oscuro
  const textoSobreAcento = luminancia(acento) > 0.55 ? '1B2130' : 'FFFFFF';
  return {
    acento, textoSobreAcento,
    suave: mezclar(acento, 'FFFFFF', 0.88),
    medio: mezclar(acento, 'FFFFFF', 0.7),
    gris: '6B7178', linea: 'D9DCE3',
  };
}

function prepararLogo(wb, cfg, uploadsDir) {
  const url = String(cfg.logo_empresa || cfg.logo_factura || '').split('?')[0];
  if (!url || !uploadsDir) return null;
  const archivo = path.join(uploadsDir, path.basename(url));
  try {
    if (!fs.existsSync(archivo)) return null;
    const ext = path.extname(archivo).slice(1).toLowerCase().replace('jpg', 'jpeg');
    if (!['png', 'jpeg'].includes(ext)) return null;
    const buf = fs.readFileSync(archivo);
    const dim = dimensionesImagen(buf) || { w: 3, h: 2 };
    const escala = Math.min(150 / dim.w, 58 / dim.h, 1) || 1;
    return { id: wb.addImage({ buffer: buf, extension: ext }), w: Math.round(dim.w * escala), h: Math.round(dim.h * escala) };
  } catch (e) { return null; }
}

/**
 * Crea una hoja con el membrete arriba. Devuelve { ws, fila } donde `fila` es la primera fila libre
 * (para la tabla). `cols` = [{ w }]: solo se usa para fijar anchos y el total de columnas.
 */
function hojaConMembrete(ctx, nombre, subtitulo, cols) {
  const { wb, E, cfg, logo, titulo, linea2, periodo, emitido, nombreNegocio } = ctx;
  const ws = wb.addWorksheet(nombre, { views: [{ showGridLines: false }], properties: { tabColor: { argb: argb(E.acento) } } });
  const n = cols.length;
  cols.forEach((c, i) => { ws.getColumn(i + 1).width = c.w; });
  // El logo vive sobre A:B: que entre
  if (ws.getColumn(1).width + ws.getColumn(2).width < 30) ws.getColumn(2).width = 30 - ws.getColumn(1).width;
  const ult = n;

  // Fila 1: logo + nombre del negocio
  ws.getRow(1).height = 32;
  ws.mergeCells(1, 3, 1, ult);
  const nom = ws.getCell(1, 3);
  nom.value = nombreNegocio;
  nom.font = { name: 'Calibri', size: 18, bold: true, color: { argb: argb(E.acento) } };
  nom.alignment = { vertical: 'bottom', horizontal: 'left', indent: 1 };
  // Fila 2: datos
  const anchoTotal = cols.reduce((a, c) => a + c.w, 0);
  ws.getRow(2).height = anchoTotal < 110 ? 32 : 22; // hoja angosta: los datos del negocio pueden ocupar dos líneas
  ws.mergeCells(2, 3, 2, ult);
  const dat = ws.getCell(2, 3);
  dat.value = linea2;
  dat.font = { name: 'Calibri', size: 9.5, color: { argb: argb(E.gris) } };
  dat.alignment = { vertical: 'top', horizontal: 'left', indent: 1, wrapText: true };
  if (logo) ws.addImage(logo.id, { tl: { col: 0.08, row: 0.1 }, ext: { width: logo.w, height: logo.h }, editAs: 'oneCell' });
  // Fila 3: franja de color
  ws.getRow(3).height = 5;
  for (let c = 1; c <= ult; c++) ws.getCell(3, c).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: argb(E.acento) } };
  // Fila 4: título del informe y período
  ws.getRow(4).height = 22;
  const corte = Math.max(2, Math.ceil(ult / 2));
  ws.mergeCells(4, 1, 4, corte);
  const t = ws.getCell(4, 1);
  t.value = titulo;
  t.font = { name: 'Calibri', size: 12, bold: true, color: { argb: argb('1B2130') } };
  t.alignment = { vertical: 'middle', horizontal: 'left' };
  if (corte < ult) {
    ws.mergeCells(4, corte + 1, 4, ult);
    const p = ws.getCell(4, corte + 1);
    p.value = (periodo ? `Período: ${periodo}   ·   ` : '') + `Emitido: ${emitido}`;
    p.font = { name: 'Calibri', size: 10, color: { argb: argb(E.gris) } };
    p.alignment = { vertical: 'middle', horizontal: 'right' };
  }
  // Fila 5: subtítulo de la hoja
  ws.getRow(5).height = 20;
  ws.mergeCells(5, 1, 5, ult);
  const s = ws.getCell(5, 1);
  s.value = subtitulo;
  s.font = { name: 'Calibri', size: 11, bold: true, color: { argb: argb(E.acento) } };
  s.alignment = { vertical: 'middle', horizontal: 'left', indent: 1 };
  for (let c = 1; c <= ult; c++) ws.getCell(5, c).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: argb(E.suave) } };
  ws.getRow(6).height = 8;

  // Impresión
  ws.pageSetup = { paperSize: 9, orientation: n > 7 ? 'landscape' : 'portrait', fitToPage: true, fitToWidth: 1, fitToHeight: 0, margins: { left: 0.4, right: 0.4, top: 0.5, bottom: 0.6, header: 0.3, footer: 0.3 } };
  ws.headerFooter = { oddFooter: `&L&8${String(nombreNegocio).replace(/&/g, '&&')} · ${ctx.pie || 'Informe de sucursal'}&R&8Página &P de &N` };
  return { ws, fila: 7 };
}

function bordeFino(E) { const l = { style: 'thin', color: { argb: argb(E.linea) } }; return { top: l, left: l, bottom: l, right: l }; }

/** Escribe encabezado + filas + (opcional) fila de totales. Devuelve la fila siguiente a la tabla. */
function escribirTabla(ctx, ws, filaIni, columnas, filas, { totales = null, congelar = true, filtro = true } = {}) {
  const { E } = ctx;
  const borde = bordeFino(E);
  const h = ws.getRow(filaIni);
  h.height = 30;
  columnas.forEach((c, i) => {
    const cell = h.getCell(i + 1);
    cell.value = c.header;
    cell.font = { name: 'Calibri', size: 10.5, bold: true, color: { argb: argb(E.textoSobreAcento) } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: argb(E.acento) } };
    cell.alignment = { vertical: 'middle', horizontal: c.num ? 'right' : (c.centro ? 'center' : 'left'), wrapText: true };
    cell.border = borde;
  });
  filas.forEach((f, r) => {
    const row = ws.getRow(filaIni + 1 + r);
    row.height = 18;
    columnas.forEach((c, i) => {
      const cell = row.getCell(i + 1);
      const v = f[c.key];
      cell.value = v === undefined ? null : v;
      cell.font = { name: 'Calibri', size: 10 };
      if (c.fmt) cell.numFmt = c.fmt;
      cell.alignment = { vertical: 'middle', horizontal: c.num ? 'right' : (c.centro ? 'center' : 'left') };
      cell.border = borde;
      if (r % 2 === 1) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: argb('F7F8FA') } };
    });
  });
  let fin = filaIni + filas.length;
  if (filas.length === 0) {
    const row = ws.getRow(filaIni + 1);
    ws.mergeCells(filaIni + 1, 1, filaIni + 1, columnas.length);
    const cell = row.getCell(1);
    cell.value = 'Sin datos en este período.';
    cell.font = { name: 'Calibri', size: 10, italic: true, color: { argb: argb(E.gris) } };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
    row.height = 24;
    fin = filaIni + 1;
  } else if (totales) {
    const row = ws.getRow(fin + 1);
    row.height = 22;
    columnas.forEach((c, i) => {
      const cell = row.getCell(i + 1);
      cell.value = totales[c.key] === undefined ? null : totales[c.key];
      cell.font = { name: 'Calibri', size: 10.5, bold: true };
      if (c.fmt) cell.numFmt = c.fmt;
      cell.alignment = { vertical: 'middle', horizontal: c.num ? 'right' : 'left' };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: argb(E.medio) } };
      cell.border = { top: { style: 'medium', color: { argb: argb(E.acento) } }, bottom: borde.bottom, left: borde.left, right: borde.right };
    });
    fin += 1;
  }
  if (congelar) ws.views = [{ state: 'frozen', ySplit: filaIni, showGridLines: false }];
  if (filtro && filas.length) ws.autoFilter = { from: { row: filaIni, column: 1 }, to: { row: filaIni + filas.length, column: columnas.length } };
  ws.pageSetup.printTitlesRow = `${filaIni}:${filaIni}`;
  return fin + 1;
}

function barraDatos(ws, ref, E) {
  ws.addConditionalFormatting({ ref, rules: [{ type: 'dataBar', priority: 1, cfvo: [{ type: 'num', value: 0 }, { type: 'max' }], color: { argb: argb(E.medio) }, gradient: false, showValue: true }] });
}

// ── Datos ───────────────────────────────────────────────────
const marcas = n => Array(n).fill('?').join(',');

function ventasDelPeriodo(db, ids, desde, hasta, conCostos) {
  const comps = db.prepare(`
    SELECT c.id, c.numero, c.tipo, c.fecha, c.total, c.subtotal, c.descuento, c.items, c.sucursal_id,
           TRIM(COALESCE(c.cliente_nombre,'') || ' ' || COALESCE(c.cliente_apellido,'')) AS cliente,
           COALESCE(NULLIF(c.vendedor_codigo,''), NULLIF(c.generado_por_usuario,''), '—') AS vendedor,
           COALESCE(s.nombre, 'Sin sucursal') AS sucursal
      FROM comprobantes c LEFT JOIN sucursales s ON s.id = c.sucursal_id
     WHERE c.estado NOT IN ('anulado','borrador') AND c.tipo IN ('factura','nota_entrega','nota_credito')
       AND date(c.fecha,'localtime') BETWEEN ? AND ? AND c.sucursal_id IN (${marcas(ids.length)})
     ORDER BY c.fecha, c.id`).all(desde, hasta, ...ids);
  const pagos = {};
  if (comps.length) {
    db.prepare(`SELECT comprobante_id, medio_pago, SUM(monto) AS monto FROM comprobante_pagos
                 WHERE comprobante_id IN (SELECT c.id FROM comprobantes c WHERE c.estado NOT IN ('anulado','borrador') AND c.tipo IN ('factura','nota_entrega','nota_credito')
                   AND date(c.fecha,'localtime') BETWEEN ? AND ? AND c.sucursal_id IN (${marcas(ids.length)}))
                 GROUP BY comprobante_id, medio_pago`).all(desde, hasta, ...ids)
      .forEach(p => { (pagos[p.comprobante_id] = pagos[p.comprobante_id] || []).push(p); });
  }
  const prods = {};
  const prod = id => prods[id] || (prods[id] = db.prepare('SELECT codigo, nombre, precio_costo FROM productos WHERE id=?').get(id) || null);
  const porProducto = {};
  const ventas = comps.map(c => {
    const signo = c.tipo === 'nota_credito' ? -1 : 1;
    const factor = c.subtotal > 0 ? Math.max(0, (c.subtotal - (c.descuento || 0)) / c.subtotal) : 1;
    let costo = 0;
    for (const i of parseItems(c.items)) {
      const cant = Number(i.cantidad) || 0, pu = Number(i.precio_unitario) || 0;
      if (cant <= 0) continue;
      const pid = pidDe(i), p = pid ? prod(pid) : null;
      const importe = pu * cant * factor, costoLinea = p ? (p.precio_costo || 0) * cant : 0;
      costo += costoLinea;
      const clave = pid ? 'p' + pid : 'd' + String(i.descripcion || i.nombre || 'Sin descripción');
      const acc = porProducto[clave] || (porProducto[clave] = { codigo: p ? p.codigo : '—', producto: p ? p.nombre : String(i.descripcion || i.nombre || 'Sin descripción'), unidades: 0, importe: 0, costo: 0 });
      acc.unidades += signo * cant; acc.importe += signo * importe; acc.costo += signo * costoLinea;
    }
    const pg = pagos[c.id] || [];
    return {
      ...c, signo, total: signo * (Number(c.total) || 0),
      costo: signo * costo,
      medios: pg.length ? pg.map(p => p.medio_pago).join(' + ') : 'Sin pago registrado',
      _pagos: pg,
      etiqueta: c.tipo === 'nota_credito' ? 'Nota de crédito' : (c.tipo === 'factura' ? 'Factura' : 'Nota de entrega'),
    };
  });
  return { ventas, productos: Object.values(porProducto).sort((a, b) => b.importe - a.importe) };
}

function stockActual(db, lugares, hayDeposito) {
  // lugares: [{ id, nombre, deposito }]
  const rows = db.prepare(`SELECT p.id, p.codigo, p.nombre, p.stock AS stock_deposito, p.stock_minimo, p.precio_costo, p.precio_venta,
                                  COALESCE(cat.nombre, p.categoria, '') AS categoria
                             FROM productos p LEFT JOIN categorias cat ON cat.id = p.categoria_id
                            WHERE COALESCE(p.visible,1) = 1 ORDER BY p.nombre`).all();
  const ss = {};
  db.prepare('SELECT producto_id, sucursal_id, cantidad FROM stock_sucursal').all().forEach(r => { (ss[r.producto_id] = ss[r.producto_id] || {})[r.sucursal_id] = r.cantidad; });
  return rows.map(r => {
    const f = { codigo: r.codigo, producto: r.nombre, categoria: r.categoria, minimo: r.stock_minimo || 0, costo: r.precio_costo || 0, precio: r.precio_venta || 0 };
    let total = 0;
    lugares.forEach(l => { const q = l.deposito ? (r.stock_deposito || 0) : ((ss[r.id] || {})[l.id] || 0); f['l' + l.id] = q; total += q; });
    f.total = total; f.valor = total * (r.precio_costo || 0);
    return f;
  });
}

// ── Informe ─────────────────────────────────────────────────
/**
 * opciones: { db, desde, hasta, sucursales:[{id,nombre}], todas:boolean, verCostos:boolean, taller:boolean,
 *             generadoPor, uploadsDir }
 * Devuelve un Buffer .xlsx
 */
async function construirInforme(op) {
  const { db, desde, hasta, sucursales, todas, verCostos, taller, generadoPor, uploadsDir } = op;
  const cfg = leerConfig(db);
  const E = crearEstilo(cfg);
  const wb = new ExcelJS.Workbook();
  wb.creator = 'SysTech';
  wb.created = new Date();
  const nombreNegocio = cfg.empresa_nombre || cfg.razon_social || 'Mi negocio';
  const datos = [cfg.empresa_direccion, cfg.empresa_telefono && 'Tel. ' + cfg.empresa_telefono, cfg.empresa_email, cfg.cuit && 'CUIT ' + cfg.cuit].filter(Boolean);
  const ids = sucursales.map(s => s.id);
  const nombreSuc = todas ? 'Todas las sucursales' : sucursales[0].nombre;
  const ctx = {
    wb, E, cfg, logo: prepararLogo(wb, cfg, uploadsDir), nombreNegocio,
    linea2: datos.join('   ·   ') || ' ',
    titulo: `Informe de sucursal — ${nombreSuc}`,
    periodo: `${dmy(desde)} al ${dmy(hasta)}`,
    emitido: new Date().toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' }) + (generadoPor ? ` · ${generadoPor}` : ''),
  };
  const { ventas, productos } = ventasDelPeriodo(db, ids, desde, hasta, verCostos);

  // ───── Resumen ─────
  {
    const { ws } = hojaConMembrete(ctx, 'Resumen', 'Resumen del período', [{ w: 26 }, { w: 16 }, { w: 18 }, { w: 18 }, { w: 18 }, { w: 18 }]);
    const soloVentas = ventas.filter(v => v.signo > 0), nc = ventas.filter(v => v.signo < 0);
    const neto = redondear(ventas.reduce((s, v) => s + v.total, 0));
    const devol = redondear(nc.reduce((s, v) => s - v.total, 0));
    const ticket = soloVentas.length ? redondear(soloVentas.reduce((s, v) => s + v.total, 0) / soloVentas.length) : 0;
    const margen = redondear(ventas.reduce((s, v) => s + v.total - v.costo, 0));
    const cajas = db.prepare(`SELECT COUNT(*) AS n, COALESCE(SUM(diferencia),0) AS dif FROM caja_sesiones WHERE date(fecha_apertura,'localtime') BETWEEN ? AND ? AND sucursal_id IN (${marcas(ids.length)})`).get(desde, hasta, ...ids);
    const tarjetas = [
      ['Ventas netas', neto, FMT_MONEDA], ['Comprobantes emitidos', soloVentas.length, FMT_ENTERO], ['Ticket promedio', ticket, FMT_MONEDA],
      ['Devoluciones (notas de crédito)', devol, FMT_MONEDA], verCostos ? ['Margen', margen, FMT_MONEDA] : ['Turnos de caja', cajas.n, FMT_ENTERO], ['Diferencia de caja acumulada', redondear(cajas.dif), FMT_MONEDA],
    ];
    const borde = bordeFino(E);
    [0, 1].forEach(fila => {
      const rl = 7 + fila * 3;
      ws.getRow(rl).height = 18; ws.getRow(rl + 1).height = 30; ws.getRow(rl + 2).height = 8;
      [0, 1, 2].forEach(k => {
        const [etq, val, fmt] = tarjetas[fila * 3 + k];
        // Tarjeta k ocupa 2 columnas: A:B, C:D, E:F
        const ca = 1 + k * 2, cb = ca + 1;
        ws.mergeCells(rl, ca, rl, cb); ws.mergeCells(rl + 1, ca, rl + 1, cb);
        const a = ws.getCell(rl, ca), b = ws.getCell(rl + 1, ca);
        a.value = etq; a.font = { name: 'Calibri', size: 9.5, color: { argb: argb(E.gris) } }; a.alignment = { vertical: 'bottom', horizontal: 'left', indent: 1 };
        b.value = val; b.numFmt = fmt; b.font = { name: 'Calibri', size: 17, bold: true, color: { argb: argb(E.acento) } }; b.alignment = { vertical: 'middle', horizontal: 'left', indent: 1 };
        for (let c = ca; c <= cb; c++) {
          [rl, rl + 1].forEach(r => { ws.getCell(r, c).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: argb('F7F8FA') } }; });
          ws.getCell(rl, c).border = { top: { style: 'medium', color: { argb: argb(E.acento) } }, left: c === ca ? borde.left : undefined, right: c === cb ? borde.right : undefined };
          ws.getCell(rl + 1, c).border = { bottom: borde.bottom, left: c === ca ? borde.left : undefined, right: c === cb ? borde.right : undefined };
        }
      });
    });
    let fila = 14;

    // Por sucursal (solo "Todas")
    if (todas) {
      ws.mergeCells(fila, 1, fila, 6);
      const tt = ws.getCell(fila, 1); tt.value = 'Por sucursal'; tt.font = { name: 'Calibri', size: 12, bold: true, color: { argb: argb(E.acento) } }; ws.getRow(fila).height = 22;
      const filas = sucursales.map(s => {
        const vs = ventas.filter(v => v.sucursal_id === s.id), sv = vs.filter(v => v.signo > 0);
        const tot = redondear(vs.reduce((a, v) => a + v.total, 0));
        return { suc: s.nombre, n: sv.length, total: tot, ticket: sv.length ? redondear(sv.reduce((a, v) => a + v.total, 0) / sv.length) : 0, devol: redondear(vs.filter(v => v.signo < 0).reduce((a, v) => a - v.total, 0)), margen: redondear(vs.reduce((a, v) => a + v.total - v.costo, 0)) };
      });
      const cols = [{ header: 'Sucursal', key: 'suc' }, { header: 'Comprobantes', key: 'n', num: true, fmt: FMT_ENTERO }, { header: 'Ventas netas', key: 'total', num: true, fmt: FMT_MONEDA }, { header: 'Ticket promedio', key: 'ticket', num: true, fmt: FMT_MONEDA }, { header: 'Devoluciones', key: 'devol', num: true, fmt: FMT_MONEDA }, ...(verCostos ? [{ header: 'Margen', key: 'margen', num: true, fmt: FMT_MONEDA }] : [])];
      const tot = { suc: 'Total', n: filas.reduce((s, f) => s + f.n, 0), total: redondear(filas.reduce((s, f) => s + f.total, 0)), devol: redondear(filas.reduce((s, f) => s + f.devol, 0)), margen: redondear(filas.reduce((s, f) => s + f.margen, 0)) };
      const ini = fila + 1;
      fila = escribirTabla(ctx, ws, ini, cols, filas, { totales: tot, congelar: false, filtro: false }) + 1;
      if (filas.length) barraDatos(ws, `C${ini + 1}:C${ini + filas.length}`, E);
    }

    // Por medio de pago
    ws.mergeCells(fila, 1, fila, 6);
    const t2 = ws.getCell(fila, 1); t2.value = 'Ventas por medio de pago'; t2.font = { name: 'Calibri', size: 12, bold: true, color: { argb: argb(E.acento) } }; ws.getRow(fila).height = 22;
    const medios = {};
    ventas.forEach(v => { if (!v._pagos.length) { medios['Sin pago registrado'] = (medios['Sin pago registrado'] || 0) + v.total; } v._pagos.forEach(p => { medios[p.medio_pago] = (medios[p.medio_pago] || 0) + v.signo * p.monto; }); });
    const totMed = Object.values(medios).reduce((a, b) => a + b, 0);
    const fm = Object.entries(medios).sort((a, b) => b[1] - a[1]).map(([m, t]) => ({ medio: m, total: redondear(t), pct: totMed ? t / totMed : 0 }));
    const iniM = fila + 1;
    fila = escribirTabla(ctx, ws, iniM, [{ header: 'Medio de pago', key: 'medio' }, { header: 'Importe', key: 'total', num: true, fmt: FMT_MONEDA }, { header: '% del total', key: 'pct', num: true, fmt: FMT_PCT }], fm, { totales: { medio: 'Total', total: redondear(totMed) }, congelar: false, filtro: false }) + 1;
    if (fm.length) barraDatos(ws, `C${iniM + 1}:C${iniM + fm.length}`, E);

    // Por día
    ws.mergeCells(fila, 1, fila, 6);
    const t3 = ws.getCell(fila, 1); t3.value = 'Ventas por día'; t3.font = { name: 'Calibri', size: 12, bold: true, color: { argb: argb(E.acento) } }; ws.getRow(fila).height = 22;
    const dias = {};
    ventas.forEach(v => { const f = fechaLocal(v.fecha); const k = f ? f.toISOString().slice(0, 10) : '—'; const d = dias[k] || (dias[k] = { n: 0, total: 0 }); if (v.signo > 0) d.n++; d.total += v.total; });
    const fd = Object.keys(dias).sort().map(k => ({ dia: new Date(k + 'T12:00:00Z'), n: dias[k].n, total: redondear(dias[k].total) }));
    const iniD = fila + 1;
    fila = escribirTabla(ctx, ws, iniD, [{ header: 'Día', key: 'dia', fmt: FMT_FECHA }, { header: 'Comprobantes', key: 'n', num: true, fmt: FMT_ENTERO }, { header: 'Ventas netas', key: 'total', num: true, fmt: FMT_MONEDA }], fd, { congelar: false, filtro: false }) + 1;
    if (fd.length) barraDatos(ws, `C${iniD + 1}:C${iniD + fd.length}`, E);

    ws.mergeCells(fila, 1, fila, 6);
    const nota = ws.getCell(fila, 1);
    nota.value = 'Incluye comprobantes emitidos (facturas y notas de entrega); las notas de crédito restan. No incluye presupuestos, borradores ni anulados.';
    nota.font = { name: 'Calibri', size: 9, italic: true, color: { argb: argb(E.gris) } };
    nota.alignment = { wrapText: true, vertical: 'top' }; ws.getRow(fila).height = 26;
    ws.views = [{ showGridLines: false }];
    ws.pageSetup.printTitlesRow = undefined;
  }

  // ───── Comparativo por sucursal (solo "Todas" y más de un local) ─────
  if (todas && sucursales.length > 1) {
    const cols = [
      { header: 'Sucursal', key: 'suc', w: 24 }, { header: 'Ventas netas', key: 'total', w: 17, num: true, fmt: FMT_MONEDA }, { header: '% del total', key: 'pct', w: 12, num: true, fmt: FMT_PCT },
      { header: 'Comprobantes', key: 'n', w: 14, num: true, fmt: FMT_ENTERO }, { header: 'Ticket promedio', key: 'ticket', w: 16, num: true, fmt: FMT_MONEDA },
      { header: 'Devoluciones', key: 'devol', w: 15, num: true, fmt: FMT_MONEDA },
      ...(verCostos ? [{ header: 'Margen', key: 'margen', w: 16, num: true, fmt: FMT_MONEDA }, { header: 'Margen %', key: 'mpct', w: 11, num: true, fmt: FMT_PCT }] : []),
      { header: 'Turnos de caja', key: 'turnos', w: 14, num: true, fmt: FMT_ENTERO }, { header: 'Diferencia de caja', key: 'dif', w: 17, num: true, fmt: FMT_MONEDA },
      ...(taller ? [{ header: 'Órdenes de taller', key: 'ords', w: 16, num: true, fmt: FMT_ENTERO }] : []),
    ];
    const { ws, fila } = hojaConMembrete(ctx, 'Comparativo', 'Comparativo entre sucursales', cols.map(c => ({ w: c.w })));
    const totalGral = ventas.reduce((a, v) => a + v.total, 0);
    const filas = sucursales.map(sc => {
      const vs = ventas.filter(v => v.sucursal_id === sc.id), sv = vs.filter(v => v.signo > 0);
      const tot = vs.reduce((a, v) => a + v.total, 0), mg = vs.reduce((a, v) => a + v.total - v.costo, 0);
      const cj = db.prepare('SELECT COUNT(*) AS n, COALESCE(SUM(diferencia),0) AS dif FROM caja_sesiones WHERE date(fecha_apertura,\'localtime\') BETWEEN ? AND ? AND sucursal_id = ?').get(desde, hasta, sc.id);
      let ords = 0;
      if (taller) ords = db.prepare('SELECT COUNT(*) AS n FROM ordenes WHERE date(fecha_ingreso,\'localtime\') BETWEEN ? AND ? AND sucursal_id = ?').get(desde, hasta, sc.id).n;
      return { suc: sc.nombre, total: redondear(tot), pct: totalGral ? tot / totalGral : 0, n: sv.length,
        ticket: sv.length ? redondear(sv.reduce((a, v) => a + v.total, 0) / sv.length) : 0,
        devol: redondear(vs.filter(v => v.signo < 0).reduce((a, v) => a - v.total, 0)),
        margen: redondear(mg), mpct: tot ? mg / tot : 0, turnos: cj.n, dif: redondear(cj.dif), ords };
    });
    const sum = k => redondear(filas.reduce((a, f) => a + f[k], 0));
    const totales = { suc: 'Total', total: sum('total'), n: sum('n'), devol: sum('devol'), margen: sum('margen'), turnos: sum('turnos'), dif: sum('dif'), ords: sum('ords') };
    const fin = escribirTabla(ctx, ws, fila, cols, filas, { totales });
    if (filas.length) barraDatos(ws, `B${fila + 1}:B${fila + filas.length}`, E);
    ws.mergeCells(fin + 1, 1, fin + 1, Math.min(cols.length, 6));
    const nt = ws.getCell(fin + 1, 1);
    nt.value = 'Las ventas del Depósito Central no se muestran: el depósito no vende por sí solo. Las notas de crédito restan.';
    nt.font = { name: 'Calibri', size: 9, italic: true, color: { argb: argb(E.gris) } };
  }

  // ───── Ventas ─────
  {
    const cols = [
      { header: 'Fecha', key: 'fecha', w: 17, fmt: FMT_FECHAHORA }, { header: 'Número', key: 'numero', w: 22 }, { header: 'Tipo', key: 'tipo', w: 16 },
      { header: 'Cliente', key: 'cliente', w: 26 }, { header: 'Vendedor', key: 'vendedor', w: 16 }, { header: 'Medio de pago', key: 'medios', w: 24 },
      ...(todas ? [{ header: 'Sucursal', key: 'sucursal', w: 18 }] : []),
      { header: 'Total', key: 'total', w: 16, num: true, fmt: FMT_MONEDA },
    ];
    const { ws, fila } = hojaConMembrete(ctx, 'Ventas', 'Detalle de ventas', cols.map(c => ({ w: c.w })));
    const filas = ventas.map(v => ({ fecha: fechaLocal(v.fecha), numero: v.numero, tipo: v.etiqueta, cliente: v.cliente || 'Consumidor final', vendedor: v.vendedor, medios: v.medios, sucursal: v.sucursal, total: redondear(v.total) }));
    escribirTabla(ctx, ws, fila, cols, filas, { totales: { fecha: 'Total', total: redondear(ventas.reduce((s, v) => s + v.total, 0)) } });
  }

  // ───── Productos vendidos ─────
  {
    const cols = [
      { header: 'Código', key: 'codigo', w: 14 }, { header: 'Producto', key: 'producto', w: 38 }, { header: 'Unidades', key: 'unidades', w: 12, num: true, fmt: FMT_ENTERO },
      { header: 'Importe', key: 'importe', w: 16, num: true, fmt: FMT_MONEDA },
      ...(verCostos ? [{ header: 'Costo', key: 'costo', w: 16, num: true, fmt: FMT_MONEDA }, { header: 'Margen', key: 'margen', w: 16, num: true, fmt: FMT_MONEDA }, { header: 'Margen %', key: 'margenPct', w: 11, num: true, fmt: FMT_PCT }] : []),
      { header: '% de las ventas', key: 'pct', w: 15, num: true, fmt: FMT_PCT },
    ];
    const { ws, fila } = hojaConMembrete(ctx, 'Productos vendidos', 'Productos vendidos en el período (ordenados por importe)', cols.map(c => ({ w: c.w })));
    const totImp = productos.reduce((s, p) => s + p.importe, 0);
    const filas = productos.map(p => ({ codigo: p.codigo, producto: p.producto, unidades: p.unidades, importe: redondear(p.importe), costo: redondear(p.costo), margen: redondear(p.importe - p.costo), margenPct: p.importe ? (p.importe - p.costo) / p.importe : 0, pct: totImp ? p.importe / totImp : 0 }));
    const tot = { codigo: 'Total', unidades: productos.reduce((s, p) => s + p.unidades, 0), importe: redondear(totImp), costo: redondear(productos.reduce((s, p) => s + p.costo, 0)), margen: redondear(totImp - productos.reduce((s, p) => s + p.costo, 0)) };
    escribirTabla(ctx, ws, fila, cols, filas, { totales: tot });
    if (filas.length) barraDatos(ws, `${String.fromCharCode(64 + cols.length)}${fila + 1}:${String.fromCharCode(64 + cols.length)}${fila + filas.length}`, E);
  }

  // ───── Stock actual ─────
  {
    const lugares = [];
    if (todas) lugares.push({ id: 0, nombre: 'Depósito Central', deposito: true });
    sucursales.forEach(s => lugares.push({ id: s.id, nombre: s.nombre, deposito: false }));
    const stock = stockActual(db, lugares, todas);
    const cols = [
      { header: 'Código', key: 'codigo', w: 14 }, { header: 'Producto', key: 'producto', w: 36 }, { header: 'Categoría', key: 'categoria', w: 18 },
      ...lugares.map(l => ({ header: l.nombre, key: 'l' + l.id, w: 13, num: true, fmt: FMT_ENTERO })),
      ...(lugares.length > 1 ? [{ header: 'Total', key: 'total', w: 11, num: true, fmt: FMT_ENTERO }] : []),
      { header: 'Mínimo', key: 'minimo', w: 10, num: true, fmt: FMT_ENTERO },
      ...(verCostos ? [{ header: 'Costo', key: 'costo', w: 14, num: true, fmt: FMT_MONEDA }, { header: 'Valor a costo', key: 'valor', w: 16, num: true, fmt: FMT_MONEDA }] : []),
      { header: 'Precio de venta', key: 'precio', w: 15, num: true, fmt: FMT_MONEDA },
      { header: 'Estado', key: 'estado', w: 12, centro: true },
    ];
    const { ws, fila } = hojaConMembrete(ctx, 'Stock actual', todas ? 'Stock actual por lugar (a hoy)' : `Stock actual de ${nombreSuc} (a hoy)`, cols.map(c => ({ w: c.w })));
    const filas = stock.map(s => ({ ...s, estado: s.total <= 0 ? 'Sin stock' : (s.total <= s.minimo ? 'Reponer' : 'OK') }));
    const tot = { codigo: 'Total', total: filas.reduce((a, f) => a + f.total, 0), valor: redondear(filas.reduce((a, f) => a + f.valor, 0)) };
    lugares.forEach(l => { tot['l' + l.id] = filas.reduce((a, f) => a + (f['l' + l.id] || 0), 0); });
    const fin = escribirTabla(ctx, ws, fila, cols, filas, { totales: tot });
    // Resaltar lo que hay que reponer
    const iEst = cols.findIndex(c => c.key === 'estado') + 1;
    filas.forEach((f, r) => {
      if (f.estado === 'OK') return;
      const cell = ws.getRow(fila + 1 + r).getCell(iEst);
      const sin = f.estado === 'Sin stock';
      cell.font = { name: 'Calibri', size: 10, bold: true, color: { argb: argb(sin ? '9B1C1C' : '8A5A00') } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: argb(sin ? 'FDE2E2' : 'FFF1CC') } };
    });
    void fin;
  }

  // ───── Caja ─────
  {
    const sesiones = db.prepare(`
      SELECT cs.*, COALESCE(s.nombre,'—') AS sucursal FROM caja_sesiones cs LEFT JOIN sucursales s ON s.id = cs.sucursal_id
       WHERE date(cs.fecha_apertura,'localtime') BETWEEN ? AND ? AND cs.sucursal_id IN (${marcas(ids.length)}) ORDER BY cs.fecha_apertura`).all(desde, hasta, ...ids);
    const cols = [
      { header: 'Turno', key: 'id', w: 8, centro: true }, { header: 'Apertura', key: 'ap', w: 18, fmt: FMT_FECHAHORA }, { header: 'Cierre', key: 'ci', w: 18, fmt: FMT_FECHAHORA },
      ...(todas ? [{ header: 'Sucursal', key: 'sucursal', w: 18 }] : []),
      { header: 'Abrió', key: 'uap', w: 14 }, { header: 'Cerró', key: 'uci', w: 14 },
      { header: 'Fondo inicial', key: 'fondo', w: 15, num: true, fmt: FMT_MONEDA }, { header: 'Esperado', key: 'esp', w: 15, num: true, fmt: FMT_MONEDA },
      { header: 'Contado', key: 'real', w: 15, num: true, fmt: FMT_MONEDA }, { header: 'Diferencia', key: 'dif', w: 15, num: true, fmt: FMT_MONEDA }, { header: 'Estado', key: 'estado', w: 11, centro: true },
    ];
    const { ws, fila } = hojaConMembrete(ctx, 'Caja', 'Turnos de caja del período', cols.map(c => ({ w: c.w })));
    const filas = sesiones.map(s => ({ id: s.id, ap: fechaLocal(s.fecha_apertura), ci: fechaLocal(s.fecha_cierre), sucursal: s.sucursal, uap: s.usuario_apertura || '', uci: s.usuario_cierre || '', fondo: s.monto_apertura || 0, esp: s.monto_cierre_esperado, real: s.monto_cierre_real, dif: s.diferencia, estado: s.estado === 'abierta' ? 'Abierta' : 'Cerrada' }));
    escribirTabla(ctx, ws, fila, cols, filas, { totales: { id: 'Total', dif: redondear(sesiones.reduce((a, s) => a + (s.diferencia || 0), 0)) } });
    const iDif = cols.findIndex(c => c.key === 'dif') + 1;
    filas.forEach((f, r) => {
      if (!f.dif) return;
      ws.getRow(fila + 1 + r).getCell(iDif).font = { name: 'Calibri', size: 10, bold: true, color: { argb: argb(f.dif < 0 ? '9B1C1C' : '1A6B3A') } };
    });
  }

  // ───── Órdenes de taller ─────
  if (taller) {
    const filtroSuc = todas ? `(o.sucursal_id IN (${marcas(ids.length)}) OR o.sucursal_id IS NULL)` : `o.sucursal_id IN (${marcas(ids.length)})`;
    const ords = db.prepare(`
      SELECT o.*, COALESCE(cl.nombre,'—') AS cliente, COALESCE(s.nombre,'Sin sucursal') AS sucursal
        FROM ordenes o LEFT JOIN clientes cl ON cl.id = o.cliente_id LEFT JOIN sucursales s ON s.id = o.sucursal_id
       WHERE date(o.fecha_ingreso,'localtime') BETWEEN ? AND ? AND ${filtroSuc} ORDER BY o.fecha_ingreso`).all(desde, hasta, ...ids);
    const cols = [
      { header: 'Orden', key: 'numero', w: 14 }, { header: 'Ingreso', key: 'ing', w: 17, fmt: FMT_FECHA }, { header: 'Entrega', key: 'ent', w: 17, fmt: FMT_FECHA },
      { header: 'Cliente', key: 'cliente', w: 24 }, { header: 'Equipo', key: 'equipo', w: 24 }, { header: 'Estado', key: 'estado', w: 14 }, { header: 'Técnico', key: 'tecnico', w: 14 },
      ...(todas ? [{ header: 'Sucursal', key: 'sucursal', w: 18 }] : []),
      { header: 'Total', key: 'total', w: 15, num: true, fmt: FMT_MONEDA }, { header: 'Cobrada', key: 'cobrado', w: 10, centro: true },
    ];
    const { ws, fila } = hojaConMembrete(ctx, 'Órdenes de taller', 'Órdenes de servicio ingresadas en el período', cols.map(c => ({ w: c.w })));
    const filas = ords.map(o => ({ numero: o.numero, ing: fechaLocal(o.fecha_ingreso), ent: fechaLocal(o.fecha_entrega), cliente: o.cliente, equipo: [o.equipo, o.marca, o.modelo].filter(Boolean).join(' '), estado: o.estado, tecnico: o.tecnico || '', sucursal: o.sucursal, total: redondear(o.total), cobrado: o.cobrado ? 'Sí' : 'No' }));
    escribirTabla(ctx, ws, fila, cols, filas, { totales: { numero: 'Total', total: redondear(ords.reduce((a, o) => a + (o.total || 0), 0)) } });
  }

  // Datos de control (para una futura herramienta que junte informes de varias sucursales)
  wb.title = `Informe de sucursal — ${nombreSuc}`;
  wb.subject = `${desde} a ${hasta}`;
  wb.description = JSON.stringify({ sistema: 'SysTech', informe: 'sucursal', desde, hasta, sucursales: sucursales.map(s => ({ id: s.id, nombre: s.nombre })), emitido: new Date().toISOString() });
  return wb.xlsx.writeBuffer();
}

// ── Planilla de cierre de caja (un turno) ───────────────────
const fmtFechaHora = txt => {
  if (!txt) return '';
  const d = new Date(String(txt).includes('T') ? txt : String(txt).replace(' ', 'T') + 'Z');
  return isNaN(d) ? String(txt) : d.toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' });
};

/**
 * opciones: { db, sesion, sucursalNombre, detalle:[{medio,esperado,contado,diferencia}], ventasPorTipo:[{label,cantidad,total}],
 *             generadoPor, uploadsDir }
 * Devuelve un Buffer .xlsx (misma estética y membrete que el informe de sucursal; sin Python).
 */
async function construirCierreCaja(op) {
  const { db, sesion, sucursalNombre, detalle, ventasPorTipo, generadoPor, uploadsDir } = op;
  const cfg = leerConfig(db);
  const E = crearEstilo(cfg);
  const wb = new ExcelJS.Workbook();
  wb.creator = 'SysTech'; wb.created = new Date();
  const nombreNegocio = cfg.empresa_nombre || cfg.razon_social || 'Mi negocio';
  const datos = [cfg.empresa_direccion, cfg.empresa_telefono && 'Tel. ' + cfg.empresa_telefono, cfg.empresa_email, cfg.cuit && 'CUIT ' + cfg.cuit].filter(Boolean);
  const ctx = {
    wb, E, cfg, logo: prepararLogo(wb, cfg, uploadsDir), nombreNegocio, linea2: datos.join('   ·   ') || ' ',
    titulo: `Planilla de cierre de caja — Turno N.º ${sesion.id}`,
    periodo: '', pie: 'Cierre de caja',
    emitido: new Date().toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' }) + (generadoPor ? ` · ${generadoPor}` : ''),
  };
  const { ws } = hojaConMembrete(ctx, 'Cierre de Caja', sucursalNombre ? `Sucursal: ${sucursalNombre}` : 'Cierre de caja', [{ w: 30 }, { w: 22 }, { w: 24 }, { w: 22 }]);
  const borde = bordeFino(E);
  let fila = 7;

  // Datos del turno
  const info = [
    ['Apertura', fmtFechaHora(sesion.fecha_apertura)],
    ['Cierre', sesion.fecha_cierre ? fmtFechaHora(sesion.fecha_cierre) : '— turno todavía abierto —'],
    ['Cajero que abrió', sesion.usuario_apertura || ''],
    ['Cajero que cierra', sesion.usuario_cierre || sesion.usuario_apertura || ''],
  ];
  info.forEach(([k, v]) => {
    ws.getCell(fila, 1).value = k; ws.getCell(fila, 1).font = { name: 'Calibri', size: 10.5, bold: true };
    ws.mergeCells(fila, 2, fila, 4);
    ws.getCell(fila, 2).value = v; ws.getCell(fila, 2).font = { name: 'Calibri', size: 10.5 };
    ws.getRow(fila).height = 18;
    fila++;
  });
  fila++;

  const titulo = txt => {
    ws.mergeCells(fila, 1, fila, 4);
    const c = ws.getCell(fila, 1); c.value = txt;
    c.font = { name: 'Calibri', size: 12, bold: true, color: { argb: argb(E.acento) } };
    ws.getRow(fila).height = 22; fila++;
  };

  // Ventas del turno
  titulo('Ventas del turno');
  const totalVentas = redondear(ventasPorTipo.reduce((a, v) => a + (Number(v.total) || 0), 0));
  fila = escribirTabla(ctx, ws, fila, [{ header: 'Tipo de comprobante', key: 'tipo' }, { header: 'Cantidad', key: 'n', num: true, fmt: FMT_ENTERO }, { header: 'Total', key: 'total', num: true, fmt: FMT_MONEDA }],
    ventasPorTipo.map(v => ({ tipo: v.label || v.tipo, n: v.cantidad, total: redondear(v.total) })),
    { totales: { tipo: 'Total ventas', total: totalVentas }, congelar: false, filtro: false }) + 1;

  // Arqueo
  titulo('Arqueo por medio de pago');
  const abierto = detalle.every(d => d.contado === null || d.contado === undefined);
  const filas = detalle.map(d => ({
    medio: d.medio, esperado: redondear(d.esperado),
    contado: d.contado === null || d.contado === undefined ? null : redondear(d.contado),
    dif: d.contado === null || d.contado === undefined ? null : redondear(d.diferencia !== undefined && d.diferencia !== null ? d.diferencia : d.contado - d.esperado),
  }));
  const totEsp = redondear(filas.reduce((a, f) => a + f.esperado, 0));
  const totCon = redondear(filas.reduce((a, f) => a + (f.contado || 0), 0));
  const iniA = fila;
  fila = escribirTabla(ctx, ws, fila, [{ header: 'Medio de pago', key: 'medio' }, { header: 'Esperado (sistema)', key: 'esperado', num: true, fmt: FMT_MONEDA }, { header: 'Contado por el cajero', key: 'contado', num: true, fmt: FMT_MONEDA }, { header: 'Diferencia', key: 'dif', num: true, fmt: FMT_MONEDA }],
    filas, { totales: abierto ? { medio: 'Total', esperado: totEsp } : { medio: 'Total', esperado: totEsp, contado: totCon, dif: redondear(totCon - totEsp) }, congelar: false, filtro: false }) + 1;
  filas.forEach((f, i) => {
    if (f.dif && Math.abs(f.dif) > 0.5) ws.getRow(iniA + 1 + i).getCell(4).font = { name: 'Calibri', size: 10, bold: true, color: { argb: argb(f.dif < 0 ? '9B1C1C' : '1A6B3A') } };
  });
  if (abierto) {
    ws.mergeCells(fila - 1, 1, fila - 1, 4);
    const n = ws.getCell(fila - 1, 1); n.value = 'El turno todavía está abierto: el contado y la diferencia se completan al cerrar la caja.';
    n.font = { name: 'Calibri', size: 9.5, italic: true, color: { argb: argb(E.gris) } };
    fila++;
  }

  // Firma
  fila += 1;
  ws.mergeCells(fila, 1, fila, 4);
  const cert = ws.getCell(fila, 1);
  cert.value = 'Certifico que los valores detallados son los que conté físicamente al cerrar este turno de caja.';
  cert.font = { name: 'Calibri', size: 10, italic: true }; cert.alignment = { wrapText: true, vertical: 'top' };
  ws.getRow(fila).height = 28;
  fila += 3;
  const linea = { bottom: { style: 'thin', color: { argb: argb('333333' )} } };
  ws.getCell(fila, 1).border = linea; ws.getCell(fila, 2).border = linea;
  ws.mergeCells(fila, 3, fila, 4); ws.getCell(fila, 3).border = linea; ws.getCell(fila, 4).border = linea;
  fila++;
  ws.getCell(fila, 1).value = `Firma y aclaración — ${sesion.usuario_cierre || sesion.usuario_apertura || ''}`;
  ws.getCell(fila, 1).font = { name: 'Calibri', size: 9, color: { argb: argb(E.gris) } };
  ws.mergeCells(fila, 3, fila, 4);
  ws.getCell(fila, 3).value = 'Fecha y hora';
  ws.getCell(fila, 3).font = { name: 'Calibri', size: 9, color: { argb: argb(E.gris) } };
  ws.pageSetup.printTitlesRow = undefined;
  ws.views = [{ showGridLines: false }];
  void borde;
  return wb.xlsx.writeBuffer();
}

module.exports = { construirInforme, construirCierreCaja };
