﻿# SysTech - instalacion automatica (se corre sola la primera vez)
#  1) Si la PC no tiene Node.js, baja una copia "portable" (sin permisos de administrador)
#  2) Instala lo que necesita el sistema
#  3) Crea el icono en el escritorio y abre SysTech
param([switch]$NoLanzar)
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $dir
$rt = Join-Path $dir 'runtime\node'
$nodeLocal = Join-Path $rt 'node.exe'

function Fallo($msg) {
  Write-Host ''
  Write-Host '================================================' -ForegroundColor Red
  Write-Host $msg -ForegroundColor Red
  Write-Host '================================================' -ForegroundColor Red
  Write-Host 'Revisa la conexion a internet y volve a abrir SysTech.'
  Read-Host 'Presiona Enter para cerrar'
  exit 1
}

try {
  Write-Host 'SysTech - preparando todo (solo la primera vez)...' -ForegroundColor Cyan
  Write-Host ''

  # 1) Node.js
  $hayNode = (Test-Path $nodeLocal) -or [bool](Get-Command node -ErrorAction SilentlyContinue)
  if (-not $hayNode) {
    Write-Host '1/3  Descargando Node.js (una sola vez, ~30 MB)...'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $base = 'https://nodejs.org/dist/latest-v24.x/'
    $sums = (Invoke-WebRequest -UseBasicParsing ($base + 'SHASUMS256.txt')).Content
    $linea = ($sums -split "`n" | Where-Object { $_ -match 'node-v[\d\.]+-win-x64\.zip\s*$' } | Select-Object -First 1)
    if (-not $linea) { Fallo 'No pude encontrar la descarga de Node.js.' }
    $partes = $linea.Trim() -split '\s+'
    $hashEsperado = $partes[0].ToLower(); $archivo = $partes[1]
    $tmp = Join-Path $env:TEMP $archivo
    Invoke-WebRequest -UseBasicParsing ($base + $archivo) -OutFile $tmp
    $hash = (Get-FileHash $tmp -Algorithm SHA256).Hash.ToLower()
    if ($hash -ne $hashEsperado) { Remove-Item $tmp -Force; Fallo 'La descarga de Node.js llego dañada. Probá de nuevo.' }
    $tmpDir = Join-Path $env:TEMP ('systech-node-' + [guid]::NewGuid().ToString('N'))
    Expand-Archive -LiteralPath $tmp -DestinationPath $tmpDir -Force
    $carpeta = Get-ChildItem $tmpDir -Directory | Select-Object -First 1
    New-Item -ItemType Directory -Force -Path (Join-Path $dir 'runtime') | Out-Null
    if (Test-Path $rt) { Remove-Item $rt -Recurse -Force }
    Move-Item $carpeta.FullName $rt
    Remove-Item $tmp, $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host '     Node.js listo.' -ForegroundColor Green
  } else {
    Write-Host '1/3  Node.js ya esta disponible.' -ForegroundColor Green
  }
  if (Test-Path $nodeLocal) { $env:Path = $rt + ';' + $env:Path }

  # 2) Dependencias
  if (-not (Test-Path (Join-Path $dir 'node_modules'))) {
    Write-Host '2/3  Instalando lo necesario (1-2 minutos, no cierres esta ventana)...'
    & cmd /c 'npm install --omit=dev --no-audit --no-fund'
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path (Join-Path $dir 'node_modules'))) { Fallo 'No se pudo instalar lo necesario.' }
    Write-Host '     Listo.' -ForegroundColor Green
  } else {
    Write-Host '2/3  Ya estaba instalado.' -ForegroundColor Green
  }

  # 3) Icono en el escritorio
  Write-Host '3/3  Creando el icono en el escritorio...'
  $desk = [Environment]::GetFolderPath('Desktop')
  $lnkPath = Join-Path $desk 'SysTech.lnk'
  if (-not (Test-Path $lnkPath)) {
    $ws = New-Object -ComObject WScript.Shell
    $l = $ws.CreateShortcut($lnkPath)
    $l.TargetPath = 'wscript.exe'
    $l.Arguments = '"' + (Join-Path $dir 'SysTech.vbs') + '"'
    $l.WorkingDirectory = $dir
    $l.IconLocation = (Join-Path $dir 'SysTech.ico')
    $l.Description = 'SysTech'
    $l.Save()
  }
  Write-Host ''
  Write-Host 'Todo listo. Desde ahora entras con el icono SysTech del escritorio.' -ForegroundColor Green
  Start-Sleep -Seconds 2
  if (-not $NoLanzar) { Start-Process 'wscript.exe' ('"' + (Join-Path $dir 'SysTech.vbs') + '"') }
  exit 0
} catch {
  Fallo ('Algo salio mal: ' + $_.Exception.Message)
}
