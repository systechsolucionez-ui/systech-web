@echo off
cd /d "%~dp0"
set PUERTO=3000
if exist puerto.txt set /p PUERTO=<puerto.txt
powershell -NoProfile -WindowStyle Hidden -Command "Get-NetTCPConnection -LocalPort %PUERTO% -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }"
ping -n 3 127.0.0.1 >nul
start "" wscript.exe "%~dp0SysTech.vbs"
exit
