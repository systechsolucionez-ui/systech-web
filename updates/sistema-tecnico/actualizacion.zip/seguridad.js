// ─── SEGURIDAD BASE ───────────────────────────────────────────────────────────
// Piezas de seguridad compartidas por server.js y tenancy.js.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');

// ── Contraseñas ───────────────────────────────────────────────────────────────
// Antes se guardaba SHA-256 sin sal: dos usuarios con la misma clave tenían el
// mismo hash y se rompe en segundos con tablas precalculadas. Ahora scrypt con
// sal propia por usuario. Los hashes viejos siguen funcionando una vez más y se
// reemplazan solos en el siguiente login correcto (migración transparente).
function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  const h = crypto.scryptSync(String(pw), salt, 64).toString('hex');
  return `scrypt$${salt}$${h}`;
}

function hashLegacy(pw) {
  return crypto.createHash('sha256').update(String(pw)).digest('hex');
}

function verificarPassword(pw, guardado) {
  if (!guardado || pw === undefined || pw === null) return { ok: false, legacy: false };
  if (guardado.startsWith('scrypt$')) {
    const [, salt, h] = guardado.split('$');
    const calc = crypto.scryptSync(String(pw), salt, 64);
    const esperado = Buffer.from(h, 'hex');
    return { ok: esperado.length === calc.length && crypto.timingSafeEqual(calc, esperado), legacy: false };
  }
  const a = Buffer.from(hashLegacy(pw));
  const b = Buffer.from(guardado);
  return { ok: a.length === b.length && crypto.timingSafeEqual(a, b), legacy: true };
}

// Mínimo razonable para una contraseña nueva
function validarPasswordNueva(pw) {
  if (typeof pw !== 'string' || pw.length < 8) return 'La contraseña nueva debe tener al menos 8 caracteres.';
  if (/^(admin123|systech2026|12345678|password)$/i.test(pw)) return 'Esa contraseña es demasiado común. Elegí otra.';
  return null;
}

// ── Fechas: nunca se pegan en una consulta SQL sin validar ────────────────────
function soloFecha(s) {
  const v = String(s || '');
  return /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : null;
}

// ── Límite de intentos de login (en memoria) ──────────────────────────────────
const intentos = new Map(); // clave -> { fallos, hasta }
const MAX_FALLOS = 5;
const BLOQUEO_MS = 5 * 60 * 1000;

function loginBloqueado(clave) {
  const e = intentos.get(clave);
  if (!e || !e.hasta) return 0;
  if (Date.now() >= e.hasta) { intentos.delete(clave); return 0; }
  return Math.ceil((e.hasta - Date.now()) / 60000); // minutos que faltan
}
function loginFallo(clave) {
  const e = intentos.get(clave) || { fallos: 0, hasta: 0 };
  e.fallos += 1;
  if (e.fallos >= MAX_FALLOS) e.hasta = Date.now() + BLOQUEO_MS;
  intentos.set(clave, e);
}
function loginOk(clave) { intentos.delete(clave); }
// Claves con formato "taller|ip|usuario". Para que el admin (o el distribuidor) pueda ver y levantar bloqueos.
function bloqueosActivos(taller) {
  const out = [], t = Date.now();
  for (const [k, e] of intentos) {
    const [tl, ip, ...u] = k.split('|');
    if (tl === taller && e.hasta && e.hasta > t) out.push({ usuario: u.join('|'), ip, minutos: Math.ceil((e.hasta - t) / 60000) });
  }
  return out;
}
function desbloquear(taller, usuario) { // usuario vacío = todos los de ese taller
  let n = 0;
  for (const k of [...intentos.keys()]) {
    const [tl, , ...u] = k.split('|');
    if (tl === taller && (!usuario || u.join('|') === String(usuario).toLowerCase())) { intentos.delete(k); n++; }
  }
  return n;
}
setInterval(() => { const t = Date.now(); for (const [k, e] of intentos) if (e.hasta && t > e.hasta) intentos.delete(k); }, 10 * 60 * 1000).unref();

// ── Encabezados de seguridad ──────────────────────────────────────────────────
function encabezadosSeguridad(req, res, next) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');           // la app usa iframes propios
  res.setHeader('Referrer-Policy', 'no-referrer');          // el token viaja en algunas URLs: que no se filtre
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(self), geolocation=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  next();
}

// ── Clave de cifrado de accesos guardados ─────────────────────────────────────
// Antes estaba escrita en el código (cualquiera con el zip podía descifrar).
// Ahora: variable de entorno, o un secreto aleatorio propio de cada instalación
// que se genera la primera vez y vive en data/ (nunca viaja en el zip).
function claveCifrado() {
  if (process.env.SYSTECH_CLAVE_CIFRADO) {
    return crypto.createHash('sha256').update(process.env.SYSTECH_CLAVE_CIFRADO).digest();
  }
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  const archivo = path.join(DATA_DIR, '.clave-cifrado');
  if (!fs.existsSync(archivo)) fs.writeFileSync(archivo, crypto.randomBytes(32).toString('hex'), { mode: 0o600 });
  return crypto.createHash('sha256').update(fs.readFileSync(archivo, 'utf8').trim()).digest();
}
// Solo para leer lo guardado antes del cambio y volver a cifrarlo con la clave nueva
const CLAVE_CIFRADO_ANTERIOR = crypto.createHash('sha256').update('systech-recursos-2026').digest();

module.exports = {
  hashPassword, verificarPassword, validarPasswordNueva, hashLegacy,
  soloFecha, loginBloqueado, loginFallo, loginOk, bloqueosActivos, desbloquear,
  encabezadosSeguridad, claveCifrado, CLAVE_CIFRADO_ANTERIOR,
};
