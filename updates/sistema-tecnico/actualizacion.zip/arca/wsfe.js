// ─── WSFE — Web Service de Facturación Electrónica ARCA/AFIP ─────────────────
// 1.6.4: consulta de comprobantes autorizados (recuperar un CAE no guardado).
// 1.6.3: conexión con el servidor de facturación de ARCA (clave DH corta).
// 1.6.2: Factura C sin bloque de IVA, condición frente al IVA del receptor (RG 5616), fecha de Argentina,
// errores y observaciones de ARCA con su mensaje real.
const axios  = require('axios');
const xml2js = require('xml2js');
const https  = require('https');

// 1.6.3: el servidor de facturación de ARCA (servicios1.afip.gov.ar) todavía usa una clave Diffie-Hellman corta
// que el Node actual rechaza ("dh key too small"). Solo para las conexiones con ARCA se acepta ese cifrado viejo;
// el resto del sistema sigue con la seguridad normal.
const AGENTE_ARCA = new https.Agent({ ciphers: 'DEFAULT@SECLEVEL=0', minDHSize: 512, keepAlive: true });

const WSFE_URL_PROD = 'https://servicios1.afip.gov.ar/wsfev1/service.asmx';
const WSFE_URL_TEST = 'https://wswhomo.afip.gov.ar/wsfev1/service.asmx';

// Tabla oficial de códigos de comprobante AFIP/ARCA (tipo_cbte del WSFE) —
// estable desde hace años, no cambia con la rebautización AFIP→ARCA de 2024.
const TIPO_COMP = {
  'factura_c_monotributo': 11,
  'factura_b':              6,
  'factura_a':              1,
  'factura_c':             11,
  'nota_credito_a':         3,
  'nota_credito_b':         8,
  'nota_credito_c':        13,
  'nota_debito_a':          2,
  'nota_debito_b':          7,
  'nota_debito_c':         12,
  'presupuesto':            0,  // No va a ARCA
  'nota_entrega':           0,  // Remito — tampoco es un comprobante fiscal, no va a ARCA
};

const TIPO_DOC = { 'CUIT':80, 'CUIL':86, 'DNI':96, 'Pasaporte':94, 'SinDoc':99 };
const TIPO_IVA = { 21: 5, 10.5: 4, 27: 6, 0: 3 };

// 1.6.2: ARCA a veces responde con error SOAP (HTTP 500): se muestra su mensaje en vez de "status code 500".
async function callWSFE(soap, accion, produccion) {
  const url = produccion ? WSFE_URL_PROD : WSFE_URL_TEST;
  let res;
  try {
    res = await axios.post(url, soap, {
      headers: {
        'Content-Type': 'text/xml; charset=UTF-8',
        'SOAPAction': `http://ar.gov.afip.dif.FEV1/${accion}`
      },
      timeout: 30000,
      httpsAgent: AGENTE_ARCA
    });
  } catch (e) {
    if (e && (e.code === 'EPROTO' || /SSL|dh key/i.test(e.message || ''))) throw new Error('No se pudo abrir la conexión segura con ARCA (' + (e.message || e.code) + '). Actualizá SysTech a la última versión.');
    const xml = e && e.response && e.response.data;
    const m = typeof xml === 'string' && xml.match(/<faultstring>([\s\S]*?)<\/faultstring>/);
    if (m) throw new Error('ARCA respondió: ' + m[1].trim());
    if (e && (e.code === 'ECONNABORTED' || e.code === 'ETIMEDOUT')) throw new Error('ARCA no respondió a tiempo. Probá de nuevo en unos minutos.');
    if (e && (e.code === 'ENOTFOUND' || e.code === 'ECONNREFUSED' || e.code === 'EAI_AGAIN')) throw new Error('No hay conexión con los servidores de ARCA. Revisá internet.');
    throw e;
  }
  const r = await xml2js.parseStringPromise(res.data, { explicitArray: false });
  // El sobre puede venir con otro prefijo (soap:, soapenv:, s:): se busca el Body sin importar cuál.
  const env = r[Object.keys(r).find(k => /(^|:)Envelope$/.test(k))] || {};
  const body = env[Object.keys(env).find(k => /(^|:)Body$/.test(k))] || {};
  return { 'soap:Envelope': { 'soap:Body': body } };
}
const listaErrores = errores => Array.isArray(errores) ? errores.map(e => `${e.Code}: ${e.Msg}`).join(' | ') : (errores ? `${errores.Code}: ${errores.Msg}` : '');
// Fecha de hoy en Argentina (AAAAMMDD). Antes se usaba la de UTC: después de las 21 h salía la fecha de mañana.
const hoyArgentina = () => new Date(Date.now() - 3 * 3600 * 1000).toISOString().slice(0, 10).replace(/-/g, '');
// Condición frente al IVA del receptor (RG 5616, obligatoria): códigos de ARCA.
const COND_IVA_RECEPTOR = { 'responsable inscripto': 1, 'iva sujeto exento': 4, 'exento': 4, 'consumidor final': 5, 'monotributo': 6, 'responsable monotributo': 6, 'monotributista': 6,
  'sujeto no categorizado': 7, 'proveedor del exterior': 8, 'cliente del exterior': 9, 'iva liberado': 10, 'monotributista social': 13, 'iva no alcanzado': 15 };
const condIvaReceptor = t => COND_IVA_RECEPTOR[String(t || '').trim().toLowerCase()] || 5;

/**
 * Obtiene el último número de comprobante autorizado
 */
async function ultimoComprobante(auth, cuit, ptoVenta, tipoComp, produccion) {
  const soap = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <FECompUltimoAutorizado xmlns="http://ar.gov.afip.dif.FEV1/">
      <Auth><Token>${auth.token}</Token><Sign>${auth.sign}</Sign><Cuit>${cuit}</Cuit></Auth>
      <PtoVta>${ptoVenta}</PtoVta><CbteTipo>${tipoComp}</CbteTipo>
    </FECompUltimoAutorizado>
  </soap:Body>
</soap:Envelope>`;
  const r = await callWSFE(soap, 'FECompUltimoAutorizado', produccion);
  const body = r['soap:Envelope']['soap:Body'];
  const result = body['FECompUltimoAutorizadoResponse']?.['FECompUltimoAutorizadoResult'];
  // Si ARCA devuelve errores (por ejemplo, un punto de venta que no es de Web Services), se avisa en vez de seguir.
  const err = listaErrores(result?.Errors?.Err);
  if (err) throw new Error('ARCA respondió: ' + err);
  return parseInt(result?.CbteNro || '0');
}

/**
 * Solicita CAE a ARCA
 */
async function solicitarCAE(auth, datos, produccion) {
  let {
    cuit, ptoVenta, tipoComp,
    cbteNro, cbteDesde, cbteHasta,
    docTipo, docNro,
    importeTotal, importeNeto, importeIVA,
    condicionIVA, concepto = 1
  } = datos;

  // Factura / Nota C (monotributo): sin IVA discriminado y SIN el bloque AlicIvas (ARCA lo rechaza si se manda).
  const esC = [11, 12, 13].includes(Number(tipoComp));
  if (esC) { importeNeto = importeTotal; importeIVA = 0; }
  // Armar AlicIvas solo si hay IVA
  const alicIvas = esC ? '' : importeIVA > 0 ? `
    <AlicIvas>
      <AlicIva>
        <Id>${TIPO_IVA[21]}</Id>
        <BaseImp>${importeNeto.toFixed(2)}</BaseImp>
        <Importe>${importeIVA.toFixed(2)}</Importe>
      </AlicIva>
    </AlicIvas>` : `<AlicIvas><AlicIva><Id>3</Id><BaseImp>${importeTotal.toFixed(2)}</BaseImp><Importe>0.00</Importe></AlicIva></AlicIvas>`;

  const fechaCbte = hoyArgentina();

  const soap = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <FECAESolicitar xmlns="http://ar.gov.afip.dif.FEV1/">
      <Auth>
        <Token>${auth.token}</Token>
        <Sign>${auth.sign}</Sign>
        <Cuit>${cuit}</Cuit>
      </Auth>
      <FeCAEReq>
        <FeCabReq>
          <CantReg>1</CantReg>
          <PtoVta>${ptoVenta}</PtoVta>
          <CbteTipo>${tipoComp}</CbteTipo>
        </FeCabReq>
        <FeDetReq>
          <FECAEDetRequest>
            <Concepto>${concepto}</Concepto>
            <DocTipo>${docTipo}</DocTipo>
            <DocNro>${docNro}</DocNro>
            <CbteDesde>${cbteDesde}</CbteDesde>
            <CbteHasta>${cbteHasta}</CbteHasta>
            <CbteFch>${fechaCbte}</CbteFch>
            <ImpTotal>${importeTotal.toFixed(2)}</ImpTotal>
            <ImpTotConc>0.00</ImpTotConc>
            <ImpNeto>${importeNeto.toFixed(2)}</ImpNeto>
            <ImpOpEx>0.00</ImpOpEx>
            <ImpIVA>${importeIVA.toFixed(2)}</ImpIVA>
            <ImpTrib>0.00</ImpTrib>
            <MonId>PES</MonId>
            <MonCotiz>1</MonCotiz>
            <CondicionIVAReceptorId>${condIvaReceptor(condicionIVA)}</CondicionIVAReceptorId>
            ${alicIvas}
          </FECAEDetRequest>
        </FeDetReq>
      </FeCAEReq>
    </FECAESolicitar>
  </soap:Body>
</soap:Envelope>`;

  const r = await callWSFE(soap, 'FECAESolicitar', produccion);
  const body = r['soap:Envelope']['soap:Body'];
  const result = body['FECAESolicitarResponse']?.['FECAESolicitarResult'];
  const det = result?.FeDetResp?.FECAEDetResponse;
  const errores = result?.Errors?.Err;

  if (det?.Resultado === 'A') {
    return {
      ok: true,
      cae: det.CAE,
      vencimientoCAE: det.CAEFchVto,
      resultado: 'Aprobado'
    };
  } else {
    // Las observaciones (Obs) explican por qué ARCA rechazó el comprobante: se suman al mensaje.
    const obs = det?.Observaciones?.Obs;
    const err = [listaErrores(errores), listaErrores(obs)].filter(Boolean).join(' | ') || 'ARCA no aprobó el comprobante (sin detalle)';
    return { ok: false, error: err };
  }
}

/**
 * 1.6.4: consulta un comprobante ya autorizado en ARCA (para recuperar un CAE que se pidió pero no se guardó).
 * Devuelve null si ARCA no lo tiene.
 */
async function consultarComprobante(auth, cuit, ptoVenta, tipoComp, nro, produccion) {
  const soap = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <FECompConsultar xmlns="http://ar.gov.afip.dif.FEV1/">
      <Auth><Token>${auth.token}</Token><Sign>${auth.sign}</Sign><Cuit>${cuit}</Cuit></Auth>
      <FeCompConsReq><CbteTipo>${tipoComp}</CbteTipo><CbteNro>${nro}</CbteNro><PtoVta>${ptoVenta}</PtoVta></FeCompConsReq>
    </FECompConsultar>
  </soap:Body>
</soap:Envelope>`;
  const r = await callWSFE(soap, 'FECompConsultar', produccion);
  const g = r['soap:Envelope']['soap:Body']['FECompConsultarResponse']?.['FECompConsultarResult']?.ResultGet;
  if (!g || !g.CodAutorizacion) return null;
  return { nro: parseInt(g.CbteDesde || nro), cae: String(g.CodAutorizacion), vencimientoCAE: String(g.FchVto || ''), total: parseFloat(g.ImpTotal || '0'),
    docTipo: parseInt(g.DocTipo || '0'), docNro: parseInt(g.DocNro || '0'), fecha: String(g.CbteFch || ''), resultado: g.Resultado };
}

/**
 * Verifica estado del servidor ARCA
 */
async function serverStatus(auth, cuit, produccion) {
  const soap = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <FEDummy xmlns="http://ar.gov.afip.dif.FEV1/"></FEDummy>
  </soap:Body>
</soap:Envelope>`;
  try {
    const r = await callWSFE(soap, 'FEDummy', produccion);
    const body = r['soap:Envelope']['soap:Body'];
    const result = body['FEDummyResponse']?.['FEDummyResult'];
    return { ok: true, appserver: result?.AppServer, dbserver: result?.DbServer, authserver: result?.AuthServer };
  } catch(e) {
    return { ok: false, error: e.message };
  }
}

module.exports = { solicitarCAE, ultimoComprobante, consultarComprobante, serverStatus, TIPO_COMP, TIPO_DOC, hoyArgentina, condIvaReceptor, AGENTE_ARCA };
