// ─── WSFE — Web Service de Facturación Electrónica ARCA/AFIP ─────────────────
const axios  = require('axios');
const xml2js = require('xml2js');

const WSFE_URL_PROD = 'https://servicios1.afip.gov.ar/wsfev1/service.asmx';
const WSFE_URL_TEST = 'https://wswhomo.afip.gov.ar/wsfev1/service.asmx';

const TIPO_COMP = {
  'factura_c_monotributo': 11,
  'factura_b':              6,
  'factura_a':              1,
  'nota_credito_a':         3,
  'nota_credito_b':         8,
  'nota_credito_c':        13,
  'presupuesto':            0  // No va a ARCA
};

const TIPO_DOC = { 'CUIT':80, 'CUIL':86, 'DNI':96, 'Pasaporte':94, 'SinDoc':99 };
const TIPO_IVA = { 21: 5, 10.5: 4, 27: 6, 0: 3 };

async function callWSFE(soap, accion, produccion) {
  const url = produccion ? WSFE_URL_PROD : WSFE_URL_TEST;
  const res = await axios.post(url, soap, {
    headers: {
      'Content-Type': 'text/xml; charset=UTF-8',
      'SOAPAction': `http://ar.gov.afip.dif.FEV1/${accion}`
    },
    timeout: 30000
  });
  return await xml2js.parseStringPromise(res.data, { explicitArray: false });
}

/**
 * Obtiene el último número de comprobante autorizado
 */
async function ultimoComprobante(auth, cuit, ptoVenta, tipoComp, produccion) {
  const soap = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <FECompUltimoAutorizado xmlns="http://ar.gov.afip.dif.FEV1/">
      <Auth><Token>${auth.token}</Token><Sign>${auth.sign}</Sign><Cuit>${cuit}</Cuit></Auth>
      <PtoVta>${ptoVenta}</PtoVta><CbteTipo>${tipoComp}</CbteTipo>
    </FECompUltimoAutorizado>
  </soap:Body>
</soap:Envelope>`;
  const r = await callWSFE(soap, 'FECompUltimoAutorizado', produccion);
  const body = r['soap:Envelope']['soap:Body'];
  const result = body['FECompUltimoAutorizadoResponse']?.['FECompUltimoAutorizadoResult'];
  return parseInt(result?.CbteNro || '0');
}

/**
 * Solicita CAE a ARCA
 */
async function solicitarCAE(auth, datos, produccion) {
  const {
    cuit, ptoVenta, tipoComp,
    cbteNro, cbteDesde, cbteHasta,
    docTipo, docNro,
    importeTotal, importeNeto, importeIVA,
    condicionIVA, concepto = 1
  } = datos;

  // Armar AlicIvas solo si hay IVA
  const alicIvas = importeIVA > 0 ? `
    <AlicIvas>
      <AlicIva>
        <Id>${TIPO_IVA[21]}</Id>
        <BaseImp>${importeNeto.toFixed(2)}</BaseImp>
        <Importe>${importeIVA.toFixed(2)}</Importe>
      </AlicIva>
    </AlicIvas>` : `<AlicIvas><AlicIva><Id>3</Id><BaseImp>${importeTotal.toFixed(2)}</BaseImp><Importe>0.00</Importe></AlicIva></AlicIvas>`;

  const fechaCbte = new Date().toISOString().slice(0,10).replace(/-/g,'');

  const soap = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <FECAESolicitar xmlns="http://ar.gov.afip.dif.FEV1/">
      <Auth>
        <Token>${auth.token}</Token>
        <Sign>${auth.sign}</Sign>
        <Cuit>${cuit}</Cuit>
      </Auth>
      <FeCAEReq>
        <FeCabReq>
          <CantReg>1</CantReg>
          <PtoVta>${ptoVenta}</PtoVta>
          <CbteTipo>${tipoComp}</CbteTipo>
        </FeCabReq>
        <FeDetReq>
          <FECAEDetRequest>
            <Concepto>${concepto}</Concepto>
            <DocTipo>${docTipo}</DocTipo>
            <DocNro>${docNro}</DocNro>
            <CbteDesde>${cbteDesde}</CbteDesde>
            <CbteHasta>${cbteHasta}</CbteHasta>
            <CbteFch>${fechaCbte}</CbteFch>
            <ImpTotal>${importeTotal.toFixed(2)}</ImpTotal>
            <ImpTotConc>0.00</ImpTotConc>
            <ImpNeto>${importeNeto.toFixed(2)}</ImpNeto>
            <ImpOpEx>0.00</ImpOpEx>
            <ImpIVA>${importeIVA.toFixed(2)}</ImpIVA>
            <ImpTrib>0.00</ImpTrib>
            <MonId>PES</MonId>
            <MonCotiz>1</MonCotiz>
            ${alicIvas}
          </FECAEDetRequest>
        </FeDetReq>
      </FeCAEReq>
    </FECAESolicitar>
  </soap:Body>
</soap:Envelope>`;

  const r = await callWSFE(soap, 'FECAESolicitar', produccion);
  const body = r['soap:Envelope']['soap:Body'];
  const result = body['FECAESolicitarResponse']?.['FECAESolicitarResult'];
  const det = result?.FeDetResp?.FECAEDetResponse;
  const errores = result?.Errors?.Err;

  if (det?.Resultado === 'A') {
    return {
      ok: true,
      cae: det.CAE,
      vencimientoCAE: det.CAEFchVto,
      resultado: 'Aprobado'
    };
  } else {
    const err = Array.isArray(errores) ? errores.map(e=>`${e.Code}: ${e.Msg}`).join(' | ') : (errores ? `${errores.Code}: ${errores.Msg}` : 'Error desconocido');
    return { ok: false, error: err };
  }
}

/**
 * Verifica estado del servidor ARCA
 */
async function serverStatus(auth, cuit, produccion) {
  const soap = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <FEDummy xmlns="http://ar.gov.afip.dif.FEV1/"></FEDummy>
  </soap:Body>
</soap:Envelope>`;
  try {
    const r = await callWSFE(soap, 'FEDummy', produccion);
    const body = r['soap:Envelope']['soap:Body'];
    const result = body['FEDummyResponse']?.['FEDummyResult'];
    return { ok: true, appserver: result?.AppServer, dbserver: result?.DbServer, authserver: result?.AuthServer };
  } catch(e) {
    return { ok: false, error: e.message };
  }
}

module.exports = { solicitarCAE, ultimoComprobante, serverStatus, TIPO_COMP, TIPO_DOC };
