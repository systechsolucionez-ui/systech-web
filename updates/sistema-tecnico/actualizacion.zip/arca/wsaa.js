// ─── WSAA — Web Service de Autenticación y Autorización ARCA/AFIP ─────────────
const forge  = require('node-forge');
const axios  = require('axios');
const xml2js = require('xml2js');
const fs     = require('fs');
const path   = require('path');

// URLs ARCA
const WSAA_URL_PROD = 'https://wsaa.afip.gov.ar/ws/services/LoginCms';
const WSAA_URL_TEST = 'https://wsaahomo.afip.gov.ar/ws/services/LoginCms';

// Cache token en memoria
let tokenCache = {};

/**
 * Genera el CMS (Cryptographic Message Syntax) firmado para WSAA
 */
function generarCMS(certPem, keyPem, servicio) {
  const ahora    = new Date();
  const desde    = new Date(ahora.getTime() - 60000);   // -1 min
  const hasta    = new Date(ahora.getTime() + 600000);  // +10 min

  const formatDate = d => d.toISOString().replace(/\.\d+Z$/, '-03:00');

  const tra = `<?xml version="1.0" encoding="UTF-8"?>
<loginTicketRequest version="1.0">
  <header>
    <uniqueId>${Math.floor(Date.now() / 1000)}</uniqueId>
    <generationTime>${formatDate(desde)}</generationTime>
    <expirationTime>${formatDate(hasta)}</expirationTime>
  </header>
  <service>${servicio}</service>
</loginTicketRequest>`;

  // Firmar con la clave privada
  const cert = forge.pki.certificateFromPem(certPem);
  const key  = forge.pki.privateKeyFromPem(keyPem);
  const p7   = forge.pkcs7.createSignedData();
  p7.content = forge.util.createBuffer(tra, 'utf8');
  p7.addCertificate(cert);
  p7.addSigner({
    key,
    certificate: cert,
    digestAlgorithm: forge.pki.oids.sha256,
    authenticatedAttributes: [
      { type: forge.pki.oids.contentType, value: forge.pki.oids.data },
      { type: forge.pki.oids.messageDigest },
      { type: forge.pki.oids.signingTime, value: ahora }
    ]
  });
  p7.sign();
  const der = forge.asn1.toDer(p7.toAsn1()).getBytes();
  return Buffer.from(der, 'binary').toString('base64');
}

/**
 * Obtiene el token de autenticación de ARCA
 * Lo cachea por 10 minutos
 */
async function obtenerToken(certPem, keyPem, servicio, produccion = false) {
  const cacheKey = `${servicio}_${produccion}`;
  const cached   = tokenCache[cacheKey];
  if (cached && new Date(cached.expiracion) > new Date(Date.now() + 60000)) {
    return cached;
  }

  const cms  = generarCMS(certPem, keyPem, servicio);
  const soap = `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                  xmlns:wsaa="http://wsaa.view.sua.dvadac.desein.afip.gov">
  <soapenv:Body>
    <wsaa:loginCms>
      <wsaa:in0>${cms}</wsaa:in0>
    </wsaa:loginCms>
  </soapenv:Body>
</soapenv:Envelope>`;

  const url = produccion ? WSAA_URL_PROD : WSAA_URL_TEST;
  const res = await axios.post(url, soap, {
    headers: { 'Content-Type': 'text/xml; charset=UTF-8', 'SOAPAction': '' },
    timeout: 30000
  });

  const parsed = await xml2js.parseStringPromise(res.data, { explicitArray: false });
  const loginTicket = parsed['soapenv:Envelope']['soapenv:Body']['loginCmsReturn'] ||
                      parsed['soapenv:Envelope']['soapenv:Body']['ns1:loginCmsResponse']?.['ns1:loginCmsReturn'] ||
                      Object.values(Object.values(parsed['soapenv:Envelope']['soapenv:Body'])[0])[0];

  const ticket = await xml2js.parseStringPromise(loginTicket, { explicitArray: false });
  const header = ticket.loginTicketResponse.header;
  const creds  = ticket.loginTicketResponse.credentials;

  const result = {
    token:      creds.token,
    sign:       creds.sign,
    expiracion: header.expirationTime
  };
  tokenCache[cacheKey] = result;
  return result;
}

module.exports = { obtenerToken };
