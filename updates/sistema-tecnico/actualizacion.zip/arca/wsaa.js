// ─── WSAA — Web Service de Autenticación y Autorización ARCA/AFIP ─────────────
// Pide el "ticket de acceso" (token + sign) con el certificado del contribuyente.
//
// Correcciones 1.6.1:
//  - La hora del pedido iba 3 horas adelantada (se ponía la hora UTC con "-03:00") y ARCA lo
//    rechazaba ("generationTime posterior a la hora actual"). Ahora va la hora de Argentina real.
//  - El ticket dura 12 h y ARCA no da otro mientras el anterior siga vigente ("ya posee un TA
//    válido"). Se guarda en disco (arca/certs/ta/) para que reiniciar el programa no lo pierda.
//  - Cada certificado tiene su propio ticket (antes, en el servidor central, dos talleres con
//    distinto CUIT compartían el mismo).
//  - Los errores de ARCA llegan con su mensaje real, en vez de "Request failed with status code 500".
const forge  = require('node-forge');
const axios  = require('axios');
const xml2js = require('xml2js');
const fs     = require('fs');
const path   = require('path');
const crypto = require('crypto');

// URLs ARCA
const WSAA_URL_PROD = 'https://wsaa.afip.gov.ar/ws/services/LoginCms';
const WSAA_URL_TEST = 'https://wsaahomo.afip.gov.ar/ws/services/LoginCms';

// Tickets: en memoria y en disco (por certificado, servicio y ambiente)
const tokenCache = {};
const TA_DIR = path.join(__dirname, 'certs', 'ta');

// Hora de Argentina (UTC-3, sin horario de verano) en el formato que pide ARCA: 2026-10-28T14:40:00-03:00
function horaArgentina(d) {
  return new Date(d.getTime() - 3 * 3600 * 1000).toISOString().replace(/\.\d+Z$/, '-03:00');
}

const huellaCert = certPem => crypto.createHash('sha256').update(String(certPem).replace(/\s+/g, '')).digest('hex').slice(0, 16);

function leerTA(archivo) {
  try { return JSON.parse(fs.readFileSync(archivo, 'utf8')); } catch (e) { return null; }
}
function guardarTA(archivo, ta) {
  try { fs.mkdirSync(TA_DIR, { recursive: true }); fs.writeFileSync(archivo, JSON.stringify(ta), { mode: 0o600 }); } catch (e) { /* sin disco: queda en memoria */ }
}
const vigente = ta => ta && ta.token && ta.sign && new Date(ta.expiracion).getTime() > Date.now() + 5 * 60 * 1000;

/** Genera el CMS (Cryptographic Message Syntax) firmado para WSAA */
function generarCMS(certPem, keyPem, servicio) {
  const ahora = new Date();
  const desde = new Date(ahora.getTime() - 5 * 60000);    // −5 min (margen por relojes desfasados)
  const hasta = new Date(ahora.getTime() + 10 * 60000);   // +10 min

  const tra = `<?xml version="1.0" encoding="UTF-8"?>
<loginTicketRequest version="1.0">
  <header>
    <uniqueId>${Math.floor(Date.now() / 1000)}</uniqueId>
    <generationTime>${horaArgentina(desde)}</generationTime>
    <expirationTime>${horaArgentina(hasta)}</expirationTime>
  </header>
  <service>${servicio}</service>
</loginTicketRequest>`;

  let cert, key;
  try { cert = forge.pki.certificateFromPem(certPem); } catch (e) { throw new Error('El certificado (.crt) no es válido. Descargalo de nuevo de ARCA.'); }
  try { key = forge.pki.privateKeyFromPem(keyPem); } catch (e) { throw new Error('La clave privada (.key) no es válida o tiene contraseña.'); }
  if (cert.publicKey.n.compareTo(key.n) !== 0) throw new Error('El certificado (.crt) no corresponde a esta clave privada (.key). Subí el par que generaste juntos.');
  if (cert.validity.notAfter < ahora) throw new Error('El certificado de ARCA está vencido (venció el ' + cert.validity.notAfter.toLocaleDateString('es-AR') + '). Generá uno nuevo.');

  const p7 = forge.pkcs7.createSignedData();
  p7.content = forge.util.createBuffer(tra, 'utf8');
  p7.addCertificate(cert);
  p7.addSigner({
    key,
    certificate: cert,
    digestAlgorithm: forge.pki.oids.sha256,
    authenticatedAttributes: [
      { type: forge.pki.oids.contentType, value: forge.pki.oids.data },
      { type: forge.pki.oids.messageDigest },
      { type: forge.pki.oids.signingTime, value: ahora }
    ]
  });
  p7.sign();
  const der = forge.asn1.toDer(p7.toAsn1()).getBytes();
  return Buffer.from(der, 'binary').toString('base64');
}

/** Mensaje claro a partir de un error SOAP de ARCA */
async function mensajeError(e) {
  const xml = e && e.response && e.response.data;
  if (typeof xml === 'string' && xml.includes('faultstring')) {
    try {
      const m = xml.match(/<faultstring>([\s\S]*?)<\/faultstring>/);
      const txt = m ? m[1].trim() : '';
      if (/posee un TA valido/i.test(txt)) return 'ARCA ya entregó un permiso a este certificado hace poco y todavía no venció. Esperá unos minutos (hasta 12 h si se perdió) y probá de nuevo.';
      if (/Computador no autorizado|no autorizado a acceder/i.test(txt)) return 'El certificado no está autorizado para "Facturación Electrónica". En ARCA: Administrador de Relaciones de Clave Fiscal → Nueva relación → Web Services → Facturación Electrónica, y elegí este alias.';
      if (/generationTime|expirationTime/i.test(txt)) return 'ARCA rechazó la hora del pedido. Revisá que la fecha y hora de esta computadora sean correctas (zona horaria de Argentina). Detalle: ' + txt;
      if (/Certificado.*(expirado|no emitido|revocado)|cms.cert/i.test(txt)) return 'ARCA no acepta el certificado: ' + txt + '. Si estás en Homologación usá un certificado de homologación; en Producción, uno de producción.';
      return 'ARCA respondió: ' + txt;
    } catch (x) { /* sigue */ }
  }
  if (e && (e.code === 'ECONNABORTED' || e.code === 'ETIMEDOUT')) return 'ARCA no respondió a tiempo. Probá de nuevo en unos minutos.';
  if (e && (e.code === 'ENOTFOUND' || e.code === 'ECONNREFUSED' || e.code === 'EAI_AGAIN')) return 'No hay conexión con los servidores de ARCA. Revisá internet.';
  return (e && e.message) || 'Error desconocido al conectar con ARCA';
}

/** Saca el loginTicketResponse (XML escapado) de la respuesta SOAP de loginCms, con o sin prefijos. */
function extraerTicket(data) {
  const s = String(data || '');
  const m = s.match(/<(?:[\w-]+:)?loginCmsReturn[^>]*>([\s\S]*?)<\/(?:[\w-]+:)?loginCmsReturn>/);
  if (!m) return null;
  let t = m[1].trim();
  if (t.startsWith('<![CDATA[')) t = t.slice(9, -3);
  return t.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#13;/g, '').replace(/&amp;/g, '&');
}

/**
 * Obtiene el ticket de acceso de ARCA (token + sign). Lo reutiliza mientras esté vigente
 * (ARCA lo da por 12 h), en memoria y en disco.
 */
async function obtenerToken(certPem, keyPem, servicio, produccion = false) {
  const clave = `${huellaCert(certPem)}-${servicio}-${produccion ? 'prod' : 'homo'}`;
  const archivo = path.join(TA_DIR, `ta-${clave}.json`);
  if (vigente(tokenCache[clave])) return tokenCache[clave];
  const enDisco = leerTA(archivo);
  if (vigente(enDisco)) { tokenCache[clave] = enDisco; return enDisco; }

  const cms  = generarCMS(certPem, keyPem, servicio);
  const soap = `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                  xmlns:wsaa="http://wsaa.view.sua.dvadac.desein.afip.gov">
  <soapenv:Body>
    <wsaa:loginCms>
      <wsaa:in0>${cms}</wsaa:in0>
    </wsaa:loginCms>
  </soapenv:Body>
</soapenv:Envelope>`;

  const url = produccion ? WSAA_URL_PROD : WSAA_URL_TEST;
  let res;
  try {
    res = await axios.post(url, soap, {
      headers: { 'Content-Type': 'text/xml; charset=UTF-8', 'SOAPAction': '' },
      timeout: 30000
    });
  } catch (e) {
    throw new Error(await mensajeError(e));
  }

  // 1.6.2: el ticket se saca directo del texto de la respuesta. Antes se buscaba dentro del objeto y, como
  // ARCA manda <loginCmsResponse xmlns="…">, se tomaba el atributo xmlns en lugar del ticket
  // ("Non-whitespace before first tag … Char: [").
  const loginTicket = extraerTicket(res.data);
  if (!loginTicket) throw new Error('ARCA respondió algo que no es un ticket de acceso. Probá de nuevo en unos minutos.');

  const ticket = await xml2js.parseStringPromise(loginTicket, { explicitArray: false });
  const header = ticket.loginTicketResponse.header;
  const creds  = ticket.loginTicketResponse.credentials;

  const result = {
    token:      creds.token,
    sign:       creds.sign,
    expiracion: header.expirationTime
  };
  tokenCache[clave] = result;
  guardarTA(archivo, result);
  return result;
}

module.exports = { obtenerToken, horaArgentina, extraerTicket };
