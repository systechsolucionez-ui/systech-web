@echo off
cd /d "%~dp0"
echo Iniciando SysTech...
node server.js
pause
