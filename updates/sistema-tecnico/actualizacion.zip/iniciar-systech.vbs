Set WshShell = CreateObject("WScript.Shell")
strPath = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
WshShell.CurrentDirectory = strPath
WshShell.Run "cmd /c node server.js", 0, False
WScript.Sleep 2500
WshShell.Run "http://localhost:3000", 1, False
