// Uso: node resetear-admin.js NuevaClave123
// Cambia la contraseña del usuario "admin" y le exige elegir otra al entrar.
const fs = require('fs'), path = require('path');
const Database = require('better-sqlite3');
const seguridad = require('./seguridad');
const nueva = process.argv[2];
if (!nueva) { console.log('Uso: node resetear-admin.js NuevaClave123'); process.exit(1); }
const err = seguridad.validarPasswordNueva(nueva);
if (err) { console.log('❌', err); process.exit(1); }
const dir = path.join(__dirname, 'data');
const bases = fs.readdirSync(dir).filter(f => /^taller_.*\.db$/.test(f));
if (!bases.length) { console.log('No encontré bases taller_*.db en', dir); process.exit(1); }
for (const f of bases) {
  const db = new Database(path.join(dir, f));
  try {
    const r = db.prepare("UPDATE usuarios SET password=?, debe_cambiar_password=1 WHERE usuario='admin'").run(seguridad.hashPassword(nueva));
    console.log(f, r.changes ? '✅ admin actualizado' : '— sin usuario admin');
  } catch (e) { console.log(f, '⚠️', e.message); }
  db.close();
}
console.log('Listo. Entrá con admin /', nueva, '(te pedirá cambiarla).');
