// ============================================================
// QUÉ INCLUYE ESTE CLIENTE — una sola fuente de verdad.
//
// Dos orígenes posibles, mismo resultado:
//   · Instalación local (.exe): sale del CÓDIGO DE ACTIVACIÓN firmado (licencia.js).
//   · Hosting (servidor de SysTech): sale del registro del negocio (tabla talleres).
//
// Devuelve siempre la misma forma:
//   { fuente, plan, modulos:{taller,tienda}, limiteSucursales,
//     addons:{tecnibot,imei,ia}, vence, vencido }
//
// IMPORTANTE: esto solo INFORMA. Quién corta el acceso a un módulo es el servidor
// (requiereModulo), nunca el menú: ocultar un botón no protege nada.
// ============================================================
const fs = require('fs');
const path = require('path');
const licencia = require('./licencia');

const SUCURSALES_BASE = 2;            // incluidas en todos los planes
const SUCURSALES_MAX_PAQUETES = 6;    // más de esto se arma a medida

function nombrePlan(taller, tienda) {
  if (taller && tienda) return 'taller_tienda';
  if (taller) return 'solo_taller';
  if (tienda) return 'solo_tienda';
  return 'sin_modulos';
}
const ETIQUETAS = {
  taller_tienda: 'Taller + Tienda',
  solo_taller: 'Solo Taller',
  solo_tienda: 'Solo Tienda',
  sin_modulos: 'Sin módulos',
};

let _cache = { clave: null, valor: null };
function licenciaCacheada() {
  // Lee el archivo de licencia solo cuando cambia (se consulta en cada pedido a la API).
  let clave = 'sin-archivo';
  try { const st = fs.statSync(path.join(__dirname, 'licencia.local.json')); clave = st.mtimeMs + ':' + st.size; } catch (e) {}
  if (_cache.clave !== clave) _cache = { clave, valor: licencia.leerLicenciaActual() };
  return _cache.valor;
}

// ── RELOJ PROTEGIDO (instalación local) ─────────────────────────────────────
// Sin internet la fecha la da el reloj de la PC. Para que atrasarlo no sirva para "estirar" una licencia,
// se recuerda la última fecha vista: si el reloj retrocede más de un día, se usa la última vista.
// No es infalible (borrar el archivo lo reinicia), pero frena el truco simple.
const ARCHIVO_RELOJ = path.join(__dirname, 'data', 'reloj.json');
let _reloj = { vista: null, cargado: false };
function hoyEfectivo() {
  const real = hoyLocal();
  if (!_reloj.cargado) {
    _reloj.cargado = true;
    try { _reloj.vista = JSON.parse(fs.readFileSync(ARCHIVO_RELOJ, 'utf8')).vista || null; } catch (e) {}
  }
  const vista = _reloj.vista;
  if (vista && real < vista && diasEntre(real, vista) > 1) return { hoy: vista, relojAtrasado: true };
  // Se registra el avance, ignorando saltos absurdos hacia adelante (reloj mal puesto por error)
  if (!vista || (real > vista && diasEntre(vista, real) <= 400)) {
    _reloj.vista = real;
    try { if (fs.existsSync(path.dirname(ARCHIVO_RELOJ))) fs.writeFileSync(ARCHIVO_RELOJ, JSON.stringify({ vista: real })); } catch (e) {}
  }
  return { hoy: real, relojAtrasado: false };
}
const venceYa = (f, hoy) => !!f && String(f).slice(0, 10) < hoy;

function desdeLicencia() {
  const lic = licenciaCacheada();
  if (!lic) return { activado: false, fuente: 'licencia', plan: 'sin_modulos', etiqueta: ETIQUETAS.sin_modulos,
    modulos: { taller: false, tienda: false }, limiteSucursales: 0, addons: { tecnibot: false, imei: false, ia: false }, vence: null, vencido: false,
    ...estadoVencimiento(null) };
  // Una licencia vieja (anterior a los planes) que no trae ninguna de las dos banderas conserva todo lo que tenía.
  const sinBanderas = lic.taller === undefined && lic.tienda === undefined;
  const taller = sinBanderas ? true : !!lic.taller, tienda = sinBanderas ? true : !!lic.tienda;
  const plan = nombrePlan(taller, tienda);
  const { hoy, relojAtrasado } = hoyEfectivo();
  const vence = lic.vence || null;
  // Cada complemento vence por separado: apagar uno no toca la base ni los otros.
  const tecnibot = !!lic.tecnibot && !venceYa(lic.tecnibotHasta, hoy);
  // "ia" = AsystenBot (asistente administrativo). Es un complemento APARTE de Tecnibot: solo lo trae un código con ia=si.
  const ia = !!lic.ia && !venceYa(lic.iaHasta, hoy);
  return {
    activado: true, fuente: 'licencia', plan, etiqueta: ETIQUETAS[plan],
    modulos: { taller, tienda },
    limiteSucursales: lic.limiteSucursales || 1, // sale SOLO del código firmado (el archivo local se puede editar)
    addons: { tecnibot, imei: false, ia },
    addonsVence: { tecnibot: lic.tecnibotHasta || null, ia: lic.iaHasta || null },
    actualizacionesHasta: lic.actualizacionesHasta || null,
    relojAtrasado,
    vence, vencido: venceYa(vence, hoy),
    ...estadoVencimiento(vence, hoy),
  };
}

// Hosting: un complemento está activo si está habilitado y su fecha no pasó (sin fecha = no vence, como siempre).
function tecnibotTaller(t) { return !!t && t.tecnibot_habilitado === 1 && !venceYa(t.tecnibot_vence, hoyLocal()); }
function iaTaller(t) { return !!t && t.ia_habilitada === 1 && !venceYa(t.ia_vence, hoyLocal()); }

function desdeTaller(t) {
  // Un registro anterior a los planes (sin las columnas nuevas) sigue funcionando igual que siempre: todo incluido.
  const taller = t.modulo_taller === null || t.modulo_taller === undefined ? true : t.modulo_taller === 1;
  const tienda = t.modulo_tienda === null || t.modulo_tienda === undefined ? true : t.modulo_tienda === 1;
  const plan = nombrePlan(taller, tienda);
  const vence = t.fecha_vencimiento || null;
  return {
    activado: true, fuente: 'hosting', plan, etiqueta: ETIQUETAS[plan],
    modulos: { taller, tienda },
    limiteSucursales: Number.isInteger(t.limite_sucursales) ? t.limite_sucursales : SUCURSALES_BASE,
    addons: { tecnibot: tecnibotTaller(t), imei: t.imei_habilitado === 1 || Number(t.imei_saldo) > 0, ia: iaTaller(t) },
    addonsVence: { tecnibot: t.tecnibot_vence || null, ia: t.ia_vence || null },
    imeiSaldo: Number(t.imei_saldo) || 0,
    vence, vencido: !!(vence && String(vence).slice(0, 10) < hoyLocal()),
    ...estadoVencimiento(vence),
  };
}

// ── VENCIMIENTO (solo hosting) ───────────────────────────────────────────────
// Cuando la suscripción vence el sistema NO se apaga ni borra nada:
//   vigente → por_vencer (7 días) → gracia (GRACIA_DIAS, sigue todo igual con aviso) → solo_lectura
// En solo lectura se puede entrar, ver y exportar todo; no se puede crear ni modificar.
const _g = parseInt(process.env.SYSTECH_GRACIA_DIAS, 10);
const GRACIA_DIAS = Number.isInteger(_g) && _g >= 0 ? _g : 5;
function hoyLocal() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function diasEntre(desde, hasta) {            // fechas 'AAAA-MM-DD'; resultado entero
  const a = Date.UTC(+desde.slice(0, 4), +desde.slice(5, 7) - 1, +desde.slice(8, 10));
  const b = Date.UTC(+hasta.slice(0, 4), +hasta.slice(5, 7) - 1, +hasta.slice(8, 10));
  return Math.round((b - a) / 86400000);
}
function estadoVencimiento(vence, hoy) {
  if (!vence) return { estadoVenc: 'sin_vencimiento', diasRestantes: null, graciaDias: GRACIA_DIAS, graciaHasta: null, soloLectura: false };
  const dias = diasEntre(hoy || hoyLocal(), String(vence).slice(0, 10));
  let estadoVenc = 'vigente';
  if (dias < 0) estadoVenc = (-dias) <= GRACIA_DIAS ? 'gracia' : 'solo_lectura';
  else if (dias <= 7) estadoVenc = 'por_vencer';
  const d = new Date(String(vence).slice(0, 10) + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + GRACIA_DIAS);
  return { estadoVenc, diasRestantes: dias, graciaDias: GRACIA_DIAS, graciaHasta: d.toISOString().slice(0, 10), soloLectura: estadoVenc === 'solo_lectura' };
}

// Rutas que siguen funcionando en solo lectura (entrar, salir, cambiar la clave)
// Comprar / renovar tiene que funcionar justamente cuando está vencido.
const RUTAS_LIBRES_VENCIDO = ['/api/login', '/api/logout', '/api/cambiar-password', '/api/licencia/activar', '/api/compras/orden', '/api/compras/debito', '/api/compras/sincronizar'];
/** Suscripción vencida más allá de la gracia: el servidor rechaza todo lo que escribe. Lo que lee sigue igual. */
function soloLecturaVencido(modoDistribuidor) {
  return (req, res, next) => {
    if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') return next();
    let lectura;
    if (modoDistribuidor) {
      if (!req.tenant) return next();
      lectura = estadoVencimiento(req.tenant.fecha_vencimiento || null).soloLectura;
    } else {
      lectura = desdeLicencia().soloLectura;   // instalación local: sale del código de activación
    }
    if (!lectura) return next();
    if (RUTAS_LIBRES_VENCIDO.includes((req.baseUrl || '') + req.path)) return next();
    res.status(402).json({ error: 'La licencia de este sistema venció: está en modo solo lectura. Podés consultar y exportar todo, pero no cargar ni modificar. Para renovar, pegá el código nuevo en Configuración → Sistema o contactá a SysTech.', suscripcion_vencida: true });
  };
}

/** req.tenant viene del tenantMiddleware. modoDistribuidor = este servidor es el hosting de SysTech. */
function queIncluye(req, modoDistribuidor) {
  if (modoDistribuidor && req && req.tenant) return desdeTaller(req.tenant);
  return desdeLicencia();
}

/** Middleware (todavía sin usar: se aplica en la etapa de módulos). */
function requiereModulo(modulo, modoDistribuidor) {
  return (req, res, next) => {
    const p = queIncluye(req, modoDistribuidor);
    if (p.modulos[modulo]) return next();
    res.status(402).json({ error: `Tu plan (${p.etiqueta}) no incluye este módulo. Contactá a SysTech para sumarlo.`, modulo_no_incluido: modulo });
  };
}

// Rutas de SERVICIO TÉCNICO: solo existen si el plan incluye el módulo Taller.
const RUTAS_TALLER = [
  '/api/ordenes', '/api/estados-orden', '/api/gremios', '/api/garantia-causas', '/api/comisiones', '/api/liquidacion', '/api/liquidaciones',
  '/api/mis-reparaciones', '/api/tecnicos', '/api/envios-equipos', '/api/cobros-pendientes', '/api/garantia',
  '/api/facturar-orden', '/api/print/orden', '/api/export/ordenes', '/api/export/herramientas', '/api/herramientas',
  '/api/recursos', '/api/tecnibot', '/api/cliente', '/api/automatizacion',
];
function esRutaTaller(ruta) {
  return RUTAS_TALLER.some(r => ruta === r || ruta.startsWith(r + '/'));
}

/** Cierra en el SERVIDOR todo lo de servicio técnico para los planes que no lo incluyen. Con el módulo incluido no hace nada. */
function gateModulos(modoDistribuidor) {
  return (req, res, next) => {
    if (!esRutaTaller((req.baseUrl || '') + req.path)) return next();
    if (!req.tenant && modoDistribuidor) return next();      // sin negocio resuelto lo maneja otro middleware
    const p = queIncluye(req, modoDistribuidor);
    if (!p.activado || p.modulos.taller) return next();      // sin activar: lo maneja la pantalla de activación
    res.status(402).json({ error: `Tu plan (${p.etiqueta}) no incluye el servicio técnico.`, modulo_no_incluido: 'taller' });
  };
}

module.exports = {
  soloLecturaVencido, estadoVencimiento, desdeTaller, desdeLicencia, hoyEfectivo, GRACIA_DIAS, hoyLocal, diasEntre,
  gateModulos, esRutaTaller, RUTAS_TALLER, tecnibotTaller, iaTaller, queIncluye, requiereModulo, nombrePlan, ETIQUETAS, SUCURSALES_BASE, SUCURSALES_MAX_PAQUETES };
