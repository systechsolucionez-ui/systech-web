@echo off
cd /d "%~dp0"
if exist "%~dp0runtime\node\node.exe" set "PATH=%~dp0runtime\node;%PATH%"
if exist puerto.txt set /p PORT=<puerto.txt
set SYSTECH_REINICIO_AUTO=1
echo [%date% %time%] Iniciando SysTech > server-log.txt
:arrancar
node server.js >> server-log.txt 2>&1
rem Codigo 75 = el sistema pidio reiniciarse (por ejemplo, tras instalar una actualizacion)
if %errorlevel%==75 (
  echo [%date% %time%] Reiniciando con la nueva version >> server-log.txt
  ping -n 3 127.0.0.1 >nul
  goto arrancar
)
echo [%date% %time%] SysTech se detuvo (codigo %errorlevel%) >> server-log.txt
