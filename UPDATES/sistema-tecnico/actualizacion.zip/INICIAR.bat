@echo off
title SysTech - Sistema de Tienda y Taller
cd /d "%~dp0"

if not exist "node_modules\" (
  echo Primera vez arrancando el sistema, instalando lo necesario...
  echo Esto puede tardar 1-2 minutos. No cierres esta ventana.
  echo.
  call npm install
  if errorlevel 1 (
    echo.
    echo ================================================
    echo Hubo un error instalando. Verifica que Node.js
    echo este bien instalado ^(node -v en la terminal^).
    echo ================================================
    pause
    exit /b 1
  )
  echo.
  echo Instalacion lista.
  echo.
)

start http://localhost:3000
timeout /t 2 /nobreak >nul
node server.js

pause
